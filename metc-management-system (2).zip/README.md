# MOUNTEC METC Management System

**Company:** MOUNTEC PTE LTD  
**Version:** 1.0.0  
**Target Domain:** Enterprise Materials, Equipment, Tools & Consumables (METC) Lifecycle & Asset Management

---

## Executive Overview
The **MOUNTEC METC Management System** is an enterprise-grade full-stack platform built specifically for **MOUNTEC PTE LTD** to automate, audit, track, and manage all site materials, heavy machinery/equipment, power tools, safety PPE, and consumables across all project sites, regional depots, and central branches in Singapore and Southeast Asia.

---

## Enterprise Architecture & Module Breakdown

### 1. Core METC Inventory Catalog
* **Materials (M):** Bulk steel, rebar, cement, aggregates, piping, timber, sheet metal with batch numbers, unit costs, min stock thresholds, and location bins.
* **Equipment (E):** Heavy excavators, mobile cranes, boom lifts, generators, scaffolding towers with serial numbers, operating hours, active site assignments, and preventative maintenance schedules.
* **Tools (T):** Power drills, laser levels, angle grinders, pneumatic hammers with barcode/QR tagging, calibration cycles, and custodian worker logs.
* **Consumables & PPE (C):** Drill bits, welding rods, safety helmets, high-vis vests, cut-resistant gloves with auto-reorder triggers and usage allocation.

### 2. Transactional Workflows
* **Issue Workflows:** Multi-item issue vouchers with QR/Barcode scanner integration, signature capture, worker identification verification, and automatic stock deduction.
* **Return Workflows:** Item return vouchers with condition assessment (Good, Minor Wear, Needs Repair, Damaged, Lost), automated repair ticket dispatch, and stock restoration.
* **Transfer Workflows:** Depot-to-Site, Site-to-Site, and Branch-to-Branch logistics transfers with dispatch notes, transit tracking, and recipient sign-off.
* **Maintenance & Repair Workflows:** Scheduled PM orders, break-fix repair ticketing, technician assignments, spare part usage, cost tracking, and SLA escalation alerts.

### 3. Enterprise Administration & Security
* **Company Profile:** UEN/GST Registration (MOUNTEC PTE LTD), HQ Address, Tax rates, Default currency (SGD $), and Branding assets.
* **User & Role Management:** Granular RBAC matrix (Super Admin, Site Manager, Storekeeper, Logistics Officer, Auditor, Worker) with module-level permissions.
* **Branches & Sites Directory:** Physical depot and jobsite registry with geofenced GPS coordinates, site engineers, and capacity limits.
* **Backup & Disaster Recovery:** PostgreSQL / Supabase SQL dump snapshot generation, automated daily/weekly backup schedules, and point-in-time restore verification.
* **Immutable Audit Trail:** Log tracking all authentication, authorization, inventory transactions, policy overrides, and data exports.
* **Infrastructure Telemetry:** Real-time diagnostics for DB ping latency, API response times, node CPU load, and database storage utilization.

### 4. Advanced Reporting & Data Analytics
* **Dashboard Kpis & Real-time Charts:** Total asset valuation, active site deployments, maintenance queue status, stock health, and return compliance rate.
* **Export Engine:** One-click automated export to PDF, Excel (.xlsx), and CSV formats across all data grids.
* **QR & Barcode Utilities:** Custom high-density QR code generation, bulk sticker label generator with print preview, and camera-based live QR/barcode scanner.

---

## Technology Stack

* **Frontend:** React 18, TypeScript 5, Vite, Tailwind CSS, Lucide Icons, Motion (Framer Motion)
* **State Management:** Zustand with persistent hydration
* **Database & BaaS:** Supabase / PostgreSQL v15, Row Level Security (RLS)
* **Exports & Utility:** jsPDF, AutoTable, XLSX (SheetJS), Canvas QR Generator

---

## System Statistics

| Metric | Count |
| :--- | :--- |
| **Total Modules** | 14 Enterprise Modules |
| **Total Pages / Views** | 22 Dedicated Pages |
| **Total Database Tables / Schemas** | 16 PostgreSQL Schema Tables |
| **Total Services & APIs** | 12 Full Service Engines |
| **Total Report Profiles** | 8 Automated Export Reports |
| **Total Security Roles** | 6 Granular RBAC Levels |

---

© 2026 MOUNTEC PTE LTD. All Rights Reserved. Enterprise Asset Management Systems.
