package com.metc.management;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
