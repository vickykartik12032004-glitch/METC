import fs from 'fs';
import path from 'path';
import { 
  Material, 
  Equipment, 
  Tool, 
  Consumable, 
  PPEItem, 
  Worker, 
  IssueRecord, 
  ReturnRecord, 
  TransferRecord, 
  RepairRecord, 
  LostItemRecord, 
  MaintenanceRecord,
  ActivityLog, 
  Notification,
  User,
  UserRole,
  StockAdjustment,
  StocktakingSession,
  SiteIssueTransaction,
  SiteReturnRecord
} from '../src/types';
import { PurchaseRecord } from '../src/types/purchase.types';
import { 
  INITIAL_MATERIALS, 
  INITIAL_EQUIPMENT, 
  INITIAL_TOOLS, 
  INITIAL_CONSUMABLES, 
  INITIAL_PPE,
  INITIAL_WORKERS, 
  INITIAL_ISSUES, 
  INITIAL_RETURNS, 
  INITIAL_TRANSFERS, 
  INITIAL_REPAIRS, 
  INITIAL_LOST, 
  INITIAL_ACTIVITIES, 
  INITIAL_NOTIFICATIONS 
} from '../src/data/mockData';
import {
  INITIAL_COMPANY_PROFILE,
  INITIAL_USERS,
  INITIAL_AUTHORIZED_USERS,
  INITIAL_ACCESS_REQUESTS,
  INITIAL_ROLES,
  INITIAL_DEPARTMENTS,
  INITIAL_BRANCHES,
  INITIAL_SITES,
  INITIAL_SUPPLIERS,
  INITIAL_UNITS,
  INITIAL_EMAIL_SETTINGS,
  INITIAL_APP_SETTINGS,
  INITIAL_SECURITY_SETTINGS,
  INITIAL_AUDIT_LOGS,
  INITIAL_BACKUPS,
  INITIAL_BACKUP_SETTINGS,
  INITIAL_SYSTEM_HEALTH,
  INITIAL_LICENSE_INFO
} from '../src/features/admin/data/initialAdminData';
import { AccessRequest, AccessStatus } from '../src/types/access.types';

export interface DatabaseSchema {
  version: number;
  lastUpdated: string;
  materials: Material[];
  equipment: Equipment[];
  tools: Tool[];
  consumables: Consumable[];
  ppe: PPEItem[];
  workers: Worker[];
  issues: IssueRecord[];
  returns: ReturnRecord[];
  transfers: TransferRecord[];
  repairs: RepairRecord[];
  lostItems: LostItemRecord[];
  maintenance: MaintenanceRecord[];
  activities: ActivityLog[];
  notifications: Notification[];
  companyProfile: any;
  users: any[];
  authorizedUsers: any[];
  accessRequests: AccessRequest[];
  roles: any[];
  departments: any[];
  branches: any[];
  sites: any[];
  suppliers: any[];
  units: any[];
  emailSettings: any;
  appSettings: any;
  securitySettings: any;
  auditLogs: any[];
  stockAdjustments?: StockAdjustment[];
  stocktakingSessions?: StocktakingSession[];
  siteIssues?: SiteIssueTransaction[];
  purchases?: PurchaseRecord[];
}


const DB_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DB_DIR, 'metc-cloud-db.json');

class CentralCloudDatabase {
  private data: DatabaseSchema;
  private isSaving = false;
  private pendingSave = false;

  constructor() {
    this.data = this.initializeDatabase();
  }

  private initializeDatabase(): DatabaseSchema {
    try {
      if (!fs.existsSync(DB_DIR)) {
        fs.mkdirSync(DB_DIR, { recursive: true });
      }

      if (fs.existsSync(DB_FILE)) {
        const fileContent = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(fileContent);
        if (parsed && Array.isArray(parsed.materials)) {
          console.log(`[DB] Loaded cloud database with ${parsed.materials.length} materials, ${parsed.equipment.length} equipment.`);
          if (!parsed.stockAdjustments) parsed.stockAdjustments = [];
          if (!parsed.stocktakingSessions) parsed.stocktakingSessions = [];
          if (!parsed.siteIssues) parsed.siteIssues = [];
          if (!parsed.purchases) parsed.purchases = [];
          return parsed;
        }
      }
    } catch (err) {
      console.warn('[DB] Failed to load existing database file, seeding defaults:', err);
    }

    // Default Seed Data (Inventory begins clean/empty for user's fresh entries)
    const seed: DatabaseSchema = {
      version: 1,
      lastUpdated: new Date().toISOString(),
      materials: [],
      equipment: [],
      tools: [],
      consumables: [],
      ppe: [],
      stockAdjustments: [],
      stocktakingSessions: [],
      siteIssues: [],
      purchases: [],
      workers: INITIAL_WORKERS || [],
      issues: INITIAL_ISSUES || [],
      returns: INITIAL_RETURNS || [],
      transfers: INITIAL_TRANSFERS || [],
      repairs: INITIAL_REPAIRS || [],
      lostItems: INITIAL_LOST || [],
      maintenance: [
        {
          id: 'mnt-1',
          maintenanceCode: 'MNT-2026-001',
          itemId: 'eqp-1',
          itemName: 'BOSCH ROTARY HAMMER GBH 2-26 DRE',
          frequency: 'Monthly',
          lastMaintenance: '2026-08-01',
          nextMaintenance: '2026-09-01',
          responsiblePerson: 'Rajesh Kumar (Electrician)',
          calibrationDue: false,
          status: 'Scheduled'
        }
      ],
      activities: INITIAL_ACTIVITIES || [],
      notifications: INITIAL_NOTIFICATIONS || [],
      companyProfile: INITIAL_COMPANY_PROFILE,
      users: INITIAL_USERS || [],
      authorizedUsers: INITIAL_AUTHORIZED_USERS || [],
      accessRequests: INITIAL_ACCESS_REQUESTS || [],
      roles: INITIAL_ROLES || [],
      departments: INITIAL_DEPARTMENTS || [],
      branches: INITIAL_BRANCHES || [],
      sites: INITIAL_SITES || [],
      suppliers: INITIAL_SUPPLIERS || [],
      units: INITIAL_UNITS || [],
      emailSettings: INITIAL_EMAIL_SETTINGS || {},
      appSettings: INITIAL_APP_SETTINGS || {},
      securitySettings: INITIAL_SECURITY_SETTINGS || {},
      auditLogs: INITIAL_AUDIT_LOGS || []
    };

    this.saveToFile(seed);
    return seed;
  }

  private saveToFile(snapshot?: DatabaseSchema): void {
    const dataToSave = snapshot || this.data;
    dataToSave.lastUpdated = new Date().toISOString();
    dataToSave.version++;

    if (this.isSaving) {
      this.pendingSave = true;
      return;
    }

    this.isSaving = true;
    try {
      if (!fs.existsSync(DB_DIR)) {
        fs.mkdirSync(DB_DIR, { recursive: true });
      }
      const tmpFile = `${DB_FILE}.tmp`;
      fs.writeFileSync(tmpFile, JSON.stringify(dataToSave, null, 2), 'utf-8');
      fs.renameSync(tmpFile, DB_FILE);
    } catch (e) {
      console.error('[DB] Error persisting database to disk:', e);
    } finally {
      this.isSaving = false;
      if (this.pendingSave) {
        this.pendingSave = false;
        this.saveToFile();
      }
    }
  }

  public getSnapshot(): DatabaseSchema {
    return this.data;
  }

  // ==========================================
  // ASSET OPERATIONS (Materials, Equipment, Tools, Consumables, PPE)
  // ==========================================

  public getAllAssets(): any[] {
    return [
      ...this.data.materials,
      ...this.data.equipment,
      ...this.data.tools,
      ...this.data.consumables,
      ...(this.data.ppe || []),
    ];
  }

  public getAssetById(id: string): any | null {
    return this.getAllAssets().find((a) => a.id === id) || null;
  }

  public addAsset(category: string, itemData: any, author = 'System'): any {
    const now = new Date().toISOString();
    const idPrefix = category.toLowerCase().slice(0, 3);
    const newItem = {
      ...itemData,
      id: itemData.id || `${idPrefix}-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      createdAt: itemData.createdAt || now,
      updatedAt: now,
      availableQuantity: itemData.availableQuantity !== undefined ? itemData.availableQuantity : itemData.quantity,
    };

    switch (category.toLowerCase()) {
      case 'material':
      case 'materials':
        this.data.materials.unshift(newItem);
        break;
      case 'equipment':
        this.data.equipment.unshift(newItem);
        break;
      case 'tool':
      case 'tools':
        this.data.tools.unshift(newItem);
        break;
      case 'consumable':
      case 'consumables':
        this.data.consumables.unshift(newItem);
        break;
      case 'ppe':
        if (!this.data.ppe) this.data.ppe = [];
        this.data.ppe.unshift(newItem);
        break;
      default:
        this.data.materials.unshift(newItem);
    }

    this.logActivity({
      action: 'Created',
      targetType: 'Asset',
      targetName: `${newItem.name} (${newItem.code || category})`,
      user: author,
      details: `Added new ${category}: "${newItem.name}" with initial quantity ${newItem.quantity} ${newItem.unit || 'units'}.`,
    });

    this.saveToFile();
    return newItem;
  }

  public bulkAddAssets(items: any[], author = 'Store Keeper'): { added: any[]; count: number } {
    const now = new Date().toISOString();
    const addedItems: any[] = [];

    if (!Array.isArray(items) || items.length === 0) {
      return { added: [], count: 0 };
    }

    if (!this.data.materials) this.data.materials = [];
    if (!this.data.equipment) this.data.equipment = [];
    if (!this.data.tools) this.data.tools = [];
    if (!this.data.consumables) this.data.consumables = [];
    if (!this.data.ppe) this.data.ppe = [];

    const getCategoryList = (cat: string) => {
      const c = (cat || '').toLowerCase();
      if (c.includes('equip')) return this.data.equipment;
      if (c.includes('tool')) return this.data.tools;
      if (c.includes('consum')) return this.data.consumables;
      if (c.includes('ppe')) return this.data.ppe;
      return this.data.materials;
    };

    for (const raw of items) {
      const cat = raw.category || 'Material';
      const list = getCategoryList(cat);
      const prefix = cat === 'Equipment' ? 'EQP' : cat === 'Tool' ? 'TOL' : cat === 'Consumable' ? 'CON' : cat === 'PPE' ? 'PPE' : 'MAT';
      const idPrefix = prefix.toLowerCase();

      const qty = Number(raw.quantity) >= 0 ? Number(raw.quantity) : (Number(raw.openingQuantity) >= 0 ? Number(raw.openingQuantity) : 0);
      const avail = Number(raw.availableQuantity) >= 0 ? Number(raw.availableQuantity) : (Number(raw.workingQuantity) >= 0 ? Number(raw.workingQuantity) : qty);
      
      const itemCode = raw.code !== undefined 
        ? String(raw.code).trim() 
        : (raw.hasMetNumber === false ? '' : `${prefix}-${Math.floor(1000 + Math.random() * 9000)}`);
      const itemId = (raw.id && String(raw.id).trim()) || `${idPrefix}-${Date.now()}-${Math.floor(Math.random() * 100000)}`;

      const newItem: any = {
        ...raw,
        id: itemId,
        code: itemCode,
        name: (raw.name || '').trim() || 'Unnamed Item',
        category: cat,
        unit: (raw.unit || 'NOS').trim().toUpperCase(),
        quantity: qty,
        availableQuantity: avail,
        minQuantityThreshold: Number(raw.minQuantityThreshold) || Number(raw.minStock) || 5,
        location: (raw.location || raw.rack || 'Main Warehouse').trim(),
        status: avail > (Number(raw.minQuantityThreshold) || 5) ? 'Available' : (avail > 0 ? 'Low Stock' : 'Out of Stock'),
        supplier: raw.supplier || '',
        damagedQuantity: Number(raw.damagedQuantity) || 0,
        remarks: raw.remarks || '',
        createdAt: raw.createdAt || now,
        updatedAt: now,
      };

      list.unshift(newItem);
      addedItems.push(newItem);
    }

    this.data.lastUpdated = now;
    this.data.version = (this.data.version || 1) + 1;

    this.logActivity({
      action: 'Created',
      targetType: 'Asset',
      targetName: `Bulk Inventory Import (${addedItems.length} items)`,
      user: author,
      details: `Batch added ${addedItems.length} inventory rows across categories.`,
    });

    this.saveToFile();
    return { added: addedItems, count: addedItems.length };
  }

  public updateAsset(category: string, id: string, updates: any, author = 'System'): any | null {
    const now = new Date().toISOString();
    let updatedItem: any = null;
    let oldQuantity: number | undefined;

    const applyUpdate = (list: any[]) => {
      if (!Array.isArray(list)) return;
      const idx = list.findIndex((x) => x.id === id);
      if (idx !== -1) {
        oldQuantity = list[idx].quantity;
        const newQty = updates.quantity !== undefined ? Number(updates.quantity) : oldQuantity;
        let newAvail = updates.availableQuantity !== undefined ? Number(updates.availableQuantity) : undefined;
        if (newAvail === undefined && updates.quantity !== undefined) {
          const diff = (newQty || 0) - (oldQuantity || 0);
          newAvail = Math.max(0, (list[idx].availableQuantity || 0) + diff);
        }

        list[idx] = {
          ...list[idx],
          ...updates,
          ...(updates.quantity !== undefined ? { quantity: newQty } : {}),
          ...(newAvail !== undefined ? { availableQuantity: newAvail } : {}),
          updatedAt: now,
        };
        updatedItem = list[idx];
      }
    };

    const cat = (category || '').toLowerCase();
    if (cat.includes('material')) {
      applyUpdate(this.data.materials);
    } else if (cat.includes('equipment')) {
      applyUpdate(this.data.equipment);
    } else if (cat.includes('tool')) {
      applyUpdate(this.data.tools);
    } else if (cat.includes('consumable')) {
      applyUpdate(this.data.consumables);
    } else if (cat.includes('ppe')) {
      if (!this.data.ppe) this.data.ppe = [];
      applyUpdate(this.data.ppe);
    }

    // If not found in expected category, search all other lists by ID
    if (!updatedItem) {
      applyUpdate(this.data.materials);
      if (!updatedItem) applyUpdate(this.data.equipment);
      if (!updatedItem) applyUpdate(this.data.tools);
      if (!updatedItem) applyUpdate(this.data.consumables);
      if (!updatedItem && this.data.ppe) applyUpdate(this.data.ppe);
    }

    // If item does not exist at all in memory database (e.g. created on Firestore from another device), insert it
    if (!updatedItem) {
      const targetList = cat.includes('equipment')
        ? this.data.equipment
        : cat.includes('tool')
        ? this.data.tools
        : cat.includes('consumable')
        ? this.data.consumables
        : cat.includes('ppe')
        ? (this.data.ppe || (this.data.ppe = []))
        : this.data.materials;

      const qty = updates.quantity !== undefined ? Number(updates.quantity) : 0;
      const avail = updates.availableQuantity !== undefined ? Number(updates.availableQuantity) : qty;
      const newItem = {
        id,
        name: updates.name || 'Unnamed Asset',
        category: updates.category || (cat.includes('tool') ? 'Tool' : cat.includes('equipment') ? 'Equipment' : 'Material'),
        ...updates,
        quantity: qty,
        availableQuantity: avail,
        createdAt: updates.createdAt || now,
        updatedAt: now,
      };
      targetList.unshift(newItem);
      updatedItem = newItem;
    }

    if (updatedItem) {
      let detailMsg = `Updated ${updatedItem.name}`;
      if (updates.quantity !== undefined && oldQuantity !== undefined && oldQuantity !== updates.quantity) {
        detailMsg = `Changed quantity from ${oldQuantity} to ${updates.quantity}`;
      }

      this.logActivity({
        action: 'Updated',
        targetType: 'Asset',
        targetName: updatedItem.name,
        user: author,
        details: detailMsg,
      });

      this.saveToFile();
    }

    return updatedItem;
  }

  public deleteAsset(category: string, id: string, author = 'System'): boolean {
    let deletedName = '';

    const filterList = (list: any[]) => {
      const idx = list.findIndex((x) => x.id === id);
      if (idx !== -1) {
        deletedName = list[idx].name;
        list.splice(idx, 1);
        return true;
      }
      return false;
    };

    let removed = false;
    switch (category.toLowerCase()) {
      case 'material':
      case 'materials':
        removed = filterList(this.data.materials);
        break;
      case 'equipment':
        removed = filterList(this.data.equipment);
        break;
      case 'tool':
      case 'tools':
        removed = filterList(this.data.tools);
        break;
      case 'consumable':
      case 'consumables':
        removed = filterList(this.data.consumables);
        break;
      case 'ppe':
        if (this.data.ppe) removed = filterList(this.data.ppe);
        break;
      default:
        removed = filterList(this.data.materials) ||
          filterList(this.data.equipment) ||
          filterList(this.data.tools) ||
          filterList(this.data.consumables) ||
          (this.data.ppe && filterList(this.data.ppe));
    }

    if (removed) {
      this.logActivity({
        action: 'Updated',
        targetType: 'Asset',
        targetName: deletedName || id,
        user: author,
        details: `Deleted item "${deletedName}" (${id}) from database.`,
      });
      this.saveToFile();
    }

    return removed;
  }

  /**
   * Clears all assets across materials, equipment, tools, consumables, and PPE.
   * Allows users to start completely fresh and add new items.
   */
  public clearAllAssets(author = 'System'): {
    materials: number;
    equipment: number;
    tools: number;
    consumables: number;
    ppe: number;
    totalCleared: number;
  } {
    const counts = {
      materials: this.data.materials ? this.data.materials.length : 0,
      equipment: this.data.equipment ? this.data.equipment.length : 0,
      tools: this.data.tools ? this.data.tools.length : 0,
      consumables: this.data.consumables ? this.data.consumables.length : 0,
      ppe: this.data.ppe ? this.data.ppe.length : 0,
      totalCleared: 0,
    };
    counts.totalCleared =
      counts.materials + counts.equipment + counts.tools + counts.consumables + counts.ppe;

    this.data.materials = [];
    this.data.equipment = [];
    this.data.tools = [];
    this.data.consumables = [];
    this.data.ppe = [];
    this.data.lastUpdated = new Date().toISOString();
    this.data.version = (this.data.version || 1) + 1;

    this.logActivity({
      action: 'Updated',
      targetType: 'Asset',
      targetName: 'All Inventory Assets',
      user: author,
      details: `Cleared all inventory assets (${counts.totalCleared} items removed). Ready for new assets entry.`,
    });

    this.saveToFile();
    return counts;
  }

  /**
   * Restores initial sample demo assets if needed.
   */
  public restoreDemoAssets(author = 'System'): {
    materials: number;
    equipment: number;
    tools: number;
    consumables: number;
    ppe: number;
  } {
    this.data.materials = [...INITIAL_MATERIALS];
    this.data.equipment = [...INITIAL_EQUIPMENT];
    this.data.tools = [...INITIAL_TOOLS];
    this.data.consumables = [...INITIAL_CONSUMABLES];
    this.data.ppe = [...(INITIAL_PPE || [])];
    this.data.lastUpdated = new Date().toISOString();
    this.data.version = (this.data.version || 1) + 1;

    this.logActivity({
      action: 'Created',
      targetType: 'Asset',
      targetName: 'Demo Inventory Assets',
      user: author,
      details: 'Restored sample/demo inventory assets.',
    });

    this.saveToFile();
    return {
      materials: this.data.materials.length,
      equipment: this.data.equipment.length,
      tools: this.data.tools.length,
      consumables: this.data.consumables.length,
      ppe: (this.data.ppe || []).length,
    };
  }

  // ==========================================
  // TRANSACTION ATOMIC OPERATIONS (Issue, Return, Transfer, Repair, Lost)
  // ==========================================

  /**
   * Safe atomic stock issue transaction with race condition prevention
   */
  public issueItem(issuePayload: any, author = 'Store Keeper'): { issue: IssueRecord; updatedAsset: any } {
    const asset = this.getAssetById(issuePayload.itemId);
    if (!asset) {
      throw new Error(`Item not found with ID ${issuePayload.itemId}`);
    }

    const qtyToIssue = Number(issuePayload.quantity) || 1;
    const currentAvailable = Number(asset.availableQuantity !== undefined ? asset.availableQuantity : asset.quantity);

    if (currentAvailable < qtyToIssue) {
      throw new Error(`Insufficient stock. Available: ${currentAvailable}, Requested: ${qtyToIssue}`);
    }

    // Deduct stock atomically
    const newAvailable = currentAvailable - qtyToIssue;
    const updatedAsset = this.updateAsset(
      asset.category || 'Material',
      asset.id,
      {
        availableQuantity: newAvailable,
        status: newAvailable === 0 ? 'Out of Stock' : newAvailable <= (asset.minQuantityThreshold || 5) ? 'Low Stock' : 'Available',
      },
      author
    );

    const now = new Date().toISOString();
    const newIssue: IssueRecord = {
      id: `iss-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      issueCode: issuePayload.issueCode || `ISS-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
      itemId: asset.id,
      itemName: asset.name,
      itemCategory: asset.category,
      workerId: issuePayload.workerId || 'wrk-1',
      workerName: issuePayload.workerName || 'Assigned Worker',
      quantity: qtyToIssue,
      issueDate: issuePayload.issueDate || now,
      expectedReturnDate: issuePayload.expectedReturnDate,
      projectSite: issuePayload.projectSite || asset.location || 'HQ Site',
      issuedBy: author,
      remarks: issuePayload.remarks || '',
      status: 'Active',
    };

    this.data.issues.unshift(newIssue);

    // Update worker assignedItemsCount
    const worker = this.data.workers.find((w) => w.id === issuePayload.workerId || w.name === issuePayload.workerName);
    if (worker) {
      worker.assignedItemsCount = (worker.assignedItemsCount || 0) + qtyToIssue;
    }

    this.logActivity({
      action: 'Issued',
      targetType: 'Asset',
      targetName: asset.name,
      user: author,
      details: `Issued ${qtyToIssue} ${asset.unit || 'unit(s)'} of "${asset.name}" to ${newIssue.workerName} at ${newIssue.projectSite}. Stock updated from ${currentAvailable} to ${newAvailable}.`,
    });

    this.saveToFile();
    return { issue: newIssue, updatedAsset };
  }

  /**
   * Safe atomic stock return transaction
   */
  public returnItem(returnPayload: any, author = 'Store Keeper'): { returnRecord: ReturnRecord; updatedAsset: any } {
    const asset = this.getAssetById(returnPayload.itemId);
    if (!asset) {
      throw new Error(`Item not found with ID ${returnPayload.itemId}`);
    }

    const qtyReturned = Number(returnPayload.quantityReturned) || 1;
    const currentAvailable = Number(asset.availableQuantity !== undefined ? asset.availableQuantity : asset.quantity);
    const newAvailable = Math.min(Number(asset.quantity), currentAvailable + qtyReturned);

    const updatedAsset = this.updateAsset(
      asset.category || 'Material',
      asset.id,
      {
        availableQuantity: newAvailable,
        status: newAvailable > (asset.minQuantityThreshold || 5) ? 'Available' : 'Low Stock',
      },
      author
    );

    const now = new Date().toISOString();
    const newReturn: ReturnRecord = {
      id: `ret-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      returnCode: returnPayload.returnCode || `RET-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
      issueId: returnPayload.issueId || '',
      issueCode: returnPayload.issueCode,
      itemId: asset.id,
      itemName: asset.name,
      workerId: returnPayload.workerId || '',
      workerName: returnPayload.workerName || 'Worker',
      quantityReturned: qtyReturned,
      returnDate: returnPayload.returnDate || now,
      conditionOnReturn: returnPayload.conditionOnReturn || 'Good',
      receivedBy: author,
      notes: returnPayload.notes || '',
      status: 'Completed',
    };

    this.data.returns.unshift(newReturn);

    // If an issueId is associated, mark it as returned
    if (returnPayload.issueId) {
      const issue = this.data.issues.find((i) => i.id === returnPayload.issueId);
      if (issue) {
        issue.status = 'Returned';
      }
    }

    // Update worker assignedItemsCount
    const worker = this.data.workers.find((w) => w.id === returnPayload.workerId || w.name === returnPayload.workerName);
    if (worker) {
      worker.assignedItemsCount = Math.max(0, (worker.assignedItemsCount || 0) - qtyReturned);
    }

    this.logActivity({
      action: 'Returned',
      targetType: 'Asset',
      targetName: asset.name,
      user: author,
      details: `Received return of ${qtyReturned} ${asset.unit || 'unit(s)'} of "${asset.name}" from ${newReturn.workerName} in ${newReturn.conditionOnReturn} condition. Available stock restored to ${newAvailable}.`,
    });

    this.saveToFile();
    return { returnRecord: newReturn, updatedAsset };
  }

  /**
   * Fast physical stock count adjustment with immutable history tracking
   */
  public addStockAdjustment(
    adjPayload: {
      itemId: string;
      newQuantity: number;
      reason: string;
      remarks?: string;
    },
    author = 'Store Keeper'
  ): { adjustment: StockAdjustment; updatedAsset: any } {
    const asset = this.getAssetById(adjPayload.itemId);
    if (!asset) {
      throw new Error(`Item not found with ID ${adjPayload.itemId}`);
    }

    const prevQty = Number(asset.quantity) || 0;
    const newQty = Number(adjPayload.newQuantity);
    if (isNaN(newQty) || newQty < 0) {
      throw new Error('Quantity cannot be negative or invalid');
    }

    const diff = newQty - prevQty;
    const currentAvail = Number(asset.availableQuantity !== undefined ? asset.availableQuantity : asset.quantity);
    const newAvail = Math.max(0, currentAvail + diff);

    const updatedAsset = this.updateAsset(
      asset.category || 'Material',
      asset.id,
      {
        quantity: newQty,
        availableQuantity: newAvail,
        status: newAvail > (asset.minQuantityThreshold || 5) ? 'Available' : (newAvail > 0 ? 'Low Stock' : 'Out of Stock'),
      },
      author
    );

    const now = new Date().toISOString();
    const adjustment: StockAdjustment = {
      id: `adj-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      adjustmentCode: `ADJ-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
      itemId: asset.id,
      itemName: asset.name,
      itemCode: asset.code,
      category: asset.category,
      previousQuantity: prevQty,
      newQuantity: newQty,
      difference: diff,
      reason: adjPayload.reason || 'Physical Count Adjustment',
      user: author,
      timestamp: now,
      location: asset.location || 'Store',
      remarks: adjPayload.remarks || '',
    };

    if (!this.data.stockAdjustments) this.data.stockAdjustments = [];
    this.data.stockAdjustments.unshift(adjustment);

    this.logActivity({
      action: 'Updated',
      targetType: 'Asset',
      targetName: `${asset.name} (${asset.code})`,
      user: author,
      details: `Physical stock count adjustment: quantity changed from ${prevQty} to ${newQty} (diff: ${diff > 0 ? `+${diff}` : diff}). Reason: ${adjustment.reason}.`,
    });

    this.saveToFile();
    return { adjustment, updatedAsset };
  }

  public createStockAdjustment(adjPayload: any, author = 'Store Keeper') {
    return this.addStockAdjustment(adjPayload, author);
  }

  public getStockAdjustments(): StockAdjustment[] {
    return this.data.stockAdjustments || [];
  }

  /**
   * Stocktaking Sessions (Pending Count Tracker)
   */
  public saveStocktakingSession(session: any, author = 'Store Keeper'): StocktakingSession {
    if (!this.data.stocktakingSessions) this.data.stocktakingSessions = [];
    const now = new Date().toISOString();

    const id = session.id || `stk-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const sessionCode = session.sessionCode || `STK-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

    const existingIdx = this.data.stocktakingSessions.findIndex((s) => s.id === id || s.sessionCode === sessionCode);
    const completeObj: StocktakingSession = {
      id,
      sessionCode,
      title: session.title || 'Inventory Physical Count',
      categories: session.categories || ['Material', 'Equipment', 'Tool', 'Consumable', 'PPE'],
      locations: session.locations || ['All'],
      status: session.status || 'In Progress',
      startedAt: session.startedAt || now,
      completedAt: session.status === 'Completed' ? (session.completedAt || now) : undefined,
      createdBy: session.createdBy || author,
      items: Array.isArray(session.items) ? session.items : [],
      totalExpected: Array.isArray(session.items) ? session.items.length : 0,
      totalCounted: Array.isArray(session.items) ? session.items.filter((i: any) => i.status === 'Counted').length : 0,
      totalDiscrepancies: Array.isArray(session.items) ? session.items.filter((i: any) => (i.difference || 0) !== 0 && i.status === 'Counted').length : 0,
      notes: session.notes || '',
    };

    if (existingIdx !== -1) {
      this.data.stocktakingSessions[existingIdx] = completeObj;
    } else {
      this.data.stocktakingSessions.unshift(completeObj);
    }

    this.logActivity({
      action: 'Updated',
      targetType: 'System',
      targetName: `Stocktaking Session: ${completeObj.title}`,
      user: author,
      details: `Saved stocktaking session ${completeObj.sessionCode} (status: ${completeObj.status}, items: ${completeObj.items.length}).`,
    });

    this.saveToFile();
    return completeObj;
  }

  public getStocktakingSessions(): StocktakingSession[] {
    return this.data.stocktakingSessions || [];
  }

  /**
   * Site Issue and Return Management
   */
  public createSiteIssue(
    issuePayload: {
      site: string;
      supervisorId: string;
      supervisorName: string;
      expectedReturnDate?: string;
      remarks?: string;
      items: Array<{ itemId: string; requestedQuantity: number; isReusable?: boolean }>;
    },
    author = 'Store Keeper'
  ): { transaction: SiteIssueTransaction; updatedAssets: any[] } {
    if (!issuePayload.site || !issuePayload.supervisorName) {
      throw new Error('Project site and responsible supervisor are required.');
    }
    if (!Array.isArray(issuePayload.items) || issuePayload.items.length === 0) {
      throw new Error('At least one item must be selected for site dispatch.');
    }

    const updatedAssets: any[] = [];
    const transactionItems: any[] = [];
    const now = new Date().toISOString();

    // Verify stock availability for each item
    for (const line of issuePayload.items) {
      const asset = this.getAssetById(line.itemId);
      if (!asset) {
        throw new Error(`Item not found in inventory: ID ${line.itemId}`);
      }
      const qty = Number(line.requestedQuantity);
      if (qty <= 0) {
        throw new Error(`Quantity for "${asset.name}" must be greater than zero.`);
      }
      const currentAvail = Number(asset.availableQuantity !== undefined ? asset.availableQuantity : asset.quantity);
      if (currentAvail < qty) {
        throw new Error(`Insufficient stock for "${asset.name}". Available: ${currentAvail}, Requested: ${qty}`);
      }
    }

    // Deduct stock atomically
    for (const line of issuePayload.items) {
      const asset = this.getAssetById(line.itemId)!;
      const qty = Number(line.requestedQuantity);
      const currentAvail = Number(asset.availableQuantity !== undefined ? asset.availableQuantity : asset.quantity);
      const newAvail = currentAvail - qty;

      const updated = this.updateAsset(
        asset.category || 'Material',
        asset.id,
        {
          availableQuantity: newAvail,
          status: newAvail === 0 ? 'Out of Stock' : newAvail <= (asset.minQuantityThreshold || 5) ? 'Low Stock' : 'Available',
        },
        author
      );
      updatedAssets.push(updated);

      const isReusable = line.isReusable !== undefined ? line.isReusable : (asset.category === 'Tool' || asset.category === 'Equipment');

      transactionItems.push({
        itemId: asset.id,
        itemCode: asset.code,
        itemName: asset.name,
        category: asset.category,
        unit: asset.unit || 'NOS',
        requestedQuantity: qty,
        issuedQuantity: qty,
        returnedQuantity: 0,
        damagedQuantity: 0,
        missingQuantity: 0,
        isReusable,
        status: isReusable ? 'Issued' : 'Consumed',
      });
    }

    const reference = `ISS-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const newTransaction: SiteIssueTransaction = {
      id: `site-iss-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      reference,
      site: issuePayload.site,
      supervisorId: issuePayload.supervisorId || '',
      supervisorName: issuePayload.supervisorName,
      issuer: author,
      date: now,
      expectedReturnDate: issuePayload.expectedReturnDate,
      remarks: issuePayload.remarks || '',
      status: 'Active',
      items: transactionItems,
      returnHistory: [],
      createdAt: now,
      updatedAt: now,
    };

    if (!this.data.siteIssues) this.data.siteIssues = [];
    this.data.siteIssues.unshift(newTransaction);

    this.logActivity({
      action: 'Issued',
      targetType: 'Asset',
      targetName: `Site Issue: ${reference} (${issuePayload.site})`,
      user: author,
      details: `Dispatched ${transactionItems.length} item lines to Site "${issuePayload.site}" (Supervisor: ${issuePayload.supervisorName}).`,
    });

    this.saveToFile();
    return { transaction: newTransaction, updatedAssets };
  }

  public getSiteIssues(): SiteIssueTransaction[] {
    return this.data.siteIssues || [];
  }

  public processSiteReturn(
    returnPayload: {
      issueId: string;
      returnDate?: string;
      remarks?: string;
      items: Array<{
        itemId: string;
        returnQty: number;
        workingQty: number;
        damagedQty: number;
        missingQty: number;
        condition?: string;
        remarks?: string;
      }>;
    },
    author = 'Store Keeper'
  ): { returnRecord: SiteReturnRecord; updatedTransaction: SiteIssueTransaction; updatedAssets: any[] } {
    if (!this.data.siteIssues) this.data.siteIssues = [];
    const transaction = this.data.siteIssues.find((s) => s.id === returnPayload.issueId || s.reference === returnPayload.issueId);
    if (!transaction) {
      throw new Error(`Site issue transaction not found with ID or reference "${returnPayload.issueId}"`);
    }

    const now = new Date().toISOString();
    const returnDate = returnPayload.returnDate || now;
    const returnCode = `RET-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const updatedAssets: any[] = [];
    const returnItemsList: any[] = [];

    for (const returnLine of returnPayload.items) {
      const txItem = transaction.items.find((i) => i.itemId === returnLine.itemId);
      if (!txItem) {
        continue;
      }

      const returnQty = Number(returnLine.returnQty) || 0;
      const workingQty = Number(returnLine.workingQty) || 0;
      const damagedQty = Number(returnLine.damagedQty) || 0;
      const missingQty = Number(returnLine.missingQty) || 0;

      const remainingIssued = txItem.issuedQuantity - txItem.returnedQuantity;
      if (returnQty > remainingIssued) {
        throw new Error(`Returned quantity (${returnQty}) exceeds remaining issued balance (${remainingIssued}) for "${txItem.itemName}".`);
      }

      // Update transaction line
      txItem.returnedQuantity += returnQty;
      txItem.damagedQuantity += damagedQty;
      txItem.missingQuantity += missingQty;
      if (txItem.returnedQuantity >= txItem.issuedQuantity) {
        txItem.status = 'Returned';
      } else {
        txItem.status = 'Partially Returned';
      }

      // Only restore WORKING quantity of REUSABLE items back to available inventory
      if (txItem.isReusable && workingQty > 0) {
        const asset = this.getAssetById(txItem.itemId);
        if (asset) {
          const currentAvail = Number(asset.availableQuantity !== undefined ? asset.availableQuantity : asset.quantity);
          const newAvail = Math.min(Number(asset.quantity), currentAvail + workingQty);

          const updated = this.updateAsset(
            asset.category || 'Material',
            asset.id,
            {
              availableQuantity: newAvail,
              status: newAvail > (asset.minQuantityThreshold || 5) ? 'Available' : 'Low Stock',
            },
            author
          );
          updatedAssets.push(updated);
        }
      }

      // If damaged quantity, update asset damaged count/repair notes
      if (damagedQty > 0) {
        const asset = this.getAssetById(txItem.itemId);
        if (asset) {
          const currDamaged = Number((asset as any).damagedQuantity || 0);
          this.updateAsset(
            asset.category || 'Material',
            asset.id,
            {
              damagedQuantity: currDamaged + damagedQty,
            },
            author
          );
        }
      }

      returnItemsList.push({
        itemId: txItem.itemId,
        itemName: txItem.itemName,
        itemCode: txItem.itemCode,
        category: txItem.category,
        returnQty,
        workingQty,
        damagedQty,
        missingQty,
        condition: returnLine.condition || 'Good',
        remarks: returnLine.remarks || '',
      });
    }

    const returnRecord: SiteReturnRecord = {
      id: `site-ret-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      returnCode,
      issueId: transaction.id,
      issueReference: transaction.reference,
      site: transaction.site,
      supervisorName: transaction.supervisorName,
      returnDate,
      receivedBy: author,
      remarks: returnPayload.remarks || '',
      items: returnItemsList,
    };

    if (!transaction.returnHistory) transaction.returnHistory = [];
    transaction.returnHistory.unshift(returnRecord);

    // Check if entire transaction is completed
    const allCompleted = transaction.items.every(
      (item) => !item.isReusable || item.returnedQuantity >= item.issuedQuantity
    );
    transaction.status = allCompleted ? 'Completed' : 'Partially Returned';
    transaction.updatedAt = now;

    this.logActivity({
      action: 'Returned',
      targetType: 'Asset',
      targetName: `Site Return: ${returnCode} (${transaction.site})`,
      user: author,
      details: `Received return voucher ${returnCode} for issue ${transaction.reference}. Returned ${returnItemsList.length} items.`,
    });

    this.saveToFile();
    return { returnRecord, updatedTransaction: transaction, updatedAssets };
  }

  // ==========================================
  // PURCHASES & AI INVOICE SCANNER INTEGRATION
  // ==========================================

  public getPurchases(): PurchaseRecord[] {
    return this.data.purchases || [];
  }

  public getPurchaseById(id: string): PurchaseRecord | undefined {
    return (this.data.purchases || []).find((p) => p.id === id);
  }

  public checkDuplicateInvoice(
    supplierName: string,
    invoiceNumber: string,
    excludeId?: string
  ): { isDuplicate: boolean; existingPurchase?: PurchaseRecord } {
    if (!supplierName || !invoiceNumber) {
      return { isDuplicate: false };
    }
    const cleanSupplier = supplierName.trim().toLowerCase();
    const cleanInvoice = invoiceNumber.trim().toLowerCase();

    const existing = (this.data.purchases || []).find(
      (p) =>
        p.id !== excludeId &&
        p.status !== 'Voided' &&
        p.invoiceNumber.trim().toLowerCase() === cleanInvoice &&
        p.supplierName.trim().toLowerCase() === cleanSupplier
    );

    return {
      isDuplicate: !!existing,
      existingPurchase: existing,
    };
  }

  public createPurchaseDraft(purchasePayload: any, author = 'Store Keeper'): PurchaseRecord {
    if (!this.data.purchases) this.data.purchases = [];
    const now = new Date().toISOString();

    const id = purchasePayload.id || `pur-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const idempotencyKey = purchasePayload.idempotencyKey || `idem-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;

    // Check if idempotencyKey already exists
    const existingByIdem = this.data.purchases.find((p) => p.idempotencyKey === idempotencyKey);
    if (existingByIdem) {
      return existingByIdem;
    }

    const draft: PurchaseRecord = {
      id,
      idempotencyKey,
      invoiceNumber: (purchasePayload.invoiceNumber || `INV-${Date.now()}`).trim(),
      invoiceDate: purchasePayload.invoiceDate || now.split('T')[0],
      purchaseOrderNumber: purchasePayload.purchaseOrderNumber || '',
      supplierName: (purchasePayload.supplierName || 'Unknown Supplier').trim(),
      supplierContact: purchasePayload.supplierContact || '',
      currency: purchasePayload.currency || 'SGD',
      paymentTerms: purchasePayload.paymentTerms || '',
      subtotal: Number(purchasePayload.subtotal) || 0,
      taxRate: Number(purchasePayload.taxRate) || 0,
      taxAmount: Number(purchasePayload.taxAmount) || 0,
      discountAmount: Number(purchasePayload.discountAmount) || 0,
      freightAmount: Number(purchasePayload.freightAmount) || 0,
      grandTotal: Number(purchasePayload.grandTotal) || 0,
      lineItemsCount: Array.isArray(purchasePayload.lineItems) ? purchasePayload.lineItems.length : 0,
      status: 'Draft',
      invoiceFile: purchasePayload.invoiceFile,
      lineItems: Array.isArray(purchasePayload.lineItems) ? purchasePayload.lineItems : [],
      stockUpdated: false,
      createdAt: now,
      updatedAt: now,
      createdByUser: author,
      auditTrail: [
        {
          timestamp: now,
          user: author,
          action: 'DRAFT_CREATED',
          note: `Created draft invoice entry for ${purchasePayload.supplierName || 'Supplier'} (Invoice #${purchasePayload.invoiceNumber || ''})`,
        },
      ],
    };

    this.data.purchases.unshift(draft);
    this.saveToFile();
    return draft;
  }

  public updatePurchaseDraft(id: string, updates: any, author = 'Store Keeper'): PurchaseRecord {
    if (!this.data.purchases) this.data.purchases = [];
    const index = this.data.purchases.findIndex((p) => p.id === id);
    if (index === -1) {
      throw new Error(`Purchase record not found: ${id}`);
    }

    const existing = this.data.purchases[index];
    if (existing.status === 'Confirmed') {
      throw new Error('Cannot modify an already confirmed purchase record.');
    }

    const now = new Date().toISOString();
    const updated: PurchaseRecord = {
      ...existing,
      ...updates,
      lineItemsCount: Array.isArray(updates.lineItems) ? updates.lineItems.length : existing.lineItemsCount,
      updatedAt: now,
    };

    if (!updated.auditTrail) updated.auditTrail = [];
    updated.auditTrail.push({
      timestamp: now,
      user: author,
      action: 'DRAFT_UPDATED',
      note: 'Updated invoice review details and line items',
    });

    this.data.purchases[index] = updated;
    this.saveToFile();
    return updated;
  }

  public confirmPurchaseAndApplyStock(
    id: string,
    idempotencyKey?: string,
    author = 'Store Keeper'
  ): { success: boolean; purchase: PurchaseRecord; stockUpdates: any[]; isAlreadyConfirmed?: boolean } {
    if (!this.data.purchases) this.data.purchases = [];
    const purchase = this.data.purchases.find((p) => p.id === id);
    if (!purchase) {
      throw new Error(`Purchase record not found: ID ${id}`);
    }

    // Idempotency check: if already confirmed or stock already updated, do NOT re-increment stock!
    if (purchase.status === 'Confirmed' || purchase.stockUpdated) {
      return {
        success: true,
        purchase,
        stockUpdates: [],
        isAlreadyConfirmed: true,
      };
    }

    const now = new Date().toISOString();
    const stockUpdates: any[] = [];

    // Process line items atomically
    for (const item of purchase.lineItems) {
      if (item.action === 'IGNORE') {
        continue;
      }

      if (item.action === 'UPDATE_EXISTING' && item.matchedAssetId) {
        const asset = this.getAssetById(item.matchedAssetId);
        if (asset) {
          const addQty = Math.max(0, Number(item.quantity) || 0);
          const currentQty = Number(asset.quantity) || 0;
          const currentAvail = Number(asset.availableQuantity !== undefined ? asset.availableQuantity : asset.quantity) || 0;
          const newQty = currentQty + addQty;
          const newAvail = currentAvail + addQty;
          const newUnitPrice = Number(item.unitPrice) > 0 ? Number(item.unitPrice) : asset.unitPrice;

          this.updateAsset(
            asset.category || item.category || 'Material',
            asset.id,
            {
              quantity: newQty,
              availableQuantity: newAvail,
              unitPrice: newUnitPrice,
              totalValue: newQty * (newUnitPrice || 0),
              status: newAvail > (asset.minQuantityThreshold || 5) ? 'Available' : 'Low Stock',
              supplier: purchase.supplierName || asset.supplier,
              purchaseDate: purchase.invoiceDate || asset.purchaseDate || now.split('T')[0],
            },
            author
          );
          stockUpdates.push({
            type: 'UPDATED_EXISTING',
            assetId: asset.id,
            name: asset.name,
            code: asset.code,
            previousQuantity: currentQty,
            addedQuantity: addQty,
            newQuantity: newQty,
          });
        }
      } else if (item.action === 'CREATE_NEW' || !item.matchedAssetId) {
        // Create brand new asset in category
        const cat = item.category || 'Material';
        const newAssetData = {
          name: item.name || item.rawDescription,
          code: item.code || '',
          category: cat,
          quantity: Number(item.quantity) || 0,
          availableQuantity: Number(item.quantity) || 0,
          unit: item.unit || 'NOS',
          unitPrice: Number(item.unitPrice) || 0,
          totalValue: (Number(item.quantity) || 0) * (Number(item.unitPrice) || 0),
          minQuantityThreshold: 5,
          maximumStock: 1000,
          location: 'Main Warehouse',
          status: 'Available',
          supplier: purchase.supplierName,
          purchaseDate: purchase.invoiceDate || now.split('T')[0],
          barcode: item.code ? `BC-${item.code.replace(/\\s+/g, '')}` : `BC-${Date.now()}`,
          qrCode: item.code ? `QR-${item.code.replace(/\\s+/g, '')}` : `QR-${Date.now()}`,
          remarks: `Created from Invoice ${purchase.invoiceNumber} (${purchase.supplierName})`,
        };
        const created = this.addAsset(cat, newAssetData, author);
        item.matchedAssetId = created.id;
        item.matchedAssetCode = created.code;
        stockUpdates.push({
          type: 'CREATED_NEW',
          assetId: created.id,
          name: created.name,
          code: created.code,
          addedQuantity: created.quantity,
          newQuantity: created.quantity,
        });
      }
    }

    purchase.status = 'Confirmed';
    purchase.stockUpdated = true;
    purchase.updatedAt = now;
    if (idempotencyKey) {
      purchase.idempotencyKey = idempotencyKey;
    }

    if (!purchase.auditTrail) purchase.auditTrail = [];
    purchase.auditTrail.push({
      timestamp: now,
      user: author,
      action: 'CONFIRMED_AND_STOCKED',
      note: `Applied stock updates for ${stockUpdates.length} items from Invoice ${purchase.invoiceNumber}`,
    });

    this.logActivity({
      action: 'Stock Received',
      targetType: 'Purchase Record',
      targetName: `Invoice #${purchase.invoiceNumber} (${purchase.supplierName})`,
      user: author,
      details: `Received and updated stock for ${stockUpdates.length} items from supplier "${purchase.supplierName}". Total: ${purchase.currency} ${purchase.grandTotal.toFixed(2)}.`,
    });

    this.saveToFile();
    return { success: true, purchase, stockUpdates };
  }

  public voidPurchase(id: string, reason: string, author = 'Store Keeper'): PurchaseRecord {
    if (!this.data.purchases) this.data.purchases = [];
    const purchase = this.data.purchases.find((p) => p.id === id);
    if (!purchase) {
      throw new Error(`Purchase record not found: ID ${id}`);
    }

    const now = new Date().toISOString();
    purchase.status = 'Voided';
    purchase.updatedAt = now;

    if (!purchase.auditTrail) purchase.auditTrail = [];
    purchase.auditTrail.push({
      timestamp: now,
      user: author,
      action: 'VOIDED',
      note: `Invoice voided: ${reason || 'No reason provided'}`,
    });

    this.logActivity({
      action: 'Purchase Voided',
      targetType: 'Purchase Record',
      targetName: `Invoice #${purchase.invoiceNumber} (${purchase.supplierName})`,
      user: author,
      details: `Voided purchase invoice ${purchase.invoiceNumber}. Reason: ${reason}.`,
    });

    this.saveToFile();
    return purchase;
  }

  public deletePurchase(id: string, author = 'Store Keeper'): boolean {
    if (!this.data.purchases) this.data.purchases = [];
    const index = this.data.purchases.findIndex((p) => p.id === id);
    if (index === -1) return false;

    const purchase = this.data.purchases[index];
    if (purchase.status === 'Confirmed') {
      throw new Error('Cannot delete a confirmed invoice. Please void it instead to preserve audit records.');
    }

    this.data.purchases.splice(index, 1);
    this.logActivity({
      action: 'Purchase Deleted',
      targetType: 'Purchase Record',
      targetName: `Draft Invoice #${purchase.invoiceNumber} (${purchase.supplierName})`,
      user: author,
      details: `Deleted draft purchase invoice ${purchase.invoiceNumber}.`,
    });

    this.saveToFile();
    return true;
  }

  public addTransfer(transferPayload: any, author = 'Supervisor'): TransferRecord {
    const now = new Date().toISOString();
    const newTransfer: TransferRecord = {
      id: `trf-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      transferCode: transferPayload.transferCode || `TRF-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
      itemId: transferPayload.itemId,
      itemName: transferPayload.itemName,
      quantity: Number(transferPayload.quantity) || 1,
      fromLocation: transferPayload.fromLocation || 'Main Store',
      toLocation: transferPayload.toLocation || 'Site A',
      transferDate: transferPayload.transferDate || now,
      initiatedBy: author,
      status: transferPayload.status || 'Pending',
      remarks: transferPayload.remarks || '',
      ...transferPayload,
    };

    this.data.transfers.unshift(newTransfer);

    this.logActivity({
      action: 'Transferred',
      targetType: 'Asset',
      targetName: newTransfer.itemName,
      user: author,
      details: `Initiated transfer of ${newTransfer.quantity} unit(s) from "${newTransfer.fromLocation}" to "${newTransfer.toLocation}".`,
    });

    this.saveToFile();
    return newTransfer;
  }

  public updateTransferStatus(id: string, status: TransferRecord['status'], author = 'Supervisor'): TransferRecord | null {
    const transfer = this.data.transfers.find((t) => t.id === id);
    if (transfer) {
      transfer.status = status;
      this.logActivity({
        action: 'Updated',
        targetType: 'Asset',
        targetName: transfer.itemName,
        user: author,
        details: `Transfer ${transfer.transferCode} status changed to ${status}.`,
      });
      this.saveToFile();
      return transfer;
    }
    return null;
  }

  public addRepair(repairPayload: any, author = 'Supervisor'): RepairRecord {
    const now = new Date().toISOString();
    const newRepair: RepairRecord = {
      id: `rep-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      repairCode: repairPayload.repairCode || `REP-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
      itemId: repairPayload.itemId,
      itemName: repairPayload.itemName,
      issueDescription: repairPayload.issueDescription || 'Requires repair/maintenance',
      sentDate: repairPayload.sentDate || now,
      handledBy: author,
      status: 'In Progress',
      ...repairPayload,
    };

    this.data.repairs.unshift(newRepair);

    this.logActivity({
      action: 'Sent for Repair',
      targetType: 'Asset',
      targetName: newRepair.itemName,
      user: author,
      details: `Item "${newRepair.itemName}" sent for repair: ${newRepair.issueDescription}.`,
    });

    this.saveToFile();
    return newRepair;
  }

  public updateRepairStatus(id: string, status: RepairRecord['status'], author = 'Supervisor'): RepairRecord | null {
    const repair = this.data.repairs.find((r) => r.id === id);
    if (repair) {
      repair.status = status;
      this.logActivity({
        action: 'Updated',
        targetType: 'Asset',
        targetName: repair.itemName,
        user: author,
        details: `Repair ${repair.repairCode} status updated to ${status}.`,
      });
      this.saveToFile();
      return repair;
    }
    return null;
  }

  public addLostItem(lostPayload: any, author = 'Supervisor'): LostItemRecord {
    const now = new Date().toISOString();
    const newLost: LostItemRecord = {
      id: `lst-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      lostCode: lostPayload.lostCode || `LST-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
      itemId: lostPayload.itemId,
      itemName: lostPayload.itemName,
      quantityLost: Number(lostPayload.quantityLost) || 1,
      reportedDate: lostPayload.reportedDate || now,
      location: lostPayload.location || 'Site',
      estimatedValue: Number(lostPayload.estimatedValue) || 0,
      incidentDetails: lostPayload.incidentDetails || 'Reported lost',
      actionTaken: lostPayload.actionTaken || 'Under Investigation',
      status: 'Reported',
      reportedBy: author,
      ...lostPayload,
    };

    this.data.lostItems.unshift(newLost);

    this.logActivity({
      action: 'Reported Lost',
      targetType: 'Asset',
      targetName: newLost.itemName,
      user: author,
      details: `Reported ${newLost.quantityLost} unit(s) of "${newLost.itemName}" lost at ${newLost.location}.`,
    });

    this.saveToFile();
    return newLost;
  }

  // ==========================================
  // WORKER OPERATIONS
  // ==========================================

  public getWorkers(): Worker[] {
    return this.data.workers;
  }

  public addWorker(workerData: any, author = 'Admin'): Worker {
    const now = new Date().toISOString();
    const newWorker: Worker = {
      id: workerData.id || `wrk-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      workerCode: workerData.workerCode || `WRK-${Math.floor(100 + Math.random() * 900)}`,
      employeeNumber: workerData.employeeNumber || workerData.badgeNumber || workerData.workerCode,
      name: workerData.name,
      trade: workerData.trade || 'General Worker',
      department: workerData.department || 'Site Operations',
      branch: workerData.branch || 'Main Branch',
      site: workerData.site || workerData.projectSite || 'Tuas Mega Logistics Depot',
      projectSite: workerData.projectSite || workerData.site || 'Tuas Mega Logistics Depot',
      company: workerData.company || 'MOUNTEC PTE LTD',
      phone: workerData.phone || '',
      email: workerData.email || '',
      status: workerData.status || 'Active',
      badgeNumber: workerData.badgeNumber || `BDG-${Math.floor(1000 + Math.random() * 9000)}`,
      assignedItemsCount: 0,
      overdueItemsCount: 0,
      joinedDate: workerData.joinedDate || workerData.joiningDate || now,
      joiningDate: workerData.joiningDate || workerData.joinedDate || now,
      createdAt: now,
      updatedAt: now,
      ...workerData,
    };

    this.data.workers.unshift(newWorker);

    this.logActivity({
      action: 'Created',
      targetType: 'Worker',
      targetName: newWorker.name,
      user: author,
      details: `Added new worker ${newWorker.name} (${newWorker.trade}) assigned to ${newWorker.projectSite || newWorker.site}.`,
    });

    this.saveToFile();
    return newWorker;
  }

  public updateWorker(id: string, updates: Partial<Worker>, author = 'Admin'): Worker | null {
    const idx = this.data.workers.findIndex((w) => w.id === id);
    if (idx !== -1) {
      this.data.workers[idx] = { 
        ...this.data.workers[idx], 
        ...updates, 
        updatedAt: new Date().toISOString() 
      };
      this.logActivity({
        action: 'Updated',
        targetType: 'Worker',
        targetName: this.data.workers[idx].name,
        user: author,
        details: `Updated worker record for ${this.data.workers[idx].name}.`,
      });
      this.saveToFile();
      return this.data.workers[idx];
    }
    return null;
  }

  public deleteWorker(id: string, author = 'Admin'): boolean {
    const idx = this.data.workers.findIndex((w) => w.id === id);
    if (idx !== -1) {
      const name = this.data.workers[idx].name;
      this.data.workers.splice(idx, 1);
      this.logActivity({
        action: 'Updated',
        targetType: 'Worker',
        targetName: name,
        user: author,
        details: `Deleted worker profile for ${name}.`,
      });
      this.saveToFile();
      return true;
    }
    return false;
  }

  /**
   * Clears all workers from the directory so user can register fresh workers.
   */
  public clearAllWorkers(author = 'System'): number {
    const count = this.data.workers ? this.data.workers.length : 0;
    this.data.workers = [];
    this.data.lastUpdated = new Date().toISOString();
    this.data.version = (this.data.version || 1) + 1;
    this.logActivity({
      action: 'Updated',
      targetType: 'Worker',
      targetName: 'All Workers Directory',
      user: author,
      details: `Cleared all workers from directory (${count} removed). Ready for new workforce entry.`,
    });
    this.saveToFile();
    return count;
  }

  /**
   * Restores initial sample enterprise workers.
   */
  public restoreDemoWorkers(author = 'System'): number {
    this.data.workers = [...(INITIAL_WORKERS || [])];
    this.data.lastUpdated = new Date().toISOString();
    this.data.version = (this.data.version || 1) + 1;
    this.logActivity({
      action: 'Created',
      targetType: 'Worker',
      targetName: 'Demo Workers Directory',
      user: author,
      details: 'Restored sample/demo workforce profiles.',
    });
    this.saveToFile();
    return this.data.workers.length;
  }

  /**
   * Clears all transactions (issues, returns, transfers, repairs, lost items, maintenance).
   */
  public clearAllTransactions(author = 'System'): {
    issues: number;
    returns: number;
    transfers: number;
    repairs: number;
    lostItems: number;
    maintenance: number;
  } {
    const counts = {
      issues: this.data.issues ? this.data.issues.length : 0,
      returns: this.data.returns ? this.data.returns.length : 0,
      transfers: this.data.transfers ? this.data.transfers.length : 0,
      repairs: this.data.repairs ? this.data.repairs.length : 0,
      lostItems: this.data.lostItems ? this.data.lostItems.length : 0,
      maintenance: this.data.maintenance ? this.data.maintenance.length : 0,
    };
    this.data.issues = [];
    this.data.returns = [];
    this.data.transfers = [];
    this.data.repairs = [];
    this.data.lostItems = [];
    this.data.maintenance = [];
    this.data.lastUpdated = new Date().toISOString();
    this.data.version = (this.data.version || 1) + 1;
    this.logActivity({
      action: 'Updated',
      targetType: 'System',
      targetName: 'All Transactions & Operations',
      user: author,
      details: 'Cleared all transaction history records (Issues, Returns, Transfers, Repairs, Lost Items, Maintenance).',
    });
    this.saveToFile();
    return counts;
  }

  /**
   * Complete clean slate: clears assets, workers, and transactions all together.
   */
  public clearAllSystemData(author = 'System'): {
    assets: number;
    workers: number;
    transactions: number;
  } {
    const assetCounts = this.clearAllAssets(author);
    const workerCount = this.clearAllWorkers(author);
    const txCounts = this.clearAllTransactions(author);
    const txTotal = txCounts.issues + txCounts.returns + txCounts.transfers + txCounts.repairs + txCounts.lostItems + txCounts.maintenance;
    return {
      assets: assetCounts.totalCleared,
      workers: workerCount,
      transactions: txTotal,
    };
  }

  // ==========================================
  // MAINTENANCE OPERATIONS
  // ==========================================

  public getMaintenanceRecords(): MaintenanceRecord[] {
    return this.data.maintenance || [];
  }

  public addMaintenanceRecord(data: any, author = 'Supervisor'): MaintenanceRecord {
    const newRecord: MaintenanceRecord = {
      id: `mnt-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      maintenanceCode: data.maintenanceCode || `MNT-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`,
      itemId: data.itemId,
      itemName: data.itemName,
      frequency: data.frequency || 'Monthly',
      lastMaintenance: data.lastMaintenance || new Date().toISOString(),
      nextMaintenance: data.nextMaintenance,
      responsiblePerson: data.responsiblePerson || author,
      status: data.status || 'Scheduled',
      ...data,
    };

    if (!this.data.maintenance) this.data.maintenance = [];
    this.data.maintenance.unshift(newRecord);

    this.logActivity({
      action: 'Created',
      targetType: 'Asset',
      targetName: newRecord.itemName,
      user: author,
      details: `Scheduled maintenance for ${newRecord.itemName} (${newRecord.frequency}).`,
    });

    this.saveToFile();
    return newRecord;
  }

  public updateMaintenanceRecord(id: string, updates: Partial<MaintenanceRecord>, author = 'Supervisor'): MaintenanceRecord | null {
    if (!this.data.maintenance) return null;
    const idx = this.data.maintenance.findIndex((m) => m.id === id);
    if (idx !== -1) {
      this.data.maintenance[idx] = { ...this.data.maintenance[idx], ...updates };
      this.saveToFile();
      return this.data.maintenance[idx];
    }
    return null;
  }

  // ==========================================
  // ACTIVITY & AUDIT LOGS
  // ==========================================

  public logActivity(activity: Omit<ActivityLog, 'id' | 'timestamp'>): ActivityLog {
    const newLog: ActivityLog = {
      id: `act-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      ...activity,
    };

    this.data.activities.unshift(newLog);
    if (this.data.activities.length > 500) {
      this.data.activities = this.data.activities.slice(0, 500); // keep recent 500
    }

    return newLog;
  }

  public getActivities(limit = 100): ActivityLog[] {
    return this.data.activities.slice(0, limit);
  }

  // ==========================================
  // NOTIFICATIONS
  // ==========================================

  public getNotifications(): Notification[] {
    return this.data.notifications || [];
  }

  public addNotification(notif: Omit<Notification, 'id' | 'createdAt'>): Notification {
    const newNotif: Notification = {
      id: `notif-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      createdAt: new Date().toISOString(),
      ...notif,
    };

    if (!this.data.notifications) this.data.notifications = [];
    this.data.notifications.unshift(newNotif);
    this.saveToFile();
    return newNotif;
  }

  public markNotificationAsRead(id: string): boolean {
    if (!this.data.notifications) return false;
    const notif = this.data.notifications.find((n) => n.id === id);
    if (notif) {
      notif.read = true;
      (notif as any).status = 'Read';
      this.saveToFile();
      return true;
    }
    return false;
  }

  // ==========================================
  // ADMIN & SYSTEM SETTINGS
  // ==========================================

  public updateCompanyProfile(profile: any, author = 'Super Admin'): any {
    this.data.companyProfile = { ...this.data.companyProfile, ...profile };
    this.logActivity({
      action: 'Updated',
      targetType: 'System',
      targetName: 'Company Profile',
      user: author,
      details: `Updated MOUNTEC company profile and settings.`,
    });
    this.saveToFile();
    return this.data.companyProfile;
  }

  public updateAppSettings(settings: any, author = 'Super Admin'): any {
    this.data.appSettings = { ...this.data.appSettings, ...settings };
    this.saveToFile();
    return this.data.appSettings;
  }

  public updateAuthorizedUsers(users: any[], author = 'Super Admin'): any[] {
    this.data.authorizedUsers = users;
    this.logActivity({
      action: 'Updated',
      targetType: 'System',
      targetName: 'Authorized Users Whitelist',
      user: author,
      details: `Updated whitelist governance table (${users.length} authorized emails).`,
    });
    this.saveToFile();
    return this.data.authorizedUsers;
  }

  public updateAdminUsers(users: any[], author = 'Super Admin'): any[] {
    this.data.users = users;
    this.saveToFile();
    return this.data.users;
  }

  public isSuperAdminEmail(email?: string): boolean {
    if (!email || typeof email !== 'string') return false;
    const normalized = email.trim().toLowerCase();
    const envEmail = (process.env.AUTHORIZED_GOOGLE_EMAIL || '').trim().toLowerCase();
    return (
      normalized === 'vickykartik12032004@gmail.com' ||
      normalized === 'admin@mountec.com' ||
      normalized === 'vs5954613@gmail.com' ||
      (Boolean(envEmail) && normalized === envEmail)
    );
  }

  public getAuthorizedGoogleEmail(): string {
    return process.env.AUTHORIZED_GOOGLE_EMAIL?.trim().toLowerCase() || 'vickykartik12032004@gmail.com';
  }

  public getAccessRequests(): AccessRequest[] {
    return this.data.accessRequests || [];
  }

  public getAccessRequestById(id: string): AccessRequest | null {
    return this.getAccessRequests().find(r => r.id === id) || null;
  }

  public getAccessRequestByGoogleId(googleId: string): AccessRequest | null {
    if (!googleId) return null;
    return this.getAccessRequests().find(r => r.googleId === googleId) || null;
  }

  public getAccessRequestByEmail(email: string): AccessRequest | null {
    const normalized = email.trim().toLowerCase();
    return this.getAccessRequests().find(r => r.googleEmail.trim().toLowerCase() === normalized) || null;
  }

  public updateAccessRequest(id: string, updates: Partial<AccessRequest>): AccessRequest | null {
    const reqIndex = this.data.accessRequests.findIndex(r => r.id === id);
    if (reqIndex === -1) return null;
    
    this.data.accessRequests[reqIndex] = {
      ...this.data.accessRequests[reqIndex],
      ...updates
    };
    
    this.saveToFile();
    return this.data.accessRequests[reqIndex];
  }

  public createAccessRequest(request: Partial<AccessRequest>): AccessRequest {
    const newRequest: AccessRequest = {
      id: `req-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      googleId: request.googleId,
      googleName: request.googleName || '',
      googleEmail: request.googleEmail?.trim().toLowerCase() || '',
      avatar: request.avatar,
      status: request.status || 'PENDING',
      requestedAt: request.requestedAt || new Date().toISOString(),
      assignedRole: request.assignedRole || 'Worker',
    };
    
    if (!this.data.accessRequests) {
      this.data.accessRequests = [];
    }
    
    this.data.accessRequests.push(newRequest);
    this.saveToFile();
    return newRequest;
  }

  public findAuthorizedUser(email?: string, name?: string, avatar?: string, googleId?: string): { isAuthorized: boolean; status: AccessStatus; user?: any; request?: AccessRequest; error?: string } {
    if (!email || typeof email !== 'string') {
      return {
        isAuthorized: false,
        status: 'REJECTED',
        error: 'Invalid email provided.'
      };
    }
    
    const normalized = email.trim().toLowerCase();
    const isSuperAdmin = this.isSuperAdminEmail(normalized);
    
    // Check if a request already exists by googleId first, then fallback to email
    let request = (googleId ? this.getAccessRequestByGoogleId(googleId) : null) || this.getAccessRequestByEmail(normalized);
    
    // If request exists but doesn't have googleId yet, link it
    if (request && googleId && !request.googleId) {
      request = this.updateAccessRequest(request.id, { googleId }) || request;
    }

    if (isSuperAdmin) {
      if (!request) {
        request = this.createAccessRequest({
          googleEmail: normalized,
          googleId: googleId,
          googleName: name || 'Vicky Kartik (Super Admin)',
          avatar: avatar,
          status: 'APPROVED',
          assignedRole: 'Super Admin',
          requestedAt: new Date().toISOString()
        });
      } else if (request.status !== 'APPROVED') {
        // Force super admin to be approved
        request = this.updateAccessRequest(request.id, { status: 'APPROVED', assignedRole: 'Super Admin' }) || request;
      }
    } else {
      const isKnownUser =
        (this.data.authorizedUsers && this.data.authorizedUsers.some(u => (u.googleEmail || '').trim().toLowerCase() === normalized)) ||
        (this.data.users && this.data.users.some(u => (u.email || '').trim().toLowerCase() === normalized));

      if (isKnownUser && !request) {
        request = this.createAccessRequest({
          googleEmail: normalized,
          googleId: googleId,
          googleName: name || 'Authorized User',
          avatar: avatar,
          status: 'APPROVED',
          assignedRole: 'Admin',
          requestedAt: new Date().toISOString()
        });
      } else if (!request) {
        return {
          isAuthorized: false,
          status: 'NEW' as any,
          error: 'Your account has not been approved by the Super Admin.'
        };
      } else if (request.status === 'REVOKED') {
        return {
          isAuthorized: false,
          status: 'REVOKED',
          request,
          error: 'Your access has been revoked by the Super Admin.'
        };
      } else if (request.status === 'PENDING') {
        return {
          isAuthorized: false,
          status: 'PENDING',
          request,
          error: 'Your access request has been sent to the Super Admin. Please wait until your request is approved.'
        };
      } else if (request.status === 'REJECTED') {
        return {
          isAuthorized: false,
          status: 'REJECTED',
          request,
          error: 'Your access request was rejected.'
        };
      }
    }

    if (!request || request.status !== 'APPROVED') {
       return {
          isAuthorized: false,
          status: request?.status || 'REJECTED',
          request: request || undefined,
          error: 'Access Denied.'
       };
    }

    // Return the authorized account profile for APPROVED users
    const governedUser = {
      id: `auth-usr-${request.id}`,
      googleId: request.googleId,
      email: normalized,
      name: request.googleName || normalized.split('@')[0],
      role: request.assignedRole || 'Worker',
      department: request.department || 'Operations',
      branch: 'Main HQ',
      site: request.site || 'Main Site',
      assignedSites: [],
      allSitesAccess: request.assignedRole === 'Super Admin' || request.assignedRole === 'Admin',
      phone: '',
      avatar: request.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150',
      accountStatus: 'Active',
      lastLogin: new Date().toISOString(),
      createdAt: request.requestedAt,
    };

    return {
      isAuthorized: true,
      status: 'APPROVED',
      request,
      user: governedUser
    };
  }

  public verifyGoogleUser(
    email?: string,
    profile?: { name?: string; avatar?: string; googleId?: string }
  ): { success: boolean; status?: AccessStatus; user?: any; session?: any; request?: AccessRequest; error?: string } {
    if (!email || typeof email !== 'string') {
      return {
        success: false,
        error: 'Valid Google email address is required.'
      };
    }

    const normalized = email.trim().toLowerCase();
    const authResult = this.findAuthorizedUser(normalized, profile?.name, profile?.avatar, profile?.googleId);

    if (!authResult.isAuthorized || !authResult.user) {
      if (authResult.status !== 'PENDING') {
        // Record security audit trail for unauthorized attempt
        this.logActivity({
          action: 'Updated',
          targetType: 'System',
          targetName: 'Authentication Governance',
          user: normalized.includes('@') ? normalized.split('@')[0] : 'Unknown',
          details: `Access Denied: Blocked unauthorized Google login attempt for ${normalized}. Only authorized company accounts are permitted.`,
        });
      }

      return {
        success: false,
        status: authResult.status,
        request: authResult.request,
        error: authResult.error || 'This Google account is not authorized to access MOUNTEC.'
      };
    }

    const user = {
      ...authResult.user,
      name: profile?.name || authResult.user.name,
      avatar: profile?.avatar || authResult.user.avatar,
      lastLogin: new Date().toISOString(),
    };

    // Update last login
    if (Array.isArray(this.data.users)) {
      const existingIdx = this.data.users.findIndex(
        (u: any) => u?.email && typeof u.email === 'string' && u.email.trim().toLowerCase() === normalized
      );
      if (existingIdx !== -1) {
        this.data.users[existingIdx].lastLogin = user.lastLogin;
      }
    }

    // Generate secure session token
    const token = `sess_g_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;
    const expiresAt = Date.now() + 24 * 60 * 60 * 1000; // 24 hours

    // Record successful login audit trail
    this.logActivity({
      action: 'Updated',
      targetType: 'System',
      targetName: 'Authentication Governance',
      user: user.name,
      details: `Successful Google Sign-In for ${user.name} (${user.email}) as authorized ${user.role}.`,
    });

    this.saveToFile();

    return {
      success: true,
      user,
      session: {
        token,
        sessionId: `sess_${Date.now()}`,
        userId: user.id,
        email: user.email,
        userEmail: user.email,
        userName: user.name,
        role: user.role,
        userRole: user.role,
        createdAt: Date.now(),
        issuedAt: Date.now(),
        expiresAt,
        rememberMe: true,
      }
    };
  }

  public updateRoles(roles: any[], author = 'Super Admin'): any[] {
    this.data.roles = roles;
    this.saveToFile();
    return this.data.roles;
  }
}

export const cloudDb = new CentralCloudDatabase();
