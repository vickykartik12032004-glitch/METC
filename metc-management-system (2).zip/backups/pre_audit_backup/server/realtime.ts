import { Response } from 'express';

export interface RealtimeClient {
  id: string;
  userId?: string;
  res: Response;
  connectedAt: string;
}

class RealtimeHub {
  private clients: Map<string, RealtimeClient> = new Map();
  private heartbeatTimer: NodeJS.Timeout | null = null;
  private version: number = 1;

  constructor() {
    this.startHeartbeat();
  }

  public getClientCount(): number {
    return this.clients.size;
  }

  public addClient(id: string, res: Response, userId?: string): void {
    // Setup SSE headers with immediate flush
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      'Connection': 'keep-alive',
      'Access-Control-Allow-Origin': '*',
      'X-Accel-Buffering': 'no',
    });

    if (typeof (res as any).flushHeaders === 'function') {
      (res as any).flushHeaders();
    }

    if (res.socket) {
      res.socket.setKeepAlive(true);
      res.socket.setNoDelay(true);
    }

    res.write(`event: connected\ndata: ${JSON.stringify({ 
      clientId: id, 
      connectedAt: new Date().toISOString(),
      version: this.version 
    })}\n\n`);

    this.clients.set(id, { id, userId, res, connectedAt: new Date().toISOString() });

    res.on('close', () => {
      this.clients.delete(id);
    });

    res.on('error', () => {
      this.clients.delete(id);
    });
  }

  public removeClient(id: string): void {
    const client = this.clients.get(id);
    if (client) {
      try {
        client.res.end();
      } catch (e) {
        // ignore
      }
      this.clients.delete(id);
    }
  }

  public broadcast(event: string, data: any, sourceUserId?: string): void {
    this.version++;
    const payload = JSON.stringify({
      event,
      data,
      sourceUserId,
      version: this.version,
      timestamp: new Date().toISOString(),
    });

    for (const [id, client] of this.clients.entries()) {
      try {
        client.res.write(`event: ${event}\ndata: ${payload}\n\n`);
      } catch (err) {
        console.error(`Failed to send event to client ${id}:`, err);
        this.clients.delete(id);
      }
    }
  }

  private startHeartbeat(): void {
    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);
    this.heartbeatTimer = setInterval(() => {
      for (const [id, client] of this.clients.entries()) {
        try {
          client.res.write(`event: ping\ndata: ${JSON.stringify({ time: new Date().toISOString(), version: this.version })}\n\n`);
        } catch (err) {
          this.clients.delete(id);
        }
      }
    }, 12000);
  }
}

export const realtimeHub = new RealtimeHub();
