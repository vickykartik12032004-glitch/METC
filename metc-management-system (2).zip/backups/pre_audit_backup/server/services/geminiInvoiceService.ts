import { GoogleGenAI, Type } from '@google/genai';
import { ExtractedInvoiceData } from '../../src/types/purchase.types';

export interface InvoiceFilePart {
  mimeType: string;
  base64Data: string;
}

export async function extractInvoiceDataWithGemini(
  fileParts: InvoiceFilePart[]
): Promise<ExtractedInvoiceData> {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY' || apiKey.trim() === '') {
    throw new Error(
      'GEMINI_API_KEY is not configured on the server. Please add your GEMINI_API_KEY in the Settings > Secrets panel in AI Studio.'
    );
  }

  if (!fileParts || fileParts.length === 0) {
    throw new Error('No invoice image or PDF file provided for extraction.');
  }

  const ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  const prompt = `You are an expert construction, industrial supply, and engineering materials invoice OCR & data extraction specialist for MOUNTEC PTE LTD (Singapore).

Carefully examine this invoice document (which may be a photo, scan, or PDF, and may span multiple pages with 30-50+ line items).
Accurately extract all structured data according to the schema provided.

Key Instructions:
1. SUPPLIER: Extract full company name, registered address, telephone, email, and tax/GST/UEN registration number if visible.
2. INVOICE DETAILS:
   - invoiceNumber: Extract exact invoice or tax invoice number.
   - invoiceDate: Standardize to YYYY-MM-DD if recognizable, or retain original string.
   - purchaseOrderNumber: Extract PO / DO / Quotation reference number if present.
   - paymentTerms: e.g. "Net 30 Days", "COD", "Cash", "Immediate", "30 Days from date of invoice".
   - currency: Default to "SGD" (Singapore Dollar) if "$" or SGD or Singapore vendor, otherwise USD, MYR, EUR, etc.
3. FINANCIAL SUMMARY:
   - subtotal: Net amount before tax/GST and shipping.
   - discountAmount: Total trade discount or promotional reduction (0 if none).
   - taxRate: Percentage (e.g. 9 for 9% GST in Singapore).
   - taxAmount: GST / VAT / Sales Tax total.
   - freightAmount: Shipping / Delivery / Transport charges (0 if none).
   - grandTotal: Final total payable.
4. LINE ITEMS (CRITICAL - DO NOT MISS ANY ROW):
   - Extract EVERY row from the invoice table. Support long tables with 30-50+ items.
   - description: Clean item name and specifications (e.g., "BOSCH ROTARY HAMMER 26MM", "REBAR T16 HIGH TENSILE 12M", "WELDING ELECTRODE E6013 3.2MM").
   - productCode: Vendor part code, catalog number, or SKU if visible (or empty string).
   - quantity: Numeric quantity purchased.
   - unit: Unit of measurement (e.g., NOS, PCS, BOX, ROLL, MTR, KG, SET, PKT, BDL, DRUM, LTR, SHEET).
   - unitPrice: Price per unit.
   - total: Line total (quantity * unitPrice after item discount).
   - categorySuggestion: Classify into exactly one of:
     * "Material" (raw construction materials: rebar, cement, timber, sand, pipes, steel beams)
     * "Equipment" (heavy or serialized machinery: generators, compressors, excavators, forklifts)
     * "Tool" (hand and power tools: drills, grinders, wrenches, pliers, meters)
     * "Consumable" (items consumed during work: drill bits, grinding discs, fuel, grease, welding rods, tape, nails)
     * "PPE" (safety equipment: helmets, safety shoes, vests, harnesses, goggles, earplugs)
   - confidence: Numeric score from 0.0 to 1.0 indicating OCR clarity and certainty for this row (use < 0.6 if faded, handwritten, or ambiguous).

Never guess or fabricate missing values. Return exact numbers.`;

  // Build content parts
  const contents: any[] = [];

  for (const part of fileParts) {
    contents.push({
      inlineData: {
        mimeType: part.mimeType,
        data: part.base64Data,
      },
    });
  }

  contents.push(prompt);

  const response = await ai.models.generateContent({
    model: 'gemini-3.8-flash',
    contents,
    config: {
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          supplier: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              contact: { type: Type.STRING },
              uenOrTaxNumber: { type: Type.STRING },
            },
            required: ['name'],
          },
          invoice: {
            type: Type.OBJECT,
            properties: {
              invoiceNumber: { type: Type.STRING },
              invoiceDate: { type: Type.STRING },
              purchaseOrderNumber: { type: Type.STRING },
              paymentTerms: { type: Type.STRING },
              currency: { type: Type.STRING },
            },
            required: ['invoiceNumber', 'invoiceDate', 'currency'],
          },
          financials: {
            type: Type.OBJECT,
            properties: {
              subtotal: { type: Type.NUMBER },
              taxRate: { type: Type.NUMBER },
              taxAmount: { type: Type.NUMBER },
              discountAmount: { type: Type.NUMBER },
              freightAmount: { type: Type.NUMBER },
              grandTotal: { type: Type.NUMBER },
            },
            required: ['subtotal', 'grandTotal'],
          },
          lineItems: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                description: { type: Type.STRING },
                productCode: { type: Type.STRING },
                quantity: { type: Type.NUMBER },
                unit: { type: Type.STRING },
                unitPrice: { type: Type.NUMBER },
                total: { type: Type.NUMBER },
                categorySuggestion: { 
                  type: Type.STRING,
                  enum: ['Material', 'Equipment', 'Tool', 'Consumable', 'PPE']
                },
                confidence: { type: Type.NUMBER },
              },
              required: ['description', 'quantity', 'unitPrice', 'total'],
            },
          },
          rawOcrNotes: { type: Type.STRING },
        },
        required: ['supplier', 'invoice', 'financials', 'lineItems'],
      },
    },
  });

  const text = response.text;
  if (!text) {
    throw new Error('Gemini returned an empty response. The invoice document may be blank or unreadable.');
  }

  try {
    const parsed = JSON.parse(text) as ExtractedInvoiceData;
    return parsed;
  } catch (err: any) {
    throw new Error(`Failed to parse AI extraction output: ${err.message}`);
  }
}
