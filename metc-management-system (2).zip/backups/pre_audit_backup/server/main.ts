import express from 'express';
import path from 'path';
import fs from 'fs';
import cors from 'cors';
import { createServer as createViteServer } from 'vite';
import { apiRouter } from './routes/api';

export async function startServer() {
  const app = express();
  // Dev server and container reverse-proxy in AI Studio strictly require port 3000
  const PORT = 3000;

  // Middlewares
  app.use(cors());
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  // API routes FIRST
  app.use('/api', apiRouter);

  // Vite middleware for development vs static files for production
  const candidateDist = path.join(process.cwd(), 'dist');
  const hasDist = fs.existsSync(path.join(candidateDist, 'index.html'));

  if (process.env.NODE_ENV === 'production' || hasDist) {
    const distPath = hasDist ? candidateDist : path.resolve(__dirname, '.');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[MOUNTEC CLOUD ENGINE] Server running on http://0.0.0.0:${PORT}`);
  });
}

// Start server on execution
startServer().catch((err) => {
  console.error('Fatal error starting server:', err);
});
