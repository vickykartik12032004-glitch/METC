import React from 'react';
import { WorkerMasterModule } from '../features/workers/WorkerMasterModule';

export const WorkersPage: React.FC = () => {
  return <WorkerMasterModule />;
};
