import { LoginPage } from './auth/LoginPage';

export const Login = LoginPage;
export default LoginPage;
