import React from 'react';
import { MOUNTECMasterModule } from '../features/metc/MOUNTECMasterModule';

export const Tools: React.FC = () => {
  return (
    <MOUNTECMasterModule
      defaultCategory="Tool"
      title="Tools & Power Instruments Management"
      subtitle="Track power drills, welding invertors, laser levels, pneumatic cutters, and hand tool kits"
    />
  );
};

export const ToolsPage = Tools;
export default Tools;
