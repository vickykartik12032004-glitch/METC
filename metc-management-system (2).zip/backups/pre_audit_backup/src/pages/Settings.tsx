import React, { useState, useRef } from 'react';
import { PageHeader } from '../components/layout/PageHeader';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Select } from '../components/ui/Select';
import { useThemeStore } from '../store/useThemeStore';
import { useAssetStore } from '../store/useAssetStore';
import { useWorkerStore } from '../store/useWorkerStore';
import { useTransactionStore } from '../store/useTransactionStore';
import { cloudApi } from '../services/apiClient';
import { DEFAULT_COMPANY } from '../constants';
import { 
  Building2, 
  Moon, 
  Sun, 
  Save, 
  Database, 
  Upload, 
  MapPin, 
  Phone, 
  Mail, 
  Globe, 
  FileText, 
  Plus, 
  Trash2, 
  RotateCcw, 
  AlertTriangle, 
  Boxes, 
  Users, 
  ReceiptText 
} from 'lucide-react';
import { toast } from 'sonner';

export const SettingsPage: React.FC = () => {
  const { isDarkMode, toggleDarkMode } = useThemeStore();
  const { clearAllAssets, restoreDemoData, getAllAssets } = useAssetStore();
  const { workers, clearAllWorkers, restoreDemoWorkers } = useWorkerStore();
  const { clearAllTransactions, issues } = useTransactionStore();
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [isWipingAll, setIsWipingAll] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [branches, setBranches] = useState([
    { id: 1, name: 'Main Office', address: '123 Business Park, #05-12' },
    { id: 2, name: 'North Site', address: '45 Industrial Estate Road' }
  ]);

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success('System settings saved successfully');
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setLogoPreview(url);
    }
  };

  const handleAddBranch = () => {
    setBranches([...branches, { id: Date.now(), name: '', address: '' }]);
  };

  const handleRemoveBranch = (id: number) => {
    setBranches(branches.filter(b => b.id !== id));
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Enterprise Configuration & Settings"
        description="Configure organization details, theme settings, security policies, and database parameters"
      />

      <form onSubmit={handleSaveSettings} className="space-y-6">
        {/* Company Branding Settings */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Building2 className="w-5 h-5 text-blue-500" />
              <CardTitle>Company Profile</CardTitle>
            </div>
            <CardDescription>Corporate identity displayed on invoices, export PDFs, and header banners</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-start gap-6">
              <div className="flex-shrink-0">
                <div 
                  className="w-32 h-32 rounded-xl border-2 border-dashed border-slate-300 dark:border-slate-700 flex flex-col items-center justify-center bg-slate-50 dark:bg-slate-800 cursor-pointer overflow-hidden relative hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                  onClick={() => fileInputRef.current?.click()}
                >
                  {logoPreview ? (
                    <img src={logoPreview} alt="Company Logo" className="w-full h-full object-cover" />
                  ) : (
                    <>
                      <Upload className="w-8 h-8 text-slate-400 mb-2" />
                      <span className="text-xs text-slate-500 font-medium">Upload Logo</span>
                    </>
                  )}
                  <input 
                    type="file" 
                    className="hidden" 
                    accept="image/*" 
                    ref={fileInputRef} 
                    onChange={handleLogoUpload}
                  />
                </div>
              </div>
              <div className="flex-1 space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <Input label="Company Name" defaultValue={DEFAULT_COMPANY.name} />
                  <Input label="Tagline" defaultValue={DEFAULT_COMPANY.tagline} />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <Input label="GST / UEN (Optional)" defaultValue="199512345M" icon={<FileText className="w-4 h-4" />} />
                  <Input label="Website" defaultValue="www.mountec.com" icon={<Globe className="w-4 h-4" />} />
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Input label="Primary Phone" defaultValue="+65 6789 0123" icon={<Phone className="w-4 h-4" />} />
              <Input label="Corporate Email" defaultValue="ops@mountec.com" icon={<Mail className="w-4 h-4" />} />
              <Input label="Headquarters Address" defaultValue="750 Construction Way, Suite 400" icon={<MapPin className="w-4 h-4" />} />
            </div>
          </CardContent>
        </Card>

        {/* Branch Management */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Branch Management</CardTitle>
                <CardDescription>Manage company branches, sites, and regional offices</CardDescription>
              </div>
              <Button type="button" variant="outline" size="sm" icon={<Plus className="w-4 h-4" />} onClick={handleAddBranch}>
                Add Branch
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {branches.map((branch, index) => (
              <div key={branch.id} className="flex items-start gap-4 p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/40">
                <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <Input 
                    placeholder="Branch Name (e.g. Main Office)" 
                    value={branch.name}
                    onChange={(e) => {
                      const newBranches = [...branches];
                      newBranches[index].name = e.target.value;
                      setBranches(newBranches);
                    }}
                  />
                  <Input 
                    placeholder="Full Address" 
                    value={branch.address}
                    onChange={(e) => {
                      const newBranches = [...branches];
                      newBranches[index].address = e.target.value;
                      setBranches(newBranches);
                    }}
                  />
                </div>
                <Button 
                  type="button" 
                  variant="outline" 
                  className="text-red-600 hover:bg-red-50 hover:text-red-700 hover:border-red-200 mt-0.5" 
                  onClick={() => handleRemoveBranch(branch.id)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            ))}
            {branches.length === 0 && (
              <div className="text-center py-6 text-sm text-slate-500">
                No branches configured. Click "Add Branch" to create one.
              </div>
            )}
          </CardContent>
        </Card>

        {/* Theme & Display Preferences */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              {isDarkMode ? <Moon className="w-5 h-5 text-purple-400" /> : <Sun className="w-5 h-5 text-amber-500" />}
              <CardTitle>Theme & Appearance</CardTitle>
            </div>
            <CardDescription>Switch theme mode and set density preferences</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
              <div>
                <p className="text-sm font-bold text-slate-900 dark:text-slate-100">Dark Mode Interface</p>
                <p className="text-xs text-slate-500">Enable high-contrast dark theme for night shifts and low light</p>
              </div>
              <Button type="button" variant="outline" size="sm" onClick={toggleDarkMode}>
                {isDarkMode ? 'Switch to Light' : 'Switch to Dark'}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Database Management & Clean Slate */}
        <Card className="border-rose-200/80 dark:border-rose-900/40">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Database className="w-5 h-5 text-rose-500" />
                <CardTitle>Data Management & Clean Slate</CardTitle>
              </div>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300 border border-rose-300 dark:border-rose-800">
                Data Reset
              </span>
            </div>
            <CardDescription>
              Wipe sample records to start fresh with your own assets, personnel, and records
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {/* Assets Card */}
              <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200">
                    <Boxes className="w-4 h-4 text-blue-500" />
                    <span>Inventory Assets</span>
                  </div>
                  <span className="text-xs font-mono font-bold text-slate-600 dark:text-slate-400">
                    {getAllAssets().length} items
                  </span>
                </div>
                <p className="text-[11px] text-slate-500">Materials, Equipment, Tools, Consumables & PPE.</p>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="w-full text-xs text-rose-600 dark:text-rose-400 border-rose-200 dark:border-rose-900/60 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                  icon={<Trash2 className="w-3.5 h-3.5" />}
                  onClick={async () => {
                    await clearAllAssets();
                    toast.success('All inventory assets cleared! Ready for new items.');
                  }}
                >
                  Clear Assets
                </Button>
              </div>

              {/* Workers Card */}
              <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200">
                    <Users className="w-4 h-4 text-amber-500" />
                    <span>Workforce Directory</span>
                  </div>
                  <span className="text-xs font-mono font-bold text-slate-600 dark:text-slate-400">
                    {workers.length} workers
                  </span>
                </div>
                <p className="text-[11px] text-slate-500">Registered personnel, site workers, and profile records.</p>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="w-full text-xs text-rose-600 dark:text-rose-400 border-rose-200 dark:border-rose-900/60 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                  icon={<Trash2 className="w-3.5 h-3.5" />}
                  onClick={async () => {
                    await clearAllWorkers();
                    toast.success('All workers cleared! Ready to add new workers.');
                  }}
                >
                  Clear Workers
                </Button>
              </div>

              {/* Transactions Card */}
              <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200">
                    <ReceiptText className="w-4 h-4 text-emerald-500" />
                    <span>Transactions</span>
                  </div>
                  <span className="text-xs font-mono font-bold text-slate-600 dark:text-slate-400">
                    {issues.length} active
                  </span>
                </div>
                <p className="text-[11px] text-slate-500">Issues, returns, transfers, repairs, and lost logs.</p>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="w-full text-xs text-rose-600 dark:text-rose-400 border-rose-200 dark:border-rose-900/60 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                  icon={<Trash2 className="w-3.5 h-3.5" />}
                  onClick={async () => {
                    await clearAllTransactions();
                    toast.success('All transactions cleared successfully.');
                  }}
                >
                  Clear Transactions
                </Button>
              </div>
            </div>

            {/* Complete Clean Slate Master Button */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0" />
                <span className="text-xs text-slate-600 dark:text-slate-400">
                  Want to clear everything at once or restore sample demo items?
                </span>
              </div>
              <div className="flex items-center gap-2 w-full sm:w-auto">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  icon={<RotateCcw className="w-3.5 h-3.5" />}
                  onClick={async () => {
                    await restoreDemoData();
                    await restoreDemoWorkers();
                    toast.info('Sample demo assets and workers restored.');
                  }}
                  className="text-xs text-slate-500"
                >
                  Restore Sample Data
                </Button>
                <Button
                  type="button"
                  variant="danger"
                  size="sm"
                  disabled={isWipingAll}
                  icon={<Trash2 className="w-3.5 h-3.5" />}
                  onClick={async () => {
                    setIsWipingAll(true);
                    try {
                      await cloudApi.clearAllSystemData();
                      await clearAllAssets(true);
                      await clearAllWorkers(true);
                      await clearAllTransactions(true);
                      toast.success('Clean slate complete! All assets, workers, and records cleared.');
                    } catch (e: any) {
                      toast.error('Failed to wipe data: ' + e.message);
                    } finally {
                      setIsWipingAll(false);
                    }
                  }}
                >
                  {isWipingAll ? 'Wiping...' : 'Clear All System Data'}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-end pt-4 pb-12">
          <Button variant="primary" size="lg" icon={<Save className="w-4 h-4" />} type="submit">
            Save System Configuration
          </Button>
        </div>
      </form>
    </div>
  );
};
