import React from 'react';
import { MOUNTECMasterModule } from '../features/metc/MOUNTECMasterModule';

export const Consumables: React.FC = () => {
  return (
    <MOUNTECMasterModule
      defaultCategory="Consumable"
      title="Consumables & Site Fuel Management"
      subtitle="Track diesel fuel, lubricants, welding electrodes, drill bits, grinding discs, and adhesive tapes"
    />
  );
};

export default Consumables;
