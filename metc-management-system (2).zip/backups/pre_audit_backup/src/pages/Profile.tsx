import React, { useState } from 'react';
import { PageHeader } from '../components/layout/PageHeader';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../components/ui/Card';
import { Avatar } from '../components/ui/Avatar';
import { RoleBadge } from '../components/common/RoleBadge';
import { Input } from '../components/ui/Input';
import { Button } from '../components/ui/Button';
import { useAuth } from '../hooks/useAuth';
import { useRole } from '../hooks/useRole';
import { usePermissions } from '../hooks/usePermissions';
import { 
  User as UserIcon, 
  Mail, 
  Phone, 
  Building2, 
  Save, 
  Camera, 
  KeyRound, 
  ShieldCheck, 
  Lock, 
  MapPin, 
  Briefcase, 
  CheckCircle2, 
  XCircle,
  Eye,
  EyeOff,
  Loader2
} from 'lucide-react';
import { toast } from 'sonner';
import { PasswordStrengthMeter, evaluatePassword } from '../features/auth/PasswordStrengthMeter';
import { uploadAvatarImage } from '../services/auth.service';

export const ProfilePage: React.FC = () => {
  const { user, updateProfile, changePassword } = useAuth();
  const { role } = useRole();
  const { permissions } = usePermissions();

  const [activeTab, setActiveTab] = useState<'info' | 'security' | 'permissions'>('info');

  // Personal Info Form State
  const [name, setName] = useState(user?.name || '');
  const [phone, setPhone] = useState(user?.phone || '+1 (555) 234-5678');
  const [department, setDepartment] = useState(user?.department || 'Operations');
  const [site, setSite] = useState(user?.projectSite || 'HQ - Tower A');
  const [isUpdatingInfo, setIsUpdatingInfo] = useState(false);

  // Photo Upload State
  const [avatarPreview, setAvatarPreview] = useState(user?.avatar || '');
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);

  // Password Change Form State
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [isChangingPassword, setIsChangingPassword] = useState(false);

  const passwordEvaluation = evaluatePassword(newPassword);

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsUpdatingInfo(true);
    const res = await updateProfile({
      name,
      phone,
      department,
    });
    setIsUpdatingInfo(false);
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    if (file.size > 5 * 1024 * 1024) {
      toast.error('Image size must be less than 5MB.');
      return;
    }

    try {
      setIsUploadingPhoto(true);
      const url = await uploadAvatarImage(user.id, file);
      setAvatarPreview(url);
      await updateProfile({ avatar: url });
      toast.success('Profile photo updated successfully!');
    } catch (err: any) {
      toast.error('Failed to upload profile photo.');
    } finally {
      setIsUploadingPhoto(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!newPassword) {
      toast.error('Please enter a new password.');
      return;
    }

    if (newPassword !== confirmPassword) {
      toast.error('New passwords do not match.');
      return;
    }

    if (passwordEvaluation.score < 3) {
      toast.error('Please choose a stronger password satisfying all security rules.');
      return;
    }

    setIsChangingPassword(true);
    const res = await changePassword(newPassword);
    setIsChangingPassword(false);

    if (res.success) {
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    }
  };

  const allPossiblePermissions = [
    { key: 'view_dashboard', label: 'View Analytics Dashboard', group: 'Dashboard' },
    { key: 'view_assets', label: 'View Inventory Assets', group: 'Assets' },
    { key: 'manage_assets', label: 'Create & Manage Assets', group: 'Assets' },
    { key: 'view_workers', label: 'View Worker Registry', group: 'Workers' },
    { key: 'manage_workers', label: 'Manage Workers & Assignments', group: 'Workers' },
    { key: 'issue_items', label: 'Issue Items to Workers', group: 'Transactions' },
    { key: 'return_items', label: 'Receive Item Returns', group: 'Transactions' },
    { key: 'transfer_items', label: 'Transfer Assets Between Sites', group: 'Transactions' },
    { key: 'repair_items', label: 'Manage Repair Logistics', group: 'Maintenance' },
    { key: 'report_lost', label: 'Report Lost & Damaged Items', group: 'Audit' },
    { key: 'view_reports', label: 'Access System Reports', group: 'Reports' },
    { key: 'export_reports', label: 'Export Data to Excel & PDF', group: 'Reports' },
    { key: 'manage_settings', label: 'Configure System Settings', group: 'Admin' },
    { key: 'manage_users', label: 'Manage Users & Permissions', group: 'Admin' },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="User Profile & Account"
        description="Manage your profile information, contact numbers, security credentials, and view system access privileges."
      />

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column - Profile Card */}
        <Card className="lg:col-span-1 shadow-md">
          <CardContent className="p-6 text-center space-y-5">
            {/* Avatar Upload Container */}
            <div className="relative inline-block mx-auto group">
              <Avatar
                name={user?.name || 'User'}
                src={avatarPreview || user?.avatar}
                size="xl"
                className="mx-auto ring-4 ring-blue-500/20 shadow-lg"
              />
              <label
                htmlFor="photo-upload"
                className="absolute bottom-0 right-0 w-9 h-9 rounded-full bg-blue-600 hover:bg-blue-500 text-white flex items-center justify-center shadow-md cursor-pointer transition-transform duration-200 hover:scale-105"
                title="Upload Profile Photo"
              >
                {isUploadingPhoto ? <Loader2 className="w-4 h-4 animate-spin" /> : <Camera className="w-4 h-4" />}
                <input
                  id="photo-upload"
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handlePhotoUpload}
                  disabled={isUploadingPhoto}
                />
              </label>
            </div>

            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">{user?.name}</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{user?.email}</p>
            </div>

            <div className="flex justify-center">
              <RoleBadge role={role} />
            </div>

            {/* Profile Attributes List */}
            <div className="pt-4 border-t border-slate-200 dark:border-slate-800 text-xs text-left space-y-2.5">
              <div className="flex items-center gap-2.5 text-slate-600 dark:text-slate-300">
                <Building2 className="w-4 h-4 text-blue-500 shrink-0" />
                <span>Department: <strong className="font-semibold text-slate-900 dark:text-slate-100">{user?.department || 'Operations'}</strong></span>
              </div>

              <div className="flex items-center gap-2.5 text-slate-600 dark:text-slate-300">
                <MapPin className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>Site / Branch: <strong className="font-semibold text-slate-900 dark:text-slate-100">{user?.projectSite || 'HQ Main'}</strong></span>
              </div>

              <div className="flex items-center gap-2.5 text-slate-600 dark:text-slate-300">
                <Briefcase className="w-4 h-4 text-amber-500 shrink-0" />
                <span>Company: <strong className="font-semibold text-slate-900 dark:text-slate-100">MOUNTEC PTE LTD</strong></span>
              </div>

              <div className="flex items-center gap-2.5 text-slate-600 dark:text-slate-300">
                <Phone className="w-4 h-4 text-indigo-500 shrink-0" />
                <span>Phone: <strong className="font-semibold text-slate-900 dark:text-slate-100">{user?.phone || '+1 (555) 234-5678'}</strong></span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Right Column - Tabs & Content */}
        <div className="lg:col-span-2 space-y-4">
          {/* Tabs Selector Header */}
          <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2">
            <button
              onClick={() => setActiveTab('info')}
              className={`px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 transition-colors ${
                activeTab === 'info'
                  ? 'bg-blue-600 text-white shadow'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <UserIcon className="w-4 h-4" />
              <span>Personal Details</span>
            </button>

            <button
              onClick={() => setActiveTab('security')}
              className={`px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 transition-colors ${
                activeTab === 'security'
                  ? 'bg-blue-600 text-white shadow'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <KeyRound className="w-4 h-4" />
              <span>Security & Password</span>
            </button>

            <button
              onClick={() => setActiveTab('permissions')}
              className={`px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 transition-colors ${
                activeTab === 'permissions'
                  ? 'bg-blue-600 text-white shadow'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Role Permissions</span>
            </button>
          </div>

          {/* TAB 1: PERSONAL DETAILS */}
          {activeTab === 'info' && (
            <Card className="shadow-md">
              <CardHeader>
                <CardTitle>Account Details</CardTitle>
                <CardDescription>Update your personal information and contact numbers.</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleUpdateProfile} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                        Full Name
                      </label>
                      <Input
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        leftIcon={<UserIcon className="w-4 h-4" />}
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                        Work Email (Read Only)
                      </label>
                      <Input
                        value={user?.email || ''}
                        disabled
                        leftIcon={<Mail className="w-4 h-4" />}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                        Phone Contact Number
                      </label>
                      <Input
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        leftIcon={<Phone className="w-4 h-4" />}
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                        Assigned Department
                      </label>
                      <Input
                        value={department}
                        onChange={(e) => setDepartment(e.target.value)}
                        leftIcon={<Building2 className="w-4 h-4" />}
                      />
                    </div>
                  </div>

                  <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex justify-end">
                    <Button
                      variant="primary"
                      type="submit"
                      disabled={isUpdatingInfo}
                      icon={isUpdatingInfo ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                    >
                      {isUpdatingInfo ? 'Saving Changes...' : 'Save Profile Changes'}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          )}

          {/* TAB 2: CHANGE PASSWORD */}
          {activeTab === 'security' && (
            <Card className="shadow-md">
              <CardHeader>
                <CardTitle>Change Password</CardTitle>
                <CardDescription>
                  Ensure your account security by updating your password regularly.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleChangePassword} className="space-y-4">
                  {/* Current Password */}
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Current Password
                    </label>
                    <div className="relative">
                      <Input
                        type={showCurrentPassword ? 'text' : 'password'}
                        value={currentPassword}
                        onChange={(e) => setCurrentPassword(e.target.value)}
                        placeholder="Enter current password"
                        leftIcon={<Lock className="w-4 h-4" />}
                      />
                      <button
                        type="button"
                        onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                        className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                      >
                        {showCurrentPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  {/* New Password */}
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      New Password
                    </label>
                    <div className="relative">
                      <Input
                        type={showNewPassword ? 'text' : 'password'}
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        placeholder="Enter strong new password"
                        leftIcon={<Lock className="w-4 h-4" />}
                      />
                      <button
                        type="button"
                        onClick={() => setShowNewPassword(!showNewPassword)}
                        className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                      >
                        {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>

                    <PasswordStrengthMeter password={newPassword} />
                  </div>

                  {/* Confirm Password */}
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Confirm New Password
                    </label>
                    <Input
                      type="password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Repeat new password"
                      leftIcon={<Lock className="w-4 h-4" />}
                    />
                  </div>

                  <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex justify-end">
                    <Button
                      variant="primary"
                      type="submit"
                      disabled={isChangingPassword}
                      icon={isChangingPassword ? <Loader2 className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
                    >
                      {isChangingPassword ? 'Updating Password...' : 'Update Password'}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          )}

          {/* TAB 3: ROLE PERMISSIONS */}
          {activeTab === 'permissions' && (
            <Card className="shadow-md">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Role Permissions Matrix</CardTitle>
                    <CardDescription>
                      System privileges associated with your current role ({role}).
                    </CardDescription>
                  </div>
                  <RoleBadge role={role} />
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {allPossiblePermissions.map((perm) => {
                    const isGranted = permissions.includes(perm.key as any);
                    return (
                      <div
                        key={perm.key}
                        className={`p-3 rounded-xl border flex items-center justify-between text-xs transition-colors ${
                          isGranted
                            ? 'bg-emerald-500/5 border-emerald-500/30 dark:bg-emerald-950/20 text-slate-800 dark:text-slate-200'
                            : 'bg-slate-100/50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 text-slate-400 opacity-60'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          {isGranted ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                          ) : (
                            <XCircle className="w-4 h-4 text-slate-400 shrink-0" />
                          )}
                          <div>
                            <p className="font-semibold">{perm.label}</p>
                            <p className="text-[10px] text-slate-500 dark:text-slate-400">{perm.group}</p>
                          </div>
                        </div>

                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            isGranted
                              ? 'bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300'
                              : 'bg-slate-200 dark:bg-slate-700 text-slate-500'
                          }`}
                        >
                          {isGranted ? 'Granted' : 'Restricted'}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
