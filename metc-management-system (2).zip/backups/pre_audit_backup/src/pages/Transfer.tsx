import React from 'react';
import { TransferMasterModule } from '../features/transfer/TransferMasterModule';

export const TransferPage: React.FC = () => {
  return (
    <div className="space-y-6">
      <TransferMasterModule />
    </div>
  );
};
