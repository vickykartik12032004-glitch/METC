import React from 'react';
import { MaintenanceMasterModule } from '../features/maintenance/MaintenanceMasterModule';

export const MaintenancePage: React.FC = () => {
  return (
    <div className="space-y-6">
      <MaintenanceMasterModule />
    </div>
  );
};
