import React from 'react';
import { MOUNTECMasterModule } from '../features/metc/MOUNTECMasterModule';

export const Equipment: React.FC = () => {
  return (
    <MOUNTECMasterModule
      defaultCategory="Equipment"
      title="Heavy Equipment & Machinery Management"
      subtitle="Track heavy excavators, cranes, generators, compaction rollers, and site machinery fleet"
    />
  );
};

export const EquipmentPage = Equipment;
export default Equipment;
