import React from 'react';
import { ReturnMasterModule } from '../features/return/ReturnMasterModule';

export const ReturnPage: React.FC = () => {
  return (
    <div className="space-y-6">
      <ReturnMasterModule />
    </div>
  );
};
