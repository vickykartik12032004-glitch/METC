import React from 'react';
import { ReportsMasterModule } from '../features/reports/ReportsMasterModule';

export const ReportsPage: React.FC = () => {
  return (
    <div className="space-y-6">
      <ReportsMasterModule />
    </div>
  );
};
