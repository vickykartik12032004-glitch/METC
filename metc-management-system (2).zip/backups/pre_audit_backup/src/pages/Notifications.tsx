import React, { useState } from 'react';
import { PageHeader } from '../components/layout/PageHeader';
import { NotificationDashboard } from '../features/notifications/components/dashboard/NotificationDashboard';
import { NotificationCenter } from '../features/notifications/components/NotificationCenter';
import { SmartAlerts } from '../features/notifications/components/SmartAlerts';
import { ReminderRules } from '../features/notifications/components/ReminderRules';
import { EmailTemplates } from '../features/notifications/components/templates/EmailTemplates';
import { PushNotifications } from '../features/notifications/components/PushNotifications';
import { NotificationHistory } from '../features/notifications/components/history/NotificationHistory';
import { NotificationSettings } from '../features/notifications/components/NotificationSettings';
import {
  LayoutDashboard,
  Bell,
  AlertTriangle,
  Clock,
  Mail,
  Send,
  History,
  Settings
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const NotificationsPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<
    'dashboard' | 'center' | 'alerts' | 'rules' | 'templates' | 'push' | 'history' | 'settings'
  >('dashboard');

  const menuTabs = [
    { id: 'dashboard', label: 'Notification Dashboard', icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: 'center', label: 'Notification Center', icon: <Bell className="w-4 h-4" /> },
    { id: 'alerts', label: 'Smart Alerts', icon: <AlertTriangle className="w-4 h-4" /> },
    { id: 'rules', label: 'Reminder Rules', icon: <Clock className="w-4 h-4" /> },
    { id: 'templates', label: 'Email Templates', icon: <Mail className="w-4 h-4" /> },
    { id: 'push', label: 'Push Notifications', icon: <Send className="w-4 h-4" /> },
    { id: 'history', label: 'Notification History', icon: <History className="w-4 h-4" /> },
    { id: 'settings', label: 'Settings', icon: <Settings className="w-4 h-4" /> },
  ] as const;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Enterprise Notification & Alert Command System"
        description="MOUNTEC PTE LTD • In-App Notifications, Email Dispatches, Push Alerts, Smart Triggers & Reminder Engine"
      />

      {/* Main SubMenu Navigation */}
      <div className="border-b border-slate-200 dark:border-slate-800">
        <nav className="flex items-center gap-1 overflow-x-auto pb-1" aria-label="Notifications Main Menu">
          {menuTabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap shrink-0 ${
                activeTab === tab.id
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60'
              }`}
            >
              {tab.icon}
              {tab.label}
            </button>
          ))}
        </nav>
      </div>

      {/* Dynamic Tab Body */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.15 }}
        >
          {activeTab === 'dashboard' && <NotificationDashboard onNavigateTab={(tab: any) => setActiveTab(tab)} />}
          {activeTab === 'center' && <NotificationCenter />}
          {activeTab === 'alerts' && <SmartAlerts />}
          {activeTab === 'rules' && <ReminderRules />}
          {activeTab === 'templates' && <EmailTemplates />}
          {activeTab === 'push' && <PushNotifications />}
          {activeTab === 'history' && <NotificationHistory />}
          {activeTab === 'settings' && <NotificationSettings />}
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

export default NotificationsPage;
