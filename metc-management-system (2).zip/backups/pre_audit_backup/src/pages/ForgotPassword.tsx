import { ForgotPasswordPage } from './auth/ForgotPasswordPage';

export const ForgotPassword = ForgotPasswordPage;
export default ForgotPasswordPage;
