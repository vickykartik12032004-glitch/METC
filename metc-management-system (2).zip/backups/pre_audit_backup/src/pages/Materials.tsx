import React from 'react';
import { MOUNTECMasterModule } from '../features/metc/MOUNTECMasterModule';

export const Materials: React.FC = () => {
  return (
    <MOUNTECMasterModule
      defaultCategory="Material"
      title="Materials Inventory Management"
      subtitle="Track raw construction materials, structural rebar, cement, aggregates, and site chemical stocks"
    />
  );
};

export default Materials;
