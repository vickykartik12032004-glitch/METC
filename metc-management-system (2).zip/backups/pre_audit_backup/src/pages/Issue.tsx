import React from 'react';
import { IssueMasterModule } from '../features/issue/IssueMasterModule';

export const IssuePage: React.FC = () => {
  return <IssueMasterModule />;
};

