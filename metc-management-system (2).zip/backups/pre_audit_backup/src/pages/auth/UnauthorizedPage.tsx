import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { ShieldAlert, ArrowLeft, LayoutDashboard, Lock, MapPin, UserX, LogOut } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { Button } from '../../components/ui/Button';

export const UnauthorizedPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, role, logout } = useAuth();
  const reason = (location.state as any)?.reason;

  const isInactive = reason === 'account_inactive' || user?.accountStatus === 'Inactive' || user?.accountStatus === 'Deactivated' || user?.accountStatus === 'Locked';
  const isSiteRestricted = reason === 'site_restricted';

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl p-8 text-center shadow-2xl relative overflow-hidden backdrop-blur-md">
        {/* Glow accent */}
        <div className="absolute -top-12 -right-12 w-36 h-36 bg-rose-500/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-12 -left-12 w-36 h-36 bg-purple-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="w-20 h-20 mx-auto rounded-2xl bg-rose-950/60 border border-rose-800/60 text-rose-400 flex items-center justify-center mb-6 shadow-inner">
          {isInactive ? <UserX className="w-10 h-10" /> : isSiteRestricted ? <MapPin className="w-10 h-10" /> : <ShieldAlert className="w-10 h-10" />}
        </div>

        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-950/60 border border-rose-800/80 text-rose-400 text-xs font-semibold mb-3">
          <Lock className="w-3.5 h-3.5" />
          <span>{isInactive ? 'Account Disabled / Inactive' : isSiteRestricted ? 'Site Access Restricted' : 'Access Restricted (403)'}</span>
        </div>

        <h1 className="text-2xl font-black text-white tracking-tight mb-2">
          {isInactive ? 'Account Not Active' : isSiteRestricted ? 'Unauthorized Project Site' : 'Permission Required'}
        </h1>

        <p className="text-slate-400 text-xs mb-6 leading-relaxed">
          Account <strong className="text-slate-200 font-semibold">{user?.email || 'Current User'}</strong> ({role || 'Worker'})
          {isInactive
            ? ' has been marked inactive or disabled by an administrator. Please contact your Super Admin.'
            : isSiteRestricted
            ? ' is not authorized to access records or operations for this specific project site.'
            : ' does not have privilege to access this module.'}
        </p>

        <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 mb-6 text-left text-xs space-y-1.5">
          <p className="text-slate-300 font-semibold">Security Governance Rules:</p>
          <ul className="text-slate-400 list-disc list-inside space-y-1 text-[11px]">
            {isInactive ? (
              <>
                <li>Account status is set to Inactive, Deactivated, or Locked.</li>
                <li>Reach out to Super Admin at MOUNTEC Management for reactivation.</li>
              </>
            ) : isSiteRestricted ? (
              <>
                <li>You are assigned to specific authorized project sites only.</li>
                <li>Request Super Admin to grant you enterprise-wide or multi-site access.</li>
              </>
            ) : (
              <>
                <li>Super Admin controls module permissions for all 4 roles.</li>
                <li>Administrative and Configuration tools require Super Admin permission.</li>
              </>
            )}
          </ul>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <Button
            variant="outline"
            className="flex-1 bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700 cursor-pointer"
            onClick={async () => {
              await logout();
              navigate('/login', { replace: true });
            }}
          >
            <LogOut className="w-4 h-4 mr-2" />
            Sign Out / Switch Account
          </Button>

          <Button
            variant="primary"
            className="flex-1 bg-blue-600 hover:bg-blue-500 text-white font-semibold shadow-lg shadow-blue-600/20 cursor-pointer"
            onClick={() => navigate('/dashboard')}
          >
            <LayoutDashboard className="w-4 h-4 mr-2" />
            Dashboard
          </Button>
        </div>
      </div>
    </div>
  );
};

export default UnauthorizedPage;
