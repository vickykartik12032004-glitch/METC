import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  Lock,
  Mail,
  Eye,
  EyeOff,
  Loader2,
  Shield,
  AlertCircle,
  Clock,
  Sparkles,
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { getFirebaseRateLimit } from '../../services/firebaseAuth.service';

export const LoginPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { login, isAuthenticated, loading: authLoading } = useAuth();

  // Form State
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);

  // Status & Lockout State
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [lockoutRemaining, setLockoutRemaining] = useState<number>(0);

  const fromLocation = (location.state as any)?.from?.pathname || '/dashboard';

  // Redirect if already authenticated
  useEffect(() => {
    if (isAuthenticated && !authLoading) {
      navigate(fromLocation, { replace: true });
    }
  }, [isAuthenticated, authLoading, navigate, fromLocation]);

  // Initial check for active lockout
  useEffect(() => {
    const rateLimit = getFirebaseRateLimit();
    if (rateLimit.isLocked && rateLimit.remainingSeconds > 0) {
      setLockoutRemaining(rateLimit.remainingSeconds);
      setErrorMessage(`Too many failed attempts. Login is disabled for ${rateLimit.remainingSeconds}s.`);
    }
  }, []);

  // Lockout countdown timer
  useEffect(() => {
    if (lockoutRemaining <= 0) return;

    const interval = setInterval(() => {
      setLockoutRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setErrorMessage(null);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [lockoutRemaining]);

  // Handle Submit Form
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (lockoutRemaining > 0 || isSubmitting) return;

    const cleanEmail = email.trim();
    const cleanPassword = password;

    if (!cleanEmail || !cleanPassword) {
      setErrorMessage('Invalid email or password');
      return;
    }

    setIsSubmitting(true);
    setErrorMessage(null);

    try {
      const result = await login(cleanEmail, cleanPassword, rememberMe);

      if (result.success) {
        navigate(fromLocation, { replace: true });
      } else {
        if (result.isLocked && result.lockoutRemainingSeconds) {
          setLockoutRemaining(result.lockoutRemainingSeconds);
          setErrorMessage(
            `Too many failed login attempts. Login disabled for ${result.lockoutRemainingSeconds} seconds.`
          );
        } else {
          // Strictly generic error message
          setErrorMessage('Invalid email or password');
        }
      }
    } catch {
      setErrorMessage('Invalid email or password');
    } finally {
      setIsSubmitting(false);
    }
  };

  const isButtonDisabled = isSubmitting || lockoutRemaining > 0 || !email.trim() || !password;

  return (
    <div className="min-h-screen flex flex-col justify-between items-center p-4 sm:p-6 lg:p-8 bg-[#0a0f1d] text-slate-100 font-sans relative overflow-hidden select-none selection:bg-amber-500/30 selection:text-amber-200">
      {/* Dark Navy / Charcoal Ambient Background with subtle Gold highlights */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Deep Charcoal Gradient */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#090d16] via-[#0d1527] to-[#080c14]" />
        
        {/* Subtle Navy / Charcoal radial mesh */}
        <div className="absolute -top-[20%] left-1/2 -translate-x-1/2 w-[700px] h-[500px] bg-gradient-to-b from-blue-950/20 via-slate-900/10 to-transparent rounded-full blur-3xl opacity-70" />
        
        {/* Very subtle Luxury Gold ambient glow */}
        <div className="absolute top-1/3 right-1/4 w-[350px] h-[350px] bg-amber-500/[0.04] rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-10 left-1/4 w-[300px] h-[300px] bg-amber-600/[0.03] rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Header Brand Bar */}
      <header className="w-full max-w-5xl flex items-center justify-between z-10 py-3">
        <div className="flex items-center gap-3">
          {/* Brand Mark with Gold Border Accent */}
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-slate-900 via-slate-800 to-slate-950 flex items-center justify-center text-amber-400 font-black text-base shadow-xl border border-amber-500/30 ring-1 ring-amber-500/20">
            M
          </div>
          <div>
            <div className="font-extrabold text-xs tracking-wider uppercase text-slate-100 flex items-center gap-1.5">
              <span>MOUNTEC</span>
              <span className="w-1 h-1 rounded-full bg-amber-400" />
              <span className="text-amber-400 font-medium text-[11px]">METC SYSTEM</span>
            </div>
            <div className="text-[10px] tracking-wide text-slate-400 font-medium">
              Enterprise Asset & Workforce Management
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-900/80 border border-slate-800 text-[11px] font-medium text-slate-400">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            <span>Firebase Auth Active</span>
          </div>
        </div>
      </header>

      {/* Main Centered Login Card */}
      <main className="w-full max-w-[420px] z-10 my-auto py-6">
        <div className="relative rounded-2xl bg-[#0e1626]/95 border border-slate-800/90 p-7 sm:p-9 shadow-2xl shadow-black/80 backdrop-blur-xl transition-all duration-300">
          {/* Subtle Top Gold Highlight Trim */}
          <div className="absolute top-0 left-8 right-8 h-[1.5px] bg-gradient-to-r from-transparent via-amber-400/50 to-transparent" />

          {/* App Logo & Title */}
          <div className="text-center space-y-2 mb-7">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-gradient-to-b from-slate-800 to-slate-900 border border-amber-500/30 text-amber-400 shadow-inner mb-2">
              <Shield className="w-6 h-6 text-amber-400" />
            </div>

            <h1 className="text-xl font-bold tracking-tight text-white">
              Private Workspace Login
            </h1>
            <p className="text-xs text-slate-400 leading-relaxed max-w-[280px] mx-auto">
              Authenticate with your assigned Firebase credentials to access the system.
            </p>
          </div>

          {/* Security Lockout Banner */}
          {lockoutRemaining > 0 && (
            <div className="mb-5 p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs flex items-start gap-2.5 animate-in fade-in duration-200">
              <Clock className="w-4 h-4 shrink-0 mt-0.5 text-amber-400" />
              <div className="space-y-0.5 text-left">
                <div className="font-semibold text-amber-300">Login Disabled</div>
                <div className="text-slate-300">
                  3 failed attempts reached. Please wait{' '}
                  <span className="font-bold text-amber-400 underline">{lockoutRemaining}s</span> before retrying.
                </div>
              </div>
            </div>
          )}

          {/* Generic Error Message Box */}
          {errorMessage && lockoutRemaining <= 0 && (
            <div className="mb-5 p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2.5 animate-in fade-in duration-200">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span className="font-medium">{errorMessage}</span>
            </div>
          )}

          {/* Email & Password Form */}
          <form onSubmit={handleSubmit} className="space-y-4 text-left">
            {/* Email Field */}
            <div className="space-y-1.5">
              <label
                htmlFor="firebase-email"
                className="block text-xs font-semibold text-slate-300 tracking-wide"
              >
                Email
              </label>
              <div className="relative group">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                  <Mail className="w-4 h-4 text-slate-500 group-focus-within:text-amber-400 transition-colors" />
                </div>
                <input
                  id="firebase-email"
                  type="email"
                  required
                  autoComplete="email"
                  disabled={isSubmitting || lockoutRemaining > 0}
                  placeholder="name@mountec.com"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    if (errorMessage) setErrorMessage(null);
                  }}
                  className="w-full pl-10 pr-4 py-2.5 text-sm rounded-xl bg-[#090e1a] border border-slate-800 text-white placeholder-slate-500 outline-none transition-all duration-200 focus:border-amber-500/60 focus:ring-2 focus:ring-amber-500/15 focus:bg-[#070b14]"
                />
              </div>
            </div>

            {/* Password Field */}
            <div className="space-y-1.5">
              <label
                htmlFor="firebase-password"
                className="block text-xs font-semibold text-slate-300 tracking-wide"
              >
                Password
              </label>
              <div className="relative group">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                  <Lock className="w-4 h-4 text-slate-500 group-focus-within:text-amber-400 transition-colors" />
                </div>
                <input
                  id="firebase-password"
                  type={showPassword ? 'text' : 'password'}
                  required
                  autoComplete="current-password"
                  disabled={isSubmitting || lockoutRemaining > 0}
                  placeholder="••••••••••••"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    if (errorMessage) setErrorMessage(null);
                  }}
                  className="w-full pl-10 pr-11 py-2.5 text-sm rounded-xl bg-[#090e1a] border border-slate-800 text-white placeholder-slate-500 outline-none transition-all duration-200 focus:border-amber-500/60 focus:ring-2 focus:ring-amber-500/15 focus:bg-[#070b14]"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  tabIndex={-1}
                  className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-500 hover:text-slate-300 transition-colors cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Remember Session Toggle */}
            <div className="flex items-center justify-between pt-1">
              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="w-4 h-4 rounded border-slate-700 bg-slate-900 text-amber-500 focus:ring-amber-500/30 accent-amber-500 cursor-pointer"
                />
                <span className="text-xs text-slate-400">Remember session</span>
              </label>

              <span className="text-[11px] text-slate-500">
                SSL 256-bit encrypted
              </span>
            </div>

            {/* Login Button with Smooth Spinner & Gold Accent */}
            <div className="pt-2">
              <button
                type="submit"
                id="login-submit-btn"
                disabled={isButtonDisabled}
                className="w-full py-3 px-4 bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 active:scale-[0.99] text-slate-950 font-bold text-sm rounded-xl transition-all duration-200 shadow-lg shadow-amber-500/15 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed disabled:transform-none border border-amber-300/40"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-slate-950" />
                    <span>Verifying with Firebase...</span>
                  </>
                ) : (
                  <span>Sign In</span>
                )}
              </button>
            </div>
          </form>

          {/* Quick autofill shortcut for testing */}
          <div className="mt-5 pt-4 border-t border-slate-800/60 space-y-2">
            <button
              type="button"
              onClick={() => {
                setEmail('test@example.com');
                setPassword('Test@1234');
                if (errorMessage) setErrorMessage(null);
              }}
              className="w-full py-2 px-3 rounded-lg bg-amber-950/30 hover:bg-amber-900/30 border border-amber-800/40 text-[11px] text-amber-300 hover:text-amber-200 flex items-center justify-between transition-colors cursor-pointer"
            >
              <span className="flex items-center gap-1.5 font-medium">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Test Account (<span className="font-mono">test@example.com</span>)</span>
              </span>
              <span className="text-[10px] text-amber-400 font-mono font-bold">Fill Test</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setEmail('vickykartik12032004@gmail.com');
                setPassword('Admin@123456');
                if (errorMessage) setErrorMessage(null);
              }}
              className="w-full py-1.5 px-3 rounded-lg bg-slate-900/60 hover:bg-slate-900 border border-slate-800 text-[11px] text-slate-400 hover:text-slate-200 flex items-center justify-between transition-colors cursor-pointer"
            >
              <span className="flex items-center gap-1.5">
                <span>Super Admin Shortcut</span>
              </span>
              <span className="text-[10px] text-slate-400 font-mono">Fill Admin</span>
            </button>
          </div>
        </div>

        {/* Small Private Access Note Below Form */}
        <div className="mt-6 text-center space-y-1">
          <p className="text-xs font-semibold text-slate-400 tracking-wide flex items-center justify-center gap-1.5">
            <Lock className="w-3 h-3 text-amber-400" />
            <span>Private access only — invite required</span>
          </p>
          <p className="text-[11px] text-slate-500 leading-relaxed max-w-xs mx-auto">
            Accounts are managed directly by administrators in the Firebase Console. No public sign-up is available.
          </p>
        </div>
      </main>

      {/* Footer System Info */}
      <footer className="w-full max-w-5xl flex flex-col sm:flex-row items-center justify-between gap-2 z-10 py-2 text-[11px] text-slate-500">
        <div>&copy; {new Date().getFullYear()} MOUNTEC PTE LTD. All rights reserved.</div>
        <div className="flex items-center gap-4">
          <span className="text-slate-400">Firebase Project: <span className="font-mono text-amber-400/90">tidal-theater-d9v0l</span></span>
          <span>•</span>
          <span>Security Protocol v3.0</span>
        </div>
      </footer>
    </div>
  );
};

export default LoginPage;
