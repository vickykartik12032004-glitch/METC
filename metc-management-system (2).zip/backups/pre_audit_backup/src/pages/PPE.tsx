import React from 'react';
import { MOUNTECMasterModule } from '../features/metc/MOUNTECMasterModule';

export const PPE: React.FC = () => {
  return (
    <MOUNTECMasterModule
      defaultCategory="PPE"
      title="PPE Safety Equipment Management"
      subtitle="Track safety helmets, high-vis vests, boots, harnesses, respirators, and compliance certifications"
    />
  );
};

export default PPE;
