import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { useAuth } from '../hooks/useAuth';
import { useRole } from '../hooks/useRole';
import { useDashboard } from '../hooks/dashboard/useDashboard';
import { DashboardHeader } from '../components/dashboard/DashboardHeader';
import { DashboardCard } from '../components/dashboard/DashboardCard';
import { QuickActions } from '../components/dashboard/QuickActions';
import { ChartCardSection } from '../components/dashboard/ChartCard';
import { ActivityTimeline } from '../components/dashboard/ActivityTimeline';
import { LowStockTable } from '../components/dashboard/LowStockTable';
import { ExpiringItemsPanel } from '../components/dashboard/ExpiringItemsPanel';
import { RecentIssuesTable } from '../components/dashboard/RecentIssuesTable';
import { NotificationPanel } from '../components/dashboard/NotificationPanel';
import { WeatherCard } from '../components/dashboard/WeatherCard';
import { CompanySummary } from '../components/dashboard/CompanySummary';
import { DashboardSkeleton } from '../components/dashboard/DashboardSkeleton';
import { DashboardEmptyState } from '../components/dashboard/DashboardEmptyState';
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/Card';

import {
  Boxes,
  CheckCircle2,
  ArrowUpRight,
  Hammer,
  ShieldAlert,
  Trash2,
  AlertTriangle,
  PackagePlus,
  PackageCheck,
  Users,
  UserMinus,
  Wrench,
  Activity,
  Calendar,
  Layers,
  Sparkles,
  Search,
} from 'lucide-react';

export const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { role } = useRole();

  const {
    timeFilter,
    setTimeFilter,
    searchQuery,
    setSearchQuery,
    isLoading,
    handleRefresh,
    activeKpiCategory,
    setActiveKpiCategory,
    formattedDate,
    formattedTime,
    kpiCards,
    monthlyTrends,
    categoryDist,
    inventoryStatus,
    activities,
    lowStockItems,
    expiringItems,
    recentIssues,
    notifications,
    weather,
    company,
  } = useDashboard();

  // Mapping KPI card IDs to corresponding icons and routes
  const getKpiMeta = (id: string) => {
    switch (id) {
      case 'total_assets':
        return { icon: <Boxes className="w-4 h-4" />, route: '/materials' };
      case 'available_items':
        return { icon: <CheckCircle2 className="w-4 h-4" />, route: '/materials' };
      case 'issued_items':
        return { icon: <ArrowUpRight className="w-4 h-4" />, route: '/issue' };
      case 'under_repair':
        return { icon: <Hammer className="w-4 h-4" />, route: '/repair' };
      case 'lost_items':
        return { icon: <ShieldAlert className="w-4 h-4" />, route: '/lost-items' };
      case 'disposed_items':
        return { icon: <Trash2 className="w-4 h-4" />, route: '/materials' };
      case 'low_stock_items':
        return { icon: <AlertTriangle className="w-4 h-4" />, route: '/materials' };
      case 'todays_issues':
        return { icon: <PackagePlus className="w-4 h-4" />, route: '/issue' };
      case 'todays_returns':
        return { icon: <PackageCheck className="w-4 h-4" />, route: '/return' };
      case 'active_workers':
        return { icon: <Users className="w-4 h-4" />, route: '/workers' };
      case 'inactive_workers':
        return { icon: <UserMinus className="w-4 h-4" />, route: '/workers' };
      case 'pending_repairs':
        return { icon: <Wrench className="w-4 h-4" />, route: '/repair' };
      default:
        return { icon: <Boxes className="w-4 h-4" />, route: '/materials' };
    }
  };

  const hasNoResults =
    searchQuery.trim().length > 0 &&
    kpiCards.length === 0 &&
    activities.length === 0 &&
    lowStockItems.length === 0 &&
    recentIssues.length === 0;

  if (isLoading) {
    return (
      <div className="space-y-6">
        <DashboardHeader
          user={user}
          role={role}
          formattedDate={formattedDate}
          formattedTime={formattedTime}
          timeFilter={timeFilter}
          onTimeFilterChange={setTimeFilter}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          isLoading={isLoading}
          onRefresh={handleRefresh}
        />
        <DashboardSkeleton />
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-12">
      {/* 1. Dashboard Enterprise Header */}
      <DashboardHeader
        user={user}
        role={role}
        formattedDate={formattedDate}
        formattedTime={formattedTime}
        timeFilter={timeFilter}
        onTimeFilterChange={setTimeFilter}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        isLoading={isLoading}
        onRefresh={handleRefresh}
      />

      {/* 2. Quick Command Actions Bar */}
      <Card>
        <CardContent className="p-4 sm:p-5">
          <div className="flex items-center justify-between mb-3">
            <p className="text-xs font-black uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-blue-500" />
              <span>Quick Operational Command Bar</span>
            </p>
            <span className="text-[10px] text-slate-400 font-mono">Role Access: {role}</span>
          </div>
          <QuickActions />
        </CardContent>
      </Card>

      {/* 3. Top 12 KPI Metric Cards Grid */}
      <div className="space-y-3">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
          <h2 className="text-sm font-black uppercase tracking-wider text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
            <Layers className="w-4 h-4 text-blue-500" />
            <span>Key Performance Telemetry ({kpiCards.length} Cards)</span>
          </h2>

          {/* Category Filter Pills */}
          <div className="flex items-center gap-1 bg-white dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-800 text-xs">
            {(['all', 'inventory', 'operations', 'workforce'] as const).map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveKpiCategory(cat)}
                className={`px-3 py-1 rounded-lg font-bold capitalize transition-all ${
                  activeKpiCategory === cat
                    ? 'bg-slate-900 text-white dark:bg-blue-600 shadow-2xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {kpiCards.length > 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, staggerChildren: 0.05 }}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4"
          >
            {kpiCards.map((kpi) => {
              const meta = getKpiMeta(kpi.id);
              return (
                <DashboardCard
                  key={kpi.id}
                  kpi={kpi}
                  icon={meta.icon}
                  onClick={() => navigate(meta.route)}
                />
              );
            })}
          </motion.div>
        ) : (
          <div className="p-8 text-center bg-slate-50 dark:bg-slate-900 rounded-2xl border border-dashed border-slate-300 dark:border-slate-800 text-xs text-slate-500">
            No KPI metrics match the current search filter.
          </div>
        )}
      </div>

      {/* Search Empty State Banner if search query active and nothing matches */}
      {hasNoResults && (
        <DashboardEmptyState
          searchQuery={searchQuery}
          onClearSearch={() => setSearchQuery('')}
        />
      )}

      {/* 4. Company Executive Portfolio Summary */}
      <CompanySummary company={company} />

      {/* 5. Enterprise Recharts Analytics Section */}
      <ChartCardSection
        monthlyTrends={monthlyTrends}
        categoryDist={categoryDist}
        inventoryStatus={inventoryStatus}
      />

      {/* 6. Middle Grid: Recent Activities, Weather, & Low Stock Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Activity Timeline Stream */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-blue-500" />
              <CardTitle>Real-Time Operational Activity Stream</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <ActivityTimeline activities={activities} />
          </CardContent>
        </Card>

        {/* Right Stack: Weather & Notifications */}
        <div className="space-y-6">
          <WeatherCard weather={weather} />
          <Card>
            <CardContent className="p-4">
              <NotificationPanel notifications={notifications} />
            </CardContent>
          </Card>
        </div>
      </div>

      {/* 7. Bottom Grid: Low Stock Watchlist & Expiring Items Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-500" />
              <CardTitle>Critical Low Stock Watchlist</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <LowStockTable items={lowStockItems} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-rose-500" />
              <CardTitle>Warranty, Expiry & Calibration Schedule</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <ExpiringItemsPanel items={expiringItems} />
          </CardContent>
        </Card>
      </div>

      {/* 8. Recent Issues Log Table */}
      <Card>
        <CardHeader className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <PackagePlus className="w-4 h-4 text-blue-500" />
            <CardTitle>Latest Asset Issue & Return Records</CardTitle>
          </div>
          <button
            onClick={() => navigate('/issue')}
            className="text-xs text-blue-600 dark:text-blue-400 font-bold hover:underline self-start sm:self-auto"
          >
            View All Issues →
          </button>
        </CardHeader>
        <CardContent>
          <RecentIssuesTable issues={recentIssues} />
        </CardContent>
      </Card>
    </div>
  );
};
