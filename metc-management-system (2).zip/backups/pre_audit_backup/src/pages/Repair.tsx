import React, { useState } from 'react';
import { PageHeader } from '../components/layout/PageHeader';
import { Button } from '../components/ui/Button';
import { SearchBox } from '../components/ui/SearchBox';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '../components/ui/Table';
import { StatusBadge } from '../components/common/StatusBadge';
import { ExportButton } from '../components/common/ExportButton';
import { EmptyState } from '../components/ui/EmptyState';
import { Modal } from '../components/ui/Modal';
import { RepairForm } from '../components/forms/RepairForm';
import { useTransactionStore } from '../store/useTransactionStore';
import { useAssetStore } from '../store/useAssetStore';
import { formatCurrency, formatDate } from '../lib/utils';
import { Hammer, Plus, Wrench, Calendar, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';

export const RepairPage: React.FC = () => {
  const { repairs, addRepair, updateRepairStatus, addActivity } = useTransactionStore();
  const { updateEquipment, updateTool } = useAssetStore();
  const [search, setSearch] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);

  const filteredRepairs = repairs.filter(
    (r) =>
      r.itemName.toLowerCase().includes(search.toLowerCase()) ||
      r.repairCode.toLowerCase().includes(search.toLowerCase()) ||
      (r.repairVendor && r.repairVendor.toLowerCase().includes(search.toLowerCase())) ||
      r.issueDescription.toLowerCase().includes(search.toLowerCase())
  );

  const handleRepairSubmit = (data: any) => {
    addRepair(data);

    // Update equipment / tool status in asset store
    updateEquipment(data.itemId, { status: 'Under Repair' });
    updateTool(data.itemId, { status: 'Under Repair' });

    addActivity({
      action: 'Sent for Repair',
      targetType: 'Asset',
      targetName: data.itemName,
      user: data.handledBy,
      details: `Dispatched to ${data.repairVendor}. Issue: ${data.issueDescription}`,
    });

    toast.success(`Repair dispatch logged for ${data.itemName}`);
    setIsModalOpen(false);
  };

  const handleCompleteRepair = (repairId: string, itemId: string) => {
    updateRepairStatus(repairId, 'Repaired');
    updateEquipment(itemId, { status: 'Available' });
    updateTool(itemId, { status: 'Available' });

    toast.success('Repair marked as completed & returned to active stock');
  };

  const exportColumns = [
    { header: 'Repair Code', key: 'repairCode' },
    { header: 'Item Name', key: 'itemName' },
    { header: 'Service Vendor', key: 'repairVendor' },
    { header: 'Dispatch Date', key: 'sentDate' },
    { header: 'Est Return', key: 'estimatedReturnDate' },
    { header: 'Cost ($)', key: 'repairCost' },
    { header: 'Status', key: 'status' },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Repair & Servicing Management"
        description="Track equipment breakdowns, external workshop repairs, and preventive maintenance logs"
        actions={
          <div className="flex items-center gap-2">
            <ExportButton title="Repair Logs" columns={exportColumns} data={filteredRepairs} filename="Repair_Logs" />
            <Button
              variant="primary"
              size="sm"
              icon={<Plus className="w-4 h-4" />}
              onClick={() => setIsModalOpen(true)}
            >
              Log Repair
            </Button>
          </div>
        }
      />

      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <SearchBox value={search} onChange={setSearch} placeholder="Search repairs by vendor, code, fault..." />
        <p className="text-xs text-slate-500">
          Repairs Tracked: <strong className="font-semibold text-slate-800 dark:text-slate-200">{filteredRepairs.length}</strong>
        </p>
      </div>

      {filteredRepairs.length === 0 ? (
        <EmptyState
          icon={<Hammer className="w-8 h-8" />}
          title="No repair logs found"
          description="There are no active or historic equipment repair jobs."
          actionLabel="Log New Repair"
          onAction={() => setIsModalOpen(true)}
        />
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Code & Asset</TableHead>
              <TableHead>Fault Scope</TableHead>
              <TableHead>Service Vendor</TableHead>
              <TableHead>Sent Date</TableHead>
              <TableHead>Est Return</TableHead>
              <TableHead>Repair Cost</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredRepairs.map((rep) => (
              <TableRow key={rep.id}>
                <TableCell>
                  <div className="font-bold text-slate-900 dark:text-slate-100">{rep.itemName}</div>
                  <div className="text-[11px] text-slate-500 font-mono">{rep.repairCode}</div>
                </TableCell>
                <TableCell>
                  <p className="text-xs text-slate-700 dark:text-slate-300 max-w-xs truncate">{rep.issueDescription}</p>
                </TableCell>
                <TableCell>{rep.repairVendor || 'Internal'}</TableCell>
                <TableCell>{rep.sentDate}</TableCell>
                <TableCell>{rep.estimatedReturnDate || 'TBD'}</TableCell>
                <TableCell className="font-semibold">{formatCurrency(rep.repairCost)}</TableCell>
                <TableCell>
                  <StatusBadge status={rep.status} />
                </TableCell>
                <TableCell className="text-right">
                  {rep.status === 'In Repair' && (
                    <Button
                      variant="outline"
                      size="xs"
                      icon={<CheckCircle className="w-3.5 h-3.5 text-emerald-500" />}
                      onClick={() => handleCompleteRepair(rep.id, rep.itemId)}
                    >
                      Complete
                    </Button>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Log Repair Dispatch" size="lg">
        <RepairForm onSubmit={handleRepairSubmit} onCancel={() => setIsModalOpen(false)} />
      </Modal>
    </div>
  );
};
