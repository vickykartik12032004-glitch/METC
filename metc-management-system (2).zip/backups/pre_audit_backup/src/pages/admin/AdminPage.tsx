import React from 'react';
import AdminModuleView from '../../features/admin/AdminModuleView';

export const AdminPage: React.FC = () => {
  return <AdminModuleView />;
};

export default AdminPage;
