import React, { useState } from 'react';
import { PageHeader } from '../components/layout/PageHeader';
import { Button } from '../components/ui/Button';
import { SearchBox } from '../components/ui/SearchBox';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '../components/ui/Table';
import { StatusBadge } from '../components/common/StatusBadge';
import { ExportButton } from '../components/common/ExportButton';
import { EmptyState } from '../components/ui/EmptyState';
import { Modal } from '../components/ui/Modal';
import { LostForm } from '../components/forms/LostForm';
import { useTransactionStore } from '../store/useTransactionStore';
import { formatCurrency, formatDate } from '../lib/utils';
import { ShieldAlert, Plus, AlertCircle, FileText } from 'lucide-react';
import { toast } from 'sonner';

export const LostItemsPage: React.FC = () => {
  const { lostItems, addLostItem, addActivity } = useTransactionStore();
  const [search, setSearch] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);

  const filteredLost = lostItems.filter(
    (l) =>
      l.itemName.toLowerCase().includes(search.toLowerCase()) ||
      (l.incidentCode || l.lostCode).toLowerCase().includes(search.toLowerCase()) ||
      (l.workerName && l.workerName.toLowerCase().includes(search.toLowerCase())) ||
      l.location.toLowerCase().includes(search.toLowerCase())
  );

  const handleLostSubmit = (data: any) => {
    addLostItem(data);

    addActivity({
      action: 'Reported Lost',
      targetType: 'Asset',
      targetName: `${data.itemName} (${data.quantityLost} units)`,
      user: data.reportedBy,
      details: `Incident reported at ${data.location}. Action: ${data.actionTaken}`,
    });

    toast.error(`Lost item incident report created for ${data.itemName}`);
    setIsModalOpen(false);
  };

  const exportColumns = [
    { header: 'Incident Code', key: 'incidentCode' },
    { header: 'Asset Name', key: 'itemName' },
    { header: 'Worker Assigned', key: 'workerName' },
    { header: 'Qty Lost', key: 'quantityLost' },
    { header: 'Location', key: 'location' },
    { header: 'Value Loss ($)', key: 'estimatedValue' },
    { header: 'Action Taken', key: 'actionTaken' },
    { header: 'Reported Date', key: 'reportedDate' },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Lost & Damaged Incident Registry"
        description="Formal loss investigation records, site security theft reports, and administrative write-offs"
        actions={
          <div className="flex items-center gap-2">
            <ExportButton title="Lost Asset Incidents" columns={exportColumns} data={filteredLost} filename="Lost_Asset_Incidents" />
            <Button
              variant="danger"
              size="sm"
              icon={<Plus className="w-4 h-4" />}
              onClick={() => setIsModalOpen(true)}
            >
              Report Lost Item
            </Button>
          </div>
        }
      />

      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <SearchBox value={search} onChange={setSearch} placeholder="Search incident reports by code, asset, location..." />
        <p className="text-xs text-slate-500">
          Total Incidents: <strong className="font-semibold text-slate-800 dark:text-slate-200">{filteredLost.length}</strong>
        </p>
      </div>

      {filteredLost.length === 0 ? (
        <EmptyState
          icon={<ShieldAlert className="w-8 h-8 text-rose-500" />}
          title="No lost item reports"
          description="There are no reported lost, stolen, or destroyed assets."
          actionLabel="File Incident Report"
          onAction={() => setIsModalOpen(true)}
        />
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Incident Code & Asset</TableHead>
              <TableHead>Assigned Worker</TableHead>
              <TableHead>Qty</TableHead>
              <TableHead>Incident Location</TableHead>
              <TableHead>Est Value Loss</TableHead>
              <TableHead>Action Taken</TableHead>
              <TableHead>Reported Date</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredLost.map((lost) => (
              <TableRow key={lost.id}>
                <TableCell>
                  <div className="font-bold text-slate-900 dark:text-slate-100">{lost.itemName}</div>
                  <div className="text-[11px] text-slate-500 font-mono">{lost.incidentCode || lost.lostCode}</div>
                </TableCell>
                <TableCell>{lost.workerName || 'Unassigned'}</TableCell>
                <TableCell>
                  <strong className="font-bold text-rose-600 dark:text-rose-400">{lost.quantityLost}</strong>
                </TableCell>
                <TableCell>{lost.location}</TableCell>
                <TableCell className="font-bold text-slate-900 dark:text-slate-100">{formatCurrency(lost.estimatedValue)}</TableCell>
                <TableCell>
                  <span className="px-2 py-0.5 rounded-md text-xs font-semibold bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200">
                    {lost.actionTaken}
                  </span>
                </TableCell>
                <TableCell>{lost.reportedDate}</TableCell>
                <TableCell>
                  <StatusBadge status={lost.status} />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="File Lost Asset Incident Report" size="lg">
        <LostForm onSubmit={handleLostSubmit} onCancel={() => setIsModalOpen(false)} />
      </Modal>
    </div>
  );
};
