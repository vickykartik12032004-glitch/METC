import { supabase, isSupabaseConfigured } from '../lib/supabase';
import type { Database } from '../types/database.types';

export type ActivityLog = Database['public']['Tables']['activity_logs']['Row'];
export type ActivityLogInsert = Database['public']['Tables']['activity_logs']['Insert'];

/**
 * Creates an activity audit log entry
 */
export async function logActivity(
  action: string,
  tableName: string,
  recordId?: string,
  details: Record<string, any> = {},
  userName: string = 'System Admin',
  userId?: string
): Promise<ActivityLog | null> {
  const payload: ActivityLogInsert = {
    action,
    table_name: tableName,
    record_id: recordId || null,
    details,
    user_name: userName,
    user_id: userId || null,
  };

  if (!isSupabaseConfigured) {
    console.log('[ActivityLog Local]', payload);
    return {
      id: `log-${Date.now()}`,
      user_id: userId || null,
      user_name: userName,
      action,
      table_name: tableName,
      record_id: recordId || null,
      details,
      ip_address: '127.0.0.1',
      timestamp: new Date().toISOString(),
    };
  }

  const { data, error } = await (supabase.from('activity_logs') as any)
    .insert(payload)
    .select()
    .single();

  if (error || !data) {
    console.error('Failed to write activity log:', error?.message);
    return null;
  }

  return data as ActivityLog;
}

/**
 * Fetch activity logs with limit & offset
 */
export async function getActivityLogs(limit = 50, offset = 0): Promise<ActivityLog[]> {
  if (!isSupabaseConfigured) return [];

  const { data, error } = await supabase
    .from('activity_logs')
    .select('*')
    .order('timestamp', { ascending: false })
    .range(offset, offset + limit - 1);

  if (error) {
    console.error('Error fetching activity logs:', error.message);
    return [];
  }

  return (data as ActivityLog[]) || [];
}
