import { useAssetStore } from '../store/useAssetStore';
import { useTransactionStore } from '../store/useTransactionStore';
import { useWorkerStore } from '../store/useWorkerStore';
import { useAdminStore } from '../store/useAdminStore';
import { useMaintenanceStore } from '../store/useMaintenanceStore';
import { useNotificationStore } from '../store/useNotificationStore';
import { useAuthStore } from '../store/useAuthStore';
import { cloudApi, getBaseApiUrl } from './apiClient';

export type SyncConnectionStatus = 'online' | 'syncing' | 'offline';

type StatusListener = (status: SyncConnectionStatus, details?: { lastSyncTime?: Date; pingMs?: number }) => void;

class RealtimeSyncManager {
  private eventSource: EventSource | null = null;
  private status: SyncConnectionStatus = typeof navigator !== 'undefined' && navigator.onLine ? 'online' : 'offline';
  private listeners: Set<StatusListener> = new Set();
  private reconnectTimer: NodeJS.Timeout | null = null;
  private watchdogTimer: NodeJS.Timeout | null = null;
  private reconnectDelay = 2000;
  private isInitialized = false;
  private lastSyncTime: Date = new Date();
  private currentDbVersion: number = 0;

  public getStatus(): SyncConnectionStatus {
    return this.status;
  }

  public getLastSyncTime(): Date {
    return this.lastSyncTime;
  }

  public subscribe(listener: StatusListener): () => void {
    this.listeners.add(listener);
    listener(this.status, { lastSyncTime: this.lastSyncTime });
    return () => this.listeners.delete(listener);
  }

  private notifyStatus(status: SyncConnectionStatus, pingMs?: number): void {
    this.status = status;
    this.listeners.forEach((fn) => fn(status, { lastSyncTime: this.lastSyncTime, pingMs }));
  }

  /**
   * Initializes real-time sync, loads initial cloud snapshot, and connects SSE listener
   */
  public async init(): Promise<void> {
    if (this.isInitialized) return;
    this.isInitialized = true;

    // Listen to browser network changes
    window.addEventListener('online', () => {
      console.log('[RealtimeSync] Network restored, reconnecting...');
      this.reconnectDelay = 1000;
      this.notifyStatus('online');
      this.connect();
      this.fetchFullSnapshot();
    });

    window.addEventListener('offline', () => {
      console.warn('[RealtimeSync] Network disconnected.');
      this.notifyStatus('offline');
      if (this.eventSource) {
        this.eventSource.close();
        this.eventSource = null;
      }
    });

    // Listen to tab visibility - when tab comes into view, refresh status and reconnect if needed
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') {
        this.checkHealthAndSync();
        if (!this.eventSource || this.eventSource.readyState === EventSource.CLOSED) {
          this.connect();
        }
      }
    });

    // Listen to auth state changes to dynamically reconnect with new credentials
    useAuthStore.subscribe((state, prevState) => {
      if (state.user?.id !== prevState.user?.id || state.user?.email !== prevState.user?.email) {
        this.refreshSession();
      }
    });

    // 1. Initial snapshot fetch
    await this.fetchFullSnapshot();

    // 2. Connect live event stream
    this.connect();

    // 3. Start background health check & fallback delta sync
    this.startBackgroundWatchdog();
  }

  /**
   * Verify server health and synchronize if newer version exists
   */
  public async checkHealthAndSync(): Promise<boolean> {
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      this.notifyStatus('offline');
      return false;
    }

    try {
      const baseApi = getBaseApiUrl();
      const res = await fetch(`${baseApi}/health`, { cache: 'no-store' });
      if (res.ok) {
        const data = await res.json();
        this.lastSyncTime = new Date();
        this.notifyStatus('online');

        // If server reported a higher databaseVersion than our current local version, fetch snapshot
        if (data.databaseVersion && data.databaseVersion > this.currentDbVersion && this.currentDbVersion > 0) {
          this.fetchFullSnapshot();
        }
        return true;
      } else {
        return false;
      }
    } catch (e) {
      if (typeof navigator !== 'undefined' && !navigator.onLine) {
        this.notifyStatus('offline');
      }
      return false;
    }
  }

  /**
   * Background watchdog every 20s to ensure active connectivity and resilient delta sync
   */
  private startBackgroundWatchdog(): void {
    if (this.watchdogTimer) clearInterval(this.watchdogTimer);
    this.watchdogTimer = setInterval(() => {
      this.checkHealthAndSync();
      // Re-establish event source if closed and network is online
      if (typeof navigator !== 'undefined' && navigator.onLine) {
        if (!this.eventSource || this.eventSource.readyState === EventSource.CLOSED) {
          this.connect();
        }
      }
    }, 20000);
  }

  /**
   * Refresh session and reconnect stream with updated credentials
   */
  public refreshSession(): void {
    if (this.eventSource) {
      this.eventSource.close();
      this.eventSource = null;
    }
    this.reconnectDelay = 1000;
    this.connect();
    this.fetchFullSnapshot();
  }

  /**
   * Fetch full central cloud database state
   */
  public async fetchFullSnapshot(): Promise<void> {
    try {
      this.notifyStatus('syncing');
      const res = await cloudApi.getFullSnapshot();
      if (res.success && res.data) {
        const snapshot = res.data;
        this.currentDbVersion = snapshot.version || 1;
        
        // Ingest into all stores
        useAssetStore.getState().syncAllAssets({
          materials: snapshot.materials,
          equipment: snapshot.equipment,
          tools: snapshot.tools,
          consumables: snapshot.consumables,
          ppe: snapshot.ppe,
        });

        useTransactionStore.getState().syncAllTransactions({
          issues: snapshot.issues,
          returns: snapshot.returns,
          transfers: snapshot.transfers,
          repairs: snapshot.repairs,
          lostItems: snapshot.lostItems,
          activities: snapshot.activities,
        });

        useWorkerStore.getState().syncAllWorkers(snapshot.workers);
        useMaintenanceStore.getState().syncAllMaintenance(snapshot.maintenance);
        useNotificationStore.getState().syncAllNotifications(snapshot.notifications);
        useAdminStore.getState().syncAllAdminData({
          companyProfile: snapshot.companyProfile,
          users: snapshot.users,
          authorizedUsers: snapshot.authorizedUsers,
          roles: snapshot.roles,
          departments: snapshot.departments,
          branches: snapshot.branches,
          sites: snapshot.sites,
          suppliers: snapshot.suppliers,
          units: snapshot.units,
          emailSettings: snapshot.emailSettings,
          appSettings: snapshot.appSettings,
          securitySettings: snapshot.securitySettings,
          auditLogs: snapshot.auditLogs,
        });

        this.lastSyncTime = new Date();
        this.notifyStatus('online');
        window.dispatchEvent(new CustomEvent('mountec:full_sync', { detail: { snapshot } }));
        console.log(`[RealtimeSync] Loaded full cloud database snapshot v${snapshot.version}`);
      }
    } catch (err) {
      console.warn('[RealtimeSync] Could not fetch initial cloud snapshot (offline or booting):', err);
      if (typeof navigator !== 'undefined' && !navigator.onLine) {
        this.notifyStatus('offline');
      } else {
        // Test health before marking offline
        this.checkHealthAndSync();
      }
    }
  }

  /**
   * Connect to Server-Sent Events stream
   */
  private connect(): void {
    if (this.eventSource) {
      this.eventSource.close();
      this.eventSource = null;
    }

    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      this.notifyStatus('offline');
      return;
    }

    const currentUser = useAuthStore.getState().user;
    let token = '';
    try {
      const raw = localStorage.getItem('mountec_auth_session');
      if (raw) token = JSON.parse(raw)?.token || '';
    } catch (e) {}

    if (!token && currentUser) {
      token = `sess_${currentUser.id || currentUser.email || 'user'}`;
    } else if (!token) {
      token = 'sess_mountec_client';
    }

    const queryParams = new URLSearchParams();
    if (currentUser) {
      queryParams.set('userId', currentUser.id);
      queryParams.set('email', currentUser.email);
    }
    if (token) {
      queryParams.set('token', token);
    }

    const baseApi = getBaseApiUrl();
    const streamUrl = `${baseApi}/realtime/stream?${queryParams.toString()}`;

    try {
      const es = new EventSource(streamUrl);
      this.eventSource = es;

      es.onopen = () => {
        this.reconnectDelay = 2000;
        this.notifyStatus('online');
        console.log('[RealtimeSync] Connected to central cloud database stream.');
      };

      es.onerror = async () => {
        console.warn('[RealtimeSync] Stream connection interrupted. Checking server health...');
        es.close();
        this.eventSource = null;

        const isHealthy = await this.checkHealthAndSync();
        if (!isHealthy) {
          this.notifyStatus('offline');
        } else {
          this.notifyStatus('online');
        }

        this.scheduleReconnect();
      };

      es.addEventListener('ping', () => {
        this.lastSyncTime = new Date();
        if (this.status !== 'online') {
          this.notifyStatus('online');
        }
      });

      // Register event listeners for each message type
      this.registerEventListeners(es);
    } catch (err) {
      console.error('[RealtimeSync] Failed to initialize EventSource:', err);
      this.scheduleReconnect();
    }
  }

  private scheduleReconnect(): void {
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.reconnectTimer = setTimeout(() => {
      this.reconnectDelay = Math.min(this.reconnectDelay * 1.5, 30000);
      this.connect();
    }, this.reconnectDelay);
  }

  private registerEventListeners(es: EventSource): void {
    const handleEvent = (type: string, rawData: string) => {
      try {
        const payload = JSON.parse(rawData);
        this.lastSyncTime = new Date();
        this.dispatchRemoteEvent(type, payload.data || payload);
      } catch (e) {
        console.error(`[RealtimeSync] Failed to parse event ${type}:`, e);
      }
    };

    const eventTypes = [
      'connected',
      'FULL_SYNC',
      'ALL_ASSETS_CLEARED',
      'DEMO_ASSETS_RESTORED',
      'ALL_WORKERS_CLEARED',
      'DEMO_WORKERS_RESTORED',
      'ALL_TRANSACTIONS_CLEARED',
      'ALL_SYSTEM_DATA_CLEARED',
      'ASSET_CREATED',
      'ASSET_UPDATED',
      'ASSET_DELETED',
      'STOCK_UPDATED',
      'TRANSACTION_CREATED',
      'TRANSACTION_UPDATED',
      'WORKER_CREATED',
      'WORKER_UPDATED',
      'WORKER_DELETED',
      'MAINTENANCE_UPDATED',
      'ACTIVITY_LOGGED',
      'NOTIFICATIONS_UPDATED',
      'SETTINGS_UPDATED',
      'ADMIN_UPDATED',
    ];

    eventTypes.forEach((evt) => {
      es.addEventListener(evt, (e: MessageEvent) => {
        handleEvent(evt, e.data);
      });
    });
  }

  /**
   * Dispatch remote broadcast events directly into client store state
   */
  private dispatchRemoteEvent(eventType: string, data: any): void {
    console.log(`[RealtimeSync] ⚡ Live event received: ${eventType}`, data);

    switch (eventType) {
      case 'FULL_SYNC':
        this.fetchFullSnapshot();
        break;

      case 'ALL_ASSETS_CLEARED':
        useAssetStore.getState().clearAllAssets(true);
        break;

      case 'DEMO_ASSETS_RESTORED':
        this.fetchFullSnapshot();
        break;

      case 'ALL_WORKERS_CLEARED':
        useWorkerStore.getState().clearAllWorkers(true);
        window.dispatchEvent(new CustomEvent('mountec:worker_sync', { detail: { event: 'ALL_WORKERS_CLEARED' } }));
        break;

      case 'DEMO_WORKERS_RESTORED':
        this.fetchFullSnapshot();
        window.dispatchEvent(new CustomEvent('mountec:worker_sync', { detail: { event: 'DEMO_WORKERS_RESTORED' } }));
        break;

      case 'ALL_TRANSACTIONS_CLEARED':
        useTransactionStore.getState().clearAllTransactions(true);
        break;

      case 'ALL_SYSTEM_DATA_CLEARED':
        useAssetStore.getState().clearAllAssets(true);
        useWorkerStore.getState().clearAllWorkers(true);
        useTransactionStore.getState().clearAllTransactions(true);
        window.dispatchEvent(new CustomEvent('mountec:worker_sync', { detail: { event: 'ALL_WORKERS_CLEARED' } }));
        break;

      case 'ASSET_CREATED':
        if (data.category && data.item) {
          useAssetStore.getState().applyRemoteAssetCreated(data.category, data.item);
        }
        break;

      case 'ASSET_UPDATED':
        if (data.category && data.item) {
          useAssetStore.getState().applyRemoteAssetUpdated(data.category, data.item);
        }
        break;

      case 'ASSET_DELETED':
        if (data.id) {
          useAssetStore.getState().applyRemoteAssetDeleted(data.category || '', data.id);
        }
        break;

      case 'STOCK_UPDATED':
        if (data.assetId !== undefined && data.availableQuantity !== undefined) {
          useAssetStore.getState().applyRemoteStockUpdated(data.assetId, data.availableQuantity, data.status);
        }
        break;

      case 'TRANSACTION_CREATED':
        if (data.type && data.record) {
          useTransactionStore.getState().applyRemoteTransactionCreated(data.type, data.record);
          // If transaction modified stock, update stock in asset store as well
          if (data.updatedAsset) {
            useAssetStore.getState().applyRemoteAssetUpdated(data.updatedAsset.category || '', data.updatedAsset);
          }
        }
        break;

      case 'TRANSACTION_UPDATED':
        if (data.type && data.id) {
          useTransactionStore.getState().applyRemoteTransactionUpdated(data.type, data.id, data.status, data.record);
        }
        break;

      case 'WORKER_CREATED':
        if (data.worker) {
          useWorkerStore.getState().applyRemoteWorkerCreated(data.worker);
          window.dispatchEvent(new CustomEvent('mountec:worker_sync', { detail: { event: 'WORKER_CREATED', data: data.worker } }));
        }
        break;

      case 'WORKER_UPDATED':
        if (data.worker) {
          useWorkerStore.getState().applyRemoteWorkerUpdated(data.worker);
          window.dispatchEvent(new CustomEvent('mountec:worker_sync', { detail: { event: 'WORKER_UPDATED', data: data.worker } }));
        }
        break;

      case 'WORKER_DELETED':
        if (data.id) {
          useWorkerStore.getState().applyRemoteWorkerDeleted(data.id);
          window.dispatchEvent(new CustomEvent('mountec:worker_sync', { detail: { event: 'WORKER_DELETED', id: data.id } }));
        }
        break;

      case 'MAINTENANCE_UPDATED':
        if (data.record) {
          useMaintenanceStore.getState().applyRemoteMaintenanceUpdated(data.record);
        }
        break;

      case 'ACTIVITY_LOGGED':
        if (data.log) {
          useTransactionStore.getState().applyRemoteActivityLogged(data.log);
        }
        break;

      case 'NOTIFICATIONS_UPDATED':
        if (data.notifications) {
          useNotificationStore.getState().syncAllNotifications(data.notifications);
        }
        break;

      case 'SETTINGS_UPDATED':
        if (data.companyProfile || data.appSettings) {
          useAdminStore.getState().syncAllAdminData({
            companyProfile: data.companyProfile,
            appSettings: data.appSettings,
          });
        }
        break;

      case 'ADMIN_UPDATED':
        useAdminStore.getState().syncAllAdminData(data);
        break;
    }
  }

  /**
   * Manual force full sync trigger
   */
  public async forceSync(): Promise<void> {
    await this.fetchFullSnapshot();
    if (!this.eventSource || this.eventSource.readyState === EventSource.CLOSED) {
      this.connect();
    }
  }
}

export const realtimeSync = new RealtimeSyncManager();
