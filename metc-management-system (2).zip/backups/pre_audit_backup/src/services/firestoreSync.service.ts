import {
  collection,
  doc,
  setDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  getDocs,
  writeBatch,
  query,
  orderBy,
  serverTimestamp,
  increment,
  Unsubscribe,
  DocumentData,
  SnapshotMetadata,
  FirestoreError,
} from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { ensureFirebaseAuthSession } from './firebaseAuth.service';

/**
 * Remove undefined or unsupported fields before Firestore persistence
 */
function sanitizeForFirestore<T extends Record<string, any>>(data: T): Record<string, any> {
  const result: Record<string, any> = {};
  for (const [key, value] of Object.entries(data)) {
    if (value === undefined || typeof value === 'function') continue;
    if (value !== null && typeof value === 'object' && !(value instanceof Date) && !Array.isArray(value)) {
      // If it's a Firestore field value (like serverTimestamp), keep it as is
      if ((value as any)._methodName) {
        result[key] = value;
      } else {
        result[key] = sanitizeForFirestore(value);
      }
    } else {
      result[key] = value;
    }
  }
  return result;
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): void {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid || null,
      email: auth.currentUser?.email || null,
      emailVerified: auth.currentUser?.emailVerified || null,
      isAnonymous: auth.currentUser?.isAnonymous || null,
      tenantId: auth.currentUser?.tenantId || null,
      providerInfo: auth.currentUser?.providerData?.map((p) => ({
        providerId: p.providerId,
        email: p.email,
      })) || [],
    },
    operationType,
    path,
  };
  console.error('[Firestore Error]:', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export interface SyncedItem {
  id: string;
  userId: string;
  name: string;
  category?: string;
  quantity?: number;
  status?: string;
  notes?: string;
  createdAt?: any;
  updatedAt?: any;
  _metadata?: {
    fromCache: boolean;
    hasPendingWrites: boolean;
  };
}

/**
 * Subscribe to real-time changes on a user's items collection:
 * /users/{userId}/items
 *
 * - Listens via onSnapshot (instant updates across multiple tabs & devices)
 * - Includes offline cache resolution and pending write indicators
 * - Returns an unsubscribe function to prevent memory leaks on unmount
 */
export function subscribeToUserItems(
  userId: string,
  onUpdate: (items: SyncedItem[], metadata: SnapshotMetadata) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  // Only connect listener if a valid authenticated user is signed in matching this userId
  if (
    !userId ||
    userId === 'anonymous-client' ||
    userId === 'guest_user' ||
    !auth.currentUser ||
    auth.currentUser.uid !== userId
  ) {
    return () => {};
  }

  const collectionPath = `users/${userId}/items`;
  const itemsColRef = collection(db, 'users', userId, 'items');
  const q = query(itemsColRef, orderBy('updatedAt', 'desc'));

  const unsubscribe = onSnapshot(
    q,
    { includeMetadataChanges: true },
    (snapshot) => {
      const items: SyncedItem[] = snapshot.docs.map((docSnap) => {
        const data = docSnap.data() as DocumentData;
        return {
          id: docSnap.id,
          userId: data.userId || userId,
          name: data.name || '',
          category: data.category || '',
          quantity: typeof data.quantity === 'number' ? data.quantity : 0,
          status: data.status || 'Available',
          notes: data.notes || '',
          createdAt: data.createdAt,
          updatedAt: data.updatedAt,
          _metadata: {
            fromCache: docSnap.metadata.fromCache,
            hasPendingWrites: docSnap.metadata.hasPendingWrites,
          },
        };
      });

      onUpdate(items, snapshot.metadata);
    },
    (error: FirestoreError) => {
      console.error(`[RealtimeSync] Listener error on ${collectionPath}:`, error);
      if (onError) {
        onError(error);
      } else {
        handleFirestoreError(error, OperationType.LIST, collectionPath);
      }
    }
  );

  return unsubscribe;
}

/**
 * Create a new item under /users/{userId}/items/{itemId}
 */
export async function createRealtimeItem(
  userId: string,
  itemData: Omit<SyncedItem, 'id' | 'userId' | 'createdAt' | 'updatedAt' | '_metadata'> & { id?: string }
): Promise<string> {
  const itemsColRef = collection(db, 'users', userId, 'items');
  const itemDocRef = itemData.id ? doc(itemsColRef, itemData.id) : doc(itemsColRef);
  const path = `users/${userId}/items/${itemDocRef.id}`;

  try {
    const payload = {
      ...itemData,
      id: itemDocRef.id,
      userId,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };
    await setDoc(itemDocRef, payload);
    return itemDocRef.id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
    return itemDocRef.id;
  }
}

/**
 * Field-level partial update (Conflict-Safe: Last-Write-Wins per Field).
 * Using updateDoc rather than setDoc prevents overwriting other devices' concurrent edits.
 */
export async function updateRealtimeItemFields(
  userId: string,
  itemId: string,
  fields: Partial<Omit<SyncedItem, 'id' | 'userId' | 'createdAt' | '_metadata'>>
): Promise<void> {
  const itemDocRef = doc(db, 'users', userId, 'items', itemId);
  const path = `users/${userId}/items/${itemId}`;

  try {
    await updateDoc(itemDocRef, {
      ...fields,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

/**
 * Atomically adjust item quantity across multiple devices without race conditions
 */
export async function adjustRealtimeItemQuantity(
  userId: string,
  itemId: string,
  delta: number
): Promise<void> {
  const itemDocRef = doc(db, 'users', userId, 'items', itemId);
  const path = `users/${userId}/items/${itemId}`;

  try {
    await updateDoc(itemDocRef, {
      quantity: increment(delta),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

/**
 * Save an asset directly to Firestore with full field-mapping and auto-auth handling.
 * Returns the saved Firestore document ID.
 */
export async function saveItemToFirestore(
  item: Partial<SyncedItem> & { name: string; category?: string; quantity?: number; status?: string; id?: string; [key: string]: any },
  customUserId?: string
): Promise<{ success: boolean; id: string; error?: string }> {
  try {
    const currentUid = auth.currentUser?.uid || customUserId;
    if (!currentUid || !auth.currentUser) {
      // Not authenticated with Firebase: keep locally in client store
      return { success: true, id: item.id || '' };
    }

    // Ensure item ID meets alphanumeric/dash/underscore constraint
    const rawId = item.id || `item_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const itemId = rawId.replace(/[^a-zA-Z0-9_\-]/g, '_');
    
    const parsedQty = typeof item.quantity === 'number' ? item.quantity : Number(item.quantity) || 0;
    const parsedAvail = typeof item.availableQuantity === 'number' ? item.availableQuantity : (Number(item.availableQuantity) || parsedQty);

    const rawPayload = {
      ...item,
      id: itemId,
      userId: currentUid,
      name: (item.name || 'Unnamed Asset').trim(),
      category: item.category || 'Material',
      quantity: parsedQty,
      availableQuantity: parsedAvail,
      status: item.status || (parsedQty === 0 ? 'Out of Stock' : 'Available'),
      updatedAt: serverTimestamp(),
      createdAt: item.createdAt || serverTimestamp(),
    };

    const sanitizedPayload = sanitizeForFirestore(rawPayload);

    // 1. Primary: Save to shared /metc_items/{itemId} for cross-device visibility
    const orgDocRef = doc(db, 'metc_items', itemId);
    await setDoc(orgDocRef, sanitizedPayload, { merge: true });

    // 2. Also save under /users/{userId}/items/{itemId} for user's subcollection
    try {
      if (currentUid && currentUid !== 'user_mountec') {
        const userItemDocRef = doc(db, 'users', currentUid, 'items', itemId);
        await setDoc(userItemDocRef, sanitizedPayload, { merge: true });
      }
    } catch (userErr) {
      console.warn('[FirestoreSync] User subcollection mirror notice:', userErr);
    }

    return { success: true, id: itemId };
  } catch (err: any) {
    console.error('[FirestoreSync] Failed to save item to Firestore:', err);
    return {
      success: false,
      id: item.id || '',
      error: err.message || 'Failed to save item to Firestore database',
    };
  }
}

/**
 * Subscribe to the shared organization METC items collection in Firestore
 */
export function subscribeToOrganizationMetcItems(
  onUpdate: (items: any[]) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  // Only connect listener if user is signed in to Firebase
  if (!auth.currentUser) {
    return () => {};
  }

  const collectionRef = collection(db, 'metc_items');
  const q = query(collectionRef);

  return onSnapshot(
    q,
    { includeMetadataChanges: false },
    (snapshot) => {
      const items: any[] = snapshot.docs.map((docSnap) => {
        const data = docSnap.data() as DocumentData;
        const qty = typeof data.quantity === 'number' ? data.quantity : Number(data.quantity) || 0;
        const avail = typeof data.availableQuantity === 'number' ? data.availableQuantity : Number(data.availableQuantity) || qty;

        return {
          ...data,
          id: docSnap.id,
          name: data.name || '',
          category: data.category || 'Material',
          quantity: qty,
          availableQuantity: avail,
          status: data.status || (qty === 0 ? 'Out of Stock' : 'Available'),
          notes: data.notes || data.description || '',
          _metadata: {
            fromCache: docSnap.metadata.fromCache,
            hasPendingWrites: docSnap.metadata.hasPendingWrites,
          },
        };
      });
      onUpdate(items);
    },
    (error) => {
      console.warn('[FirestoreSync] Org listener note:', error);
      if (onError) onError(error);
    }
  );
}

/**
 * Delete an item
 */
export async function deleteRealtimeItem(userId: string, itemId: string): Promise<void> {
  if (!userId || !auth.currentUser || auth.currentUser.uid !== userId) {
    return;
  }
  const itemDocRef = doc(db, 'users', userId, 'items', itemId);
  const path = `users/${userId}/items/${itemId}`;

  try {
    await deleteDoc(itemDocRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

/**
 * Clears all items stored in Firestore under /users/{userId}/items
 */
export async function clearAllUserFirestoreItems(userId: string): Promise<void> {
  if (!userId || !auth.currentUser || auth.currentUser.uid !== userId) {
    return;
  }
  const itemsColRef = collection(db, 'users', userId, 'items');
  try {
    const snap = await getDocs(itemsColRef);
    if (snap.empty) return;
    const batch = writeBatch(db);
    snap.docs.forEach((docSnap) => {
      batch.delete(docSnap.ref);
    });
    await batch.commit();
  } catch (error) {
    console.warn('[FirestoreSync] Failed to clear user items from Firestore:', error);
  }
}
