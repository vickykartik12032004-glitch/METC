import { PurchaseRecord, ExtractedInvoiceData, InvoiceDiscrepancyCheck } from '../types/purchase.types';

export interface ScanInvoiceResponse {
  success: boolean;
  extractedData?: ExtractedInvoiceData;
  discrepancyCheck?: InvoiceDiscrepancyCheck;
  error?: string;
}

export const purchaseService = {
  /**
   * Send invoice images/PDF to server-side Gemini AI Vision OCR
   */
  async scanInvoice(
    files: Array<{ mimeType: string; base64Data: string }>,
    fileName?: string
  ): Promise<ScanInvoiceResponse> {
    const res = await fetch('/api/invoices/scan', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ files, fileName }),
    });

    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data.error || 'Invoice scanning failed on the server.');
    }

    return data;
  },

  /**
   * Check for duplicate invoice numbers for a given supplier
   */
  async checkDuplicate(
    supplierName: string,
    invoiceNumber: string,
    excludeId?: string
  ): Promise<{ isDuplicate: boolean; existingPurchase?: PurchaseRecord }> {
    const params = new URLSearchParams({
      supplierName,
      invoiceNumber,
    });
    if (excludeId) params.append('excludeId', excludeId);

    const res = await fetch(`/api/invoices/check-duplicate?${params.toString()}`);
    if (!res.ok) return { isDuplicate: false };
    return await res.json();
  },

  /**
   * Fetch all purchases with optional search and status filters
   */
  async getPurchases(search?: string, status?: string): Promise<PurchaseRecord[]> {
    const params = new URLSearchParams();
    if (search) params.append('search', search);
    if (status) params.append('status', status);

    const res = await fetch(`/api/purchases?${params.toString()}`);
    if (!res.ok) throw new Error('Failed to load purchases history');
    const data = await res.json();
    return data.data || [];
  },

  /**
   * Get single purchase by ID
   */
  async getPurchaseById(id: string): Promise<PurchaseRecord> {
    const res = await fetch(`/api/purchases/${id}`);
    if (!res.ok) throw new Error('Failed to load purchase record');
    const data = await res.json();
    return data.data;
  },

  /**
   * Save a new draft purchase
   */
  async createDraft(payload: Partial<PurchaseRecord>, author?: string): Promise<PurchaseRecord> {
    const res = await fetch('/api/purchases/draft', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-name': author || 'Store Keeper',
      },
      body: JSON.stringify({ ...payload, author }),
    });
    const data = await res.json();
    if (!res.ok || !data.success) throw new Error(data.error || 'Failed to create draft purchase');
    return data.data;
  },

  /**
   * Update an existing draft purchase
   */
  async updateDraft(id: string, payload: Partial<PurchaseRecord>, author?: string): Promise<PurchaseRecord> {
    const res = await fetch(`/api/purchases/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'x-user-name': author || 'Store Keeper',
      },
      body: JSON.stringify({ ...payload, author }),
    });
    const data = await res.json();
    if (!res.ok || !data.success) throw new Error(data.error || 'Failed to update draft purchase');
    return data.data;
  },

  /**
   * Confirm purchase and atomically increment inventory stock (Idempotent)
   */
  async confirmPurchase(
    id: string,
    idempotencyKey?: string,
    author?: string
  ): Promise<{ success: boolean; purchase: PurchaseRecord; stockUpdates: any[] }> {
    const idemKey = idempotencyKey || `idem-${id}-${Date.now()}`;
    const res = await fetch(`/api/purchases/${id}/confirm`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-idempotency-key': idemKey,
        'x-user-name': author || 'Store Keeper',
      },
      body: JSON.stringify({ idempotencyKey: idemKey, author }),
    });
    const data = await res.json();
    if (!res.ok || !data.success) throw new Error(data.error || 'Failed to confirm purchase and apply stock updates');
    return data;
  },

  /**
   * Void a purchase record
   */
  async voidPurchase(id: string, reason: string, author?: string): Promise<PurchaseRecord> {
    const res = await fetch(`/api/purchases/${id}/void`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-name': author || 'Store Keeper',
      },
      body: JSON.stringify({ reason, author }),
    });
    const data = await res.json();
    if (!res.ok || !data.success) throw new Error(data.error || 'Failed to void purchase');
    return data.data;
  },

  /**
   * Delete a draft purchase
   */
  async deletePurchase(id: string, author?: string): Promise<boolean> {
    const res = await fetch(`/api/purchases/${id}`, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
        'x-user-name': author || 'Store Keeper',
      },
      body: JSON.stringify({ author }),
    });
    const data = await res.json();
    if (!res.ok || !data.success) throw new Error(data.error || 'Failed to delete draft purchase');
    return true;
  },
};
