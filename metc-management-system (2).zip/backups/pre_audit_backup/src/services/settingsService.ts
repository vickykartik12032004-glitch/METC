import { supabase, isSupabaseConfigured } from '../lib/supabase';
import type { Database } from '../types/database.types';
import { logActivity } from './activityLogService';

export type Settings = Database['public']['Tables']['settings']['Row'];
export type SettingsUpdate = Database['public']['Tables']['settings']['Update'];

/**
 * Get system settings
 */
export async function getSettings(): Promise<Settings | null> {
  if (!isSupabaseConfigured) return null;

  const { data, error } = await supabase
    .from('settings')
    .select('*')
    .limit(1)
    .maybeSingle();

  if (error) {
    console.error('Error fetching settings:', error.message);
    return null;
  }
  return data as Settings | null;
}

/**
 * Update system settings
 */
export async function updateSettings(
  id: string,
  updates: SettingsUpdate,
  userName = 'Super Admin'
): Promise<Settings | null> {
  if (!isSupabaseConfigured) return null;

  const { data, error } = await (supabase.from('settings') as any)
    .update(updates)
    .eq('id', id)
    .select()
    .single();

  if (error || !data) {
    console.error('Error updating settings:', error?.message);
    throw new Error(error?.message || 'Failed to update settings');
  }

  const updated = data as Settings;
  await logActivity('UPDATE_SETTINGS', 'settings', id, updates, userName);
  return updated;
}
