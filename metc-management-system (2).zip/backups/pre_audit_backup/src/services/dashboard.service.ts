import { useAssetStore } from '../store/useAssetStore';
import { useTransactionStore } from '../store/useTransactionStore';
import { useWorkerStore } from '../store/useWorkerStore';
import { useAdminStore } from '../store/useAdminStore';

export interface DashboardKpi {
  id: string;
  title: string;
  value: number;
  unit?: string;
  todayDiff: number;
  percentChange: number;
  isPositiveGood: boolean;
  color: 'blue' | 'emerald' | 'purple' | 'amber' | 'rose' | 'indigo' | 'cyan' | 'teal';
  category: 'inventory' | 'operations' | 'workforce';
}

export interface ChartDataPoint {
  period: string;
  issued: number;
  returned: number;
  transferred: number;
  repaired: number;
}

export interface CategoryDistribution {
  name: string;
  value: number;
  color: string;
}

export interface InventoryStatusPoint {
  status: string;
  count: number;
  color: string;
}

export interface ActivityItem {
  id: string;
  user: string;
  role: string;
  avatar?: string;
  action: string;
  target: string;
  timestamp: string;
  status: 'Completed' | 'In Progress' | 'Alert' | 'Pending';
  type: 'issue' | 'return' | 'repair' | 'worker' | 'system';
}

export interface LowStockItem {
  id: string;
  code: string;
  name: string;
  category: string;
  currentStock: number;
  minStock: number;
  unit: string;
  location: string;
  status: 'Critical' | 'Warning';
}

export interface ExpiringItem {
  id: string;
  itemCode: string;
  itemName: string;
  type: 'Warranty' | 'Calibration' | 'Expiry';
  dueDate: string;
  daysRemaining: number;
  assignedTo?: string;
  status: 'Overdue' | 'Urgent' | 'Upcoming';
}

export interface RecentIssueRecord {
  id: string;
  issueCode: string;
  workerName: string;
  workerRole: string;
  itemName: string;
  itemCode: string;
  issueDate: string;
  expectedReturnDate: string;
  status: 'Active' | 'Returned' | 'Overdue' | 'Pending Return';
}

export interface SystemNotification {
  id: string;
  type: 'low_stock' | 'repair_complete' | 'warranty_expiry' | 'system_alert';
  title: string;
  message: string;
  timeAgo: string;
  read: boolean;
  priority: 'high' | 'medium' | 'low';
}

export interface WeatherData {
  siteName: string;
  temperatureC: number;
  temperatureF: number;
  condition: string;
  humidity: number;
  windSpeedKm: number;
  uvIndex: string;
  safetyStatus: string;
  updatedAt: string;
}

export interface CompanyMetrics {
  companyName: string;
  logoUrl?: string;
  branchCount: number;
  siteCount: number;
  departmentCount: number;
  workerCount: number;
  totalAssetValue: string;
  activeProjects: number;
}

export class DashboardService {
  static getKpiCards(): DashboardKpi[] {
    const assets = useAssetStore.getState().getAllAssets();
    const transactionStore = useTransactionStore.getState();
    const workerStore = useWorkerStore.getState();

    const totalAssets = assets.reduce((sum, item) => sum + item.quantity, 0);
    const availableItems = assets.filter(i => i.status === 'Available').reduce((sum, i) => sum + i.availableQuantity, 0);
    const issuedItems = transactionStore.issues.filter(i => i.status === 'Active').reduce((sum, i) => sum + i.quantity, 0);
    const underRepair = transactionStore.repairs.filter(r => r.status === 'In Repair' || r.status === 'Pending').length;
    const lostItems = transactionStore.lostItems.reduce((sum, l) => sum + l.quantityLost, 0);
    const disposedItems = assets.filter(i => i.status === 'Disposed').length;
    const lowStockItems = assets.filter(i => i.status === 'Low Stock' || i.availableQuantity <= i.minQuantityThreshold).length;

    const todayStr = new Date().toISOString().split('T')[0];
    const todaysIssues = transactionStore.issues.filter(i => i.issueDate?.startsWith(todayStr)).length;
    const todaysReturns = transactionStore.returns.filter(r => r.returnDate?.startsWith(todayStr)).length;

    const activeWorkers = workerStore.workers.filter(w => w.status === 'Active').length;
    const inactiveWorkers = workerStore.workers.filter(w => w.status === 'Inactive' || w.status === 'On Leave').length;
    const pendingRepairs = transactionStore.repairs.filter(r => r.status === 'Pending').length;

    return [
      {
        id: 'total_assets',
        title: 'Total Assets',
        value: totalAssets,
        todayDiff: 0,
        percentChange: 0,
        isPositiveGood: true,
        color: 'blue',
        category: 'inventory',
      },
      {
        id: 'available_items',
        title: 'Available Items',
        value: availableItems,
        todayDiff: 0,
        percentChange: 0,
        isPositiveGood: true,
        color: 'emerald',
        category: 'inventory',
      },
      {
        id: 'issued_items',
        title: 'Issued Items',
        value: issuedItems,
        todayDiff: 0,
        percentChange: 0,
        isPositiveGood: true,
        color: 'purple',
        category: 'operations',
      },
      {
        id: 'under_repair',
        title: 'Under Repair',
        value: underRepair,
        todayDiff: 0,
        percentChange: 0,
        isPositiveGood: true,
        color: 'amber',
        category: 'operations',
      },
      {
        id: 'lost_items',
        title: 'Lost Items',
        value: lostItems,
        todayDiff: 0,
        percentChange: 0,
        isPositiveGood: false,
        color: 'rose',
        category: 'inventory',
      },
      {
        id: 'disposed_items',
        title: 'Disposed Items',
        value: disposedItems,
        todayDiff: 0,
        percentChange: 0,
        isPositiveGood: true,
        color: 'indigo',
        category: 'inventory',
      },
      {
        id: 'low_stock_items',
        title: 'Low Stock Items',
        value: lowStockItems,
        todayDiff: 0,
        percentChange: 0,
        isPositiveGood: false,
        color: 'amber',
        category: 'inventory',
      },
      {
        id: 'todays_issues',
        title: "Today's Issues",
        value: todaysIssues,
        todayDiff: 0,
        percentChange: 0,
        isPositiveGood: true,
        color: 'cyan',
        category: 'operations',
      },
      {
        id: 'todays_returns',
        title: "Today's Returns",
        value: todaysReturns,
        todayDiff: 0,
        percentChange: 0,
        isPositiveGood: true,
        color: 'teal',
        category: 'operations',
      },
      {
        id: 'active_workers',
        title: 'Active Workers',
        value: activeWorkers,
        todayDiff: 0,
        percentChange: 0,
        isPositiveGood: true,
        color: 'emerald',
        category: 'workforce',
      },
      {
        id: 'inactive_workers',
        title: 'Inactive Workers',
        value: inactiveWorkers,
        todayDiff: 0,
        percentChange: 0,
        isPositiveGood: true,
        color: 'rose',
        category: 'workforce',
      },
      {
        id: 'pending_repairs',
        title: 'Pending Repairs',
        value: pendingRepairs,
        todayDiff: 0,
        percentChange: 0,
        isPositiveGood: true,
        color: 'amber',
        category: 'operations',
      },
    ];
  }

  static getMonthlyTrends(): ChartDataPoint[] {
    const transactionStore = useTransactionStore.getState();
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    
    // If no transactions exist, return 0 for each month
    return months.map((m) => ({
      period: m,
      issued: 0,
      returned: 0,
      transferred: 0,
      repaired: 0,
    }));
  }

  static getCategoryDistribution(): CategoryDistribution[] {
    const assets = useAssetStore.getState().getAllAssets();
    if (assets.length === 0) return [];

    const categoryCounts: Record<string, number> = {};
    assets.forEach(asset => {
      const cat = asset.category || 'Other';
      categoryCounts[cat] = (categoryCounts[cat] || 0) + asset.quantity;
    });

    const colors = ['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899'];
    return Object.keys(categoryCounts).map((cat, idx) => ({
      name: cat,
      value: categoryCounts[cat],
      color: colors[idx % colors.length],
    }));
  }

  static getInventoryStatus(): InventoryStatusPoint[] {
    const assets = useAssetStore.getState().getAllAssets();
    const available = assets.filter(i => i.status === 'Available').length;
    const issued = assets.filter(i => i.status === 'Issued').length;
    const repair = assets.filter(i => i.status === 'Under Repair').length;
    const lowStock = assets.filter(i => i.status === 'Low Stock').length;
    const lost = assets.filter(i => i.status === 'Lost' || i.status === 'Out of Stock').length;

    return [
      { status: 'Available', count: available, color: '#10b981' },
      { status: 'Issued', count: issued, color: '#3b82f6' },
      { status: 'Under Repair', count: repair, color: '#f59e0b' },
      { status: 'Low Stock', count: lowStock, color: '#ec4899' },
      { status: 'Lost / Damaged', count: lost, color: '#ef4444' },
    ];
  }

  static getRecentActivities(): ActivityItem[] {
    const activities = useTransactionStore.getState().activities;
    return activities.map(act => ({
      id: act.id,
      user: act.user,
      role: 'System User',
      action: act.action,
      target: act.targetName,
      timestamp: new Date(act.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'Completed' as const,
      type: 'issue' as const,
    }));
  }

  static getLowStockItems(): LowStockItem[] {
    const assets = useAssetStore.getState().getAllAssets();
    const lowStock = assets.filter(i => i.status === 'Low Stock' || i.availableQuantity <= i.minQuantityThreshold);
    return lowStock.map(item => ({
      id: item.id,
      code: item.code,
      name: item.name,
      category: item.category,
      currentStock: item.availableQuantity,
      minStock: item.minQuantityThreshold,
      unit: item.unit,
      location: item.location,
      status: item.availableQuantity === 0 ? 'Critical' : 'Warning',
    }));
  }

  static getExpiringItems(): ExpiringItem[] {
    return [];
  }

  static getRecentIssues(): RecentIssueRecord[] {
    const issues = useTransactionStore.getState().issues;
    return issues.slice(0, 10).map(i => ({
      id: i.id,
      issueCode: i.issueCode,
      workerName: i.workerName,
      workerRole: 'Worker',
      itemName: i.itemName,
      itemCode: i.itemId,
      issueDate: i.issueDate,
      expectedReturnDate: i.expectedReturnDate || '-',
      status: i.status === 'Active' ? 'Active' : 'Returned',
    }));
  }

  static getNotifications(): SystemNotification[] {
    return [];
  }

  static getWeather(): WeatherData {
    return {
      siteName: 'MOUNTEC Headquarters',
      temperatureC: 30,
      temperatureF: 86,
      condition: 'Fair',
      humidity: 60,
      windSpeedKm: 10,
      uvIndex: 'Moderate (4.0)',
      safetyStatus: 'Safe for All Work Operations',
      updatedAt: 'Live Feed',
    };
  }

  static getCompanySummary(): CompanyMetrics {
    const adminStore = useAdminStore.getState();
    const workerStore = useWorkerStore.getState();
    const assets = useAssetStore.getState().getAllAssets();

    const totalValue = assets.reduce((sum, a) => sum + (a.totalValue || 0), 0);
    const activeProjects = adminStore.sites.filter(s => s.status === 'Active').length;

    return {
      companyName: adminStore.companyProfile.companyName || 'MOUNTEC PTE LTD',
      logoUrl: adminStore.companyProfile.logoUrl || '',
      branchCount: adminStore.branches.length,
      siteCount: adminStore.sites.length,
      departmentCount: adminStore.departments.length,
      workerCount: workerStore.workers.length,
      totalAssetValue: `$${totalValue.toLocaleString()}`,
      activeProjects,
    };
  }
}

