import { supabase, isSupabaseConfigured } from '../lib/supabase';
import type { Database } from '../types/database.types';

export type Notification = Database['public']['Tables']['notifications']['Row'];
export type NotificationInsert = Database['public']['Tables']['notifications']['Insert'];

/**
 * Fetch Notifications
 */
export async function getNotifications(userId?: string): Promise<Notification[]> {
  if (!isSupabaseConfigured) return [];

  let query = supabase
    .from('notifications')
    .select('*')
    .order('created_at', { ascending: false });

  if (userId) {
    query = query.or(`user_id.eq.${userId},user_id.is.null`);
  }

  const { data, error } = await query;
  if (error) {
    console.error('Error fetching notifications:', error.message);
    return [];
  }
  return (data as Notification[]) || [];
}

/**
 * Create a Notification
 */
export async function createNotification(notification: NotificationInsert): Promise<Notification | null> {
  if (!isSupabaseConfigured) return null;

  const { data, error } = await (supabase.from('notifications') as any)
    .insert(notification)
    .select()
    .single();

  if (error) {
    console.error('Error creating notification:', error.message);
    return null;
  }
  return data as Notification;
}

/**
 * Mark notification as read
 */
export async function markNotificationAsRead(id: string): Promise<boolean> {
  if (!isSupabaseConfigured) return true;

  const { error } = await (supabase.from('notifications') as any)
    .update({ read_status: true })
    .eq('id', id);

  if (error) {
    console.error(`Error marking notification ${id} as read:`, error.message);
    return false;
  }
  return true;
}
