import { supabase, isSupabaseConfigured } from '../lib/supabase';
import type { Database } from '../types/database.types';
import { logActivity } from './activityLogService';

export type IssueTransaction = Database['public']['Tables']['issue_transactions']['Row'];
export type IssueTransactionInsert = Database['public']['Tables']['issue_transactions']['Insert'];

export type ReturnTransaction = Database['public']['Tables']['return_transactions']['Row'];
export type ReturnTransactionInsert = Database['public']['Tables']['return_transactions']['Insert'];

export type TransferTransaction = Database['public']['Tables']['transfer_transactions']['Row'];
export type TransferTransactionInsert = Database['public']['Tables']['transfer_transactions']['Insert'];

export type RepairTransaction = Database['public']['Tables']['repair_transactions']['Row'];
export type RepairTransactionInsert = Database['public']['Tables']['repair_transactions']['Insert'];

export type LostTransaction = Database['public']['Tables']['lost_transactions']['Row'];
export type LostTransactionInsert = Database['public']['Tables']['lost_transactions']['Insert'];

export type StockAdjustment = Database['public']['Tables']['stock_adjustments']['Row'];
export type StockAdjustmentInsert = Database['public']['Tables']['stock_adjustments']['Insert'];

/**
 * Helper to generate sequential transaction numbers
 */
export function generateTransactionNumber(prefix: string): string {
  const timestamp = Date.now().toString().slice(-6);
  const random = Math.floor(100 + Math.random() * 900);
  return `${prefix}-${timestamp}-${random}`;
}

// =========================================================
// ISSUE TRANSACTIONS
// =========================================================

export async function createIssueTransaction(
  issueData: Omit<IssueTransactionInsert, 'issue_number'>,
  userName = 'Store Keeper'
): Promise<IssueTransaction | null> {
  if (!isSupabaseConfigured) return null;

  const issueNumber = generateTransactionNumber('ISS');

  // Check item availability
  const { data: itemData, error: itemErr } = await supabase
    .from('metc_items')
    .select('id, current_stock, minimum_stock, item_name')
    .eq('id', issueData.item_id)
    .single();

  if (itemErr || !itemData) {
    throw new Error('Item not found or unavailable for issuance.');
  }

  const item = itemData as { id: string; current_stock: number; minimum_stock: number; item_name: string };
  const issueQty = issueData.quantity || 1;

  if (item.current_stock < issueQty) {
    throw new Error(`Insufficient stock. Current available stock: ${item.current_stock}`);
  }

  // Create issue record
  const { data: issueRecord, error: issueErr } = await (supabase.from('issue_transactions') as any)
    .insert({
      ...issueData,
      issue_number: issueNumber,
      quantity: issueQty,
      status: 'Active',
    })
    .select()
    .single();

  if (issueErr || !issueRecord) {
    throw new Error(`Failed to create issue transaction: ${issueErr?.message || 'Unknown error'}`);
  }

  const issue = issueRecord as IssueTransaction;

  // Deduct stock
  const newStock = Math.max(0, item.current_stock - issueQty);
  let newStatus: any = 'Available';
  if (newStock === 0) newStatus = 'Out of Stock';
  else if (newStock <= item.minimum_stock) newStatus = 'Low Stock';

  await (supabase.from('metc_items') as any)
    .update({ current_stock: newStock, status: newStatus })
    .eq('id', item.id);

  await logActivity('ISSUE_ITEM', 'issue_transactions', issue.id, {
    issue_number: issueNumber,
    item_id: item.id,
    item_name: item.item_name,
    quantity: issueQty,
    worker_id: issueData.worker_id,
  }, userName);

  return issue;
}

export async function getIssueTransactions(): Promise<IssueTransaction[]> {
  if (!isSupabaseConfigured) return [];
  const { data, error } = await supabase
    .from('issue_transactions')
    .select('*')
    .order('issue_date', { ascending: false });

  if (error) {
    console.error('Error fetching issues:', error.message);
    return [];
  }
  return (data as IssueTransaction[]) || [];
}

// =========================================================
// RETURN TRANSACTIONS
// =========================================================

export async function createReturnTransaction(
  returnData: Omit<ReturnTransactionInsert, 'return_number'>,
  userName = 'Store Keeper'
): Promise<ReturnTransaction | null> {
  if (!isSupabaseConfigured) return null;

  const returnNumber = generateTransactionNumber('RET');

  // Verify Issue Record
  const { data: issueData, error: issueErr } = await supabase
    .from('issue_transactions')
    .select('*')
    .eq('id', returnData.issue_id)
    .single();

  if (issueErr || !issueData) {
    throw new Error('Associated Issue record not found.');
  }

  const issue = issueData as IssueTransaction;

  // Create Return Record
  const { data: returnRecord, error: returnErr } = await (supabase.from('return_transactions') as any)
    .insert({
      ...returnData,
      return_number: returnNumber,
      item_id: issue.item_id,
      worker_id: issue.worker_id,
    })
    .select()
    .single();

  if (returnErr || !returnRecord) {
    throw new Error(`Failed to log return transaction: ${returnErr?.message || 'Unknown error'}`);
  }

  const returnRec = returnRecord as ReturnTransaction;

  // Update Issue Status
  await (supabase.from('issue_transactions') as any)
    .update({ status: 'Returned' })
    .eq('id', issue.id);

  // Restore Item Stock & Status
  const { data: itemData } = await supabase
    .from('metc_items')
    .select('id, current_stock, minimum_stock')
    .eq('id', issue.item_id)
    .single();

  if (itemData) {
    const item = itemData as { id: string; current_stock: number; minimum_stock: number };
    const returnedQty = returnData.quantity_returned || 1;
    const restoredStock = item.current_stock + returnedQty;
    let updatedStatus: any = 'Available';

    if (returnData.condition === 'Needs Repair' || returnData.condition === 'Damaged') {
      updatedStatus = 'Repair';
    } else if (returnedQty < issue.quantity) {
      updatedStatus = 'Issued';
    }

    await (supabase.from('metc_items') as any)
      .update({ current_stock: restoredStock, status: updatedStatus })
      .eq('id', item.id);
  }

  await logActivity('RETURN_ITEM', 'return_transactions', returnRec.id, {
    return_number: returnNumber,
    issue_id: issue.id,
    condition: returnData.condition,
  }, userName);

  return returnRec;
}

export async function getReturnTransactions(): Promise<ReturnTransaction[]> {
  if (!isSupabaseConfigured) return [];
  const { data, error } = await supabase
    .from('return_transactions')
    .select('*')
    .order('return_date', { ascending: false });

  if (error) {
    console.error('Error fetching returns:', error.message);
    return [];
  }
  return (data as ReturnTransaction[]) || [];
}

// =========================================================
// TRANSFER TRANSACTIONS
// =========================================================

export async function createTransferTransaction(
  transferData: Omit<TransferTransactionInsert, 'transfer_number'>,
  userName = 'Store Keeper'
): Promise<TransferTransaction | null> {
  if (!isSupabaseConfigured) return null;

  const transferNumber = generateTransactionNumber('TRF');

  const { data: record, error } = await (supabase.from('transfer_transactions') as any)
    .insert({
      ...transferData,
      transfer_number: transferNumber,
      status: 'Completed',
    })
    .select()
    .single();

  if (error || !record) {
    throw new Error(`Transfer failed: ${error?.message || 'Unknown error'}`);
  }

  const data = record as TransferTransaction;

  // Update Item Site if transferring sites
  if (transferData.to_site_id) {
    await (supabase.from('metc_items') as any)
      .update({ site_id: transferData.to_site_id })
      .eq('id', transferData.item_id);
  }

  await logActivity('TRANSFER_ITEM', 'transfer_transactions', data.id, {
    transfer_number: transferNumber,
    item_id: transferData.item_id,
    to_site_id: transferData.to_site_id,
  }, userName);

  return data;
}

// =========================================================
// REPAIR TRANSACTIONS
// =========================================================

export async function createRepairTransaction(
  repairData: Omit<RepairTransactionInsert, 'repair_number'>,
  userName = 'Store Keeper'
): Promise<RepairTransaction | null> {
  if (!isSupabaseConfigured) return null;

  const repairNumber = generateTransactionNumber('REP');

  const { data: record, error } = await (supabase.from('repair_transactions') as any)
    .insert({
      ...repairData,
      repair_number: repairNumber,
      repair_status: 'In Repair',
    })
    .select()
    .single();

  if (error || !record) {
    throw new Error(`Repair record creation failed: ${error?.message || 'Unknown error'}`);
  }

  const data = record as RepairTransaction;

  // Update Item Status to Repair
  await (supabase.from('metc_items') as any)
    .update({ status: 'Repair' })
    .eq('id', repairData.item_id);

  await logActivity('LOG_REPAIR', 'repair_transactions', data.id, {
    repair_number: repairNumber,
    item_id: repairData.item_id,
    vendor: repairData.vendor,
  }, userName);

  return data;
}

// =========================================================
// LOST TRANSACTIONS
// =========================================================

export async function createLostTransaction(
  lostData: Omit<LostTransactionInsert, 'lost_number'>,
  userName = 'Store Keeper'
): Promise<LostTransaction | null> {
  if (!isSupabaseConfigured) return null;

  const lostNumber = generateTransactionNumber('LST');

  const { data: record, error } = await (supabase.from('lost_transactions') as any)
    .insert({
      ...lostData,
      lost_number: lostNumber,
    })
    .select()
    .single();

  if (error || !record) {
    throw new Error(`Lost report creation failed: ${error?.message || 'Unknown error'}`);
  }

  const data = record as LostTransaction;

  // Update item stock & status
  const { data: itemData } = await supabase
    .from('metc_items')
    .select('id, current_stock')
    .eq('id', lostData.item_id)
    .single();

  if (itemData) {
    const item = itemData as { id: string; current_stock: number };
    const qtyLost = lostData.quantity_lost || 1;
    const newStock = Math.max(0, item.current_stock - qtyLost);

    await (supabase.from('metc_items') as any)
      .update({
        current_stock: newStock,
        status: newStock === 0 ? 'Lost' : 'Available',
      })
      .eq('id', item.id);
  }

  await logActivity('REPORT_LOST', 'lost_transactions', data.id, {
    lost_number: lostNumber,
    item_id: lostData.item_id,
    reason: lostData.reason,
  }, userName);

  return data;
}

// =========================================================
// STOCK ADJUSTMENT
// =========================================================

export async function createStockAdjustment(
  adjustmentData: Omit<StockAdjustmentInsert, 'adjustment_number'>,
  userName = 'Store Keeper'
): Promise<StockAdjustment | null> {
  if (!isSupabaseConfigured) return null;

  const adjustmentNumber = generateTransactionNumber('ADJ');

  const { data: record, error } = await (supabase.from('stock_adjustments') as any)
    .insert({
      ...adjustmentData,
      adjustment_number: adjustmentNumber,
    })
    .select()
    .single();

  if (error || !record) {
    throw new Error(`Stock adjustment failed: ${error?.message || 'Unknown error'}`);
  }

  const data = record as StockAdjustment;

  // Set new current_stock on metc_items
  const { data: itemData } = await supabase
    .from('metc_items')
    .select('id, minimum_stock')
    .eq('id', adjustmentData.item_id)
    .single();

  if (itemData) {
    const item = itemData as { id: string; minimum_stock: number };
    let newStatus: any = 'Available';
    if (adjustmentData.new_quantity === 0) newStatus = 'Out of Stock';
    else if (adjustmentData.new_quantity <= item.minimum_stock) newStatus = 'Low Stock';

    await (supabase.from('metc_items') as any)
      .update({
        current_stock: adjustmentData.new_quantity,
        status: newStatus,
      })
      .eq('id', item.id);
  }

  await logActivity('ADJUST_STOCK', 'stock_adjustments', data.id, {
    adjustment_number: adjustmentNumber,
    item_id: adjustmentData.item_id,
    new_quantity: adjustmentData.new_quantity,
    reason: adjustmentData.reason,
  }, userName);

  return data;
}
