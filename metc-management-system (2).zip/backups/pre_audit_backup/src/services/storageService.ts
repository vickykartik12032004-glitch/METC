import { uploadFileToBucket, getPublicStorageUrl, STORAGE_BUCKETS } from '../lib/supabase';

/**
 * Service to handle uploading files to the 4 defined Supabase storage buckets:
 * - item-images
 * - worker-images
 * - documents
 * - company-logo
 */

export async function uploadItemPhoto(file: File, itemId: string): Promise<string | null> {
  const extension = file.name.split('.').pop() || 'jpg';
  const path = `items/${itemId}-${Date.now()}.${extension}`;
  const { url, error } = await uploadFileToBucket('ITEM_IMAGES', path, file);
  if (error) throw new Error(`Item photo upload failed: ${error.message}`);
  return url;
}

export async function uploadWorkerPhoto(file: File, workerId: string): Promise<string | null> {
  const extension = file.name.split('.').pop() || 'jpg';
  const path = `workers/${workerId}-${Date.now()}.${extension}`;
  const { url, error } = await uploadFileToBucket('WORKER_IMAGES', path, file);
  if (error) throw new Error(`Worker photo upload failed: ${error.message}`);
  return url;
}

export async function uploadDocument(file: File, itemId: string): Promise<string | null> {
  const path = `documents/${itemId}/${Date.now()}-${file.name}`;
  const { url, error } = await uploadFileToBucket('DOCUMENTS', path, file);
  if (error) throw new Error(`Document upload failed: ${error.message}`);
  return url;
}

export async function uploadCompanyLogo(file: File): Promise<string | null> {
  const extension = file.name.split('.').pop() || 'png';
  const path = `logo/company-logo-${Date.now()}.${extension}`;
  const { url, error } = await uploadFileToBucket('COMPANY_LOGO', path, file);
  if (error) throw new Error(`Logo upload failed: ${error.message}`);
  return url;
}
