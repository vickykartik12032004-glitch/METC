import { supabase, isSupabaseConfigured } from '../lib/supabase';
import type { Database } from '../types/database.types';
import { METCItem, AssetCategory, AssetStatus } from '../types';
import { logActivity } from './activityLogService';

export type METCDbRow = Database['public']['Tables']['metc_items']['Row'];
export type METCDbInsert = Database['public']['Tables']['metc_items']['Insert'];
export type METCDbUpdate = Database['public']['Tables']['metc_items']['Update'];

export interface METCFilterParams {
  category?: AssetCategory | 'All';
  searchQuery?: string;
  status?: string;
  siteId?: string;
  supplier?: string;
  lowStockOnly?: boolean;
  warrantyExpiringSoon?: boolean;
  calibrationDueSoon?: boolean;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

/**
 * Maps DB row or app object to unified METCItem interface
 */
export function mapDbRowToMETCItem(row: METCDbRow): METCItem {
  const categoryMap: Record<string, AssetCategory> = {
    'Material': 'Material',
    'Equipment': 'Equipment',
    'Tool': 'Tool',
    'Consumable': 'Consumable',
    'PPE': 'PPE',
  };

  const cat: AssetCategory = categoryMap[row.category_id] || 'Material';

  const base = {
    id: row.id,
    code: row.asset_id || row.id,
    name: row.item_name,
    category: cat,
    description: row.description || undefined,
    unit: row.unit || 'Units',
    quantity: row.quantity || 0,
    minQuantityThreshold: row.minimum_stock || 10,
    availableQuantity: row.current_stock ?? row.quantity ?? 0,
    location: row.storage_location || 'Main Store',
    status: (row.status as AssetStatus) || 'Available',
    unitPrice: row.purchase_cost || undefined,
    totalValue: (row.purchase_cost || 0) * (row.quantity || 0),
    supplier: row.supplier_id || undefined,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    brand: row.brand || undefined,
    model: row.model || undefined,
    serialNumber: row.serial_number || undefined,
    assetNumber: row.asset_number || undefined,
    qrCode: row.qr_code || undefined,
    barcode: row.barcode || undefined,
    minimumStock: row.minimum_stock,
    maximumStock: row.maximum_stock,
    currentStock: row.current_stock,
    purchaseDate: row.purchase_date || undefined,
    purchaseCost: row.purchase_cost || undefined,
    warrantyExpiry: row.warranty_expiry || undefined,
    calibrationDue: row.calibration_due || undefined,
    storageLocation: row.storage_location || undefined,
    rackNumber: row.rack_number || undefined,
    siteId: row.site_id || undefined,
    photoUrl: row.photo_url || undefined,
    remarks: row.remarks || undefined,
  };

  if (cat === 'Equipment') {
    return {
      ...base,
      category: 'Equipment',
      serialNumber: row.serial_number || 'N/A',
      modelNumber: row.model || undefined,
      manufacturer: row.brand || undefined,
    };
  }

  if (cat === 'Tool') {
    return {
      ...base,
      category: 'Tool',
      brand: row.brand || undefined,
      condition: 'Good',
    };
  }

  if (cat === 'Consumable') {
    return {
      ...base,
      category: 'Consumable',
      reorderLevel: row.minimum_stock || 10,
    };
  }

  if (cat === 'PPE') {
    return {
      ...base,
      category: 'PPE',
      size: 'Standard',
      safetyStandard: 'ANSI Z87.1',
      inspectionDueDate: row.calibration_due || undefined,
    };
  }

  return {
    ...base,
    category: 'Material',
    materialGrade: row.model || 'Standard',
    batchNumber: row.serial_number || undefined,
  };
}

/**
 * Fetch items from Supabase metc_items with filters
 */
export async function fetchMETCItems(filters?: METCFilterParams): Promise<METCItem[]> {
  if (!isSupabaseConfigured) return [];

  try {
    let query = supabase.from('metc_items').select('*');

    if (filters?.category && filters.category !== 'All') {
      query = query.eq('category_id', filters.category);
    }

    if (filters?.status && filters.status !== 'All') {
      query = query.eq('status', filters.status as any);
    }

    if (filters?.searchQuery && filters.searchQuery.trim() !== '') {
      const q = `%${filters.searchQuery.trim()}%`;
      query = query.or(
        `item_name.ilike.${q},asset_id.ilike.${q},serial_number.ilike.${q},asset_number.ilike.${q},brand.ilike.${q},barcode.ilike.${q},storage_location.ilike.${q}`
      );
    }

    const sortCol = filters?.sortBy || 'created_at';
    const isAsc = filters?.sortOrder === 'asc';
    query = query.order(sortCol, { ascending: isAsc });

    const { data, error } = await query;
    if (error) {
      console.warn('Supabase fetchMETCItems notice:', error.message);
      return [];
    }

    if (!data) return [];
    return data.map(mapDbRowToMETCItem);
  } catch (err) {
    console.error('Error in fetchMETCItems:', err);
    return [];
  }
}

/**
 * Create an item in Supabase
 */
export async function createMETCItemDb(
  itemData: any,
  userName = 'Store Keeper'
): Promise<METCItem | null> {
  if (!isSupabaseConfigured) return null;

  try {
    const item = itemData || {};
    const insertRow: METCDbInsert = {
      asset_id: item.code || `AST-${Date.now().toString().slice(-6)}`,
      category_id: item.category || 'Material',
      item_name: item.name || 'New Asset',
      description: item.description || null,
      brand: item.brand || item.manufacturer || null,
      model: item.model || item.materialGrade || null,
      serial_number: item.serialNumber || item.batchNumber || null,
      asset_number: item.assetNumber || null,
      qr_code: item.qrCode || `QR-${item.code || Date.now()}`,
      barcode: item.barcode || `BC-${item.code || Date.now()}`,
      unit: item.unit || 'Units',
      quantity: item.quantity ?? 0,
      minimum_stock: item.minQuantityThreshold ?? item.minimumStock ?? 10,
      maximum_stock: item.maximumStock ?? 1000,
      current_stock: item.availableQuantity ?? item.quantity ?? 0,
      purchase_date: item.purchaseDate || null,
      purchase_cost: item.unitPrice || item.purchaseCost || null,
      supplier_id: item.supplier || null,
      warranty_expiry: item.warrantyExpiry || null,
      calibration_due: item.calibrationDue || null,
      storage_location: item.location || item.storageLocation || 'Main Store',
      rack_number: item.rackNumber || null,
      site_id: item.siteId || null,
      photo_url: item.photoUrl || null,
      status: (item.status as any) || 'Available',
      remarks: item.remarks || null,
    };

    const { data, error } = await (supabase.from('metc_items') as any)
      .insert(insertRow)
      .select()
      .single();

    if (error || !data) {
      console.error('Failed to create item in Supabase:', error?.message);
      return null;
    }

    const created = mapDbRowToMETCItem(data as METCDbRow);
    await logActivity(
      'Created',
      'metc_items',
      created.id,
      { details: `Registered ${created.category} asset code: ${created.code}` },
      userName
    );
    return created;
  } catch (e) {
    console.error('Error inserting item to Supabase:', e);
    return null;
  }
}

/**
 * Update an item in Supabase
 */
export async function updateMETCItemDb(
  id: string,
  updatesData: any,
  userName = 'Store Keeper'
): Promise<METCItem | null> {
  if (!isSupabaseConfigured) return null;

  try {
    const updates = updatesData || {};
    const updateRow: METCDbUpdate = {};

    if (updates.name !== undefined) updateRow.item_name = updates.name;
    if (updates.code !== undefined) updateRow.asset_id = updates.code;
    if (updates.category !== undefined) updateRow.category_id = updates.category;
    if (updates.description !== undefined) updateRow.description = updates.description;
    if (updates.brand !== undefined || updates.manufacturer !== undefined) updateRow.brand = updates.brand || updates.manufacturer;
    if (updates.model !== undefined || updates.materialGrade !== undefined) updateRow.model = updates.model || updates.materialGrade;
    if (updates.serialNumber !== undefined || updates.batchNumber !== undefined) updateRow.serial_number = updates.serialNumber || updates.batchNumber;
    if (updates.assetNumber !== undefined) updateRow.asset_number = updates.assetNumber;
    if (updates.barcode !== undefined) updateRow.barcode = updates.barcode;
    if (updates.qrCode !== undefined) updateRow.qr_code = updates.qrCode;
    if (updates.unit !== undefined) updateRow.unit = updates.unit;
    if (updates.quantity !== undefined) updateRow.quantity = updates.quantity;
    if (updates.availableQuantity !== undefined) updateRow.current_stock = updates.availableQuantity;
    if (updates.minQuantityThreshold !== undefined || updates.minimumStock !== undefined) updateRow.minimum_stock = updates.minQuantityThreshold ?? updates.minimumStock;
    if (updates.maximumStock !== undefined) updateRow.maximum_stock = updates.maximumStock;
    if (updates.unitPrice !== undefined || updates.purchaseCost !== undefined) updateRow.purchase_cost = updates.unitPrice ?? updates.purchaseCost;
    if (updates.supplier !== undefined) updateRow.supplier_id = updates.supplier;
    if (updates.location !== undefined || updates.storageLocation !== undefined) updateRow.storage_location = updates.location || updates.storageLocation;
    if (updates.warrantyExpiry !== undefined) updateRow.warranty_expiry = updates.warrantyExpiry;
    if (updates.calibrationDue !== undefined) updateRow.calibration_due = updates.calibrationDue;
    if (updates.status !== undefined) updateRow.status = updates.status as any;
    if (updates.photoUrl !== undefined) updateRow.photo_url = updates.photoUrl;
    if (updates.remarks !== undefined) updateRow.remarks = updates.remarks;

    updateRow.updated_at = new Date().toISOString();

    const { data, error } = await (supabase.from('metc_items') as any)
      .update(updateRow)
      .eq('id', id)
      .select()
      .single();

    if (error || !data) {
      console.warn('Notice updating item in Supabase:', error?.message);
      return null;
    }

    const updated = mapDbRowToMETCItem(data as METCDbRow);
    await logActivity(
      'Updated',
      'metc_items',
      updated.id,
      { details: `Updated asset details for ${updated.code}` },
      userName
    );
    return updated;
  } catch (e) {
    console.error('Error updating item in Supabase:', e);
    return null;
  }
}

/**
 * Delete / Archive item in Supabase
 */
export async function deleteMETCItemDb(id: string, userName = 'Super Admin'): Promise<boolean> {
  if (!isSupabaseConfigured) return false;

  try {
    const { error } = await supabase.from('metc_items').delete().eq('id', id);
    if (error) {
      console.warn('Notice deleting item in Supabase:', error.message);
      return false;
    }

    await logActivity(
      'Deleted',
      'metc_items',
      id,
      { details: `Archived / deleted asset record ${id}` },
      userName
    );
    return true;
  } catch (e) {
    console.error('Error deleting item in Supabase:', e);
    return false;
  }
}
