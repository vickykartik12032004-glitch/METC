import { supabase, isSupabaseConfigured } from '../lib/supabase';
import type { Database } from '../types/database.types';
import { logActivity } from './activityLogService';

export type Worker = Database['public']['Tables']['workers']['Row'];
export type WorkerInsert = Database['public']['Tables']['workers']['Insert'];
export type WorkerUpdate = Database['public']['Tables']['workers']['Update'];
export type Department = Database['public']['Tables']['departments']['Row'];
export type Site = Database['public']['Tables']['sites']['Row'];
export type Branch = Database['public']['Tables']['branches']['Row'];

export interface WorkerFilterOptions {
  departmentId?: string;
  siteId?: string;
  status?: string;
  searchQuery?: string;
}

/**
 * Fetch Departments
 */
export async function getDepartments(): Promise<Department[]> {
  if (!isSupabaseConfigured) return [];
  const { data, error } = await supabase.from('departments').select('*').order('name');
  if (error) {
    console.error('Error fetching departments:', error.message);
    return [];
  }
  return (data as Department[]) || [];
}

/**
 * Fetch Sites
 */
export async function getSites(): Promise<Site[]> {
  if (!isSupabaseConfigured) return [];
  const { data, error } = await supabase.from('sites').select('*').order('name');
  if (error) {
    console.error('Error fetching sites:', error.message);
    return [];
  }
  return (data as Site[]) || [];
}

/**
 * Fetch Branches
 */
export async function getBranches(): Promise<Branch[]> {
  if (!isSupabaseConfigured) return [];
  const { data, error } = await supabase.from('branches').select('*').order('name');
  if (error) {
    console.error('Error fetching branches:', error.message);
    return [];
  }
  return (data as Branch[]) || [];
}

/**
 * Fetch Workers with filters
 */
export async function getWorkers(filters?: WorkerFilterOptions): Promise<Worker[]> {
  if (!isSupabaseConfigured) return [];

  let query = supabase.from('workers').select('*').order('created_at', { ascending: false });

  if (filters?.departmentId) {
    query = query.eq('department_id', filters.departmentId);
  }
  if (filters?.siteId) {
    query = query.eq('site_id', filters.siteId);
  }
  if (filters?.status) {
    query = query.eq('status', filters.status as any);
  }
  if (filters?.searchQuery) {
    const q = `%${filters.searchQuery}%`;
    query = query.or(`name.ilike.${q},worker_id.ilike.${q},employee_number.ilike.${q},trade.ilike.${q}`);
  }

  const { data, error } = await query;
  if (error) {
    console.error('Error fetching workers:', error.message);
    return [];
  }
  return (data as Worker[]) || [];
}

/**
 * Fetch Worker by ID
 */
export async function getWorkerById(id: string): Promise<Worker | null> {
  if (!isSupabaseConfigured) return null;

  const { data, error } = await supabase
    .from('workers')
    .select('*')
    .eq('id', id)
    .single();

  if (error) {
    console.error(`Error fetching worker ${id}:`, error.message);
    return null;
  }
  return data as Worker;
}

/**
 * Create a Worker record
 */
export async function createWorker(worker: WorkerInsert, userName = 'Store Keeper'): Promise<Worker | null> {
  if (!isSupabaseConfigured) return null;

  const { data, error } = await (supabase.from('workers') as any)
    .insert(worker)
    .select()
    .single();

  if (error || !data) {
    console.error('Error creating worker:', error?.message);
    throw new Error(error?.message || 'Failed to create worker');
  }

  const created = data as Worker;
  await logActivity('CREATE', 'workers', created.id, { name: created.name, worker_id: created.worker_id }, userName);
  return created;
}

/**
 * Update a Worker record
 */
export async function updateWorker(id: string, updates: WorkerUpdate, userName = 'Store Keeper'): Promise<Worker | null> {
  if (!isSupabaseConfigured) return null;

  const { data, error } = await (supabase.from('workers') as any)
    .update(updates)
    .eq('id', id)
    .select()
    .single();

  if (error || !data) {
    console.error(`Error updating worker ${id}:`, error?.message);
    throw new Error(error?.message || 'Failed to update worker');
  }

  const updated = data as Worker;
  await logActivity('UPDATE', 'workers', id, updates, userName);
  return updated;
}
