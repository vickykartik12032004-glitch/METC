import { supabase, isSupabaseConfigured, uploadFileToBucket } from '../lib/supabase';
import type { Database } from '../types/database.types';
import { User, UserRole, UserSession } from '../types';
import {
  hashPassword,
  verifyPassword,
  generateSecureToken,
  getRateLimitStatus,
  recordFailedAttempt,
  resetFailedAttempts,
} from '../utils/crypto';

export type DbUser = Database['public']['Tables']['users']['Row'];

// Storage Keys
const SESSION_STORAGE_KEY = 'mountec_auth_session';
const REGISTERED_USERS_KEY = 'mountec_registered_users';
const PASSWORD_RESET_TOKENS_KEY = 'mountec_password_reset_tokens';

// Session duration configuration
export const SESSION_DURATION_HOURS = 24; // 24 hours standard
export const REMEMBER_ME_DURATION_DAYS = 30; // 30 days if remember me is checked

export interface AuthResult {
  success: boolean;
  user?: User;
  session?: UserSession;
  error?: string;
  isLocked?: boolean;
  lockoutRemainingSeconds?: number;
}

export interface StoredUserAccount extends User {
  passwordHash: string;
  passwordSalt: string;
  accountStatus: 'Active' | 'Inactive' | 'Locked' | 'Deactivated';
  failedLoginAttempts?: number;
  lastLoginAt?: string;
  updatedAt?: string;
}

export interface PasswordResetToken {
  token: string;
  email: string;
  expiresAt: number; // timestamp
  used: boolean;
  createdAt: number;
}

/**
 * Initial Root Super Admin Account Seed (if no accounts exist)
 */
const DEFAULT_INITIAL_ADMINS: Array<{
  id: string;
  email: string;
  name: string;
  role: UserRole;
  passwordPlain: string;
  department: string;
  phone: string;
  projectSite: string;
  assignedSites: string[];
  allSitesAccess: boolean;
}> = [
  {
    id: 'auth-usr-001',
    email: 'vickykartik12032004@gmail.com',
    name: 'Super Admin',
    role: 'Super Admin',
    passwordPlain: 'Admin@123456',
    department: 'Management & IT',
    phone: '+65 6789 1234',
    projectSite: 'Corporate HQ - Marina Bay',
    assignedSites: ['M-001_Tenga Plantation C1', 'M-002_Blue Horizon #14-21', 'M-003_Parc Life', 'Q-001_OVB #19-04 (Astro)', 'Q-002_RWS (NH)'],
    allSitesAccess: true,
  },
  {
    id: 'usr-admin-ops',
    email: 'admin@mountec.com',
    name: 'David Tan (Admin)',
    role: 'Admin',
    passwordPlain: 'Admin@123456',
    department: 'Store & Inventory Logistics',
    phone: '+65 6789 2200',
    projectSite: 'Corporate HQ - Marina Bay',
    assignedSites: ['Corporate HQ - Marina Bay', 'Tuas Mega Logistics Depot', 'Changi Airport Terminal 5 Expansion'],
    allSitesAccess: true,
  },
];

/**
 * Get all registered accounts from persistent storage
 */
export async function getStoredAccounts(): Promise<StoredUserAccount[]> {
  try {
    const raw = localStorage.getItem(REGISTERED_USERS_KEY);
    let accounts: StoredUserAccount[] = raw ? JSON.parse(raw) : [];

    // If storage is empty, initialize default seed accounts with hashed passwords
    if (accounts.length === 0) {
      accounts = [];
      for (const admin of DEFAULT_INITIAL_ADMINS) {
        const { hash, salt } = await hashPassword(admin.passwordPlain);
        accounts.push({
          id: admin.id,
          email: admin.email.toLowerCase(),
          name: admin.name,
          role: admin.role,
          avatar: `https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80`,
          department: admin.department,
          phone: admin.phone,
          projectSite: admin.projectSite,
          assignedSites: admin.assignedSites,
          allSitesAccess: admin.allSitesAccess,
          accountStatus: 'Active',
          passwordHash: hash,
          passwordSalt: salt,
          createdAt: new Date().toISOString(),
        });
      }
      localStorage.setItem(REGISTERED_USERS_KEY, JSON.stringify(accounts));
    }

    return accounts;
  } catch (err) {
    console.error('Failed to load accounts from storage:', err);
    return [];
  }
}

/**
 * Save updated accounts list to persistent storage
 */
export function saveStoredAccounts(accounts: StoredUserAccount[]): void {
  try {
    localStorage.setItem(REGISTERED_USERS_KEY, JSON.stringify(accounts));
  } catch (err) {
    console.error('Failed to save accounts to storage:', err);
  }
}

/**
 * Find account by email (case-insensitive)
 */
export async function findAccountByEmail(email?: string | null): Promise<StoredUserAccount | null> {
  if (!email || typeof email !== 'string') return null;
  const accounts = await getStoredAccounts();
  const normalized = email.trim().toLowerCase();
  return accounts.find((a) => a && a.email && a.email.toLowerCase() === normalized) || null;
}

/**
 * Register a new user account with secure password hashing and duplicate check
 */
export async function registerNewUser(params: {
  name: string;
  email: string;
  password: string;
  role?: UserRole;
  department?: string;
  phone?: string;
  projectSite?: string;
}): Promise<AuthResult> {
  const email = params.email.trim().toLowerCase();
  const name = params.name.trim();

  if (!email || !params.password || !name) {
    return { success: false, error: 'All required fields must be filled.' };
  }

  // Check duplicate email
  const existing = await findAccountByEmail(email);
  if (existing) {
    return {
      success: false,
      error: 'An account with this email address already exists. Please sign in or use a different email.',
    };
  }

  // Hash the password with a unique cryptographic salt
  const { hash, salt } = await hashPassword(params.password);

  const newUser: StoredUserAccount = {
    id: `usr-${Date.now()}-${generateSecureToken(4)}`,
    email,
    name,
    role: params.role || 'User',
    avatar: '',
    department: params.department || 'Operations',
    phone: params.phone || '',
    projectSite: params.projectSite || 'HQ Main',
    accountStatus: 'Active',
    passwordHash: hash,
    passwordSalt: salt,
    createdAt: new Date().toISOString(),
  };

  // If Supabase is configured, create the user in Supabase Auth and database
  if (isSupabaseConfigured) {
    try {
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email,
        password: params.password,
        options: {
          data: {
            full_name: name,
            role: newUser.role,
          },
        },
      });

      if (authError) {
        // If Supabase signup fails, report specific error
        console.warn('Supabase signup notice:', authError.message);
      } else if (authData.user) {
        newUser.id = authData.user.id;
        // Insert to users table
        try {
          await (supabase.from('users') as any).insert({
            id: authData.user.id,
            email,
            full_name: name,
            phone: params.phone || null,
            created_at: new Date().toISOString(),
          });
        } catch (dbErr) {
          console.warn('Supabase DB table insert notice:', dbErr);
        }
      }
    } catch (err: any) {
      console.warn('Supabase signup call failed, continuing with local secure storage:', err);
    }
  }

  // Save to persistent local accounts store
  const accounts = await getStoredAccounts();
  accounts.push(newUser);
  saveStoredAccounts(accounts);

  // Return clean user object (excluding secret password fields)
  const { passwordHash: _h, passwordSalt: _s, ...cleanUser } = newUser;
  return {
    success: true,
    user: cleanUser,
  };
}

/**
 * Authenticate with Email & Password
 */
export async function authenticateWithEmailPassword(
  email: string,
  passwordPlain: string,
  rememberMe: boolean = true
): Promise<AuthResult> {
  const normalizedEmail = email.trim().toLowerCase();

  // 1. Rate Limit & Lockout Check
  const rateLimit = getRateLimitStatus(normalizedEmail);
  if (rateLimit.isLocked) {
    return {
      success: false,
      isLocked: true,
      lockoutRemainingSeconds: rateLimit.remainingLockoutSeconds,
      error: `Account temporarily locked due to excessive failed attempts. Please retry in ${rateLimit.remainingLockoutSeconds} seconds.`,
    };
  }

  // 2. Attempt Supabase Auth first if configured
  if (isSupabaseConfigured) {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: normalizedEmail,
        password: passwordPlain,
      });

      if (!error && data.user && data.session) {
        resetFailedAttempts(normalizedEmail);

        // Fetch user metadata/role from DB
        let userRole: UserRole = 'Super Admin';
        let fullName = data.user.user_metadata?.full_name || email.split('@')[0];
        let avatarUrl = data.user.user_metadata?.avatar_url || '';

        try {
          const { data: dbUser } = await (supabase.from('users') as any)
            .select('*, roles(name)')
            .eq('id', data.user.id)
            .maybeSingle();

          if (dbUser) {
            fullName = (dbUser as any).full_name || fullName;
            avatarUrl = (dbUser as any).avatar_url || avatarUrl;
            if ((dbUser as any).roles?.name) {
              userRole = (dbUser as any).roles.name as UserRole;
            }
          }
        } catch (e) {
          console.warn('DB user fetch notice:', e);
        }

        const userObj: User = {
          id: data.user.id,
          email: data.user.email || normalizedEmail,
          name: fullName,
          role: userRole,
          avatar: avatarUrl,
          department: 'Operations',
          phone: '',
          projectSite: 'HQ - Tower A',
          accountStatus: 'Active',
          lastLogin: new Date().toISOString(),
          createdAt: data.user.created_at || new Date().toISOString(),
        };

        const session = createSessionObject(userObj, rememberMe, data.session.access_token);
        saveSessionToStorage(session);
        return { success: true, user: userObj, session };
      }
    } catch (err: any) {
      console.warn('Supabase auth attempt failed, checking local accounts store:', err?.message);
    }
  }

  // 3. Authenticate against persistent secure accounts store
  const account = await findAccountByEmail(normalizedEmail);

  if (!account) {
    recordFailedAttempt(normalizedEmail);
    return {
      success: false,
      error: 'Invalid email address or password. Please verify your credentials.',
    };
  }

  // Check account status
  if (account.accountStatus === 'Inactive' || account.accountStatus === 'Deactivated') {
    return {
      success: false,
      error: 'This account has been deactivated. Please contact your system administrator.',
    };
  }

  if (account.accountStatus === 'Locked') {
    return {
      success: false,
      error: 'This account is locked for administrative review. Please contact support.',
    };
  }

  // Verify password hash
  const isValidPassword = await verifyPassword(
    passwordPlain,
    account.passwordHash,
    account.passwordSalt
  );

  if (!isValidPassword) {
    const attemptResult = recordFailedAttempt(normalizedEmail);
    if (attemptResult.isNowLocked) {
      return {
        success: false,
        isLocked: true,
        lockoutRemainingSeconds: attemptResult.lockoutMinutes * 60,
        error: `Too many invalid attempts. Account has been locked for ${attemptResult.lockoutMinutes} minutes.`,
      };
    }

    const remaining = 5 - attemptResult.attemptsCount;
    return {
      success: false,
      error: `Invalid email address or password. ${remaining > 0 ? `(${remaining} attempts remaining before temporary lockout)` : ''}`,
    };
  }

  // Password correct: Reset failed attempts counter
  resetFailedAttempts(normalizedEmail);

  // Update last login timestamp
  account.lastLoginAt = new Date().toISOString();
  account.lastLogin = account.lastLoginAt;
  const allAccounts = await getStoredAccounts();
  const index = allAccounts.findIndex((a) => a.id === account.id);
  if (index >= 0) {
    allAccounts[index] = account;
    saveStoredAccounts(allAccounts);
  }

  // Clean user object
  const { passwordHash: _h, passwordSalt: _s, ...cleanUser } = account;
  const session = createSessionObject(cleanUser, rememberMe);
  saveSessionToStorage(session);

  return {
    success: true,
    user: cleanUser,
    session,
  };
}

/**
 * Authenticate with Google Sign-In
 * Verifies directly with backend cloud database authorization whitelist
 */
export async function authenticateWithGoogle(
  googleProfile: {
    email: string;
    name?: string;
    avatar?: string;
    credential?: string;
    sub?: string;
  },
  rememberMe: boolean = true
): Promise<AuthResult & { status?: string; request?: any }> {
  const normalizedEmail = (googleProfile.email || '').trim().toLowerCase();

  try {
    // 1. Verify with Central Cloud Database API
    const response = await fetch('/api/auth/google/verify', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: normalizedEmail,
        name: googleProfile.name,
        avatar: googleProfile.avatar,
        credential: googleProfile.credential,
      }),
    });

    const contentType = response.headers.get('content-type');
    if (!contentType || !contentType.includes('application/json')) {
      return {
        success: false,
        error: 'The server is temporarily unavailable (starting up). Please try again in a few seconds.',
      };
    }

    const data = await response.json();

    if (response.ok && data.success && data.user) {
      if (data.status === 'APPROVED') {
        const normalizedSession: UserSession = {
          token: data.session?.token || `sess_g_${Date.now()}_${generateSecureToken(16)}`,
          sessionId: data.session?.sessionId || `sess_${generateSecureToken(16)}`,
          userId: data.user.id || `usr-${Date.now()}`,
          email: data.user.email || normalizedEmail,
          role: data.user.role || 'Worker',
          issuedAt: data.session?.createdAt || Date.now(),
          expiresAt: data.session?.expiresAt || Date.now() + 24 * 60 * 60 * 1000,
          rememberMe: true,
        };
        saveSessionToStorage(normalizedSession);
        return {
          success: true,
          status: 'APPROVED',
          user: { ...data.user, accountStatus: 'Active' },
          session: normalizedSession,
        };
      }
    }
    
    // Status is not APPROVED (PENDING or REJECTED)
    return {
      success: false,
      status: data.status,
      request: data.request,
      error: data.error || 'Access denied.'
    };
    
  } catch (apiErr: any) {
    console.error('[Auth] Server verify API error:', apiErr);
    return {
      success: false,
      error: apiErr.message || 'Server error during authentication.'
    };
  }
}

/**
 * Request Password Reset Email / Token
 */
export async function requestPasswordReset(email: string): Promise<{ success: boolean; token?: string; error?: string }> {
  const normalizedEmail = email.trim().toLowerCase();

  if (isSupabaseConfigured) {
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(normalizedEmail, {
        redirectTo: `${window.location.origin}/reset-password`,
      });
      if (error) {
        console.warn('Supabase reset email notice:', error.message);
      }
    } catch (e) {
      console.warn('Supabase reset error:', e);
    }
  }

  const account = await findAccountByEmail(normalizedEmail);
  if (!account) {
    // Return true without disclosing whether email exists (Security best practice)
    return { success: true };
  }

  // Generate a secure reset token expiring in 1 hour
  const token = generateSecureToken(32);
  const resetEntry: PasswordResetToken = {
    token,
    email: normalizedEmail,
    expiresAt: Date.now() + 60 * 60 * 1000, // 1 hour
    used: false,
    createdAt: Date.now(),
  };

  try {
    const raw = localStorage.getItem(PASSWORD_RESET_TOKENS_KEY);
    const list: PasswordResetToken[] = raw ? JSON.parse(raw) : [];
    list.push(resetEntry);
    localStorage.setItem(PASSWORD_RESET_TOKENS_KEY, JSON.stringify(list));
  } catch (e) {
    // Ignore storage errors
  }

  return {
    success: true,
    token,
  };
}

/**
 * Reset user password with token or for currently authenticated user
 */
export async function resetPasswordWithToken(newPasswordPlain: string, token?: string): Promise<{ success: boolean; error?: string }> {
  if (isSupabaseConfigured) {
    try {
      const { error } = await supabase.auth.updateUser({
        password: newPasswordPlain,
      });
      if (!error) {
        return { success: true };
      }
    } catch (e) {
      console.warn('Supabase password update error:', e);
    }
  }

  // Look up token or active session
  let targetEmail = '';

  if (token) {
    try {
      const raw = localStorage.getItem(PASSWORD_RESET_TOKENS_KEY);
      const list: PasswordResetToken[] = raw ? JSON.parse(raw) : [];
      const entry = list.find((t) => t.token === token && !t.used && t.expiresAt > Date.now());
      if (!entry) {
        return {
          success: false,
          error: 'This password reset link is invalid or has expired. Please request a new one.',
        };
      }
      entry.used = true;
      localStorage.setItem(PASSWORD_RESET_TOKENS_KEY, JSON.stringify(list));
      targetEmail = entry.email;
    } catch (e) {
      return { success: false, error: 'Failed to process reset token.' };
    }
  } else {
    const activeSession = getActiveSession();
    if (!activeSession) {
      return { success: false, error: 'Session expired. Please sign in again.' };
    }
    targetEmail = activeSession.email;
  }

  const account = await findAccountByEmail(targetEmail);
  if (!account) {
    return { success: false, error: 'User account not found.' };
  }

  // Update hashed password
  const { hash, salt } = await hashPassword(newPasswordPlain);
  account.passwordHash = hash;
  account.passwordSalt = salt;
  account.updatedAt = new Date().toISOString();

  const allAccounts = await getStoredAccounts();
  const index = allAccounts.findIndex((a) => a.id === account.id);
  if (index >= 0) {
    allAccounts[index] = account;
    saveStoredAccounts(allAccounts);
  }

  return { success: true };
}

/**
 * Change password for active user (verifying old password)
 */
export async function changeUserPassword(
  newPasswordPlain: string,
  oldPasswordPlain?: string
): Promise<{ success: boolean; error?: string }> {
  const activeSession = getActiveSession();
  if (!activeSession) {
    return { success: false, error: 'Active session not found. Please log in.' };
  }

  if (isSupabaseConfigured) {
    try {
      const { error } = await supabase.auth.updateUser({
        password: newPasswordPlain,
      });
      if (error) {
        return { success: false, error: error.message };
      }
    } catch (e) {
      console.warn('Supabase password change error:', e);
    }
  }

  const account = await findAccountByEmail(activeSession.email);
  if (!account) {
    return { success: false, error: 'Account not found.' };
  }

  if (oldPasswordPlain) {
    const isOldValid = await verifyPassword(oldPasswordPlain, account.passwordHash, account.passwordSalt);
    if (!isOldValid) {
      return { success: false, error: 'Current password is incorrect.' };
    }
  }

  const { hash, salt } = await hashPassword(newPasswordPlain);
  account.passwordHash = hash;
  account.passwordSalt = salt;
  account.updatedAt = new Date().toISOString();

  const allAccounts = await getStoredAccounts();
  const index = allAccounts.findIndex((a) => a.id === account.id);
  if (index >= 0) {
    allAccounts[index] = account;
    saveStoredAccounts(allAccounts);
  }

  return { success: true };
}

/**
 * Update User Profile
 */
export async function updateUserProfile(
  userId: string,
  updates: Partial<{ name: string; phone: string; avatar: string; department: string; projectSite: string }>
): Promise<{ success: boolean; error?: string }> {
  if (isSupabaseConfigured) {
    try {
      await (supabase.from('users') as any)
        .update({
          full_name: updates.name,
          phone: updates.phone,
          avatar_url: updates.avatar,
          updated_at: new Date().toISOString(),
        })
        .eq('id', userId);
    } catch (err) {
      console.warn('User table update skipped/error:', err);
    }
  }

  // Update in local accounts store
  const allAccounts = await getStoredAccounts();
  const index = allAccounts.findIndex((a) => a.id === userId);
  if (index >= 0) {
    const current = allAccounts[index];
    allAccounts[index] = {
      ...current,
      name: updates.name ?? current.name,
      phone: updates.phone ?? current.phone,
      avatar: updates.avatar ?? current.avatar,
      department: updates.department ?? current.department,
      projectSite: updates.projectSite ?? current.projectSite,
      updatedAt: new Date().toISOString(),
    };
    saveStoredAccounts(allAccounts);
  }

  return { success: true };
}

/**
 * Upload Avatar image
 */
export async function uploadAvatarImage(userId: string, file: File): Promise<string> {
  const filePath = `avatars/${userId}-${Date.now()}.${file.name.split('.').pop()}`;
  const result = await uploadFileToBucket('WORKER_IMAGES', filePath, file);
  if (result.error || !result.url) {
    return URL.createObjectURL(file);
  }
  return result.url;
}

/**
 * Session Helpers
 */
function createSessionObject(user: User, rememberMe: boolean, customToken?: string): UserSession {
  const now = Date.now();
  const durationMs = rememberMe
    ? REMEMBER_ME_DURATION_DAYS * 24 * 60 * 60 * 1000
    : SESSION_DURATION_HOURS * 60 * 60 * 1000;

  return {
    token: customToken || `tok_${generateSecureToken(32)}`,
    sessionId: `sess_${generateSecureToken(16)}`,
    userId: user.id,
    email: user.email,
    role: user.role,
    issuedAt: now,
    expiresAt: now + durationMs,
    rememberMe,
  };
}

export function saveSessionToStorage(session: UserSession): void {
  try {
    localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));
  } catch (e) {
    console.error('Failed to store session:', e);
  }
}

export function getActiveSession(): UserSession | null {
  try {
    const raw = localStorage.getItem(SESSION_STORAGE_KEY);
    if (!raw) return null;

    const session: UserSession = JSON.parse(raw);
    const now = Date.now();

    // Check expiration
    if (session.expiresAt && session.expiresAt <= now) {
      destroySession();
      return null;
    }

    return session;
  } catch (e) {
    return null;
  }
}

export function destroySession(): void {
  try {
    localStorage.removeItem(SESSION_STORAGE_KEY);
  } catch (e) {
    // Ignore error
  }
}

/**
 * Sign out current user completely
 */
export async function signOutUser(): Promise<void> {
  destroySession();
  if (isSupabaseConfigured) {
    try {
      await supabase.auth.signOut();
    } catch (e) {
      console.warn('Supabase signout notice:', e);
    }
  }
}

/**
 * Restore user profile from active session
 */
export async function restoreUserFromSession(session: any): Promise<User | null> {
  if (!session) return null;
  const rawEmail = session.email || session.userEmail || '';
  const email = typeof rawEmail === 'string' ? rawEmail.trim().toLowerCase() : '';

  if (!email) {
    if (session.userId) {
      const allAccounts = await getStoredAccounts();
      const byId = allAccounts.find((a) => a && a.id === session.userId);
      if (byId) {
        const { passwordHash: _h, passwordSalt: _s, ...cleanUser } = byId;
        return cleanUser;
      }
    }
    return null;
  }

  const account = await findAccountByEmail(email);
  if (!account) {
    const fallbackName =
      session.userName || session.name || (email.includes('@') ? email.split('@')[0] : 'User');
    return {
      id: session.userId || `usr-${Date.now()}`,
      email: email,
      name: fallbackName,
      role: session.role || session.userRole || 'Super Admin',
      department: 'Operations',
      phone: '',
      projectSite: 'HQ - Tower A',
      accountStatus: 'Active',
      createdAt: new Date().toISOString(),
    };
  }

  const { passwordHash: _h, passwordSalt: _s, ...cleanUser } = account;
  return cleanUser;
}
