import { supabase, isSupabaseConfigured } from '../lib/supabase';
import type { Database } from '../types/database.types';
import { logActivity } from './activityLogService';

export type MOUNTECItem = Database['public']['Tables']['metc_items']['Row'];
export type MOUNTECItemInsert = Database['public']['Tables']['metc_items']['Insert'];
export type MOUNTECItemUpdate = Database['public']['Tables']['metc_items']['Update'];
export type MOUNTECCategory = Database['public']['Tables']['metc_categories']['Row'];
export type Supplier = Database['public']['Tables']['suppliers']['Row'];
export type ItemDocument = Database['public']['Tables']['item_documents']['Row'];

export interface ItemFilterOptions {
  categoryId?: string;
  siteId?: string;
  status?: string;
  searchQuery?: string;
}

/**
 * Fetch all MOUNTEC Categories
 */
export async function getCategories(): Promise<MOUNTECCategory[]> {
  if (!isSupabaseConfigured) return [];

  const { data, error } = await supabase
    .from('metc_categories')
    .select('*')
    .order('name', { ascending: true });

  if (error) {
    console.error('Error fetching categories:', error.message);
    return [];
  }
  return (data as MOUNTECCategory[]) || [];
}

/**
 * Fetch all Suppliers
 */
export async function getSuppliers(): Promise<Supplier[]> {
  if (!isSupabaseConfigured) return [];

  const { data, error } = await supabase
    .from('suppliers')
    .select('*')
    .order('supplier_name', { ascending: true });

  if (error) {
    console.error('Error fetching suppliers:', error.message);
    return [];
  }
  return (data as Supplier[]) || [];
}

/**
 * Fetch items with optional filters
 */
export async function getMOUNTECItems(filters?: ItemFilterOptions): Promise<MOUNTECItem[]> {
  if (!isSupabaseConfigured) return [];

  let query = supabase.from('metc_items').select('*').order('created_at', { ascending: false });

  if (filters?.categoryId) {
    query = query.eq('category_id', filters.categoryId);
  }
  if (filters?.siteId) {
    query = query.eq('site_id', filters.siteId);
  }
  if (filters?.status) {
    query = query.eq('status', filters.status as any);
  }
  if (filters?.searchQuery) {
    const q = `%${filters.searchQuery}%`;
    query = query.or(`item_name.ilike.${q},asset_id.ilike.${q},serial_number.ilike.${q},asset_number.ilike.${q},brand.ilike.${q}`);
  }

  const { data, error } = await query;
  if (error) {
    console.error('Error fetching MOUNTEC items:', error.message);
    return [];
  }
  return (data as MOUNTECItem[]) || [];
}

/**
 * Fetch a single MOUNTEC item by ID
 */
export async function getMOUNTECItemById(id: string): Promise<MOUNTECItem | null> {
  if (!isSupabaseConfigured) return null;

  const { data, error } = await supabase
    .from('metc_items')
    .select('*')
    .eq('id', id)
    .single();

  if (error) {
    console.error(`Error fetching item ${id}:`, error.message);
    return null;
  }
  return data as MOUNTECItem;
}

/**
 * Create a new MOUNTEC Item
 */
export async function createMOUNTECItem(item: MOUNTECItemInsert, userName = 'Store Keeper'): Promise<MOUNTECItem | null> {
  if (!isSupabaseConfigured) return null;

  const { data, error } = await (supabase.from('metc_items') as any)
    .insert(item)
    .select()
    .single();

  if (error || !data) {
    console.error('Error creating MOUNTEC item:', error?.message);
    throw new Error(error?.message || 'Failed to create item');
  }

  const created = data as MOUNTECItem;
  await logActivity('CREATE', 'metc_items', created.id, { item_name: created.item_name, asset_id: created.asset_id }, userName);
  return created;
}

/**
 * Update an existing MOUNTEC Item
 */
export async function updateMOUNTECItem(id: string, updates: MOUNTECItemUpdate, userName = 'Store Keeper'): Promise<MOUNTECItem | null> {
  if (!isSupabaseConfigured) return null;

  const { data, error } = await (supabase.from('metc_items') as any)
    .update(updates)
    .eq('id', id)
    .select()
    .single();

  if (error || !data) {
    console.error(`Error updating MOUNTEC item ${id}:`, error?.message);
    throw new Error(error?.message || 'Failed to update item');
  }

  const updated = data as MOUNTECItem;
  await logActivity('UPDATE', 'metc_items', id, updates, userName);
  return updated;
}

/**
 * Delete a MOUNTEC Item
 */
export async function deleteMOUNTECItem(id: string, userName = 'Super Admin'): Promise<boolean> {
  if (!isSupabaseConfigured) return false;

  const { error } = await supabase.from('metc_items').delete().eq('id', id);
  if (error) {
    console.error(`Error deleting item ${id}:`, error.message);
    throw new Error(error.message);
  }

  await logActivity('DELETE', 'metc_items', id, {}, userName);
  return true;
}

/**
 * Fetch documents attached to an item
 */
export async function getItemDocuments(itemId: string): Promise<ItemDocument[]> {
  if (!isSupabaseConfigured) return [];

  const { data, error } = await supabase
    .from('item_documents')
    .select('*')
    .eq('item_id', itemId)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching item documents:', error.message);
    return [];
  }
  return (data as ItemDocument[]) || [];
}
