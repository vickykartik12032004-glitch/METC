import { useAuthStore } from '../store/useAuthStore';

export function getCloudServerOrigin(): string {
  // 1. Check if user configured or persisted a custom server endpoint
  try {
    const saved = localStorage.getItem('mountec_cloud_api_url');
    if (saved && saved.trim().startsWith('http')) {
      return saved.trim().replace(/\/$/, '');
    }
  } catch (e) {}

  // 2. Check if Vite provided an explicit API URL
  const envUrl = (import.meta as any).env?.VITE_API_URL || (import.meta as any).env?.VITE_CLOUD_API_URL;
  if (envUrl && typeof envUrl === 'string' && envUrl.trim().startsWith('http')) {
    return envUrl.trim().replace(/\/$/, '');
  }

  // 3. Detect Capacitor or native mobile webview environment (where origin is capacitor: or file:)
  if (typeof window !== 'undefined') {
    const isCapacitor =
      Boolean((window as any).Capacitor?.isNativePlatform?.()) ||
      window.location.protocol === 'capacitor:' ||
      window.location.protocol === 'file:';

    if (isCapacitor) {
      return (window.location.origin && window.location.origin.startsWith('http'))
        ? window.location.origin
        : 'https://ais-dev-3coess7e4ei5xayobkdnqb-750024708981.asia-southeast1.run.app';
    }
  }

  return '';
}

export function getBaseApiUrl(): string {
  const origin = getCloudServerOrigin();
  return origin ? `${origin}/api` : '/api';
}

function getStoredSessionToken(): string | null {
  try {
    const raw = localStorage.getItem('mountec_auth_session');
    if (raw) {
      const sess = JSON.parse(raw);
      if (sess?.token) return sess.token;
    }
  } catch (e) {}

  const currentUser = useAuthStore.getState().user;
  if (currentUser) {
    return `sess_${currentUser.id || currentUser.email || 'user'}`;
  }
  return 'sess_mountec_client';
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const currentUser = useAuthStore.getState().user;
  const token = getStoredSessionToken();
  
  const headers = new Headers(options.headers || {});
  headers.set('Content-Type', 'application/json');
  
  if (token) {
    headers.set('Authorization', `Bearer ${token}`);
    headers.set('x-session-token', token);
  }

  if (currentUser) {
    headers.set('x-user-id', currentUser.id);
    headers.set('x-user-email', currentUser.email);
    headers.set('x-user-name', currentUser.name || currentUser.email);
    headers.set('x-user-role', currentUser.role);
  }

  const baseUrl = getBaseApiUrl();
  const fullUrl = `${baseUrl}${endpoint}`;

  const response = await fetch(fullUrl, {
    ...options,
    headers,
  });

  if (!response.ok) {
    let errMsg = `Request failed with status ${response.status}`;
    try {
      const errData = await response.json();
      if (errData.error) errMsg = errData.error;
    } catch (e) {
      // fallback
    }
    throw new Error(errMsg);
  }

  return response.json();
}

export const cloudApi = {
  // Sync
  getFullSnapshot: () => request<{ success: boolean; data: any; version: number }>('/sync/full'),
  
  // Health
  checkHealth: () => request<{ status: string; serverTime: string; connectedClients: number }>('/health'),

  // Assets
  getAssets: (category?: string) => request<{ success: boolean; data: any[] }>(`/assets${category ? `?category=${category}` : ''}`),
  createAsset: (category: string, item: any) => request<{ success: boolean; data: any }>(`/assets/${category}`, {
    method: 'POST',
    body: JSON.stringify(item),
  }),
  bulkAddAssets: (items: any[], author?: string) => request<{ success: boolean; count: number; data: any[] }>('/assets/bulk', {
    method: 'POST',
    body: JSON.stringify({ items, author }),
  }),
  updateAsset: (category: string, id: string, item: any) => request<{ success: boolean; data: any }>(`/assets/${category}/${id}`, {
    method: 'PUT',
    body: JSON.stringify(item),
  }),
  deleteAsset: (category: string, id: string) => request<{ success: boolean }>(`/assets/${category}/${id}`, {
    method: 'DELETE',
  }),
  clearAllAssets: (author?: string) => request<{ success: boolean; cleared: any }>('/assets/clear-all', {
    method: 'POST',
    body: JSON.stringify({ author }),
  }),
  restoreDemoAssets: (author?: string) => request<{ success: boolean; restored: any; data?: any[] }>('/assets/restore-demo', {
    method: 'POST',
    body: JSON.stringify({ author }),
  }),

  // Transactions (Atomic Issue & Return)
  createIssue: (issueData: any) => request<{ success: boolean; data: { issue: any; updatedAsset: any } }>('/transactions/issue', {
    method: 'POST',
    body: JSON.stringify(issueData),
  }),
  createReturn: (returnData: any) => request<{ success: boolean; data: { returnRecord: any; updatedAsset: any } }>('/transactions/return', {
    method: 'POST',
    body: JSON.stringify(returnData),
  }),
  createTransfer: (transferData: any) => request<{ success: boolean; data: any }>('/transactions/transfer', {
    method: 'POST',
    body: JSON.stringify(transferData),
  }),
  updateTransferStatus: (id: string, status: string) => request<{ success: boolean; data: any }>(`/transactions/transfer/${id}/status`, {
    method: 'PUT',
    body: JSON.stringify({ status }),
  }),
  createRepair: (repairData: any) => request<{ success: boolean; data: any }>('/transactions/repair', {
    method: 'POST',
    body: JSON.stringify(repairData),
  }),
  updateRepairStatus: (id: string, status: string) => request<{ success: boolean; data: any }>(`/transactions/repair/${id}/status`, {
    method: 'PUT',
    body: JSON.stringify({ status }),
  }),
  createLostItem: (lostData: any) => request<{ success: boolean; data: any }>('/transactions/lost', {
    method: 'POST',
    body: JSON.stringify(lostData),
  }),

  // Site Issue & Return
  getSiteIssues: () => request<{ success: boolean; data: any[] }>('/site-issues'),
  createSiteIssue: (payload: any) => request<{ success: boolean; data: any; updatedAssets: any[] }>('/site-issues', {
    method: 'POST',
    body: JSON.stringify(payload),
  }),
  processSiteReturn: (payload: any) => request<{ success: boolean; data: any; updatedTransaction: any; updatedAssets: any[] }>('/site-returns', {
    method: 'POST',
    body: JSON.stringify(payload),
  }),

  // Stock Adjustment & Count
  getStockAdjustments: () => request<{ success: boolean; data: any[] }>('/stock-adjustments'),
  createStockAdjustment: (payload: any) => request<{ success: boolean; data: any; updatedAsset: any }>('/stock-adjustments', {
    method: 'POST',
    body: JSON.stringify(payload),
  }),

  // Stocktaking Sessions (Pending Count Tracker)
  getStocktakingSessions: () => request<{ success: boolean; data: any[] }>('/stocktaking/sessions'),
  saveStocktakingSession: (session: any) => request<{ success: boolean; data: any }>('/stocktaking/sessions', {
    method: 'POST',
    body: JSON.stringify(session),
  }),

  // Workers
  getWorkers: () => request<{ success: boolean; data: any[] }>('/workers'),
  createWorker: (workerData: any) => request<{ success: boolean; data: any }>('/workers', {
    method: 'POST',
    body: JSON.stringify(workerData),
  }),
  updateWorker: (id: string, workerData: any) => request<{ success: boolean; data: any }>(`/workers/${id}`, {
    method: 'PUT',
    body: JSON.stringify(workerData),
  }),
  deleteWorker: (id: string) => request<{ success: boolean }>(`/workers/${id}`, {
    method: 'DELETE',
  }),
  clearAllWorkers: (author?: string) => request<{ success: boolean; cleared: number }>('/workers/clear-all', {
    method: 'POST',
    body: JSON.stringify({ author }),
  }),
  restoreDemoWorkers: (author?: string) => request<{ success: boolean; restored: number; data?: any[] }>('/workers/restore-demo', {
    method: 'POST',
    body: JSON.stringify({ author }),
  }),

  // Transaction Clear
  clearAllTransactions: (author?: string) => request<{ success: boolean; cleared: any }>('/transactions/clear-all', {
    method: 'POST',
    body: JSON.stringify({ author }),
  }),

  // Master System Clean Slate
  clearAllSystemData: (author?: string) => request<{ success: boolean; result: any }>('/system/clear-all', {
    method: 'POST',
    body: JSON.stringify({ author }),
  }),

  // Maintenance
  getMaintenance: () => request<{ success: boolean; data: any[] }>('/maintenance'),
  createMaintenance: (data: any) => request<{ success: boolean; data: any }>('/maintenance', {
    method: 'POST',
    body: JSON.stringify(data),
  }),
  updateMaintenance: (id: string, data: any) => request<{ success: boolean; data: any }>(`/maintenance/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  }),

  // Activities & Notifications
  getActivities: (limit = 100) => request<{ success: boolean; data: any[] }>(`/activities?limit=${limit}`),
  logActivity: (activity: any) => request<{ success: boolean; data: any }>('/activities', {
    method: 'POST',
    body: JSON.stringify(activity),
  }),
  getNotifications: () => request<{ success: boolean; data: any[] }>('/notifications'),
  markNotificationRead: (id: string) => request<{ success: boolean }>(`/notifications/${id}/read`, {
    method: 'PUT',
  }),

  // Admin & Settings
  getCompanyProfile: () => request<{ success: boolean; data: any }>('/admin/company-profile'),
  updateCompanyProfile: (profile: any) => request<{ success: boolean; data: any }>('/admin/company-profile', {
    method: 'PUT',
    body: JSON.stringify(profile),
  }),
  getAuthorizedUsers: () => request<{ success: boolean; data: any[] }>('/admin/authorized-users'),
  updateAuthorizedUsers: (users: any[]) => request<{ success: boolean; data: any }>('/admin/authorized-users', {
    method: 'PUT',
    body: JSON.stringify({ users }),
  }),
  getAdminUsers: () => request<{ success: boolean; data: any[] }>('/admin/users'),
  updateAdminUsers: (users: any[]) => request<{ success: boolean; data: any }>('/admin/users', {
    method: 'PUT',
    body: JSON.stringify({ users }),
  }),
  getRoles: () => request<{ success: boolean; data: any[] }>('/admin/roles'),
  updateRoles: (roles: any[]) => request<{ success: boolean; data: any }>('/admin/roles', {
    method: 'PUT',
    body: JSON.stringify({ roles }),
  }),
};
