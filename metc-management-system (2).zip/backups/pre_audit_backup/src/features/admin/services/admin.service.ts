import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';
import { useAdminStore } from '../../../store/useAdminStore';
import {
  AdminUser,
  AdminRole,
  AdminModule,
  ModulePermissions,
  BackupRecord,
  Branch,
  ProjectSite
} from '../types';

export const adminService = {
  // User Management
  async createUser(user: Omit<AdminUser, 'id' | 'createdAt'>): Promise<void> {
    const store = useAdminStore.getState();
    store.addUser(user);
  },

  async updateUser(id: string, user: Partial<AdminUser>): Promise<void> {
    const store = useAdminStore.getState();
    store.updateUser(id, user);
  },

  async deleteUser(id: string): Promise<void> {
    const store = useAdminStore.getState();
    store.deleteUser(id);
  },

  async deactivateUser(id: string): Promise<void> {
    const store = useAdminStore.getState();
    store.deactivateUser(id);
  },

  async resetUserPassword(id: string): Promise<string> {
    const store = useAdminStore.getState();
    return store.resetUserPassword(id);
  },

  async lockUser(id: string): Promise<void> {
    const store = useAdminStore.getState();
    store.lockUser(id);
  },

  async unlockUser(id: string): Promise<void> {
    const store = useAdminStore.getState();
    store.unlockUser(id);
  },

  // Role Management
  async createRole(role: Omit<AdminRole, 'id' | 'createdAt'>): Promise<void> {
    const store = useAdminStore.getState();
    store.addRole(role);
  },

  async assignPermission(
    roleId: string,
    module: AdminModule,
    permissionKey: keyof ModulePermissions,
    value: boolean
  ): Promise<void> {
    const store = useAdminStore.getState();
    store.assignPermission(roleId, module, permissionKey, value);
  },

  // Backup & Restore
  async backupDatabase(type: 'Manual' | 'Automatic' = 'Manual', name?: string): Promise<BackupRecord> {
    const store = useAdminStore.getState();
    return store.createBackup(type, name);
  },

  async restoreDatabase(backupId: string): Promise<void> {
    const store = useAdminStore.getState();
    store.restoreBackup(backupId);
  },

  // Email Test
  async sendTestEmail(targetEmail: string): Promise<boolean> {
    const store = useAdminStore.getState();
    store.updateEmailSettings({ testEmailStatus: 'testing' });
    await new Promise((res) => setTimeout(res, 1200));
    store.updateEmailSettings({
      testEmailStatus: 'success',
      lastTestedAt: new Date().toISOString()
    });
    store.addAuditLog({
      user: 'Admin',
      email: 'admin@mountec.sg',
      userRole: 'Super Admin',
      ipAddress: '127.0.0.1',
      action: 'Settings Changes',
      module: 'Email Settings',
      details: `Sent SMTP test email verification to ${targetEmail}`,
      severity: 'Info',
    });
    return true;
  },

  // EXPORT UTILITIES (CSV, Excel, PDF)
  exportToCSV(data: Record<string, any>[], filename: string): void {
    if (!data.length) return;
    const headers = Object.keys(data[0]);
    const csvRows = [];
    csvRows.push(headers.join(','));

    for (const row of data) {
      const values = headers.map((header) => {
        const val = row[header];
        const escaped = ('' + (val ?? '')).replace(/"/g, '\\"');
        return `"${escaped}"`;
      });
      csvRows.push(values.join(','));
    }

    const blob = new Blob([csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${filename}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  },

  exportToExcel(data: Record<string, any>[], filename: string, sheetName = 'Data'): void {
    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
    XLSX.writeFile(workbook, `${filename}.xlsx`);
  },

  exportToPDF(
    title: string,
    headers: string[],
    rows: (string | number)[][],
    filename: string
  ): void {
    const doc = new jsPDF({ orientation: 'landscape' });

    // Company Header Branding
    doc.setFillColor(15, 23, 42); // slate-900
    doc.rect(0, 0, doc.internal.pageSize.width, 24, 'F');

    doc.setFontSize(14);
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.text('MOUNTEC PTE LTD', 14, 12);

    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(148, 163, 184); // slate-400
    doc.text('ENTERPRISE SYSTEM ADMINISTRATION REPORT', 14, 18);

    doc.setFontSize(12);
    doc.setTextColor(15, 23, 42);
    doc.setFont('helvetica', 'bold');
    doc.text(title, 14, 34);

    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100, 116, 139);
    doc.text(`Generated on: ${new Date().toLocaleString()} | MOUNTEC Enterprise v2.5.0-EE`, 14, 40);

    autoTable(doc, {
      startY: 44,
      head: [headers],
      body: rows,
      theme: 'grid',
      headStyles: {
        fillColor: [30, 41, 59],
        textColor: [255, 255, 255],
        fontSize: 9,
        fontStyle: 'bold',
      },
      bodyStyles: {
        fontSize: 8,
        textColor: [30, 41, 59],
      },
      alternateRowStyles: {
        fillColor: [248, 250, 252],
      },
    });

    doc.save(`${filename}.pdf`);
  },

  exportUsers(users: AdminUser[], format: 'csv' | 'excel' | 'pdf'): void {
    const filtered = users.filter((u) => !u.isSoftDeleted);
    const data = filtered.map((u) => ({
      'Employee No': u.employeeNumber,
      'Full Name': u.fullName,
      Email: u.email,
      Phone: u.phone,
      Role: u.role,
      Department: u.department,
      Branch: u.branch,
      Site: u.site,
      Status: u.status,
    }));

    if (format === 'csv') this.exportToCSV(data, 'MOUNTEC_Users_List');
    if (format === 'excel') this.exportToExcel(data, 'MOUNTEC_Users_List', 'Users');
    if (format === 'pdf') {
      const headers = ['Emp No', 'Name', 'Email', 'Role', 'Department', 'Branch', 'Status'];
      const rows = filtered.map((u) => [
        u.employeeNumber,
        u.fullName,
        u.email,
        u.role,
        u.department,
        u.branch,
        u.status,
      ]);
      this.exportToPDF('MOUNTEC PTE LTD - Active Users Directory', headers, rows, 'MOUNTEC_Users_Directory');
    }
  },

  exportBranches(branches: Branch[], format: 'csv' | 'excel' | 'pdf'): void {
    const data = branches.map((b) => ({
      Code: b.code,
      Name: b.name,
      Address: b.address,
      Manager: b.manager,
      Phone: b.phone,
      Email: b.email,
      Workers: b.workerCount,
      Status: b.status,
    }));

    if (format === 'csv') this.exportToCSV(data, 'MOUNTEC_Branches_List');
    if (format === 'excel') this.exportToExcel(data, 'MOUNTEC_Branches_List', 'Branches');
    if (format === 'pdf') {
      const headers = ['Code', 'Branch Name', 'Address', 'Manager', 'Phone', 'Workers', 'Status'];
      const rows = branches.map((b) => [
        b.code,
        b.name,
        b.address,
        b.manager,
        b.phone,
        b.workerCount,
        b.status,
      ]);
      this.exportToPDF('MOUNTEC PTE LTD - Branch Offices', headers, rows, 'MOUNTEC_Branches');
    }
  },

  exportSites(sites: ProjectSite[], format: 'csv' | 'excel' | 'pdf'): void {
    const data = sites.map((s) => ({
      Code: s.siteCode,
      SiteName: s.siteName,
      Project: s.projectName,
      Address: s.address,
      Manager: s.manager,
      Phone: s.phone,
      Workers: s.workerCount,
      Status: s.status,
    }));

    if (format === 'csv') this.exportToCSV(data, 'MOUNTEC_Project_Sites');
    if (format === 'excel') this.exportToExcel(data, 'MOUNTEC_Project_Sites', 'Sites');
    if (format === 'pdf') {
      const headers = ['Code', 'Site Name', 'Project Name', 'Manager', 'Workers', 'Status'];
      const rows = sites.map((s) => [
        s.siteCode,
        s.siteName,
        s.projectName,
        s.manager,
        s.workerCount,
        s.status,
      ]);
      this.exportToPDF('MOUNTEC PTE LTD - Project Sites Directory', headers, rows, 'MOUNTEC_Project_Sites');
    }
  }
};
