import React, { useState } from 'react';
import {
  UserPlus,
  KeyRound,
  Lock,
  Unlock,
  Trash2,
  Edit2,
  FileSpreadsheet,
  FileText,
  UserCheck,
  Building2,
  ShieldAlert,
  Search,
  Filter,
  X,
  CheckCircle2,
  AlertOctagon,
  Copy,
  ShieldCheck,
  Mail,
  UserX,
  MapPin,
  Globe,
  CheckSquare,
  Square,
  Shield
} from 'lucide-react';
import { toast } from 'sonner';
import { useAdmin } from '../hooks/useAdmin';
import { useAdminStore } from '../../../store/useAdminStore';
import { useAuthStore } from '../../../store/useAuthStore';
import { AdminUser, AuthorizedUser, SystemRole, UserStatus } from '../types';

export const UserManagementSection: React.FC = () => {
  const {
    activeUsers,
    roles,
    departments,
    branches,
    sites,
    addUser,
    updateUser,
    deleteUser,
    deactivateUser,
    activateUser,
    toggleUserStatus,
    updateUserRole,
    updateUserSiteAccess,
    resetUserPassword,
    lockUser,
    unlockUser,
    adminService
  } = useAdmin();

  const {
    authorizedUsers,
    addAuthorizedUser,
    updateAuthorizedUser,
    deleteAuthorizedUser,
    activateAuthorizedUser,
    deactivateAuthorizedUser,
  } = useAdminStore();

  const [activeSubTab, setActiveSubTab] = useState<'system_users' | 'authorized_google'>('system_users');
  const [roleFilter, setRoleFilter] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [siteFilter, setSiteFilter] = useState<string>('All');
  const [search, setSearch] = useState('');

  // Modals for System Users
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<AdminUser | null>(null);
  const [resetPassUser, setResetPassUser] = useState<{ user: AdminUser; tempPass: string } | null>(null);

  // Modals for Authorized Google Users Whitelist
  const [isAddAuthOpen, setIsAddAuthOpen] = useState(false);
  const [editingAuthUser, setEditingAuthUser] = useState<AuthorizedUser | null>(null);

  // Form State for Authorized Google User
  const [authFormData, setAuthFormData] = useState({
    fullName: '',
    googleEmail: '',
    role: 'Admin' as SystemRole,
    department: 'Management & IT',
    site: 'Corporate HQ - Marina Bay',
    branch: 'Main HQ International Plaza',
    assignedSites: ['Corporate HQ - Marina Bay'] as string[],
    allSitesAccess: true,
    status: 'Active' as 'Active' | 'Inactive',
  });

  // Form State for Create / Edit System Users
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    password: '',
    employeeNumber: '',
    department: 'Store & Inventory Logistics',
    branch: 'Main HQ International Plaza',
    site: 'Corporate HQ - Marina Bay',
    assignedSites: ['Corporate HQ - Marina Bay'] as string[],
    allSitesAccess: false,
    role: 'Worker' as SystemRole,
    status: 'Active' as UserStatus,
    photo: '',
  });

  const resetAuthForm = () => {
    setAuthFormData({
      fullName: '',
      googleEmail: '',
      role: 'Admin',
      department: departments[0]?.name || 'Management & IT',
      site: sites[0]?.siteName || 'Corporate HQ - Marina Bay',
      branch: branches[0]?.name || 'Main HQ International Plaza',
      assignedSites: sites.map((s) => s.siteName),
      allSitesAccess: true,
      status: 'Active',
    });
  };

  const resetForm = () => {
    setFormData({
      fullName: '',
      email: '',
      phone: '',
      password: `Mnc#${Math.floor(100000 + Math.random() * 900000)}`,
      employeeNumber: `MNC-${Math.floor(1000 + Math.random() * 9000)}`,
      department: departments[0]?.name || 'Store & Inventory Logistics',
      branch: branches[0]?.name || 'Main HQ International Plaza',
      site: sites[0]?.siteName || 'Corporate HQ - Marina Bay',
      assignedSites: [sites[0]?.siteName || 'Corporate HQ - Marina Bay'],
      allSitesAccess: false,
      role: 'Worker',
      status: 'Active',
      photo: '',
    });
  };

  const handleOpenAddAuth = () => {
    resetAuthForm();
    setIsAddAuthOpen(true);
  };

  const handleOpenEditAuth = (authUser: AuthorizedUser) => {
    setEditingAuthUser(authUser);
    setAuthFormData({
      fullName: authUser.fullName,
      googleEmail: authUser.googleEmail,
      role: authUser.role,
      department: authUser.department,
      site: authUser.site,
      branch: authUser.branch,
      assignedSites: authUser.assignedSites || [authUser.site],
      allSitesAccess: authUser.allSitesAccess ?? (authUser.role === 'Super Admin' || authUser.role === 'Admin'),
      status: authUser.status,
    });
  };

  const handleSaveAuthUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!authFormData.googleEmail.trim()) {
      toast.error('Google Account Email is required.');
      return;
    }

    if (editingAuthUser) {
      updateAuthorizedUser(editingAuthUser.id, authFormData);
      toast.success(`Updated authorized Google user ${authFormData.fullName}`);
      setEditingAuthUser(null);
    } else {
      addAuthorizedUser(authFormData);
      toast.success(`Authorized Google account ${authFormData.googleEmail} added to Whitelist.`);
      setIsAddAuthOpen(false);
    }
  };

  const handleOpenAdd = () => {
    resetForm();
    setIsAddOpen(true);
  };

  const handleOpenEdit = (user: AdminUser) => {
    setEditingUser(user);
    setFormData({
      fullName: user.fullName,
      email: user.email,
      phone: user.phone,
      employeeNumber: user.employeeNumber,
      department: user.department,
      branch: user.branch,
      site: user.site,
      assignedSites: user.assignedSites || [user.site],
      allSitesAccess: user.allSitesAccess ?? (user.role === 'Super Admin'),
      role: user.role,
      status: user.status,
      photo: user.photo || '',
    });
  };

  const handleSaveUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingUser) {
      updateUser(editingUser.id, formData);
      toast.success(`User ${formData.fullName} updated successfully.`);
      setEditingUser(null);
    } else {
      const generatedPass = formData.password || `Mnc#${Math.floor(100000 + Math.random() * 900000)}`;
      addUser({
        ...formData,
        tempPassword: generatedPass,
        password: generatedPass,
      });
      toast.success(`New user ${formData.fullName} created successfully.`);
      setIsAddOpen(false);
      // Prompt modal with credentials to copy
      const createdUser: AdminUser = {
        id: 'new',
        fullName: formData.fullName,
        email: formData.email,
        phone: formData.phone,
        employeeNumber: formData.employeeNumber,
        department: formData.department,
        branch: formData.branch,
        site: formData.site,
        role: formData.role,
        status: formData.status,
        createdAt: new Date().toISOString(),
      };
      setResetPassUser({ user: createdUser, tempPass: generatedPass });
    }
  };

  const handleResetPassword = (user: AdminUser) => {
    const tempPass = resetUserPassword(user.id);
    setResetPassUser({ user, tempPass });
  };

  // Filtered Authorized Google Accounts list
  const filteredAuthUsers = authorizedUsers.filter((u) => {
    const matchesSearch =
      u.fullName.toLowerCase().includes(search.toLowerCase()) ||
      u.googleEmail.toLowerCase().includes(search.toLowerCase());
    const matchesRole = roleFilter === 'All' || u.role === roleFilter;
    const matchesStatus = statusFilter === 'All' || u.status === statusFilter;
    const matchesSite =
      siteFilter === 'All' ||
      u.site === siteFilter ||
      u.allSitesAccess ||
      (u.assignedSites && u.assignedSites.includes(siteFilter));
    return matchesSearch && matchesRole && matchesStatus && matchesSite;
  });

  // Filtered users list
  const filteredUsers = activeUsers.filter((u) => {
    const matchesSearch =
      u.fullName.toLowerCase().includes(search.toLowerCase()) ||
      u.email.toLowerCase().includes(search.toLowerCase()) ||
      u.employeeNumber.toLowerCase().includes(search.toLowerCase()) ||
      u.department.toLowerCase().includes(search.toLowerCase());
    const matchesRole = roleFilter === 'All' || u.role === roleFilter;
    const matchesStatus = statusFilter === 'All' || u.status === statusFilter;
    const matchesSite =
      siteFilter === 'All' ||
      u.site === siteFilter ||
      u.allSitesAccess ||
      (u.assignedSites && u.assignedSites.includes(siteFilter));
    return matchesSearch && matchesRole && matchesStatus && matchesSite;
  });

  const getRoleBadge = (roleName: string) => {
    switch (roleName) {
      case 'Super Admin':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-purple-500/15 text-purple-300 border border-purple-500/30">
            Super Admin
          </span>
        );
      case 'Admin':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/15 text-blue-300 border border-blue-500/30">
            Admin
          </span>
        );
      case 'Supervisor':
      case 'Site Supervisor':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/15 text-amber-300 border border-amber-500/30">
            Supervisor
          </span>
        );
      case 'Worker':
      case 'Store Keeper':
      case 'User':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
            Worker
          </span>
        );
      default:
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-800 text-slate-300 border border-slate-700">
            {roleName}
          </span>
        );
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Active':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1 w-fit">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span> Active
          </span>
        );
      case 'Inactive':
      case 'Deactivated':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/20 flex items-center gap-1 w-fit">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-400"></span> Inactive / Disabled
          </span>
        );
      case 'Locked':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20 flex items-center gap-1 w-fit">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span> Locked
          </span>
        );
      default:
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-slate-500/10 text-slate-400 border border-slate-500/20">
            {status}
          </span>
        );
    }
  };

  const getSiteAccessPill = (userItem: { site?: string; assignedSites?: string[]; allSitesAccess?: boolean; role?: string }) => {
    if (userItem.role === 'Super Admin' || userItem.allSitesAccess) {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-purple-500/10 text-purple-300 text-[10px] font-medium border border-purple-500/20" title="Full Enterprise Site Authorization">
          <Globe className="w-3 h-3 text-purple-400" /> All Sites ({sites.length})
        </span>
      );
    }
    const count = userItem.assignedSites?.length || 1;
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 text-[10px] font-medium border border-slate-700" title={userItem.assignedSites?.join(', ') || userItem.site}>
        <MapPin className="w-3 h-3 text-blue-400" /> {count} {count === 1 ? 'Site' : 'Sites'}
      </span>
    );
  };

  return (
    <div className="space-y-6" id="user-management-section">
      {/* Top Header & Navigation */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg">
        <div className="space-y-1">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white tracking-wide">Enterprise User & Access Governance</h2>
                <span className="px-2 py-0.5 bg-blue-500/10 text-blue-400 text-[10px] font-bold rounded-full border border-blue-500/30 uppercase tracking-wider">
                  MOUNTEC RBAC
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Super Admin governance for user accounts, role assignments (Super Admin, Admin, Supervisor, Worker), site authorization, and security statuses.
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          {activeSubTab === 'system_users' ? (
            <button
              onClick={handleOpenAdd}
              className="flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold shadow-md shadow-blue-900/40 transition cursor-pointer"
            >
              <UserPlus className="w-4 h-4" /> Add System User
            </button>
          ) : (
            <button
              onClick={handleOpenAddAuth}
              className="flex items-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold shadow-md shadow-emerald-900/40 transition cursor-pointer"
            >
              <UserPlus className="w-4 h-4" /> Authorize Google Account
            </button>
          )}

          <button
            onClick={() => {
              adminService.exportUsers(activeUsers, 'csv');
              toast.success('Exported Users Directory to CSV.');
            }}
            className="flex items-center gap-1.5 px-3 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold border border-slate-700 transition cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" /> Export CSV
          </button>
        </div>
      </div>

      {/* Subtabs Selector */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
        <button
          onClick={() => setActiveSubTab('system_users')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition cursor-pointer ${
            activeSubTab === 'system_users'
              ? 'bg-blue-600 text-white shadow-md shadow-blue-900/30'
              : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
          }`}
        >
          <Building2 className="w-4 h-4" /> System Users Directory ({activeUsers.length})
        </button>

        <button
          onClick={() => setActiveSubTab('authorized_google')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition cursor-pointer ${
            activeSubTab === 'authorized_google'
              ? 'bg-emerald-600 text-white shadow-md shadow-emerald-900/30'
              : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
          }`}
        >
          <ShieldCheck className="w-4 h-4" /> Google SSO Whitelist ({authorizedUsers.length})
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            placeholder={
              activeSubTab === 'system_users'
                ? 'Search name, email, employee ID...'
                : 'Search Google email or full name...'
            }
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value)}
            className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="All">All Roles</option>
            <option value="Super Admin">Super Admin</option>
            <option value="Admin">Admin</option>
            <option value="Supervisor">Supervisor</option>
            <option value="Worker">Worker</option>
          </select>
        </div>

        <div>
          <select
            value={siteFilter}
            onChange={(e) => setSiteFilter(e.target.value)}
            className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="All">All Project Sites</option>
            {sites.map((s) => (
              <option key={s.id} value={s.siteName}>{s.siteName}</option>
            ))}
          </select>
        </div>

        <div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="All">All Statuses</option>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive / Disabled</option>
            <option value="Locked">Locked</option>
          </select>
        </div>
      </div>

      {/* TAB 1: SYSTEM USERS DIRECTORY */}
      {activeSubTab === 'system_users' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl space-y-0">
          <div className="p-4 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between text-xs text-slate-300">
            <span className="font-semibold text-blue-400 flex items-center gap-1.5">
              <Building2 className="w-4 h-4" />
              <span>Full System User Registry & Role Assignment</span>
            </span>
            <span className="text-[11px] text-slate-500">Showing {filteredUsers.length} of {activeUsers.length} Users</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950/90 text-slate-400 uppercase tracking-wider text-[10px] border-b border-slate-800 font-semibold">
                <tr>
                  <th className="py-3.5 px-4 min-w-[200px]">User Profile</th>
                  <th className="py-3.5 px-4">Role & Permissions</th>
                  <th className="py-3.5 px-4">Department</th>
                  <th className="py-3.5 px-4">Site Authorization</th>
                  <th className="py-3.5 px-4">Account Status</th>
                  <th className="py-3.5 px-4 text-right">Super Admin Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredUsers.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-12 text-center text-slate-500 text-xs">
                      No system users found matching the selected filters.
                    </td>
                  </tr>
                ) : (
                  filteredUsers.map((u) => (
                    <tr key={u.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 text-white font-bold flex items-center justify-center shrink-0 text-xs">
                            {u.photo ? (
                              <img src={u.photo} alt={u.fullName} className="w-full h-full rounded-full object-cover" />
                            ) : (
                              u.fullName.charAt(0)
                            )}
                          </div>
                          <div>
                            <p className="font-bold text-white text-xs">{u.fullName}</p>
                            <p className="text-[11px] text-slate-400 font-mono">{u.email}</p>
                            <p className="text-[10px] text-slate-500 font-mono">ID: {u.employeeNumber}</p>
                          </div>
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="space-y-1">
                          {getRoleBadge(u.role)}
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <p className="text-slate-200 text-xs font-medium">{u.department}</p>
                        <p className="text-[10px] text-slate-400">{u.branch}</p>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="space-y-1">
                          {getSiteAccessPill(u)}
                          <p className="text-[10px] text-slate-400 truncate max-w-[140px]">{u.site}</p>
                        </div>
                      </td>

                      <td className="py-3.5 px-4">{getStatusBadge(u.status)}</td>

                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Edit User Modal */}
                          <button
                            onClick={() => handleOpenEdit(u)}
                            title="Edit User & Site Access"
                            className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-blue-400 transition cursor-pointer"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          {/* Reset Password */}
                          <button
                            onClick={() => handleResetPassword(u)}
                            title="Reset Temporary Password"
                            className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-amber-400 transition cursor-pointer"
                          >
                            <KeyRound className="w-3.5 h-3.5" />
                          </button>

                          {/* Toggle Active / Inactive Status */}
                          <button
                            onClick={() => {
                              toggleUserStatus(u.id);
                              toast.info(`Toggled status for ${u.fullName}`);
                            }}
                            title={u.status === 'Active' ? 'Deactivate User Account' : 'Activate User Account'}
                            className={`px-2 py-1 rounded-lg text-[10px] font-semibold transition cursor-pointer border ${
                              u.status === 'Active'
                                ? 'bg-amber-950/60 hover:bg-amber-900 border-amber-800 text-amber-300'
                                : 'bg-emerald-950/60 hover:bg-emerald-900 border-emerald-800 text-emerald-300'
                            }`}
                          >
                            {u.status === 'Active' ? 'Deactivate' : 'Activate'}
                          </button>

                          {/* Remove Access / Delete */}
                          <button
                            onClick={async () => {
                              if (confirm(`Are you sure you want to completely REVOKE access for ${u.fullName}? They will be blocked from the system immediately.`)) {
                                try {
                                  // Optimistic UI update
                                  deleteUser(u.id);
                                  
                                  // Call API
                                  const { user } = useAuthStore.getState();
                                  await fetch('/api/admin/revoke-access', {
                                    method: 'PUT',
                                    headers: {
                                      'Content-Type': 'application/json',
                                      'X-User-Name': user?.name || 'Super Admin'
                                    },
                                    body: JSON.stringify({ email: u.email })
                                  });
                                  
                                  toast.error(`Access Revoked for ${u.fullName}`);
                                } catch (err) {
                                  toast.error('Failed to revoke access');
                                }
                              }
                            }}
                            title="Remove / Revoke Access"
                            className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-500 hover:text-rose-400 transition cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: AUTHORIZED GOOGLE ACCOUNTS WHITELIST */}
      {activeSubTab === 'authorized_google' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl space-y-0">
          <div className="p-4 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between text-xs text-slate-300">
            <span className="font-semibold text-emerald-400 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4" />
              <span>Google SSO Authorization Whitelist (Only listed accounts can sign in)</span>
            </span>
            <span className="text-[11px] text-slate-500">Super Admin Governance</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950/90 text-slate-400 uppercase tracking-wider text-[10px] border-b border-slate-800 font-semibold">
                <tr>
                  <th className="py-3.5 px-4 min-w-[200px]">Authorized Google Account</th>
                  <th className="py-3.5 px-4">Role</th>
                  <th className="py-3.5 px-4">Department</th>
                  <th className="py-3.5 px-4">Site Authorization</th>
                  <th className="py-3.5 px-4">SSO Status</th>
                  <th className="py-3.5 px-4 text-right">Super Admin Governance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredAuthUsers.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-12 text-center text-slate-500 text-xs">
                      No authorized Google accounts found matching the selected filters.
                    </td>
                  </tr>
                ) : (
                  filteredAuthUsers.map((u) => (
                    <tr key={u.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center border border-emerald-500/30 shrink-0 text-xs">
                            G
                          </div>
                          <div>
                            <p className="font-bold text-white text-xs">{u.fullName}</p>
                            <p className="text-[11px] text-emerald-400 font-mono flex items-center gap-1">
                              <Mail className="w-3 h-3 text-slate-500" />
                              <span>{u.googleEmail}</span>
                            </p>
                          </div>
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        {getRoleBadge(u.role)}
                      </td>

                      <td className="py-3.5 px-4">
                        <p className="text-slate-200 text-xs font-medium">{u.department}</p>
                        <p className="text-[10px] text-slate-400">{u.branch}</p>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="space-y-1">
                          {getSiteAccessPill(u)}
                          <p className="text-[10px] text-slate-400 truncate max-w-[140px]">{u.site}</p>
                        </div>
                      </td>

                      <td className="py-3.5 px-4">{getStatusBadge(u.status)}</td>

                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Edit Authorized User */}
                          <button
                            onClick={() => handleOpenEditAuth(u)}
                            title="Edit Google Account Details & Role"
                            className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer text-[10px] font-semibold"
                          >
                            Edit
                          </button>

                          {/* Toggle Active / Inactive Status */}
                          {u.status === 'Active' ? (
                            <button
                              onClick={() => {
                                deactivateAuthorizedUser(u.id);
                                toast.warning(`Deactivated Google account access for ${u.googleEmail}`);
                              }}
                              title="Deactivate and Block Google Login"
                              className="px-2 py-1 rounded-lg bg-rose-950/60 hover:bg-rose-900 border border-rose-800 text-rose-300 transition cursor-pointer text-[10px] font-semibold"
                            >
                              Deactivate
                            </button>
                          ) : (
                            <button
                              onClick={() => {
                                activateAuthorizedUser(u.id);
                                toast.success(`Activated Google account authorization for ${u.googleEmail}`);
                              }}
                              title="Activate Google Login"
                              className="px-2 py-1 rounded-lg bg-emerald-950/60 hover:bg-emerald-900 border border-emerald-800 text-emerald-300 transition cursor-pointer text-[10px] font-semibold"
                            >
                              Activate
                            </button>
                          )}

                          {/* Revoke / Remove Account */}
                          <button
                            onClick={async () => {
                              if (confirm(`Revoke Google OAuth authorization for ${u.fullName} (${u.googleEmail})? They will be blocked from the system immediately.`)) {
                                try {
                                  deleteAuthorizedUser(u.id);
                                  
                                  const { user } = useAuthStore.getState();
                                  await fetch('/api/admin/revoke-access', {
                                    method: 'PUT',
                                    headers: {
                                      'Content-Type': 'application/json',
                                      'X-User-Name': user?.name || 'Super Admin'
                                    },
                                    body: JSON.stringify({ email: u.googleEmail })
                                  });

                                  toast.error(`Revoked access for ${u.googleEmail}`);
                                } catch (err) {
                                  toast.error('Failed to revoke access');
                                }
                              }
                            }}
                            title="Revoke & Delete from Whitelist"
                            className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-500 hover:text-rose-400 transition cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* MODAL: RESET PASSWORD DISPLAY */}
      {resetPassUser && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 text-slate-200 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
                <KeyRound className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Temporary Credential Generated</h3>
                <p className="text-xs text-slate-400">{resetPassUser.user.fullName} ({resetPassUser.user.email})</p>
              </div>
            </div>

            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Temporary Password</span>
              <div className="flex items-center justify-between bg-slate-900 px-3 py-2 rounded-lg border border-slate-700">
                <span className="font-mono text-sm font-bold text-amber-400">{resetPassUser.tempPass}</span>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(resetPassUser.tempPass);
                    toast.success('Temporary password copied to clipboard!');
                  }}
                  className="flex items-center gap-1 text-[11px] text-slate-300 hover:text-white px-2 py-1 rounded bg-slate-800 border border-slate-700 cursor-pointer"
                >
                  <Copy className="w-3 h-3" /> Copy
                </button>
              </div>
              <p className="text-[11px] text-slate-500">
                Share this secure one-time password with the user. They will be prompted to update their password upon next sign-in.
              </p>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setResetPassUser(null)}
                className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: ADD / EDIT AUTHORIZED GOOGLE ACCOUNT */}
      {(isAddAuthOpen || editingAuthUser) && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 text-slate-200 shadow-2xl space-y-5 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
                <h3 className="text-base font-bold text-white">
                  {editingAuthUser ? `Edit Authorized Account: ${editingAuthUser.googleEmail}` : 'Authorize Google SSO Account'}
                </h3>
              </div>
              <button
                onClick={() => {
                  setIsAddAuthOpen(false);
                  setEditingAuthUser(null);
                }}
                className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveAuthUser} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. David Tan"
                  value={authFormData.fullName}
                  onChange={(e) => setAuthFormData({ ...authFormData, fullName: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Google Email Address *
                </label>
                <input
                  type="email"
                  required
                  placeholder="e.g. user@gmail.com or employee@mountec.sg"
                  value={authFormData.googleEmail}
                  onChange={(e) => setAuthFormData({ ...authFormData, googleEmail: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    System Role *
                  </label>
                  <select
                    value={authFormData.role}
                    onChange={(e) => {
                      const newRole = e.target.value as SystemRole;
                      const isMaster = newRole === 'Super Admin' || newRole === 'Admin';
                      setAuthFormData({
                        ...authFormData,
                        role: newRole,
                        allSitesAccess: isMaster ? true : authFormData.allSitesAccess
                      });
                    }}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs"
                  >
                    <option value="Super Admin">Super Admin (Full Master Access)</option>
                    <option value="Admin">Admin (Enterprise Operations)</option>
                    <option value="Supervisor">Supervisor (Site Operations)</option>
                    <option value="Worker">Worker (Field Operations)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Authorization Status
                  </label>
                  <select
                    value={authFormData.status}
                    onChange={(e) => setAuthFormData({ ...authFormData, status: e.target.value as 'Active' | 'Inactive' })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs"
                  >
                    <option value="Active">Active (Allowed)</option>
                    <option value="Inactive">Inactive (Blocked)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Department</label>
                <select
                  value={authFormData.department}
                  onChange={(e) => setAuthFormData({ ...authFormData, department: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs"
                >
                  {departments.map((d) => (
                    <option key={d.id} value={d.name}>{d.name}</option>
                  ))}
                </select>
              </div>

              {/* Site Authorizations */}
              <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-white flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-blue-400" /> Authorized Project Sites
                  </span>
                  <label className="flex items-center gap-1.5 text-xs text-purple-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={authFormData.allSitesAccess}
                      onChange={(e) => setAuthFormData({ ...authFormData, allSitesAccess: e.target.checked })}
                      className="rounded border-slate-700 text-purple-600 focus:ring-purple-500"
                    />
                    <span>All Sites Access</span>
                  </label>
                </div>

                {!authFormData.allSitesAccess && (
                  <div className="space-y-1.5 pt-1">
                    {sites.map((s) => {
                      const isChecked = authFormData.assignedSites.includes(s.siteName);
                      return (
                        <label
                          key={s.id}
                          className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-slate-900 text-xs text-slate-300 cursor-pointer"
                        >
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setAuthFormData({
                                  ...authFormData,
                                  assignedSites: [...authFormData.assignedSites, s.siteName]
                                });
                              } else {
                                setAuthFormData({
                                  ...authFormData,
                                  assignedSites: authFormData.assignedSites.filter((name) => name !== s.siteName)
                                });
                              }
                            }}
                            className="rounded border-slate-700 text-blue-600"
                          />
                          <span>{s.siteName}</span>
                        </label>
                      );
                    })}
                  </div>
                )}
              </div>

              <div className="pt-4 border-t border-slate-800 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddAuthOpen(false);
                    setEditingAuthUser(null);
                  }}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold cursor-pointer shadow-md shadow-emerald-900/30"
                >
                  {editingAuthUser ? 'Save Changes' : 'Authorize Account'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: CREATE / EDIT SYSTEM USER */}
      {(isAddOpen || editingUser) && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 text-slate-200 shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div>
                <h3 className="text-base font-bold text-white">
                  {editingUser ? `Edit User: ${editingUser.fullName}` : 'Add New Enterprise User'}
                </h3>
                <p className="text-xs text-slate-400">MOUNTEC PTE LTD Enterprise RBAC & Site Access Provisioning</p>
              </div>
              <button
                onClick={() => {
                  setIsAddOpen(false);
                  setEditingUser(null);
                }}
                className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveUser} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Full Name *</label>
                  <input
                    type="text"
                    required
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Email Address *</label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Employee Number *</label>
                  <input
                    type="text"
                    required
                    value={formData.employeeNumber}
                    onChange={(e) => setFormData({ ...formData, employeeNumber: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Contact Phone *</label>
                  <input
                    type="text"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                  />
                </div>

                {!editingUser && (
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-semibold text-slate-300">Password / Temp Credential *</label>
                      <button
                        type="button"
                        onClick={() =>
                          setFormData({
                            ...formData,
                            password: `Mnc#${Math.floor(100000 + Math.random() * 900000)}`,
                          })
                        }
                        className="text-[10px] text-amber-400 hover:text-amber-300 underline cursor-pointer"
                      >
                        Regenerate
                      </button>
                    </div>
                    <input
                      type="text"
                      required
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                      placeholder="e.g. Mnc#337373"
                      className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-amber-400 font-mono text-xs font-medium"
                    />
                  </div>
                )}

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">System Role (4 Core Roles) *</label>
                  <select
                    value={formData.role}
                    onChange={(e) => {
                      const newRole = e.target.value as SystemRole;
                      const isMaster = newRole === 'Super Admin' || newRole === 'Admin';
                      setFormData({
                        ...formData,
                        role: newRole,
                        allSitesAccess: isMaster ? true : formData.allSitesAccess
                      });
                    }}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-medium"
                  >
                    <option value="Super Admin">Super Admin (Full Unrestricted Access)</option>
                    <option value="Admin">Admin (Enterprise Operations)</option>
                    <option value="Supervisor">Supervisor (Site Operations)</option>
                    <option value="Worker">Worker (Field Operations)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Department *</label>
                  <select
                    value={formData.department}
                    onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                  >
                    {departments.map((d) => (
                      <option key={d.id} value={d.name}>{d.name}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Assigned Branch *</label>
                  <select
                    value={formData.branch}
                    onChange={(e) => setFormData({ ...formData, branch: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                  >
                    {branches.map((b) => (
                      <option key={b.id} value={b.name}>{b.name}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Primary Project Site *</label>
                  <select
                    value={formData.site}
                    onChange={(e) => setFormData({ ...formData, site: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                  >
                    {sites.map((s) => (
                      <option key={s.id} value={s.siteName}>{s.siteName}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Account Status</label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value as UserStatus })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                  >
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive / Deactivated</option>
                    <option value="Locked">Locked</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Photo Avatar URL</label>
                  <input
                    type="text"
                    placeholder="https://..."
                    value={formData.photo}
                    onChange={(e) => setFormData({ ...formData, photo: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                  />
                </div>
              </div>

              {/* Site Authorizations Checkboxes */}
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-white flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-blue-400" /> Authorized Project Sites
                  </span>
                  <label className="flex items-center gap-1.5 text-xs text-purple-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.allSitesAccess}
                      onChange={(e) => setFormData({ ...formData, allSitesAccess: e.target.checked })}
                      className="rounded border-slate-700 text-purple-600 focus:ring-purple-500"
                    />
                    <span>All Sites Access (Enterprise-Wide)</span>
                  </label>
                </div>

                {!formData.allSitesAccess && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                    {sites.map((s) => {
                      const isChecked = formData.assignedSites.includes(s.siteName);
                      return (
                        <label
                          key={s.id}
                          className="flex items-center gap-2 p-2 rounded-lg bg-slate-900/60 hover:bg-slate-900 text-xs text-slate-300 border border-slate-800/80 cursor-pointer"
                        >
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setFormData({
                                  ...formData,
                                  assignedSites: [...formData.assignedSites, s.siteName]
                                });
                              } else {
                                setFormData({
                                  ...formData,
                                  assignedSites: formData.assignedSites.filter((name) => name !== s.siteName)
                                });
                              }
                            }}
                            className="rounded border-slate-700 text-blue-600"
                          />
                          <span className="truncate">{s.siteName}</span>
                        </label>
                      );
                    })}
                  </div>
                )}
              </div>

              <div className="pt-4 border-t border-slate-800 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddOpen(false);
                    setEditingUser(null);
                  }}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold cursor-pointer shadow-md shadow-blue-900/30"
                >
                  {editingUser ? 'Update User' : 'Save New User'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserManagementSection;
