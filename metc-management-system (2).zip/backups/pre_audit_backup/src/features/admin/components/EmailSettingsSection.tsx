import React, { useState } from 'react';
import { Mail, Server, ShieldCheck, Send, Save, CheckCircle2, AlertCircle, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';
import { useAdmin } from '../hooks/useAdmin';

export const EmailSettingsSection: React.FC = () => {
  const { emailSettings, updateEmailSettings, adminService } = useAdmin();
  const [formData, setFormData] = useState(emailSettings);
  const [testEmailAddress, setTestEmailAddress] = useState('admin@mountec.sg');
  const [isSendingTest, setIsSendingTest] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateEmailSettings(formData);
    toast.success('SMTP Email settings updated successfully.');
  };

  const handleSendTest = async () => {
    setIsSendingTest(true);
    try {
      await adminService.sendTestEmail(testEmailAddress);
      toast.success(`Verification test email delivered to ${testEmailAddress}`);
    } catch (err) {
      toast.error('Failed to dispatch test email. Check SMTP credentials.');
    } finally {
      setIsSendingTest(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-white tracking-wide">Enterprise Email Engine (SMTP)</h2>
            <span className="px-2.5 py-0.5 bg-emerald-500/10 text-emerald-400 text-[10px] font-semibold rounded-full border border-emerald-500/20">
              Active Connection
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Configure outgoing mail server for automated system alerts, issue vouchers, reminders, and user invitations.
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-slate-200 space-y-6 shadow-md">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* SMTP Host */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <Server className="w-3.5 h-3.5 text-blue-400" /> SMTP Host Server *
            </label>
            <input
              type="text"
              required
              value={formData.smtpHost}
              onChange={(e) => setFormData({ ...formData, smtpHost: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-mono"
            />
          </div>

          {/* Port */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300">SMTP Port *</label>
            <input
              type="number"
              required
              value={formData.smtpPort}
              onChange={(e) => setFormData({ ...formData, smtpPort: Number(e.target.value) })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-mono"
            />
          </div>

          {/* Encryption */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300">Security Encryption</label>
            <select
              value={formData.encryption}
              onChange={(e) => setFormData({ ...formData, encryption: e.target.value as any })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-semibold"
            >
              <option value="TLS">TLS (Transport Layer Security)</option>
              <option value="SSL">SSL (Secure Sockets Layer)</option>
              <option value="None">None (Unencrypted - Not Recommended)</option>
            </select>
          </div>

          {/* Sender Email */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-amber-400" /> Default Sender Address *
            </label>
            <input
              type="email"
              required
              value={formData.senderEmail}
              onChange={(e) => setFormData({ ...formData, senderEmail: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-mono"
            />
          </div>

          {/* Sender Name */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300">Default Sender Display Name *</label>
            <input
              type="text"
              required
              value={formData.senderName}
              onChange={(e) => setFormData({ ...formData, senderName: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-semibold"
            />
          </div>

          {/* Username */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300">SMTP Auth Username</label>
            <input
              type="text"
              value={formData.username}
              onChange={(e) => setFormData({ ...formData, username: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-mono"
            />
          </div>
        </div>

        {/* Action Bar */}
        <div className="pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          {/* Test Email Bar */}
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <input
              type="email"
              placeholder="Test recipient address..."
              value={testEmailAddress}
              onChange={(e) => setTestEmailAddress(e.target.value)}
              className="px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none"
            />
            <button
              type="button"
              onClick={handleSendTest}
              disabled={isSendingTest}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition border border-slate-700 flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              {isSendingTest ? <RefreshCw className="w-3.5 h-3.5 animate-spin text-blue-400" /> : <Send className="w-3.5 h-3.5 text-blue-400" />}
              Send Test
            </button>
          </div>

          <button
            type="submit"
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs transition shadow-md shadow-blue-900/30 cursor-pointer"
          >
            <Save className="w-4 h-4" /> Save SMTP Settings
          </button>
        </div>
      </form>
    </div>
  );
};
