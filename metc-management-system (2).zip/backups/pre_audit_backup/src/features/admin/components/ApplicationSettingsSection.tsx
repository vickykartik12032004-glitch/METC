import React, { useState } from 'react';
import { Sliders, Moon, Sun, Monitor, Calendar, Clock, DollarSign, Layout, Save, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';
import { useAdmin } from '../hooks/useAdmin';

export const ApplicationSettingsSection: React.FC = () => {
  const { appSettings, updateAppSettings } = useAdmin();
  const [formData, setFormData] = useState(appSettings);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateAppSettings(formData);
    toast.success('Application global preferences saved successfully.');
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
        <div className="flex items-center gap-2">
          <h2 className="text-base font-bold text-white tracking-wide">Application Global Configuration</h2>
          <span className="px-2.5 py-0.5 bg-blue-500/10 text-blue-400 text-[10px] font-semibold rounded-full border border-blue-500/20">
            System Preferences
          </span>
        </div>
        <p className="text-xs text-slate-400 mt-1">
          Customize global visual themes, localized date/time formatting, default landing views, and regional defaults.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-slate-200 space-y-6 shadow-md">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Theme Mode */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <Sun className="w-3.5 h-3.5 text-amber-400" /> Default Visual Theme Mode
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { key: 'Dark', icon: Moon, label: 'Dark' },
                { key: 'Light', icon: Sun, label: 'Light' },
                { key: 'System', icon: Monitor, label: 'System' },
              ].map((t) => {
                const Icon = t.icon;
                const isSelected = formData.themeMode === t.key;
                return (
                  <button
                    key={t.key}
                    type="button"
                    onClick={() => setFormData({ ...formData, themeMode: t.key as any })}
                    className={`py-2.5 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 transition cursor-pointer ${
                      isSelected
                        ? 'bg-blue-600 border-blue-500 text-white shadow-md'
                        : 'bg-slate-800/80 border-slate-700 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" /> {t.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Date Format */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-blue-400" /> System Date Format
            </label>
            <select
              value={formData.dateFormat}
              onChange={(e) => setFormData({ ...formData, dateFormat: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-mono focus:ring-2 focus:ring-blue-500 focus:outline-none"
            >
              <option value="DD/MM/YYYY">DD/MM/YYYY (Singapore / UK Standard)</option>
              <option value="MM/DD/YYYY">MM/DD/YYYY (US Standard)</option>
              <option value="YYYY-MM-DD">YYYY-MM-DD (ISO 8601 Standard)</option>
            </select>
          </div>

          {/* Time Format */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-emerald-400" /> System Time Clock Format
            </label>
            <select
              value={formData.timeFormat}
              onChange={(e) => setFormData({ ...formData, timeFormat: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-mono focus:ring-2 focus:ring-blue-500 focus:outline-none"
            >
              <option value="12h">12-Hour Clock (02:30 PM)</option>
              <option value="24h">24-Hour Military Clock (14:30)</option>
            </select>
          </div>

          {/* Base Currency */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <DollarSign className="w-3.5 h-3.5 text-emerald-400" /> Financial Valuation Currency
            </label>
            <select
              value={formData.currency}
              onChange={(e) => setFormData({ ...formData, currency: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none font-semibold"
            >
              <option value="SGD (S$)">SGD - Singapore Dollar (S$)</option>
              <option value="USD ($)">USD - US Dollar ($)</option>
              <option value="EUR (€)">EUR - Euro (€)</option>
              <option value="MYR (RM)">MYR - Malaysian Ringgit (RM)</option>
            </select>
          </div>

          {/* Default Landing Tab */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <Layout className="w-3.5 h-3.5 text-purple-400" /> Default Initial Landing View
            </label>
            <select
              value={formData.defaultDashboardView}
              onChange={(e) => setFormData({ ...formData, defaultDashboardView: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none font-semibold"
            >
              <option value="Dashboard">Executive Operational Dashboard</option>
              <option value="Materials">Materials & Master Asset Inventory</option>
              <option value="Issue">Issue / Return Voucher Terminal</option>
              <option value="Notifications">Notification Center</option>
              <option value="Administration">System Administration Panel</option>
            </select>
          </div>

          {/* Language */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-300">System Localization Language</label>
            <select
              value={formData.language}
              onChange={(e) => setFormData({ ...formData, language: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none font-semibold"
            >
              <option value="English (EN-SG)">English (Singapore / International)</option>
              <option value="Chinese (ZH-SG)">Chinese Simplified (中文)</option>
              <option value="Malay (MS-SG)">Bahasa Melayu</option>
            </select>
          </div>
        </div>

        <div className="pt-4 border-t border-slate-800 flex justify-end">
          <button
            type="submit"
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs transition shadow-md shadow-blue-900/30 cursor-pointer"
          >
            <Save className="w-4 h-4" /> Save Application Preferences
          </button>
        </div>
      </form>
    </div>
  );
};
