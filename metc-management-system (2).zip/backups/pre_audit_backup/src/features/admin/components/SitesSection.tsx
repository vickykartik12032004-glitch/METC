import React, { useState } from 'react';
import { HardHat, Plus, Edit2, Trash2, MapPin, Phone, Users, FileSpreadsheet, FileText, X } from 'lucide-react';
import { toast } from 'sonner';
import { useAdmin } from '../hooks/useAdmin';
import { ProjectSite } from '../types';

export const SitesSection: React.FC = () => {
  const { filteredSites, addSite, updateSite, deleteSite, adminService } = useAdmin();
  const [isOpen, setIsOpen] = useState(false);
  const [editingSite, setEditingSite] = useState<ProjectSite | null>(null);

  const [formData, setFormData] = useState({
    siteName: '',
    siteCode: '',
    projectName: '',
    address: '',
    manager: '',
    phone: '',
    status: 'Active' as 'Active' | 'Completed' | 'On Hold',
    workerCount: 0,
  });

  const handleOpenAdd = () => {
    setEditingSite(null);
    setFormData({
      siteName: '',
      siteCode: `PS-MNC-${Math.floor(100 + Math.random() * 900)}`,
      projectName: '',
      address: '',
      manager: '',
      phone: '+65 ',
      status: 'Active',
      workerCount: 0,
    });
    setIsOpen(true);
  };

  const handleOpenEdit = (s: ProjectSite) => {
    setEditingSite(s);
    setFormData({
      siteName: s.siteName,
      siteCode: s.siteCode,
      projectName: s.projectName,
      address: s.address,
      manager: s.manager,
      phone: s.phone,
      status: s.status,
      workerCount: s.workerCount,
    });
    setIsOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingSite) {
      updateSite(editingSite.id, formData);
      toast.success(`Site ${formData.siteName} updated.`);
    } else {
      addSite(formData);
      toast.success(`Project site ${formData.siteName} registered.`);
    }
    setIsOpen(false);
  };

  const getStatusBadge = (status: 'Active' | 'Completed' | 'On Hold') => {
    if (status === 'Active') return <span className="px-2.5 py-0.5 text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-full">Active</span>;
    if (status === 'Completed') return <span className="px-2.5 py-0.5 text-[10px] font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/20 rounded-full">Completed</span>;
    return <span className="px-2.5 py-0.5 text-[10px] font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20 rounded-full">On Hold</span>;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-5">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-white tracking-wide">Project Sites Directory</h2>
            <span className="px-2.5 py-0.5 bg-blue-500/10 text-blue-400 text-[10px] font-semibold rounded-full border border-blue-500/20">
              Unlimited Project Sites
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Track active construction sites, infrastructure projects, site engineers, and worker deployments.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => adminService.exportSites(filteredSites, 'csv')}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" /> CSV
          </button>
          <button
            onClick={() => adminService.exportSites(filteredSites, 'pdf')}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5 text-rose-400" /> PDF
          </button>
          <button
            onClick={handleOpenAdd}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs transition shadow-md shadow-blue-900/40 cursor-pointer shrink-0"
          >
            <Plus className="w-4 h-4" /> Add Project Site
          </button>
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredSites.map((s) => (
          <div
            key={s.id}
            className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 hover:border-slate-700 transition flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <span className="text-[10px] font-mono font-bold text-blue-400 px-2 py-0.5 bg-blue-950 border border-blue-800/80 rounded">
                    {s.siteCode}
                  </span>
                  <h3 className="text-sm font-bold text-white mt-1.5">{s.siteName}</h3>
                  <p className="text-xs text-amber-400/90 font-medium">{s.projectName}</p>
                </div>
                {getStatusBadge(s.status)}
              </div>

              <div className="space-y-1 text-xs text-slate-400 pt-1">
                <p className="flex items-start gap-2">
                  <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0 mt-0.5" />
                  <span>{s.address}</span>
                </p>
                <p className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>{s.phone}</span>
                </p>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
              <div>
                <span className="text-slate-400 text-[11px]">Site Manager: </span>
                <span className="font-semibold text-white">{s.manager}</span>
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => handleOpenEdit(s)}
                  className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-blue-400 transition cursor-pointer"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => {
                    if (confirm(`Delete project site ${s.siteName}?`)) {
                      deleteSite(s.id);
                      toast.error(`Deleted ${s.siteName}`);
                    }
                  }}
                  className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-rose-400 transition cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* MODAL */}
      {isOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 text-slate-200 shadow-2xl space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-white">
                {editingSite ? 'Edit Project Site' : 'Register New Project Site'}
              </h3>
              <button onClick={() => setIsOpen(false)} className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2 space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Site Name *</label>
                  <input
                    type="text"
                    required
                    value={formData.siteName}
                    onChange={(e) => setFormData({ ...formData, siteName: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Site Code *</label>
                  <input
                    type="text"
                    required
                    value={formData.siteCode}
                    onChange={(e) => setFormData({ ...formData, siteCode: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Project Contract Name *</label>
                  <input
                    type="text"
                    required
                    value={formData.projectName}
                    onChange={(e) => setFormData({ ...formData, projectName: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                  />
                </div>

                <div className="col-span-2 space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Site Address *</label>
                  <textarea
                    rows={2}
                    required
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Site Manager *</label>
                  <input
                    type="text"
                    required
                    value={formData.manager}
                    onChange={(e) => setFormData({ ...formData, manager: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Site Contact Phone *</label>
                  <input
                    type="text"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Status</label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                  >
                    <option value="Active">Active</option>
                    <option value="Completed">Completed</option>
                    <option value="On Hold">On Hold</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold cursor-pointer"
                >
                  Save Site
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
