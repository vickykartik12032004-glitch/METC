import React, { useState, useMemo } from 'react';
import {
  Shield,
  ShieldPlus,
  Check,
  X,
  Info,
  Trash2,
  Lock,
  Users,
  RotateCcw,
  CheckCheck,
  Ban,
  Search,
  SlidersHorizontal,
  Sparkles
} from 'lucide-react';
import { toast } from 'sonner';
import { useAdmin } from '../hooks/useAdmin';
import { AdminModule, ModulePermissions } from '../types';

const ALL_MODULES: { name: AdminModule; category: string; description: string }[] = [
  { name: 'Dashboard', category: 'General', description: 'Executive KPIs, asset analytics, and system summaries' },
  { name: 'Materials', category: 'Inventory', description: 'Raw materials, bulk inventory, and storage tracking' },
  { name: 'Equipment', category: 'Inventory', description: 'Heavy machinery, operational units, and deployment' },
  { name: 'Tools', category: 'Inventory', description: 'Handheld & power tools catalogue and condition' },
  { name: 'Consumables', category: 'Inventory', description: 'Consumable parts, fittings, fasteners, and supplies' },
  { name: 'PPE', category: 'Safety', description: 'Personal protective equipment issuance and safety compliance' },
  { name: 'Workers', category: 'Human Resources', description: 'Field workforce roster, trade skills, and pass details' },
  { name: 'Issue', category: 'Operations', description: 'Asset check-out, issuance slips, and verification' },
  { name: 'Return', category: 'Operations', description: 'Asset check-in, condition inspection, and restocking' },
  { name: 'Transfer', category: 'Operations', description: 'Inter-site asset logistics and dispatch orders' },
  { name: 'Repair', category: 'Maintenance', description: 'Defect ticketing, maintenance schedules, and third-party repair' },
  { name: 'Reports', category: 'Analytics', description: 'Audit logs, stock valuations, and historical reporting' },
  { name: 'Notifications', category: 'General', description: 'System alerts, broadcast messages, and notifications' },
  { name: 'Settings', category: 'Administration', description: 'Application preferences, regional formats, and notifications' },
  { name: 'Administration', category: 'Administration', description: 'RBAC permissions, user accounts, and security controls' },
];

const PERMISSION_KEYS: { key: keyof ModulePermissions; label: string; tooltip: string }[] = [
  { key: 'view', label: 'View', tooltip: 'Read-only access to browse module data' },
  { key: 'create', label: 'Create', tooltip: 'Ability to add new records or initiate requests' },
  { key: 'update', label: 'Update', tooltip: 'Ability to edit or modify existing records' },
  { key: 'delete', label: 'Delete', tooltip: 'Ability to remove or purge records' },
  { key: 'approve', label: 'Approve', tooltip: 'Authorize transactions, transfers, or sign-offs' },
  { key: 'export', label: 'Export', tooltip: 'Download reports, Excel, or PDF data' },
  { key: 'import', label: 'Import', tooltip: 'Bulk upload CSV or spreadsheet entries' },
];

export const RoleManagementSection: React.FC = () => {
  const {
    roles,
    users,
    addRole,
    deleteRole,
    assignPermission,
    grantAllPermissions,
    revokeAllPermissions,
    resetRolePermissions
  } = useAdmin();

  const [selectedRoleId, setSelectedRoleId] = useState<string>(roles[0]?.id || 'role-superadmin');
  const [moduleSearch, setModuleSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [isAddCustomModalOpen, setIsAddCustomModalOpen] = useState(false);

  // New Custom Role Form
  const [newRoleName, setNewRoleName] = useState('');
  const [newRoleDesc, setNewRoleDesc] = useState('');

  const selectedRole = roles.find((r) => r.id === selectedRoleId) || roles[0];
  const isSuperAdminRole = selectedRole?.name === 'Super Admin';

  // Calculate live user count for selected role
  const roleUserCount = useMemo(() => {
    if (!selectedRole) return 0;
    return users.filter(
      (u) => !u.isSoftDeleted && (u.role === selectedRole.name || u.role.toLowerCase() === selectedRole.name.toLowerCase())
    ).length;
  }, [users, selectedRole]);

  // Categories list
  const categories = useMemo(() => {
    const set = new Set(ALL_MODULES.map((m) => m.category));
    return ['All', ...Array.from(set)];
  }, []);

  // Filtered modules
  const filteredModules = useMemo(() => {
    return ALL_MODULES.filter((m) => {
      const matchSearch =
        m.name.toLowerCase().includes(moduleSearch.toLowerCase()) ||
        m.description.toLowerCase().includes(moduleSearch.toLowerCase());
      const matchCat = selectedCategory === 'All' || m.category === selectedCategory;
      return matchSearch && matchCat;
    });
  }, [moduleSearch, selectedCategory]);

  const handleTogglePermission = (
    module: AdminModule,
    key: keyof ModulePermissions,
    currentVal: boolean
  ) => {
    if (!selectedRole) return;
    if (isSuperAdminRole) {
      toast.info('Super Admin permissions are permanent and cannot be modified.');
      return;
    }
    assignPermission(selectedRole.id, module, key, !currentVal);
    toast.success(`Updated ${key} permission for ${module}`);
  };

  const handleGrantAll = () => {
    if (!selectedRole) return;
    if (isSuperAdminRole) return;
    grantAllPermissions(selectedRole.id);
    toast.success(`Granted all module permissions to ${selectedRole.name}`);
  };

  const handleRevokeAll = () => {
    if (!selectedRole) return;
    if (isSuperAdminRole) return;
    revokeAllPermissions(selectedRole.id);
    toast.warning(`Revoked operational permissions from ${selectedRole.name}`);
  };

  const handleResetDefaults = () => {
    if (!selectedRole) return;
    if (isSuperAdminRole) return;
    resetRolePermissions(selectedRole.id);
    toast.success(`Reset permissions for ${selectedRole.name} to system defaults`);
  };

  const handleCreateCustomRole = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRoleName.trim()) return;

    // Create default matrix
    const defaultMatrix = {} as Record<AdminModule, ModulePermissions>;
    ALL_MODULES.forEach((m) => {
      defaultMatrix[m.name] = {
        view: true,
        create: false,
        update: false,
        delete: false,
        approve: false,
        export: false,
        import: false,
      };
    });

    addRole({
      name: newRoleName.trim(),
      description: newRoleDesc.trim() || 'Custom enterprise access role with configurable permissions.',
      isCustom: true,
      permissions: defaultMatrix,
      userCount: 0,
    });

    toast.success(`Custom role "${newRoleName}" created successfully!`);
    setNewRoleName('');
    setNewRoleDesc('');
    setIsAddCustomModalOpen(false);
  };

  return (
    <div className="space-y-6" id="role-management-section">
      {/* Top Header Banner */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg">
        <div className="space-y-1">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-400">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white tracking-wide">4-Role RBAC & Permission Governance</h2>
                <span className="px-2 py-0.5 bg-purple-500/10 text-purple-300 text-[10px] font-bold rounded-full border border-purple-500/30 uppercase tracking-wider">
                  Enterprise Security
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Manage fine-grained authorizations across the 4 primary system roles (Super Admin, Admin, Supervisor, Worker).
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2.5 shrink-0">
          <button
            onClick={() => setIsAddCustomModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs transition shadow-md shadow-purple-900/40 cursor-pointer"
          >
            <ShieldPlus className="w-4 h-4" /> Create Custom Role
          </button>
        </div>
      </div>

      {/* Role Selection Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {roles.map((role) => {
          const isSelected = role.id === selectedRoleId;
          const isSuper = role.name === 'Super Admin';
          const isAdmin = role.name === 'Admin';
          const isSup = role.name === 'Supervisor' || role.name === 'Site Supervisor';
          const isWrk = role.name === 'Worker' || role.name === 'Store Keeper' || role.name === 'User';

          let themeBg = 'bg-slate-900 border-slate-800';
          let badgeColor = 'bg-slate-800 text-slate-300 border-slate-700';

          if (isSuper) {
            badgeColor = 'bg-purple-500/15 text-purple-300 border-purple-500/30';
          } else if (isAdmin) {
            badgeColor = 'bg-blue-500/15 text-blue-300 border-blue-500/30';
          } else if (isSup) {
            badgeColor = 'bg-amber-500/15 text-amber-300 border-amber-500/30';
          } else if (isWrk) {
            badgeColor = 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30';
          }

          if (isSelected) {
            if (isSuper) themeBg = 'bg-purple-950/40 border-purple-500 ring-1 ring-purple-500/40 shadow-lg shadow-purple-950/50';
            else if (isAdmin) themeBg = 'bg-blue-950/40 border-blue-500 ring-1 ring-blue-500/40 shadow-lg shadow-blue-950/50';
            else if (isSup) themeBg = 'bg-amber-950/40 border-amber-500 ring-1 ring-amber-500/40 shadow-lg shadow-amber-950/50';
            else themeBg = 'bg-emerald-950/40 border-emerald-500 ring-1 ring-emerald-500/40 shadow-lg shadow-emerald-950/50';
          }

          // Count users
          const uCount = users.filter((u) => !u.isSoftDeleted && u.role === role.name).length;

          return (
            <div
              key={role.id}
              onClick={() => setSelectedRoleId(role.id)}
              className={`p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between space-y-3 relative group ${themeBg}`}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className={`px-2 py-0.5 text-[10px] font-bold rounded-md border uppercase tracking-wider ${badgeColor}`}>
                      {role.name}
                    </span>
                    {isSuper && (
                      <span className="p-1 rounded bg-purple-500/20 text-purple-300" title="Full System Authority">
                        <Lock className="w-3 h-3" />
                      </span>
                    )}
                  </div>

                  {role.isCustom && (
                    <span className="text-[9px] font-bold px-1.5 py-0.5 bg-amber-500/10 text-amber-400 rounded border border-amber-500/20">
                      CUSTOM
                    </span>
                  )}
                </div>

                <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                  {role.description}
                </p>
              </div>

              <div className="flex items-center justify-between pt-2.5 border-t border-slate-800/80 text-[10px] text-slate-400">
                <span className="flex items-center gap-1 font-medium text-slate-300">
                  <Users className="w-3.5 h-3.5 text-slate-500" /> {uCount} Assigned {uCount === 1 ? 'User' : 'Users'}
                </span>
                {isSelected ? (
                  <span className="text-white font-bold text-[10px] uppercase tracking-wider flex items-center gap-1">
                    <Check className="w-3 h-3 text-emerald-400" /> Configured
                  </span>
                ) : (
                  <span className="text-slate-500 group-hover:text-slate-300 text-[10px]">Select to Edit</span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Role Permissions Matrix Table & Controls */}
      {selectedRole && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-5 shadow-xl">
          {/* Header & Quick Action Buttons */}
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-5 border-b border-slate-800">
            <div className="space-y-1">
              <div className="flex items-center gap-3">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  Permissions Matrix: <span className="text-purple-400">{selectedRole.name}</span>
                </h3>
                {isSuperAdminRole && (
                  <span className="px-2.5 py-0.5 bg-purple-500/20 text-purple-300 text-[11px] font-bold rounded-full border border-purple-500/40 flex items-center gap-1">
                    <Lock className="w-3 h-3" /> Master Controller (Unrestricted)
                  </span>
                )}
                {selectedRole.isCustom && (
                  <button
                    onClick={() => {
                      if (confirm(`Delete custom role "${selectedRole.name}"?`)) {
                        deleteRole(selectedRole.id);
                        setSelectedRoleId(roles[0]?.id || '');
                        toast.error(`Deleted custom role ${selectedRole.name}`);
                      }
                    }}
                    className="flex items-center gap-1 text-[10px] text-rose-400 hover:text-rose-300 font-semibold px-2 py-1 rounded bg-rose-500/10 border border-rose-500/20 cursor-pointer"
                  >
                    <Trash2 className="w-3 h-3" /> Delete Custom Role
                  </button>
                )}
              </div>
              <p className="text-xs text-slate-400">{selectedRole.description}</p>
            </div>

            {/* Batch Controls for Non-Super-Admins */}
            {!isSuperAdminRole ? (
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={handleGrantAll}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-950/60 hover:bg-emerald-900/60 text-emerald-300 border border-emerald-800 text-xs font-semibold transition cursor-pointer"
                >
                  <CheckCheck className="w-3.5 h-3.5" /> Grant All
                </button>
                <button
                  onClick={handleRevokeAll}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-950/60 hover:bg-rose-900/60 text-rose-300 border border-rose-800 text-xs font-semibold transition cursor-pointer"
                >
                  <Ban className="w-3.5 h-3.5" /> Revoke Ops
                </button>
                <button
                  onClick={handleResetDefaults}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" /> Reset Defaults
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2 text-xs text-purple-300 bg-purple-950/40 px-3.5 py-2 rounded-xl border border-purple-800/60">
                <Sparkles className="w-4 h-4 text-purple-400 shrink-0" /> Super Admin holds permanent full authority across all application modules.
              </div>
            )}
          </div>

          {/* Search & Category Filter */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
            <div className="relative flex-1 max-w-sm">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                placeholder="Search modules..."
                value={moduleSearch}
                onChange={(e) => setModuleSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
              />
            </div>

            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
              <span className="text-[10px] uppercase font-bold text-slate-500 mr-1 flex items-center gap-1">
                <SlidersHorizontal className="w-3 h-3" /> Category:
              </span>
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition cursor-pointer whitespace-nowrap ${
                    selectedCategory === cat
                      ? 'bg-purple-600 text-white shadow-sm'
                      : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Matrix Table */}
          <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950/40">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider text-[10px] border-b border-slate-800 font-semibold">
                <tr>
                  <th className="py-3 px-4 min-w-[180px]">System Module</th>
                  <th className="py-3 px-3 min-w-[100px]">Category</th>
                  {PERMISSION_KEYS.map((p) => (
                    <th key={p.key} className="py-3 px-3 text-center" title={p.tooltip}>
                      <div className="flex flex-col items-center">
                        <span>{p.label}</span>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredModules.map((mod) => {
                  const modPerms = selectedRole.permissions[mod.name] || {
                    view: false,
                    create: false,
                    update: false,
                    delete: false,
                    approve: false,
                    export: false,
                    import: false,
                  };

                  return (
                    <tr key={mod.name} className="hover:bg-slate-800/30 transition-colors">
                      <td className="py-3 px-4">
                        <div className="font-semibold text-white">{mod.name}</div>
                        <div className="text-[10px] text-slate-400 line-clamp-1">{mod.description}</div>
                      </td>
                      <td className="py-3 px-3">
                        <span className="px-2 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-800 text-[10px] font-medium">
                          {mod.category}
                        </span>
                      </td>
                      {PERMISSION_KEYS.map((p) => {
                        const isGranted = isSuperAdminRole ? true : Boolean(modPerms[p.key]);

                        return (
                          <td key={p.key} className="py-3 px-3 text-center">
                            <button
                              disabled={isSuperAdminRole}
                              onClick={() => handleTogglePermission(mod.name, p.key, isGranted)}
                              title={
                                isSuperAdminRole
                                  ? 'Super Admin permissions cannot be modified'
                                  : `${isGranted ? 'Revoke' : 'Grant'} ${p.label} on ${mod.name}`
                              }
                              className={`w-7 h-7 rounded-lg border flex items-center justify-center mx-auto transition ${
                                isSuperAdminRole
                                  ? 'bg-purple-950/40 border-purple-800/60 text-purple-300 cursor-not-allowed opacity-90'
                                  : isGranted
                                  ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400 hover:bg-emerald-500/30 cursor-pointer'
                                  : 'bg-slate-950 border-slate-800 text-slate-600 hover:text-slate-400 hover:border-slate-700 cursor-pointer'
                              }`}
                            >
                              {isGranted ? <Check className="w-4 h-4" /> : <X className="w-3.5 h-3.5 opacity-40" />}
                            </button>
                          </td>
                        );
                      })}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* CREATE CUSTOM ROLE MODAL */}
      {isAddCustomModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 text-slate-200 shadow-2xl space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <ShieldPlus className="w-5 h-5 text-purple-400" /> Create Custom Role
              </h3>
              <button
                onClick={() => setIsAddCustomModalOpen(false)}
                className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateCustomRole} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Role Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Safety Inspector, Lead Auditor"
                  value={newRoleName}
                  onChange={(e) => setNewRoleName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-purple-500 focus:outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Description</label>
                <textarea
                  rows={3}
                  placeholder="Define responsibilities and authorization scope..."
                  value={newRoleDesc}
                  onChange={(e) => setNewRoleDesc(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-purple-500 focus:outline-none"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsAddCustomModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold cursor-pointer shadow-md shadow-purple-900/40"
                >
                  Create Role
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default RoleManagementSection;
