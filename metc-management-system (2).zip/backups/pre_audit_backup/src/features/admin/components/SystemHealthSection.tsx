import React from 'react';
import { Activity, Database, Cpu, HardDrive, Zap, RefreshCw, Server, CheckCircle2, AlertTriangle, ShieldCheck } from 'lucide-react';
import { toast } from 'sonner';
import { useAdmin } from '../hooks/useAdmin';

export const SystemHealthSection: React.FC = () => {
  const { systemHealth, refreshHealthMetrics } = useAdmin();

  const handleRefresh = () => {
    refreshHealthMetrics();
    toast.success('System health telemetry refreshed.');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-5">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-white tracking-wide">Enterprise Infrastructure Health & Telemetry</h2>
            <span className="px-2.5 py-0.5 bg-emerald-500/10 text-emerald-400 text-[10px] font-semibold rounded-full border border-emerald-500/20 flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" /> ALL SYSTEMS OPERATIONAL
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Real-time diagnostics covering database connection latency, API response times, node CPU load, memory allocation, and active sessions.
          </p>
        </div>

        <button
          onClick={handleRefresh}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition border border-slate-700 cursor-pointer shrink-0"
        >
          <RefreshCw className="w-3.5 h-3.5 text-blue-400" /> Refresh Diagnostics
        </button>
      </div>

      {/* KPI Gauge Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* DB Ping */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span className="flex items-center gap-1.5 font-semibold">
              <Database className="w-4 h-4 text-blue-400" /> PostgreSQL DB Ping
            </span>
            <span className="text-[10px] text-emerald-400 font-mono">HEALTHY</span>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold text-white font-mono">{systemHealth.dbPingMs} <span className="text-xs font-normal text-slate-400">ms</span></span>
            <span className="text-[10px] text-slate-500">Target &lt; 50ms</span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
            <div className="bg-blue-500 h-full rounded-full" style={{ width: `${Math.min(100, systemHealth.dbPingMs * 2)}%` }}></div>
          </div>
        </div>

        {/* API Response Time */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span className="flex items-center gap-1.5 font-semibold">
              <Zap className="w-4 h-4 text-amber-400" /> API Latency
            </span>
            <span className="text-[10px] text-emerald-400 font-mono">OPTIMAL</span>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold text-white font-mono">{systemHealth.apiResponseTimeMs} <span className="text-xs font-normal text-slate-400">ms</span></span>
            <span className="text-[10px] text-slate-500">Target &lt; 100ms</span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
            <div className="bg-amber-500 h-full rounded-full" style={{ width: `${Math.min(100, systemHealth.apiResponseTimeMs)}%` }}></div>
          </div>
        </div>

        {/* CPU Load */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span className="flex items-center gap-1.5 font-semibold">
              <Cpu className="w-4 h-4 text-purple-400" /> Server CPU Load
            </span>
            <span className="text-[10px] text-emerald-400 font-mono">LOW</span>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold text-white font-mono">{systemHealth.cpuLoadPercent} <span className="text-xs font-normal text-slate-400">%</span></span>
            <span className="text-[10px] text-slate-500">8 Core VCPU</span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
            <div className="bg-purple-500 h-full rounded-full" style={{ width: `${systemHealth.cpuLoadPercent}%` }}></div>
          </div>
        </div>

        {/* Storage */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span className="flex items-center gap-1.5 font-semibold">
              <HardDrive className="w-4 h-4 text-emerald-400" /> DB Storage Space
            </span>
            <span className="text-[10px] text-slate-400 font-mono">1.4 / 100 GB</span>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold text-white font-mono">1.4 <span className="text-xs font-normal text-slate-400">GB</span></span>
            <span className="text-[10px] text-emerald-400 font-bold">1.4% Used</span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
            <div className="bg-emerald-500 h-full rounded-full" style={{ width: '1.4%' }}></div>
          </div>
        </div>
      </div>

      {/* Infrastructure Node Telemetry Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4 shadow-xl">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <Server className="w-4 h-4 text-blue-400" /> Cloud Cluster Microservices Topology
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-xl space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white">Database Cluster (Primary)</span>
              <span className="px-2 py-0.5 rounded text-[9px] bg-emerald-500/10 text-emerald-400 font-semibold border border-emerald-500/20">Active</span>
            </div>
            <p className="text-[11px] text-slate-400 font-mono">Engine: PostgreSQL v15.3 (Supabase)</p>
            <p className="text-[11px] text-slate-400 font-mono">Pooler: PgBouncer (64 Connections)</p>
          </div>

          <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-xl space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white">Notification Worker Engine</span>
              <span className="px-2 py-0.5 rounded text-[9px] bg-emerald-500/10 text-emerald-400 font-semibold border border-emerald-500/20">Active</span>
            </div>
            <p className="text-[11px] text-slate-400 font-mono">Queue: Redis BullMQ Worker</p>
            <p className="text-[11px] text-slate-400 font-mono">Pending Dispatch Jobs: 0</p>
          </div>

          <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-xl space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white">Edge Gateway Proxy</span>
              <span className="px-2 py-0.5 rounded text-[9px] bg-emerald-500/10 text-emerald-400 font-semibold border border-emerald-500/20">Active</span>
            </div>
            <p className="text-[11px] text-slate-400 font-mono">Port: 3000 (0.0.0.0 Binding)</p>
            <p className="text-[11px] text-slate-400 font-mono">SSL Cert: Let's Encrypt Wildcard</p>
          </div>
        </div>
      </div>
    </div>
  );
};
