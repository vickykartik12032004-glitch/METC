import React, { useState } from 'react';
import { Database, HardDrive, Download, RefreshCw, AlertOctagon, CheckCircle2, ShieldAlert, Save, Clock, Play } from 'lucide-react';
import { toast } from 'sonner';
import { useAdmin } from '../hooks/useAdmin';
import { BackupRecord } from '../types';

export const BackupRestoreSection: React.FC = () => {
  const { backups, backupSettings, createBackup, restoreBackup, updateBackupSettings } = useAdmin();
  const [isCreating, setIsCreating] = useState(false);
  const [restoringBackup, setRestoringBackup] = useState<BackupRecord | null>(null);
  const [isRestoring, setIsRestoring] = useState(false);

  // Settings State
  const [settingsData, setSettingsData] = useState(backupSettings);

  const handleManualBackup = async () => {
    setIsCreating(true);
    toast.info('Initiating full PostgreSQL database snapshot...');
    await new Promise((res) => setTimeout(res, 1800));
    const record = createBackup('Manual');
    setIsCreating(false);
    toast.success(`Database snapshot created: ${record.name} (${record.sizeMb} MB)`);
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateBackupSettings(settingsData);
    toast.success('Automated backup schedule settings saved.');
  };

  const handleConfirmRestore = async () => {
    if (!restoringBackup) return;
    setIsRestoring(true);
    toast.info(`Restoring database snapshot: ${restoringBackup.name}...`);
    await new Promise((res) => setTimeout(res, 2200));
    restoreBackup(restoringBackup.id);
    setIsRestoring(false);
    setRestoringBackup(null);
    toast.success('Database state successfully restored to snapshot!');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-white tracking-wide">Enterprise Database Backup & Disaster Recovery</h2>
            <span className="px-2.5 py-0.5 bg-emerald-500/10 text-emerald-400 text-[10px] font-semibold rounded-full border border-emerald-500/20">
              Supabase / PostgreSQL
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Generate point-in-time SQL dump snapshots, configure automated CRON backup schedules, and perform point-of-failure restores.
          </p>
        </div>

        <button
          onClick={handleManualBackup}
          disabled={isCreating}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs transition shadow-md shadow-blue-900/40 cursor-pointer disabled:opacity-50 shrink-0"
        >
          {isCreating ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin" /> Creating Snapshot...
            </>
          ) : (
            <>
              <Database className="w-4 h-4" /> Create Manual Backup Snapshot
            </>
          )}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Backup Schedule Settings */}
        <form onSubmit={handleSaveSettings} className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-md h-fit">
          <h3 className="text-sm font-bold text-white flex items-center gap-2 pb-3 border-b border-slate-800">
            <Clock className="w-4 h-4 text-blue-400" /> Automated Backup Schedule
          </h3>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300">Auto Backup Frequency</label>
            <select
              value={settingsData.schedule}
              onChange={(e) => setSettingsData({ ...settingsData, schedule: e.target.value as any })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-semibold"
            >
              <option value="Daily">Daily (Every Midnight 00:00 SGT)</option>
              <option value="Weekly">Weekly (Every Sunday 02:00 SGT)</option>
              <option value="Monthly">Monthly (1st of Month 03:00 SGT)</option>
              <option value="Disabled">Disabled</option>
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300">Auto Execution Time</label>
            <input
              type="text"
              value={settingsData.executionTime}
              onChange={(e) => setSettingsData({ ...settingsData, executionTime: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-mono"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300">Retain Backup Snapshots Count</label>
            <input
              type="number"
              min={1}
              max={100}
              value={settingsData.retentionSnapshots}
              onChange={(e) => setSettingsData({ ...settingsData, retentionSnapshots: Number(e.target.value) })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-mono"
            />
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold border border-slate-700 flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Save className="w-3.5 h-3.5 text-blue-400" /> Save Schedule
            </button>
          </div>
        </form>

        {/* Backups History List */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-md">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <HardDrive className="w-4 h-4 text-emerald-400" /> Available Database Snapshots ({backups.length})
            </h3>
            <span className="text-[10px] text-slate-400 font-mono">Storage: SQL Dump Format</span>
          </div>

          <div className="space-y-3">
            {backups.map((bk) => (
              <div
                key={bk.id}
                className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:border-slate-700 transition"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-white">{bk.name}</span>
                    <span
                      className={`px-2 py-0.5 text-[9px] font-bold rounded ${
                        bk.type === 'Automatic'
                          ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20'
                          : 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                      }`}
                    >
                      {bk.type}
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400 font-mono">
                    Created: {new Date(bk.createdAt).toLocaleString()} | Size: <span className="text-slate-200 font-bold">{bk.sizeMb} MB</span> | Creator: {bk.createdBy}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <a
                    href={`data:text/plain;charset=utf-8,${encodeURIComponent('-- MOUNTEC PTE LTD POSTGRESQL DUMP\n-- Generated on ' + bk.createdAt)}`}
                    download={bk.name}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 flex items-center gap-1 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5 text-blue-400" /> Download
                  </a>
                  <button
                    onClick={() => setRestoringBackup(bk)}
                    className="px-3 py-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-xs font-semibold border border-rose-500/20 flex items-center gap-1 cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" /> Restore
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* RESTORE CONFIRMATION MODAL */}
      {restoringBackup && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-rose-900/60 rounded-2xl max-w-md w-full p-6 text-slate-200 shadow-2xl space-y-5">
            <div className="flex items-center gap-3 text-rose-400">
              <AlertOctagon className="w-7 h-7 shrink-0" />
              <div>
                <h3 className="text-base font-bold text-white">Restore Database Confirmation</h3>
                <p className="text-xs text-rose-400/90">CRITICAL SYSTEM OVERWRITE</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed bg-rose-950/20 border border-rose-900/40 p-3 rounded-xl">
              You are about to restore snapshot <strong className="text-white font-mono">{restoringBackup.name}</strong>. Current database state will be overwritten with snapshot state from <strong className="text-white">{new Date(restoringBackup.createdAt).toLocaleString()}</strong>.
            </p>

            <div className="pt-3 border-t border-slate-800 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setRestoringBackup(null)}
                disabled={isRestoring}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmRestore}
                disabled={isRestoring}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold flex items-center gap-2 cursor-pointer shadow-md shadow-rose-900/40"
              >
                {isRestoring ? <RefreshCw className="w-4 h-4 animate-spin" /> : 'Confirm Overwrite & Restore'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
