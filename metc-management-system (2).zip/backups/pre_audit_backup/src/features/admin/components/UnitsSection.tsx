import React, { useState } from 'react';
import { Scale, Plus, Edit2, Trash2, X } from 'lucide-react';
import { toast } from 'sonner';
import { useAdmin } from '../hooks/useAdmin';
import { UnitOfMeasure } from '../types';

export const UnitsSection: React.FC = () => {
  const { units, addUnit, updateUnit, deleteUnit } = useAdmin();
  const [isOpen, setIsOpen] = useState(false);
  const [editingUnit, setEditingUnit] = useState<UnitOfMeasure | null>(null);

  const [formData, setFormData] = useState({
    code: '',
    name: '',
    description: '',
    conversionFactor: 1,
    baseUnit: 'PCS',
  });

  const handleOpenAdd = () => {
    setEditingUnit(null);
    setFormData({
      code: '',
      name: '',
      description: '',
      conversionFactor: 1,
      baseUnit: 'PCS',
    });
    setIsOpen(true);
  };

  const handleOpenEdit = (u: UnitOfMeasure) => {
    setEditingUnit(u);
    setFormData({
      code: u.code,
      name: u.name,
      description: u.description || '',
      conversionFactor: u.conversionFactor || 1,
      baseUnit: u.baseUnit || 'PCS',
    });
    setIsOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingUnit) {
      updateUnit(editingUnit.id, formData);
      toast.success(`Unit ${formData.code} updated.`);
    } else {
      addUnit(formData);
      toast.success(`New unit ${formData.code} added.`);
    }
    setIsOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-5">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-white tracking-wide">Units of Measure (UOM) Catalog</h2>
            <span className="px-2.5 py-0.5 bg-blue-500/10 text-blue-400 text-[10px] font-semibold rounded-full border border-blue-500/20">
              Inventory Standards
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Standard unit definitions (PCS, BOX, SET, PAIR, KG, LTR, MTR, ROLL) and custom fractional conversions.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs transition shadow-md shadow-blue-900/40 cursor-pointer shrink-0"
        >
          <Plus className="w-4 h-4" /> Add Custom UOM
        </button>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        {units.map((u) => (
          <div
            key={u.id}
            className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3 hover:border-slate-700 transition flex flex-col justify-between"
          >
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="px-2.5 py-1 bg-blue-600/20 text-blue-400 font-mono font-bold text-xs rounded-lg border border-blue-500/30">
                  {u.code}
                </span>
                <span className="text-[10px] text-slate-500 font-mono">ID: {u.id}</span>
              </div>
              <h3 className="text-sm font-bold text-white pt-1">{u.name}</h3>
              <p className="text-xs text-slate-400 line-clamp-2">{u.description || 'Standard inventory unit.'}</p>
            </div>

            <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
              <span className="text-slate-400 text-[10px]">
                1 {u.code} = {u.conversionFactor} {u.baseUnit}
              </span>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => handleOpenEdit(u)}
                  className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-blue-400 transition cursor-pointer"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => {
                    if (confirm(`Delete unit ${u.code}?`)) {
                      deleteUnit(u.id);
                      toast.error(`Deleted unit ${u.code}`);
                    }
                  }}
                  className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-rose-400 transition cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* MODAL */}
      {isOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 text-slate-200 shadow-2xl space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-white">
                {editingUnit ? 'Edit Unit of Measure' : 'Add Custom UOM'}
              </h3>
              <button onClick={() => setIsOpen(false)} className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">UOM Code (e.g. PAL, BND) *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. PAL"
                  value={formData.code}
                  onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Unit Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Pallet"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Conversion Factor</label>
                <input
                  type="number"
                  min={0.01}
                  step={0.01}
                  value={formData.conversionFactor}
                  onChange={(e) => setFormData({ ...formData, conversionFactor: Number(e.target.value) })}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Base Unit</label>
                <input
                  type="text"
                  value={formData.baseUnit}
                  onChange={(e) => setFormData({ ...formData, baseUnit: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Description</label>
                <textarea
                  rows={2}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold cursor-pointer"
                >
                  Save UOM
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
