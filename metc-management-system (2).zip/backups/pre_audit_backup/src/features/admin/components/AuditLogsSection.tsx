import React, { useState } from 'react';
import { History, ShieldAlert, Search, Filter, Trash2, FileSpreadsheet, FileText, AlertTriangle, CheckCircle2, Info } from 'lucide-react';
import { toast } from 'sonner';
import { useAdmin } from '../hooks/useAdmin';
import { AuditLogSeverity } from '../types';

export const AuditLogsSection: React.FC = () => {
  const { filteredAuditLogs, clearAuditLogs, adminService } = useAdmin();
  const [severityFilter, setSeverityFilter] = useState<string>('All');
  const [search, setSearch] = useState('');

  const logs = filteredAuditLogs.filter((log) => {
    const matchesSev = severityFilter === 'All' || log.severity === severityFilter;
    const matchesSearch =
      log.user.toLowerCase().includes(search.toLowerCase()) ||
      log.email.toLowerCase().includes(search.toLowerCase()) ||
      log.details.toLowerCase().includes(search.toLowerCase()) ||
      log.action.toLowerCase().includes(search.toLowerCase()) ||
      log.module.toLowerCase().includes(search.toLowerCase());
    return matchesSev && matchesSearch;
  });

  const getSeverityBadge = (sev: AuditLogSeverity) => {
    switch (sev) {
      case 'Info':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/20">Info</span>;
      case 'Warning':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20">Warning</span>;
      case 'Critical':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/20">Critical</span>;
      default:
        return null;
    }
  };

  const handleExportPDF = () => {
    const headers = ['Timestamp', 'User', 'Role', 'IP Address', 'Action', 'Module', 'Details', 'Severity'];
    const rows = logs.map((l) => [
      new Date(l.timestamp).toLocaleString(),
      l.user,
      l.userRole,
      l.ipAddress,
      l.action,
      l.module,
      l.details,
      l.severity,
    ]);
    adminService.exportToPDF('MOUNTEC PTE LTD - Enterprise System Audit Logs', headers, rows, 'MOUNTEC_Audit_Logs');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-5">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-white tracking-wide">Enterprise Audit Trail & System Event Logs</h2>
            <span className="px-2.5 py-0.5 bg-blue-500/10 text-blue-400 text-[10px] font-semibold rounded-full border border-blue-500/20">
              Immutable Records
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Real-time activity log tracking authentication events, authorization updates, database snapshots, security policy overrides.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => adminService.exportToCSV(logs, 'MOUNTEC_Audit_Logs')}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" /> CSV
          </button>
          <button
            onClick={() => adminService.exportToExcel(logs, 'MOUNTEC_Audit_Logs')}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-blue-400" /> Excel
          </button>
          <button
            onClick={handleExportPDF}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5 text-rose-400" /> PDF
          </button>
          <button
            onClick={() => {
              if (confirm('Are you sure you want to purge local audit logs?')) {
                clearAuditLogs();
                toast.error('Audit log history purged.');
              }
            }}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-xs font-semibold border border-rose-500/20 transition cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" /> Purge Logs
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div className="md:col-span-2 relative">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-500" />
          <input
            type="text"
            placeholder="Search by user, action, module, details, or IP address..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
          <select
            value={severityFilter}
            onChange={(e) => setSeverityFilter(e.target.value)}
            className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="All">All Severities</option>
            <option value="Info">Info (Standard)</option>
            <option value="Warning">Warning (Changes)</option>
            <option value="Critical">Critical (Security/Restore)</option>
          </select>
        </div>
      </div>

      {/* Audit Logs Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-lg">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/80 text-slate-400 uppercase tracking-wider text-[10px] border-b border-slate-800 font-semibold">
              <tr>
                <th className="py-3.5 px-4">Timestamp</th>
                <th className="py-3.5 px-4">User & Role</th>
                <th className="py-3.5 px-4">Action & Module</th>
                <th className="py-3.5 px-4">Event Details</th>
                <th className="py-3.5 px-4">IP Source</th>
                <th className="py-3.5 px-4 text-center">Severity</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {logs.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-500 font-sans text-xs">
                    No matching audit records recorded.
                  </td>
                </tr>
              ) : (
                logs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3.5 px-4 text-[11px] text-slate-400 whitespace-nowrap">
                      {new Date(log.timestamp).toLocaleString()}
                    </td>

                    <td className="py-3.5 px-4">
                      <p className="font-semibold text-white font-sans text-xs">{log.user}</p>
                      <p className="text-[10px] text-slate-400 font-sans">{log.userRole}</p>
                    </td>

                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <p className="font-semibold text-blue-400 font-sans text-xs">{log.action}</p>
                      <p className="text-[10px] text-slate-400 font-sans">{log.module}</p>
                    </td>

                    <td className="py-3.5 px-4 font-sans text-xs text-slate-300 max-w-xs truncate">
                      {log.details}
                    </td>

                    <td className="py-3.5 px-4 text-[11px] text-slate-400 whitespace-nowrap">
                      {log.ipAddress}
                    </td>

                    <td className="py-3.5 px-4 text-center font-sans">
                      {getSeverityBadge(log.severity)}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
