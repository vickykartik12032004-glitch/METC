import React from 'react';
import { Award, ShieldCheck, CheckCircle2, Building2, Calendar, Users, Key, Zap } from 'lucide-react';
import { useAdmin } from '../hooks/useAdmin';

export const LicenseSection: React.FC = () => {
  const { licenseInfo, companyProfile } = useAdmin();

  const features = [
    'Unlimited User Credentials & Role Assignment',
    'Multi-Branch & Regional Depot Network',
    'Multi-Site Project Management',
    'PostgreSQL / Supabase Database Snapshot Engine',
    'Granular Module-Level Permissions Matrix',
    'Automated Email & Push Alert Workflows',
    'Real-time Infrastructure Telemetry',
    'Immutable Audit Logs & Export (PDF/Excel/CSV)'
  ];

  return (
    <div className="space-y-6 max-w-4xl">
      {/* License Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 border border-blue-900/60 rounded-2xl p-6 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0 font-bold shadow-inner">
            <Award className="w-8 h-8" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-white tracking-wide">{licenseInfo.licenseType}</h2>
              <span className="px-2.5 py-0.5 text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-full flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> VERIFIED LICENSED
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-1">
              Registered Owner: <strong className="text-white">{licenseInfo.companyName}</strong> ({companyProfile.uenGstNumber})
            </p>
            <p className="text-[11px] text-slate-400 font-mono mt-0.5">License Key: {licenseInfo.licenseKey}</p>
          </div>
        </div>
      </div>

      {/* Details Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-2">
          <div className="flex items-center gap-2 text-slate-400 text-xs font-semibold">
            <Calendar className="w-4 h-4 text-blue-400" /> Expiry & Renewal
          </div>
          <p className="text-base font-bold text-white font-mono">{licenseInfo.expiryDate}</p>
          <p className="text-[11px] text-slate-400">Support Tier: {licenseInfo.supportTier}</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-2">
          <div className="flex items-center gap-2 text-slate-400 text-xs font-semibold">
            <Users className="w-4 h-4 text-emerald-400" /> User Allocation
          </div>
          <p className="text-base font-bold text-white font-mono">{String(licenseInfo.maxUsers)}</p>
          <p className="text-[11px] text-slate-400">Unlimited admin and worker accounts.</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-2">
          <div className="flex items-center gap-2 text-slate-400 text-xs font-semibold">
            <Building2 className="w-4 h-4 text-purple-400" /> Multi-Branch & Site
          </div>
          <p className="text-base font-bold text-white font-mono">{String(licenseInfo.maxBranches)}</p>
          <p className="text-[11px] text-slate-400">Unlimited sites and logistics depots.</p>
        </div>
      </div>

      {/* Features Included List */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4 shadow-md">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2 pb-3 border-b border-slate-800">
          <Zap className="w-4 h-4 text-amber-400" /> Licensed Enterprise System Modules
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          {features.map((feat, idx) => (
            <div key={idx} className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-950/60 border border-slate-800">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span className="font-semibold text-slate-200">{feat}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
