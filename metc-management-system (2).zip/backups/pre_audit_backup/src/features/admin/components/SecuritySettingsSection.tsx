import React, { useState } from 'react';
import { ShieldCheck, Lock, Clock, AlertTriangle, KeyRound, Save, Eye, EyeOff } from 'lucide-react';
import { toast } from 'sonner';
import { useAdmin } from '../hooks/useAdmin';

export const SecuritySettingsSection: React.FC = () => {
  const { securitySettings, updateSecuritySettings } = useAdmin();
  const [formData, setFormData] = useState(securitySettings);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateSecuritySettings(formData);
    toast.success('Security governance policies updated successfully.');
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-white tracking-wide">Enterprise Security & Compliance Governance</h2>
            <span className="px-2.5 py-0.5 bg-rose-500/10 text-rose-400 text-[10px] font-semibold rounded-full border border-rose-500/20">
              High Severity
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Enforce password complexity rules, session expiration timeouts, 2FA MFA mandates, and brute-force account lockout limits.
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-slate-200 space-y-6 shadow-md">
        {/* Password Policy Sub-card */}
        <div className="space-y-4 pb-6 border-b border-slate-800">
          <h3 className="text-xs font-bold text-blue-400 uppercase tracking-wider flex items-center gap-2">
            <KeyRound className="w-4 h-4" /> Password Complexity Rules
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Min Length */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-slate-300">Minimum Password Length</label>
                <span className="text-xs font-bold font-mono text-blue-400">{formData.passwordMinLength} Characters</span>
              </div>
              <input
                type="range"
                min={8}
                max={24}
                step={1}
                value={formData.passwordMinLength}
                onChange={(e) => setFormData({ ...formData, passwordMinLength: Number(e.target.value) })}
                className="w-full accent-blue-500 cursor-pointer"
              />
            </div>

            {/* Password Expiration Days */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">Password Expiration Cycle (Days)</label>
              <select
                value={formData.passwordExpiryDays}
                onChange={(e) => setFormData({ ...formData, passwordExpiryDays: Number(e.target.value) })}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-mono"
              >
                <option value={30}>Every 30 Days (Strict ISO 27001)</option>
                <option value={60}>Every 60 Days</option>
                <option value={90}>Every 90 Days (Recommended Standard)</option>
                <option value={180}>Every 180 Days</option>
                <option value={0}>Never Expire (Not Recommended)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
            {[
              { key: 'requireNumbers', label: 'Require Numbers (0-9)' },
              { key: 'requireSymbols', label: 'Require Symbols (!@#$%^&*)' },
              { key: 'requireUppercase', label: 'Require Capital Letters (A-Z)' },
            ].map((rule) => {
              const val = Boolean(formData[rule.key as keyof typeof formData]);
              return (
                <label
                  key={rule.key}
                  className={`p-3 rounded-xl border flex items-center gap-2 text-xs font-semibold cursor-pointer transition ${
                    val ? 'bg-blue-950/40 border-blue-500/50 text-white' : 'bg-slate-800/60 border-slate-700/80 text-slate-400'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={val}
                    onChange={(e) => setFormData({ ...formData, [rule.key]: e.target.checked })}
                    className="accent-blue-500 rounded cursor-pointer"
                  />
                  {rule.label}
                </label>
              );
            })}
          </div>
        </div>

        {/* Session & Authentication Lockouts */}
        <div className="space-y-4">
          <h3 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-2">
            <Clock className="w-4 h-4" /> Session Timeout & Account Protection
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Session Timeout */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">Inactivity Idle Session Timeout</label>
              <select
                value={formData.sessionTimeoutMinutes}
                onChange={(e) => setFormData({ ...formData, sessionTimeoutMinutes: Number(e.target.value) })}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-mono"
              >
                <option value={15}>15 Minutes Idle (High Security)</option>
                <option value={30}>30 Minutes Idle (Standard Enterprise)</option>
                <option value={60}>60 Minutes Idle</option>
                <option value={120}>2 Hours Idle</option>
              </select>
            </div>

            {/* Max Failed Attempts */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">Lockout Trigger Limit (Failed Logins)</label>
              <select
                value={formData.maxFailedLoginAttempts}
                onChange={(e) => setFormData({ ...formData, maxFailedLoginAttempts: Number(e.target.value) })}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-mono"
              >
                <option value={3}>3 Failed Attempts (Strict)</option>
                <option value={5}>5 Failed Attempts (Standard)</option>
                <option value={10}>10 Failed Attempts</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
            <label
              className={`p-3.5 rounded-xl border flex items-center justify-between text-xs font-semibold cursor-pointer transition ${
                formData.enableTwoFactorAuth ? 'bg-emerald-950/30 border-emerald-500/50 text-white' : 'bg-slate-800/60 border-slate-700 text-slate-400'
              }`}
            >
              <div>
                <p className="text-xs font-bold">Mandate 2FA Multi-Factor Authentication</p>
                <p className="text-[10px] text-slate-400 mt-0.5">Force TOTP authenticator apps for all Super Admin & Staff roles.</p>
              </div>
              <input
                type="checkbox"
                checked={formData.enableTwoFactorAuth}
                onChange={(e) => setFormData({ ...formData, enableTwoFactorAuth: e.target.checked })}
                className="accent-emerald-500 w-4 h-4 cursor-pointer"
              />
            </label>

            <label
              className={`p-3.5 rounded-xl border flex items-center justify-between text-xs font-semibold cursor-pointer transition ${
                formData.enableIpWhitelist ? 'bg-purple-950/30 border-purple-500/50 text-white' : 'bg-slate-800/60 border-slate-700 text-slate-400'
              }`}
            >
              <div>
                <p className="text-xs font-bold">Enable IP Address Audit Whitelisting</p>
                <p className="text-[10px] text-slate-400 mt-0.5">Record and log all client source IP addresses on API calls.</p>
              </div>
              <input
                type="checkbox"
                checked={formData.enableIpWhitelist}
                onChange={(e) => setFormData({ ...formData, enableIpWhitelist: e.target.checked })}
                className="accent-purple-500 w-4 h-4 cursor-pointer"
              />
            </label>
          </div>
        </div>

        <div className="pt-4 border-t border-slate-800 flex justify-end">
          <button
            type="submit"
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs transition shadow-md shadow-blue-900/30 cursor-pointer"
          >
            <Save className="w-4 h-4" /> Save Security Policies
          </button>
        </div>
      </form>
    </div>
  );
};
