import React, { useState, useEffect } from 'react';
import { useAuth } from '../../../hooks/useAuth';
import { toast } from 'sonner';
import { ShieldCheck, UserX, Clock, CheckCircle, XCircle } from 'lucide-react';

export const AccessRequestsSection = () => {
  const [requests, setRequests] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const { session } = useAuth();

  const fetchRequests = async () => {
    try {
      const res = await fetch('/api/admin/access-requests', {
        headers: {
          'Authorization': `Bearer ${session?.token}`
        }
      });
      const data = await res.json();
      if (data.success) {
        setRequests(data.data || []);
      }
    } catch (err) {
      console.error(err);
      toast.error('Failed to load access requests');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (session?.token) {
      fetchRequests();
    }
  }, [session]);

  const handleUpdateStatus = async (id: string, status: string) => {
    try {
      const res = await fetch(`/api/admin/access-requests/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session?.token}`
        },
        body: JSON.stringify({ status })
      });
      
      const data = await res.json();
      if (data.success) {
        toast.success(`Request ${status.toLowerCase()} successfully`);
        fetchRequests();
      } else {
        toast.error(data.error || 'Failed to update request');
      }
    } catch (err) {
      toast.error('Network error');
    }
  };

  if (loading) return <div className="text-slate-400 p-8 text-center animate-pulse">Loading Access Requests...</div>;

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-white">Access Requests</h2>
        <span className="bg-blue-600/20 text-blue-400 px-3 py-1 rounded-full text-xs font-semibold">
          {requests.filter(r => r.status === 'PENDING').length} Pending
        </span>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
        {requests.length === 0 ? (
          <div className="p-12 text-center text-slate-500">No access requests found.</div>
        ) : (
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-800/50 text-slate-400">
              <tr>
                <th className="px-6 py-4 font-medium">User</th>
                <th className="px-6 py-4 font-medium">Role Requested</th>
                <th className="px-6 py-4 font-medium">Requested At</th>
                <th className="px-6 py-4 font-medium">Status</th>
                <th className="px-6 py-4 text-right font-medium">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {requests.map((req) => (
                <tr key={req.id} className="hover:bg-slate-800/25 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <img src={req.avatar || 'https://via.placeholder.com/40'} alt="" className="w-10 h-10 rounded-full bg-slate-800" />
                      <div>
                        <div className="text-white font-medium">{req.googleName || 'Unknown User'}</div>
                        <div className="text-slate-400 text-xs">{req.googleEmail}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-slate-300 bg-slate-800 px-2.5 py-1 rounded-md text-xs font-medium">
                      {req.assignedRole || 'Worker'}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-slate-400">
                    {new Date(req.requestedAt).toLocaleString()}
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${
                      req.status === 'APPROVED' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                      req.status === 'REJECTED' ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' :
                      req.status === 'REVOKED' ? 'bg-slate-500/10 text-slate-400 border border-slate-500/20' :
                      'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                    }`}>
                      {req.status === 'APPROVED' && <CheckCircle className="w-3.5 h-3.5" />}
                      {req.status === 'REJECTED' && <XCircle className="w-3.5 h-3.5" />}
                      {req.status === 'REVOKED' && <UserX className="w-3.5 h-3.5" />}
                      {req.status === 'PENDING' && <Clock className="w-3.5 h-3.5" />}
                      {req.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex justify-end gap-2">
                      {req.status !== 'APPROVED' && (
                        <button
                          onClick={() => handleUpdateStatus(req.id, 'APPROVED')}
                          className="p-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 rounded-lg transition-colors cursor-pointer"
                          title="Approve"
                        >
                          <ShieldCheck className="w-4 h-4" />
                        </button>
                      )}
                      {(req.status === 'PENDING' || req.status === 'APPROVED') && (
                        <button
                          onClick={() => handleUpdateStatus(req.id, 'REJECTED')}
                          className="p-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 rounded-lg transition-colors cursor-pointer"
                          title="Reject"
                        >
                          <UserX className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};
