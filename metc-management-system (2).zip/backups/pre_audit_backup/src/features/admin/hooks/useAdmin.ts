import { useMemo } from 'react';
import { useAdminStore } from '../../../store/useAdminStore';
import { adminService } from '../services/admin.service';

export const useAdmin = () => {
  const store = useAdminStore();

  // Filtered users considering soft delete & global search
  const activeUsers = useMemo(() => {
    let list = store.users.filter((u) => !u.isSoftDeleted);
    if (store.globalSearchQuery.trim()) {
      const q = store.globalSearchQuery.toLowerCase();
      list = list.filter(
        (u) =>
          u.fullName.toLowerCase().includes(q) ||
          u.email.toLowerCase().includes(q) ||
          u.employeeNumber.toLowerCase().includes(q) ||
          u.department.toLowerCase().includes(q) ||
          u.role.toLowerCase().includes(q)
      );
    }
    return list;
  }, [store.users, store.globalSearchQuery]);

  // Filtered branches
  const filteredBranches = useMemo(() => {
    let list = store.branches;
    if (store.globalSearchQuery.trim()) {
      const q = store.globalSearchQuery.toLowerCase();
      list = list.filter(
        (b) =>
          b.name.toLowerCase().includes(q) ||
          b.code.toLowerCase().includes(q) ||
          b.manager.toLowerCase().includes(q) ||
          b.address.toLowerCase().includes(q)
      );
    }
    return list;
  }, [store.branches, store.globalSearchQuery]);

  // Filtered sites
  const filteredSites = useMemo(() => {
    let list = store.sites;
    if (store.globalSearchQuery.trim()) {
      const q = store.globalSearchQuery.toLowerCase();
      list = list.filter(
        (s) =>
          s.siteName.toLowerCase().includes(q) ||
          s.siteCode.toLowerCase().includes(q) ||
          s.projectName.toLowerCase().includes(q) ||
          s.manager.toLowerCase().includes(q)
      );
    }
    return list;
  }, [store.sites, store.globalSearchQuery]);

  // Filtered suppliers
  const filteredSuppliers = useMemo(() => {
    let list = store.suppliers;
    if (store.globalSearchQuery.trim()) {
      const q = store.globalSearchQuery.toLowerCase();
      list = list.filter(
        (sup) =>
          sup.name.toLowerCase().includes(q) ||
          sup.code.toLowerCase().includes(q) ||
          sup.contactPerson.toLowerCase().includes(q)
      );
    }
    return list;
  }, [store.suppliers, store.globalSearchQuery]);

  // Filtered audit logs
  const filteredAuditLogs = useMemo(() => {
    let list = store.auditLogs;
    if (store.globalSearchQuery.trim()) {
      const q = store.globalSearchQuery.toLowerCase();
      list = list.filter(
        (a) =>
          a.user.toLowerCase().includes(q) ||
          a.action.toLowerCase().includes(q) ||
          a.module.toLowerCase().includes(q) ||
          a.details.toLowerCase().includes(q) ||
          a.ipAddress.toLowerCase().includes(q)
      );
    }
    return list;
  }, [store.auditLogs, store.globalSearchQuery]);

  return {
    ...store,
    activeUsers,
    filteredBranches,
    filteredSites,
    filteredSuppliers,
    filteredAuditLogs,
    adminService,
  };
};

export default useAdmin;
