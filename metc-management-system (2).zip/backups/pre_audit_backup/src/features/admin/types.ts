export type SystemRole = 'Super Admin' | 'Admin' | 'Supervisor' | 'Worker' | 'Store Keeper' | 'Site Supervisor' | 'Viewer' | string;

export type UserStatus = 'Active' | 'Inactive' | 'Locked' | 'Deactivated';

export type AdminModule =
  | 'Dashboard'
  | 'Materials'
  | 'Equipment'
  | 'Tools'
  | 'Consumables'
  | 'PPE'
  | 'Workers'
  | 'Issue'
  | 'Return'
  | 'Transfer'
  | 'Repair'
  | 'Lost Items'
  | 'Reports'
  | 'Notifications'
  | 'Settings'
  | 'Administration';

export interface ModulePermissions {
  view: boolean;
  create: boolean;
  update: boolean;
  delete: boolean;
  approve: boolean;
  export: boolean;
  import: boolean;
}

export interface CompanyProfile {
  companyName: string;
  logoUrl?: string;
  address: string;
  phone: string;
  email: string;
  website: string;
  uenGstNumber: string;
  currency: string;
  timezone: string;
  language: string;
  businessHours: string;
}

export interface AdminUser {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  employeeNumber: string;
  department: string;
  branch: string;
  site: string;
  assignedSites?: string[];
  allSitesAccess?: boolean;
  role: SystemRole;
  status: UserStatus;
  photo?: string;
  tempPassword?: string;
  password?: string;
  isSoftDeleted?: boolean;
  failedLoginAttempts?: number;
  lastLogin?: string;
  createdAt: string;
}

export interface AdminRole {
  id: string;
  name: string;
  description: string;
  isCustom: boolean;
  permissions: Record<AdminModule, ModulePermissions>;
  userCount?: number;
  createdAt: string;
}

export interface Department {
  id: string;
  name: string;
  code: string;
  headOfDepartment: string;
  description?: string;
  userCount: number;
  status: 'Active' | 'Inactive';
  createdAt: string;
}

export interface Branch {
  id: string;
  name: string;
  code: string;
  address: string;
  manager: string;
  phone: string;
  email: string;
  status: 'Active' | 'Inactive';
  workerCount: number;
  createdAt: string;
}

export interface ProjectSite {
  id: string;
  siteName: string;
  siteCode: string;
  projectName: string;
  projectCode?: string;
  rawMasterCode?: string;
  series?: 'M' | 'Q';
  address: string;
  manager: string;
  phone: string;
  status: 'Active' | 'Inactive' | 'Completed' | 'On Hold' | 'Archived';
  workerCount: number;
  isDuplicateId?: boolean;
  duplicateNotes?: string;
  assignedUsers?: string[];
  assignedSupervisors?: string[];
  assignedWorkers?: string[];
  assignedAdmins?: string[];
  isArchived?: boolean;
  remarks?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface SupplierDocument {
  id: string;
  name: string;
  url: string;
  type: string;
  uploadedAt: string;
}

export interface Supplier {
  id: string;
  name: string;
  code: string;
  contactPerson: string;
  phone: string;
  email: string;
  address: string;
  rating: number; // 1 to 5
  performanceScore: number; // 0 to 100
  documents: SupplierDocument[];
  status: 'Active' | 'Inactive';
  createdAt: string;
}

export interface UnitOfMeasure {
  id: string;
  code: string; // PCS, BOX, SET, PAIR, KG, LTR, MTR, ROLL, custom
  name: string;
  symbol: string;
  category: 'Quantity' | 'Weight' | 'Volume' | 'Length' | 'Packaging' | 'Custom';
  description?: string;
  conversionFactor?: number;
  baseUnit?: string;
  status: 'Active' | 'Inactive';
  createdAt: string;
}

export interface EmailSettings {
  smtpServer: string;
  smtpPort: number;
  encryption: 'SSL/TLS' | 'STARTTLS' | 'None';
  smtpUsername: string;
  smtpPassword?: string;
  senderName: string;
  senderEmail: string;
  testEmailStatus?: 'idle' | 'testing' | 'success' | 'failed';
  lastTestedAt?: string;
}

export interface ApplicationSettings {
  theme: 'Dark' | 'Light' | 'System';
  dateFormat: 'DD/MM/YYYY' | 'MM/DD/YYYY' | 'YYYY-MM-DD';
  timeFormat: '12-hour' | '24-hour';
  currency: 'SGD (S$)' | 'USD ($)' | 'EUR (€)' | 'MYR (RM)';
  language: 'English' | 'Mandarin' | 'Malay' | 'Tamil';
  defaultDashboard: 'Executive Summary' | 'Operational' | 'Warehouse' | 'Site View';
}

export interface SecuritySettings {
  minPasswordLength: number;
  requireUppercase: boolean;
  requireNumbers: boolean;
  requireSpecialChars: boolean;
  sessionTimeoutMinutes: number;
  autoLogout: boolean;
  enable2FA: boolean;
  loginAttemptLimit: number;
  ipLoggingEnabled: boolean;
  allowedIPs: string[];
}

export type AuditLogSeverity = 'Info' | 'Warning' | 'Critical';

export interface AuthorizedUser {
  id: string;
  fullName: string;
  googleEmail: string;
  role: SystemRole;
  department: string;
  site: string;
  branch: string;
  assignedSites?: string[];
  allSitesAccess?: boolean;
  status: 'Active' | 'Inactive';
  createdAt: string;
  updatedAt: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  user: string;
  email: string;
  userRole: string;
  ipAddress: string;
  action:
    | 'Login'
    | 'Logout'
    | 'Failed Login'
    | 'Account Registration'
    | 'Google SSO Login'
    | 'Unauthorized Login Attempt'
    | 'Create'
    | 'Edit'
    | 'Delete'
    | 'Issue'
    | 'Return'
    | 'Transfer'
    | 'Repair'
    | 'Lost'
    | 'Settings Changes'
    | 'User Changes'
    | 'Role Changes'
    | 'Security Changes';
  module: string;
  details: string;
  severity: AuditLogSeverity;
}

export interface BackupRecord {
  id: string;
  name: string;
  type: 'Manual' | 'Automatic';
  schedule?: 'Daily' | 'Weekly' | 'Monthly';
  sizeMb: number;
  createdAt: string;
  createdBy: string;
  status: 'Completed' | 'In Progress' | 'Failed';
  downloadUrl?: string;
}

export interface BackupSettings {
  autoBackupEnabled: boolean;
  schedule: 'Daily' | 'Weekly' | 'Monthly';
  retentionDays: number;
  cloudSync: boolean;
}

export interface SystemHealth {
  dbStatus: 'Optimal' | 'Degraded' | 'Offline';
  dbPingMs: number;
  storageUsedGb: number;
  storageTotalGb: number;
  userCount: number;
  assetCount: number;
  apiResponseTimeMs: number;
  memoryUsageMb: number;
  cpuLoadPercent: number;
  uptimePercent: number;
  lastCheckedAt: string;
}

export interface LicenseInfo {
  companyName: string;
  licenseType: 'Enterprise Platinum Edition';
  expiryDate: string;
  applicationVersion: string;
  maxSites: number | 'Unlimited';
  maxBranches: number | 'Unlimited';
  maxUsers: number | 'Unlimited';
  supportTier: string;
  registeredTo: string;
  issuedDate: string;
  licenseKey: string;
}

export type AdminTab =
  | 'company'
  | 'access-requests'
  | 'users'
  | 'roles'
  | 'departments'
  | 'branches'
  | 'sites'
  | 'suppliers'
  | 'units'
  | 'email'
  | 'app'
  | 'app_settings'
  | 'security'
  | 'audit'
  | 'backup'
  | 'health'
  | 'license';
