import React from 'react';
import {
  Building2,
  Users,
  Shield,
  Building,
  MapPin,
  HardHat,
  Truck,
  Scale,
  Mail,
  Sliders,
  Lock,
  Database,
  History,
  Activity,
  Award,
  Search
} from 'lucide-react';
import { useAdmin } from './hooks/useAdmin';
import { AdminTab } from './types';
import { CompanyProfileSection } from './components/CompanyProfileSection';
import { AccessRequestsSection } from './components/AccessRequestsSection';
import { UserManagementSection } from './components/UserManagementSection';
import { RoleManagementSection } from './components/RoleManagementSection';
import { DepartmentsSection } from './components/DepartmentsSection';
import { BranchesSection } from './components/BranchesSection';
import { SitesSection } from './components/SitesSection';
import { SuppliersSection } from './components/SuppliersSection';
import { UnitsSection } from './components/UnitsSection';
import { EmailSettingsSection } from './components/EmailSettingsSection';
import { ApplicationSettingsSection } from './components/ApplicationSettingsSection';
import { SecuritySettingsSection } from './components/SecuritySettingsSection';
import { AuditLogsSection } from './components/AuditLogsSection';
import { BackupRestoreSection } from './components/BackupRestoreSection';
import { SystemHealthSection } from './components/SystemHealthSection';
import { LicenseSection } from './components/LicenseSection';

interface NavGroup {
  groupLabel: string;
  items: { tab: AdminTab; label: string; icon: React.ElementType }[];
}

const NAV_GROUPS: NavGroup[] = [
  {
    groupLabel: 'ORGANIZATION',
    items: [
      { tab: 'company', label: 'Company Profile', icon: Building2 },
      { tab: 'access-requests', label: 'Access Requests', icon: Shield },
      { tab: 'users', label: 'Users', icon: Users },
      { tab: 'roles', label: 'Roles & Permissions', icon: Shield },
      { tab: 'departments', label: 'Departments', icon: Building },
      { tab: 'branches', label: 'Branches', icon: MapPin },
      { tab: 'sites', label: 'Sites', icon: HardHat },
    ],
  },
  {
    groupLabel: 'CATALOGS',
    items: [
      { tab: 'suppliers', label: 'Suppliers', icon: Truck },
      { tab: 'units', label: 'Units of Measure', icon: Scale },
    ],
  },
  {
    groupLabel: 'SYSTEM CONFIG',
    items: [
      { tab: 'email', label: 'Email Settings', icon: Mail },
      { tab: 'app', label: 'Application Settings', icon: Sliders },
      { tab: 'security', label: 'Security', icon: Lock },
    ],
  },
  {
    groupLabel: 'MAINTENANCE & GOVERNANCE',
    items: [
      { tab: 'backup', label: 'Backup & Restore', icon: Database },
      { tab: 'audit', label: 'Audit Logs', icon: History },
      { tab: 'health', label: 'System Health', icon: Activity },
      { tab: 'license', label: 'License', icon: Award },
    ],
  },
];

export const AdminModuleView: React.FC = () => {
  const { activeTab, setActiveTab, globalSearchQuery, setGlobalSearchQuery } = useAdmin();

  const renderActiveSection = () => {
    switch (activeTab) {
      case 'company':
        return <CompanyProfileSection />;
      case 'access-requests':
        return <AccessRequestsSection />;
      case 'users':
        return <UserManagementSection />;
      case 'roles':
        return <RoleManagementSection />;
      case 'departments':
        return <DepartmentsSection />;
      case 'branches':
        return <BranchesSection />;
      case 'sites':
        return <SitesSection />;
      case 'suppliers':
        return <SuppliersSection />;
      case 'units':
        return <UnitsSection />;
      case 'email':
        return <EmailSettingsSection />;
      case 'app':
        return <ApplicationSettingsSection />;
      case 'security':
        return <SecuritySettingsSection />;
      case 'backup':
        return <BackupRestoreSection />;
      case 'audit':
        return <AuditLogsSection />;
      case 'health':
        return <SystemHealthSection />;
      case 'license':
        return <LicenseSection />;
      default:
        return <CompanyProfileSection />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-4 lg:p-6 space-y-6">
      {/* Top Banner Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-xl lg:text-2xl font-bold text-white tracking-tight">System Administration</h1>
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-blue-600/20 text-blue-400 border border-blue-500/30 font-mono">
              MOUNTEC PTE LTD
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Enterprise Administration Panel similar to SAP, Oracle Enterprise Manager & Microsoft Dynamics Admin Center.
          </p>
        </div>

        {/* Global Admin Search Bar */}
        <div className="relative w-full lg:w-80">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-500" />
          <input
            type="text"
            placeholder="Search users, branches, logs, suppliers..."
            value={globalSearchQuery}
            onChange={(e) => setGlobalSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      {/* Main Admin Layout (Sidebar Nav + Section View) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Navigation Tabs Bar */}
        <div className="lg:col-span-3 bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-5 shadow-lg shrink-0">
          {NAV_GROUPS.map((group, gIdx) => (
            <div key={gIdx} className="space-y-1">
              <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider px-3 mb-1">
                {group.groupLabel}
              </p>
              <div className="space-y-0.5">
                {group.items.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.tab;
                  return (
                    <button
                      key={item.tab}
                      onClick={() => setActiveTab(item.tab)}
                      className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
                        isActive
                          ? 'bg-blue-600 text-white shadow-md shadow-blue-900/40 font-bold'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                      }`}
                    >
                      <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-500'}`} />
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* Content View Container */}
        <div className="lg:col-span-9 min-h-[600px]">
          {renderActiveSection()}
        </div>
      </div>
    </div>
  );
};

export default AdminModuleView;
