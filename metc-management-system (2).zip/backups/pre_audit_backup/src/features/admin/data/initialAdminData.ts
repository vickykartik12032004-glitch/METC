import {
  CompanyProfile,
  AdminUser,
  AuthorizedUser,
  AdminRole,
  Department,
  Branch,
  ProjectSite,
  Supplier,
  UnitOfMeasure,
  EmailSettings,
  ApplicationSettings,
  SecuritySettings,
  AuditLog,
  BackupRecord,
  BackupSettings,
  SystemHealth,
  LicenseInfo,
  ModulePermissions,
  AdminModule
} from '../types';
import { INITIAL_PROJECT_MASTER_LIST } from '../../../data/projectMasterData';

export const INITIAL_COMPANY_PROFILE: CompanyProfile = {
  companyName: 'MOUNTEC PTE LTD',
  logoUrl: 'https://images.unsplash.com/photo-1541888946425-d0fbb186a5b7?auto=format&fit=crop&q=80&w=200',
  address: '10 Anson Road, #25-08 International Plaza, Singapore 079903',
  phone: '+65 6789 1234',
  email: 'info@mountec.sg',
  website: 'https://www.mountec.sg',
  uenGstNumber: '201812345M / GST-REG-2018',
  currency: 'SGD (S$)',
  timezone: 'Asia/Singapore (GMT+8)',
  language: 'English',
  businessHours: 'Mon - Fri: 08:00 - 18:00, Sat: 08:00 - 13:00',
};

const fullPerms: ModulePermissions = {
  view: true,
  create: true,
  update: true,
  delete: true,
  approve: true,
  export: true,
  import: true,
};

const adminPerms: ModulePermissions = {
  view: true,
  create: true,
  update: true,
  delete: true,
  approve: true,
  export: true,
  import: true,
};

const supervisorPerms: ModulePermissions = {
  view: true,
  create: false,
  update: false,
  delete: false,
  approve: true,
  export: true,
  import: false,
};

const viewOnlyPerms: ModulePermissions = {
  view: true,
  create: false,
  update: false,
  delete: false,
  approve: false,
  export: true,
  import: false,
};

const workerPerms: ModulePermissions = {
  view: true,
  create: true,
  update: false,
  delete: false,
  approve: false,
  export: false,
  import: false,
};

const noAccessPerms: ModulePermissions = {
  view: false,
  create: false,
  update: false,
  delete: false,
  approve: false,
  export: false,
  import: false,
};

const defaultModules: AdminModule[] = [
  'Dashboard',
  'Materials',
  'Equipment',
  'Tools',
  'Consumables',
  'PPE',
  'Workers',
  'Issue',
  'Return',
  'Transfer',
  'Repair',
  'Lost Items',
  'Reports',
  'Notifications',
  'Settings',
  'Administration'
];

export const createFullMatrix = (): Record<AdminModule, ModulePermissions> => {
  const record = {} as Record<AdminModule, ModulePermissions>;
  defaultModules.forEach((mod) => {
    record[mod] = { ...fullPerms };
  });
  return record;
};

export const createAdminMatrix = (): Record<AdminModule, ModulePermissions> => {
  const record = {} as Record<AdminModule, ModulePermissions>;
  defaultModules.forEach((mod) => {
    if (mod === 'Administration') {
      record[mod] = { ...adminPerms, delete: false };
    } else {
      record[mod] = { ...adminPerms };
    }
  });
  return record;
};

export const createSupervisorMatrix = (): Record<AdminModule, ModulePermissions> => {
  const record = {} as Record<AdminModule, ModulePermissions>;
  defaultModules.forEach((mod) => {
    if (['Settings', 'Administration'].includes(mod)) {
      record[mod] = { ...noAccessPerms };
    } else {
      record[mod] = { ...supervisorPerms };
    }
  });
  return record;
};

export const createWorkerMatrix = (): Record<AdminModule, ModulePermissions> => {
  const record = {} as Record<AdminModule, ModulePermissions>;
  defaultModules.forEach((mod) => {
    if (['Dashboard', 'Notifications'].includes(mod)) {
      record[mod] = { ...viewOnlyPerms };
    } else if (['Materials', 'Equipment', 'Tools', 'Consumables', 'PPE'].includes(mod)) {
      record[mod] = { ...viewOnlyPerms, export: false };
    } else if (['Issue', 'Return'].includes(mod)) {
      record[mod] = { ...workerPerms };
    } else {
      record[mod] = { ...noAccessPerms };
    }
  });
  return record;
};

export const createViewerMatrix = (): Record<AdminModule, ModulePermissions> => {
  const record = {} as Record<AdminModule, ModulePermissions>;
  defaultModules.forEach((mod) => {
    if (['Settings', 'Administration'].includes(mod)) {
      record[mod] = { ...noAccessPerms };
    } else {
      record[mod] = { ...viewOnlyPerms };
    }
  });
  return record;
};

export const INITIAL_ROLES: AdminRole[] = [
  {
    id: 'role-superadmin',
    name: 'Super Admin',
    description: 'Highest-level authority with complete unmitigated governance, role & permission control, all-site access, and system administration. Permanent and immutable.',
    isCustom: false,
    permissions: createFullMatrix(),
    userCount: 2,
    createdAt: '2025-01-01T00:00:00Z',
  },
  {
    id: 'role-admin',
    name: 'Admin',
    description: 'Administrative operational authority with management access across inventory, transactions, reports, worker directories, and project sites.',
    isCustom: false,
    permissions: createAdminMatrix(),
    userCount: 3,
    createdAt: '2025-01-01T00:00:00Z',
  },
  {
    id: 'role-supervisor',
    name: 'Supervisor',
    description: 'On-site supervisory operations, tool issues, material verifications, transfer requests, and team approvals for assigned project sites. View-only access to master data.',
    isCustom: false,
    permissions: createSupervisorMatrix(),
    userCount: 8,
    createdAt: '2025-01-01T00:00:00Z',
  },
  {
    id: 'role-worker',
    name: 'Worker',
    description: 'Field operative with self-service request capabilities, personal equipment inspection, and site inventory visibility. View-only access.',
    isCustom: false,
    permissions: createWorkerMatrix(),
    userCount: 25,
    createdAt: '2025-01-01T00:00:00Z',
  },
  {
    id: 'role-viewer',
    name: 'Viewer',
    description: 'Strict Read-Only Viewer. Can view and search inventory assets, materials, tools, equipment, consumables, PPE, and worker directories. No editing privileges.',
    isCustom: false,
    permissions: createViewerMatrix(),
    userCount: 5,
    createdAt: '2025-01-01T00:00:00Z',
  }
];

export const INITIAL_DEPARTMENTS: Department[] = [
  { id: 'dept-01', name: 'Management & IT', code: 'MIT', headOfDepartment: 'Super Admin', description: 'Executive oversight & IT systems governance', userCount: 3, status: 'Active', createdAt: '2025-01-01T00:00:00Z' },
  { id: 'dept-02', name: 'Store & Inventory Logistics', code: 'SIL', headOfDepartment: 'Marcus Vance', description: 'Central stores, warehouse & METC asset tracking', userCount: 12, status: 'Active', createdAt: '2025-01-01T00:00:00Z' },
  { id: 'dept-03', name: 'Site Operations', code: 'OPS', headOfDepartment: 'Elena Rostova', description: 'Field construction, project sites & machinery execution', userCount: 28, status: 'Active', createdAt: '2025-01-01T00:00:00Z' },
  { id: 'dept-04', name: 'Safety & Quality Assurance', code: 'SQA', headOfDepartment: 'David Tan', description: 'HSE compliance, PPE inspections & ISO audit standards', userCount: 6, status: 'Active', createdAt: '2025-01-01T00:00:00Z' }
];

export const INITIAL_BRANCHES: Branch[] = [
  { id: 'br-01', name: 'Main HQ International Plaza', code: 'BR-HQ', address: '10 Anson Road, Singapore 079903', manager: 'Director Tan', phone: '+65 6789 1234', email: 'hq@mountec.sg', status: 'Active', workerCount: 15, createdAt: '2025-01-01T00:00:00Z' },
  { id: 'br-02', name: 'Tuas Western Logistics Hub', code: 'BR-TUAS', address: '28 Tuas South Ave 8, Singapore 637800', manager: 'Marcus Vance', phone: '+65 6789 5678', email: 'tuas.store@mountec.sg', status: 'Active', workerCount: 35, createdAt: '2025-01-01T00:00:00Z' }
];

export const INITIAL_SITES: ProjectSite[] = INITIAL_PROJECT_MASTER_LIST;

export const INITIAL_SUPPLIERS: Supplier[] = [
  { id: 'sup-01', name: 'Hilti Singapore Pte Ltd', code: 'SUP-HILTI', contactPerson: 'Michael Chang', phone: '+65 6845 9300', email: 'orders@hilti.com.sg', address: '20 Harbour Drive, PSA Vista #07-01, Singapore 117612', rating: 5, performanceScore: 98, documents: [], status: 'Active', createdAt: '2025-01-01T00:00:00Z' },
  { id: 'sup-02', name: '3M Safety & Industrial SG', code: 'SUP-3M', contactPerson: 'Cheryl Goh', phone: '+65 6450 8888', email: 'safety.sg@mmm.com', address: '10 Ang Mo Kio Street 65, Singapore 569059', rating: 5, performanceScore: 95, documents: [], status: 'Active', createdAt: '2025-01-01T00:00:00Z' },
  { id: 'sup-03', name: 'Bosch Power Tools SEA', code: 'SUP-BOSCH', contactPerson: 'Lucas Lee', phone: '+65 6571 2222', email: 'support.powertools@bosch.sg', address: '11 Bishan Street 21, Singapore 573943', rating: 4, performanceScore: 92, documents: [], status: 'Active', createdAt: '2025-01-01T00:00:00Z' }
];

export const INITIAL_USERS: AdminUser[] = [
  {
    id: 'usr-001',
    fullName: 'Super Admin',
    email: 'vickykartik12032004@gmail.com',
    phone: '+65 6789 1234',
    employeeNumber: 'MNC-1001',
    department: 'Management & IT',
    branch: 'Main HQ International Plaza',
    site: 'M-001_Tenga Plantation C1',
    assignedSites: ['M-001_Tenga Plantation C1', 'M-002_Blue Horizon #14-21', 'M-003_Parc Life', 'Q-001_OVB #19-04 (Astro)', 'Q-002_RWS (NH)'],
    allSitesAccess: true,
    role: 'Super Admin',
    status: 'Active',
    photo: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150',
    failedLoginAttempts: 0,
    lastLogin: '2026-07-31T00:00:00Z',
    createdAt: '2025-01-01T00:00:00Z',
  },
  {
    id: 'usr-002',
    fullName: 'David Tan (Operations Admin)',
    email: 'admin@mountec.com',
    phone: '+65 6789 2200',
    employeeNumber: 'MNC-1002',
    department: 'Store & Inventory Logistics',
    branch: 'Main HQ International Plaza',
    site: 'M-001_Tenga Plantation C1',
    assignedSites: ['M-001_Tenga Plantation C1', 'M-002_Blue Horizon #14-21', 'M-003_Parc Life'],
    allSitesAccess: true,
    role: 'Admin',
    status: 'Active',
    photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=150',
    failedLoginAttempts: 0,
    lastLogin: '2026-07-30T10:00:00Z',
    createdAt: '2025-01-05T00:00:00Z',
  },
  {
    id: 'usr-003',
    fullName: 'Elena Rostova (Site Supervisor)',
    email: 'supervisor@mountec.com',
    phone: '+65 6789 3300',
    employeeNumber: 'MNC-2001',
    department: 'Site Operations',
    branch: 'Tuas Western Logistics Hub',
    site: 'M-001_Tenga Plantation C1',
    assignedSites: ['M-001_Tenga Plantation C1', 'M-002_Blue Horizon #14-21', 'M-003_Parc Life'],
    allSitesAccess: false,
    role: 'Supervisor',
    status: 'Active',
    photo: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=150',
    failedLoginAttempts: 0,
    lastLogin: '2026-07-29T14:30:00Z',
    createdAt: '2025-01-10T00:00:00Z',
  },
  {
    id: 'usr-004',
    fullName: 'Chen Wei (Lead Field Worker)',
    email: 'worker@mountec.com',
    phone: '+65 6789 4400',
    employeeNumber: 'MNC-3001',
    department: 'Site Operations',
    branch: 'Tuas Western Logistics Hub',
    site: 'M-001_Tenga Plantation C1',
    assignedSites: ['M-001_Tenga Plantation C1'],
    allSitesAccess: false,
    role: 'Worker',
    status: 'Active',
    photo: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=150',
    failedLoginAttempts: 0,
    lastLogin: '2026-07-28T09:15:00Z',
    createdAt: '2025-01-15T00:00:00Z',
  },
  {
    id: 'usr-005',
    fullName: 'RAJENDIRAN RAMU',
    email: 'rajendiran.ramu@mountec.sg',
    phone: '+65 8123 4004',
    employeeNumber: 'ME-004',
    department: 'Site Operations',
    branch: 'Tuas Western Logistics Hub',
    site: 'M-001_Tenga Plantation C1',
    assignedSites: ['M-001_Tenga Plantation C1'],
    allSitesAccess: false,
    role: 'Worker',
    status: 'Active',
    photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=150',
    failedLoginAttempts: 0,
    lastLogin: '2026-08-01T08:00:00Z',
    createdAt: '2025-01-15T00:00:00Z',
  },
  {
    id: 'usr-006',
    fullName: 'RAMU ELUMALAI',
    email: 'ramu.elumalai@mountec.sg',
    phone: '+65 8123 4005',
    employeeNumber: 'ME-005',
    department: 'Site Operations',
    branch: 'Tuas Western Logistics Hub',
    site: 'M-001_Tenga Plantation C1',
    assignedSites: ['M-001_Tenga Plantation C1'],
    allSitesAccess: false,
    role: 'Worker',
    status: 'Active',
    photo: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=150',
    failedLoginAttempts: 0,
    lastLogin: '2026-08-01T08:00:00Z',
    createdAt: '2025-02-01T00:00:00Z',
  },
  {
    id: 'usr-007',
    fullName: 'PANNEER SELVAM VENKATESAN',
    email: 'panneerselvam.v@mountec.sg',
    phone: '+65 8123 4009',
    employeeNumber: 'ME-009',
    department: 'Site Operations',
    branch: 'Main HQ International Plaza',
    site: 'M-003_Parc Life',
    assignedSites: ['M-003_Parc Life'],
    allSitesAccess: false,
    role: 'Worker',
    status: 'Active',
    photo: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=150',
    failedLoginAttempts: 0,
    lastLogin: '2026-08-01T08:00:00Z',
    createdAt: '2025-02-20T00:00:00Z',
  },
  {
    id: 'usr-008',
    fullName: 'K.VICKY',
    email: 'k.vicky@mountec.sg',
    phone: '+65 8123 4012',
    employeeNumber: 'ME-012',
    department: 'Site Operations',
    branch: 'Main HQ International Plaza',
    site: 'M-001_Tenga Plantation C1',
    assignedSites: ['M-001_Tenga Plantation C1'],
    allSitesAccess: false,
    role: 'Worker',
    status: 'Active',
    photo: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=150',
    failedLoginAttempts: 0,
    lastLogin: '2026-08-01T08:00:00Z',
    createdAt: '2025-03-01T00:00:00Z',
  },
  {
    id: 'usr-009',
    fullName: 'HOSSAIN MOHAMMAD RAKIB',
    email: 'rakib.hossain@mountec.sg',
    phone: '+65 8123 4026',
    employeeNumber: 'ME-026',
    department: 'Site Operations',
    branch: 'Tuas Western Logistics Hub',
    site: 'M-002_Blue Horizon #14-21',
    assignedSites: ['M-002_Blue Horizon #14-21'],
    allSitesAccess: false,
    role: 'Worker',
    status: 'Active',
    photo: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=150',
    failedLoginAttempts: 0,
    lastLogin: '2026-08-01T08:00:00Z',
    createdAt: '2025-03-15T00:00:00Z',
  },
  {
    id: 'usr-010',
    fullName: 'MANI RAGHU',
    email: 'mani.raghu@mountec.sg',
    phone: '+65 8123 4027',
    employeeNumber: 'ME-027',
    department: 'Site Operations',
    branch: 'Main HQ International Plaza',
    site: 'M-003_Parc Life',
    assignedSites: ['M-003_Parc Life'],
    allSitesAccess: false,
    role: 'Worker',
    status: 'Active',
    photo: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&q=80&w=150',
    failedLoginAttempts: 0,
    lastLogin: '2026-08-01T08:00:00Z',
    createdAt: '2025-04-10T00:00:00Z',
  },
  {
    id: 'usr-011',
    fullName: 'RATHINASAMY AYYAPPAN',
    email: 'r.ayyappan@mountec.sg',
    phone: '+65 8123 4028',
    employeeNumber: 'ME-028',
    department: 'Site Operations',
    branch: 'Main HQ International Plaza',
    site: 'Q-001_OVB #19-04 (Astro)',
    assignedSites: ['Q-001_OVB #19-04 (Astro)'],
    allSitesAccess: false,
    role: 'Worker',
    status: 'Active',
    photo: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150',
    failedLoginAttempts: 0,
    lastLogin: '2026-08-01T08:00:00Z',
    createdAt: '2025-05-02T00:00:00Z',
  },
  {
    id: 'usr-012',
    fullName: 'CHINNIAH RENGASAMY',
    email: 'chinniah.r@mountec.sg',
    phone: '+65 8123 4029',
    employeeNumber: 'ME-029',
    department: 'Safety & Quality Assurance',
    branch: 'Tuas Western Logistics Hub',
    site: 'M-001_Tenga Plantation C1',
    assignedSites: ['M-001_Tenga Plantation C1'],
    allSitesAccess: false,
    role: 'Worker',
    status: 'Active',
    photo: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=150',
    failedLoginAttempts: 0,
    lastLogin: '2026-08-01T08:00:00Z',
    createdAt: '2025-05-20T00:00:00Z',
  }
];

export const INITIAL_UNITS: UnitOfMeasure[] = [
  { id: 'u-01', code: 'PCS', name: 'Pieces', symbol: 'pcs', category: 'Quantity', status: 'Active', createdAt: '2025-01-01T00:00:00Z' },
  { id: 'u-02', code: 'BOX', name: 'Box Package', symbol: 'box', category: 'Packaging', status: 'Active', createdAt: '2025-01-01T00:00:00Z' },
  { id: 'u-03', code: 'SET', name: 'Complete Tool Set', symbol: 'set', category: 'Quantity', status: 'Active', createdAt: '2025-01-01T00:00:00Z' },
  { id: 'u-04', code: 'PAIR', name: 'Pair (Gloves/Boots)', symbol: 'pr', category: 'Packaging', status: 'Active', createdAt: '2025-01-01T00:00:00Z' },
  { id: 'u-05', code: 'KG', name: 'Kilograms', symbol: 'kg', category: 'Weight', status: 'Active', createdAt: '2025-01-01T00:00:00Z' },
  { id: 'u-06', code: 'LTR', name: 'Liters', symbol: 'L', category: 'Volume', status: 'Active', createdAt: '2025-01-01T00:00:00Z' },
  { id: 'u-07', code: 'MTR', name: 'Meters', symbol: 'm', category: 'Length', status: 'Active', createdAt: '2025-01-01T00:00:00Z' },
  { id: 'u-08', code: 'ROLL', name: 'Roll / Coil', symbol: 'roll', category: 'Packaging', status: 'Active', createdAt: '2025-01-01T00:00:00Z' },
  { id: 'u-09', code: 'DRUM', name: 'Drum Container (200L)', symbol: 'drum', category: 'Volume', status: 'Active', createdAt: '2025-03-01T00:00:00Z' }
];

export const INITIAL_EMAIL_SETTINGS: EmailSettings = {
  smtpServer: 'smtp.office365.com',
  smtpPort: 587,
  encryption: 'STARTTLS',
  smtpUsername: 'notifications@mountec.sg',
  senderName: 'MOUNTEC PTE LTD System',
  senderEmail: 'notifications@mountec.sg',
  testEmailStatus: 'idle',
  lastTestedAt: '2026-07-28T12:00:00Z',
};

export const INITIAL_APP_SETTINGS: ApplicationSettings = {
  theme: 'Dark',
  dateFormat: 'DD/MM/YYYY',
  timeFormat: '24-hour',
  currency: 'SGD (S$)',
  language: 'English',
  defaultDashboard: 'Executive Summary',
};

export const INITIAL_SECURITY_SETTINGS: SecuritySettings = {
  minPasswordLength: 10,
  requireUppercase: true,
  requireNumbers: true,
  requireSpecialChars: true,
  sessionTimeoutMinutes: 30,
  autoLogout: true,
  enable2FA: false,
  loginAttemptLimit: 5,
  ipLoggingEnabled: true,
  allowedIPs: ['118.200.12.44', '202.156.98.10', '10.0.0.0/16'],
};

export const INITIAL_AUDIT_LOGS: AuditLog[] = [];

export const INITIAL_BACKUPS: BackupRecord[] = [];

export const INITIAL_BACKUP_SETTINGS: BackupSettings = {
  autoBackupEnabled: true,
  schedule: 'Daily',
  retentionDays: 30,
  cloudSync: true,
};

export const INITIAL_SYSTEM_HEALTH: SystemHealth = {
  dbStatus: 'Optimal',
  dbPingMs: 12,
  storageUsedGb: 0.1,
  storageTotalGb: 100,
  userCount: 1,
  assetCount: 0,
  apiResponseTimeMs: 25,
  memoryUsageMb: 128,
  cpuLoadPercent: 2,
  uptimePercent: 100.0,
  lastCheckedAt: '2026-07-31T00:00:00Z',
};

export const INITIAL_LICENSE_INFO: LicenseInfo = {
  companyName: 'MOUNTEC PTE LTD',
  licenseType: 'Enterprise Platinum Edition',
  expiryDate: '2028-12-31',
  applicationVersion: 'v2.5.0-EE Enterprise',
  maxSites: 'Unlimited',
  maxBranches: 'Unlimited',
  maxUsers: 'Unlimited',
  supportTier: '24/7 Platinum Dedicated SLA (15 min response)',
  registeredTo: 'MOUNTEC PTE LTD (UEN: 201812345M)',
  issuedDate: '2024-01-01',
  licenseKey: 'MNC-ENT-9823-4410-8812-PLTN-2028',
};

export const INITIAL_AUTHORIZED_USERS: AuthorizedUser[] = [
  {
    id: 'auth-usr-001',
    fullName: 'Super Admin (Google SSO)',
    googleEmail: 'vickykartik12032004@gmail.com',
    role: 'Super Admin',
    department: 'Management & IT',
    site: 'M-001_Tenga Plantation C1',
    branch: 'Main HQ International Plaza',
    assignedSites: ['M-001_Tenga Plantation C1', 'M-002_Blue Horizon #14-21', 'M-003_Parc Life', 'Q-001_OVB #19-04 (Astro)', 'Q-002_RWS (NH)'],
    allSitesAccess: true,
    status: 'Active',
    createdAt: '2025-01-01T00:00:00Z',
    updatedAt: '2026-07-31T00:00:00Z',
  },
  {
    id: 'auth-usr-002',
    fullName: 'David Tan (Operations Admin)',
    googleEmail: 'admin@mountec.com',
    role: 'Super Admin',
    department: 'Store & Inventory Logistics',
    site: 'M-001_Tenga Plantation C1',
    branch: 'Main HQ International Plaza',
    assignedSites: ['M-001_Tenga Plantation C1', 'M-002_Blue Horizon #14-21', 'M-003_Parc Life'],
    allSitesAccess: true,
    status: 'Active',
    createdAt: '2025-01-01T00:00:00Z',
    updatedAt: '2026-07-31T00:00:00Z',
  },
  {
    id: 'auth-usr-003',
    fullName: 'Administrator',
    googleEmail: 'vs5954613@gmail.com',
    role: 'Super Admin',
    department: 'Management & IT',
    site: 'M-001_Tenga Plantation C1',
    branch: 'Main HQ International Plaza',
    assignedSites: ['M-001_Tenga Plantation C1', 'M-002_Blue Horizon #14-21', 'M-003_Parc Life'],
    allSitesAccess: true,
    status: 'Active',
    createdAt: '2025-01-01T00:00:00Z',
    updatedAt: '2026-07-31T00:00:00Z',
  }
];

export const INITIAL_ACCESS_REQUESTS = [
  {
    id: 'req-superadmin',
    googleName: 'Vicky Kartik (Super Admin)',
    googleEmail: 'vickykartik12032004@gmail.com',
    status: 'APPROVED' as const,
    requestedAt: '2025-01-01T00:00:00.000Z',
    approvedAt: '2025-01-01T00:00:00.000Z',
    approvedBy: 'System (Permanent Super Admin)',
    assignedRole: 'Super Admin' as const,
    department: 'Management & IT',
    site: 'M-001_Tenga Plantation C1',
    notes: 'Permanent, immutable Super Admin account',
  },
  {
    id: 'req-admin-mountec',
    googleName: 'David Tan (Operations Admin)',
    googleEmail: 'admin@mountec.com',
    status: 'APPROVED' as const,
    requestedAt: '2025-01-01T00:00:00.000Z',
    approvedAt: '2025-01-01T00:00:00.000Z',
    approvedBy: 'System (Super Admin)',
    assignedRole: 'Super Admin' as const,
    department: 'Store & Inventory Logistics',
    site: 'M-001_Tenga Plantation C1',
    notes: 'Operations Super Admin account',
  },
  {
    id: 'req-admin-vs5954613',
    googleName: 'Administrator',
    googleEmail: 'vs5954613@gmail.com',
    status: 'APPROVED' as const,
    requestedAt: '2025-01-01T00:00:00.000Z',
    approvedAt: '2025-01-01T00:00:00.000Z',
    approvedBy: 'System (Super Admin)',
    assignedRole: 'Super Admin' as const,
    department: 'Management & IT',
    site: 'M-001_Tenga Plantation C1',
    notes: 'Management IT Admin account',
  }
];

