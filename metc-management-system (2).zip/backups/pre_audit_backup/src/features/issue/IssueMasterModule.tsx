import React, { useState } from 'react';
import { useIssue } from './hooks/useIssue';
import { IssueDashboardKpis } from './components/dashboard/IssueDashboardKpis';
import { QuickActions } from './components/dashboard/QuickActions';
import { NewIssueForm } from './components/forms/NewIssueForm';
import { MultiItemIssueForm } from './components/forms/MultiItemIssueForm';
import { BulkIssueForm } from './components/forms/BulkIssueForm';
import { QRBarcodeScannerModal } from './components/forms/QRBarcodeScannerModal';
import { ActiveIssuesTable } from './components/tables/ActiveIssuesTable';
import { IssueHistoryTable } from './components/tables/IssueHistoryTable';
import { PendingReturnsTable } from './components/tables/PendingReturnsTable';
import { IssueDetailsModal } from './components/details/IssueDetailsModal';
import { IssueSlipModal } from './components/details/IssueSlipModal';
import { IssueReportsView } from './components/reports/IssueReportsView';
import type { EnterpriseIssue, IssueStatus } from './types';
import type { AssetCategory } from '../../types';
import {
  LayoutDashboard,
  Plus,
  Clock,
  History,
  Users,
  PackageX,
  FileBarChart2,
  Search,
  RefreshCw,
  X,
  Layers,
  RotateCcw,
  AlertOctagon,
} from 'lucide-react';
import { toast } from 'sonner';

export type IssueTabType =
  | 'dashboard'
  | 'new'
  | 'multi'
  | 'active'
  | 'history'
  | 'bulk'
  | 'pending'
  | 'reports';

export const IssueMasterModule: React.FC = () => {
  const {
    issues,
    filteredIssues,
    pendingReturnsList,
    loading,
    filters,
    setFilters,
    categoryOptions,
    siteOptions,
    departmentOptions,
    kpiStats,
    rawAssets,
    rawWorkers,
    reloadIssues,
    handleSingleIssue,
    handleMultiIssue,
    handleBulkIssue,
    handleReturnItem,
    handleMarkLost,
  } = useIssue();

  const [activeTab, setActiveTab] = useState<IssueTabType>('dashboard');

  // Modal States
  const [selectedIssueForDetails, setSelectedIssueForDetails] = useState<EnterpriseIssue | null>(null);
  const [selectedIssueForSlip, setSelectedIssueForSlip] = useState<EnterpriseIssue | null>(null);
  const [isScannerOpen, setIsScannerOpen] = useState<boolean>(false);

  // Quick Action Return Modal State
  const [returnModal, setReturnModal] = useState<{
    isOpen: boolean;
    issue: EnterpriseIssue | null;
    qty: number;
    condition: 'Good' | 'Damaged' | 'Needs Repair';
    notes: string;
  }>({
    isOpen: false,
    issue: null,
    qty: 1,
    condition: 'Good',
    notes: '',
  });

  // Quick Action Mark Lost Modal State
  const [lostModal, setLostModal] = useState<{
    isOpen: boolean;
    issue: EnterpriseIssue | null;
    notes: string;
  }>({
    isOpen: false,
    issue: null,
    notes: '',
  });

  // Handlers for Quick Return
  const handleOpenReturnModal = (issue: EnterpriseIssue) => {
    setReturnModal({
      isOpen: true,
      issue,
      qty: issue.quantity,
      condition: 'Good',
      notes: '',
    });
  };

  const handleConfirmReturn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!returnModal.issue) return;

    const ok = await handleReturnItem(
      returnModal.issue.id,
      returnModal.qty,
      returnModal.condition,
      returnModal.notes
    );

    if (ok) {
      setReturnModal({ isOpen: false, issue: null, qty: 1, condition: 'Good', notes: '' });
    }
  };

  // Handlers for Mark Lost
  const handleOpenLostModal = (issue: EnterpriseIssue) => {
    setLostModal({
      isOpen: true,
      issue,
      notes: '',
    });
  };

  const handleConfirmLost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!lostModal.issue) return;

    const ok = await handleMarkLost(lostModal.issue.id, lostModal.notes);
    if (ok) {
      setLostModal({ isOpen: false, issue: null, notes: '' });
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* TOP HEADER & MODULE TAB BAR */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300">
              SAP EAM & Oracle Inventory Style
            </span>
            <span className="text-xs text-slate-400">• Enterprise Issue Module</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100">
            Enterprise Issue Management
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Issue materials, equipment, tools, consumables & PPE to site workers with complete real-time tracking.
          </p>
        </div>

        {/* MAIN MENU TABS */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar bg-slate-100 dark:bg-slate-800 p-1.5 rounded-xl border border-slate-200 dark:border-slate-700">
          {[
            { id: 'dashboard', label: 'Issue Dashboard', icon: LayoutDashboard },
            { id: 'new', label: 'New Issue', icon: Plus },
            { id: 'active', label: 'Active Issues', icon: Clock, badge: kpiStats.activeIssues },
            { id: 'history', label: 'Issue History', icon: History },
            { id: 'bulk', label: 'Bulk Issue', icon: Users },
            { id: 'pending', label: 'Pending Returns', icon: PackageX, badge: kpiStats.pendingReturns },
            { id: 'reports', label: 'Reports', icon: FileBarChart2 },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as IssueTabType)}
                className={`px-3 py-2 text-xs font-bold rounded-lg transition-all flex items-center gap-2 whitespace-nowrap ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
                {tab.badge !== undefined && tab.badge > 0 && (
                  <span
                    className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
                      isActive
                        ? 'bg-blue-700 text-white'
                        : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200'
                    }`}
                  >
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* TAB 1: ISSUE DASHBOARD */}
      {activeTab === 'dashboard' && (
        <div className="space-y-6">
          <IssueDashboardKpis
            kpis={kpiStats}
            onFilterStatus={(st) => {
              setFilters({ ...filters, status: st as any });
              setActiveTab('active');
            }}
          />

          <QuickActions
            onNewSingleIssue={() => setActiveTab('new')}
            onNewMultiIssue={() => setActiveTab('multi')}
            onNewBulkIssue={() => setActiveTab('bulk')}
            onScanQr={() => setIsScannerOpen(true)}
            onScanBarcode={() => setIsScannerOpen(true)}
            onViewReports={() => setActiveTab('reports')}
          />

          {/* ACTIVE ISSUES RECENT TABLE */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-black text-slate-900 dark:text-slate-100">
                Recent Active Dispatch Transactions
              </h3>
              <button
                onClick={() => setActiveTab('active')}
                className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline"
              >
                View All Active Issues ({kpiStats.activeIssues}) →
              </button>
            </div>

            <ActiveIssuesTable
              issues={issues.filter((i) => i.status === 'Active' || i.status === 'Overdue').slice(0, 6)}
              onViewDetails={setSelectedIssueForDetails}
              onPrintSlip={setSelectedIssueForSlip}
              onQuickReturn={handleOpenReturnModal}
              onMarkLost={handleOpenLostModal}
            />
          </div>
        </div>
      )}

      {/* TAB 2: NEW SINGLE ISSUE FORM */}
      {activeTab === 'new' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs max-w-4xl mx-auto space-y-4">
          <div className="pb-3 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <div>
              <h2 className="text-lg font-black text-slate-900 dark:text-slate-100">
                New Single Issue & Material Dispatch
              </h2>
              <p className="text-xs text-slate-500">
                Issue materials, equipment or tools to a site worker with real-time stock update
              </p>
            </div>
            <button
              onClick={() => setActiveTab('multi')}
              className="text-xs font-bold text-purple-600 hover:underline flex items-center gap-1"
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Switch to Multi-Item Issue</span>
            </button>
          </div>

          <NewIssueForm
            workers={rawWorkers}
            items={rawAssets}
            currentUser="Store Keeper"
            onSubmit={async (payload) => {
              const ok = await handleSingleIssue(payload);
              if (ok) setActiveTab('active');
              return ok;
            }}
            onCancel={() => setActiveTab('dashboard')}
            onOpenScanner={() => setIsScannerOpen(true)}
          />
        </div>
      )}

      {/* TAB 3: MULTI ITEM ISSUE FORM */}
      {activeTab === 'multi' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs max-w-4xl mx-auto space-y-4">
          <MultiItemIssueForm
            workers={rawWorkers}
            items={rawAssets}
            currentUser="Store Keeper"
            onSubmit={async (payload) => {
              const ok = await handleMultiIssue(payload);
              if (ok) setActiveTab('active');
              return ok;
            }}
            onCancel={() => setActiveTab('dashboard')}
          />
        </div>
      )}

      {/* TAB 4: ACTIVE ISSUES TABLE */}
      {activeTab === 'active' && (
        <div className="space-y-4">
          {/* SEARCH & FILTERS BAR */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={filters.searchQuery}
                onChange={(e) => setFilters({ ...filters, searchQuery: e.target.value })}
                placeholder="Search by Issue Code, Worker, Employee ID, Item Name, Asset ID, Serial No, Site..."
                className="w-full pl-10 pr-4 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-500 text-slate-900 dark:text-slate-100"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <select
                value={filters.status}
                onChange={(e) => setFilters({ ...filters, status: e.target.value as any })}
                className="px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
              >
                <option value="All">All Statuses</option>
                <option value="Active">Active</option>
                <option value="Overdue">Overdue</option>
                <option value="Returned">Returned</option>
                <option value="Repair">Repair</option>
                <option value="Lost">Lost</option>
                <option value="Cancelled">Cancelled</option>
              </select>

              <select
                value={filters.category}
                onChange={(e) => setFilters({ ...filters, category: e.target.value as any })}
                className="px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
              >
                {categoryOptions.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat === 'All' ? 'All Categories' : cat}
                  </option>
                ))}
              </select>

              <select
                value={filters.site}
                onChange={(e) => setFilters({ ...filters, site: e.target.value })}
                className="px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
              >
                {siteOptions.map((s) => (
                  <option key={s} value={s}>
                    {s === 'All' ? 'All Sites' : s}
                  </option>
                ))}
              </select>

              <button
                onClick={reloadIssues}
                title="Refresh Records"
                className="p-2 text-slate-500 hover:text-blue-600 bg-slate-100 dark:bg-slate-800 rounded-xl"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>
          </div>

          <ActiveIssuesTable
            issues={filteredIssues}
            onViewDetails={setSelectedIssueForDetails}
            onPrintSlip={setSelectedIssueForSlip}
            onQuickReturn={handleOpenReturnModal}
            onMarkLost={handleOpenLostModal}
          />
        </div>
      )}

      {/* TAB 5: ISSUE HISTORY */}
      {activeTab === 'history' && (
        <IssueHistoryTable
          issues={issues}
          onViewDetails={setSelectedIssueForDetails}
        />
      )}

      {/* TAB 6: BULK ISSUE FORM */}
      {activeTab === 'bulk' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs max-w-4xl mx-auto">
          <BulkIssueForm
            workers={rawWorkers}
            items={rawAssets}
            currentUser="Store Keeper"
            onSubmit={async (payload) => {
              const ok = await handleBulkIssue(payload);
              if (ok) setActiveTab('active');
              return ok;
            }}
            onCancel={() => setActiveTab('dashboard')}
          />
        </div>
      )}

      {/* TAB 7: PENDING RETURNS */}
      {activeTab === 'pending' && (
        <PendingReturnsTable
          pendingIssues={pendingReturnsList}
          onQuickReturn={handleOpenReturnModal}
          onRefresh={reloadIssues}
        />
      )}

      {/* TAB 8: REPORTS */}
      {activeTab === 'reports' && <IssueReportsView issues={issues} />}

      {/* DETAIL MODAL */}
      <IssueDetailsModal
        isOpen={Boolean(selectedIssueForDetails)}
        onClose={() => setSelectedIssueForDetails(null)}
        issue={selectedIssueForDetails}
        onPrintSlip={setSelectedIssueForSlip}
      />

      {/* PRINT SLIP MODAL */}
      <IssueSlipModal
        isOpen={Boolean(selectedIssueForSlip)}
        onClose={() => setSelectedIssueForSlip(null)}
        issue={selectedIssueForSlip}
      />

      {/* BARCODE / QR SCANNER MODAL */}
      <QRBarcodeScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        items={rawAssets}
        workers={rawWorkers}
        onSelectScannedItem={() => {
          setActiveTab('new');
        }}
        onSelectScannedWorker={() => {
          setActiveTab('new');
        }}
      />

      {/* QUICK RETURN MODAL */}
      {returnModal.isOpen && returnModal.issue && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <RotateCcw className="w-4 h-4 text-emerald-500" />
                <span>Return Item: {returnModal.issue.itemName}</span>
              </h3>
              <button
                onClick={() => setReturnModal({ isOpen: false, issue: null, qty: 1, condition: 'Good', notes: '' })}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleConfirmReturn} className="space-y-3">
              <div>
                <label className="block text-xs font-bold mb-1">Quantity Returned</label>
                <input
                  type="number"
                  min={1}
                  max={returnModal.issue.quantity}
                  value={returnModal.qty}
                  onChange={(e) => setReturnModal({ ...returnModal, qty: parseInt(e.target.value) || 1 })}
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold mb-1">Condition on Return</label>
                <select
                  value={returnModal.condition}
                  onChange={(e) => setReturnModal({ ...returnModal, condition: e.target.value as any })}
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
                >
                  <option value="Good">Good / Undamaged</option>
                  <option value="Damaged">Damaged / Operational Wear</option>
                  <option value="Needs Repair">Needs Repair / Maintenance</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold mb-1">Return Notes / Inspection Remarks</label>
                <textarea
                  rows={2}
                  value={returnModal.notes}
                  onChange={(e) => setReturnModal({ ...returnModal, notes: e.target.value })}
                  placeholder="Notes on item condition upon return..."
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl resize-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setReturnModal({ isOpen: false, issue: null, qty: 1, condition: 'Good', notes: '' })}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs"
                >
                  Confirm Item Return
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* QUICK MARK LOST MODAL */}
      {lostModal.isOpen && lostModal.issue && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <AlertOctagon className="w-4 h-4 text-rose-500" />
                <span>Report Lost Asset: {lostModal.issue.itemName}</span>
              </h3>
              <button
                onClick={() => setLostModal({ isOpen: false, issue: null, notes: '' })}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleConfirmLost} className="space-y-3">
              <p className="text-xs text-slate-600 dark:text-slate-300">
                Marking asset <strong>{lostModal.issue.itemName}</strong> ({lostModal.issue.issueCode}) assigned to <strong>{lostModal.issue.workerName}</strong> as lost.
              </p>

              <div>
                <label className="block text-xs font-bold mb-1">Incident / Loss Details *</label>
                <textarea
                  rows={3}
                  value={lostModal.notes}
                  onChange={(e) => setLostModal({ ...lostModal, notes: e.target.value })}
                  placeholder="Describe incident, site location where asset was lost..."
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl resize-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setLostModal({ isOpen: false, issue: null, notes: '' })}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl shadow-xs"
                >
                  Report Lost Asset
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
