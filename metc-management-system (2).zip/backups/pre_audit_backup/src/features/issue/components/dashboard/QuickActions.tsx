import React from 'react';
import { Plus, Layers, QrCode, Barcode, FileText, Users } from 'lucide-react';

interface Props {
  onNewSingleIssue: () => void;
  onNewMultiIssue: () => void;
  onNewBulkIssue: () => void;
  onScanQr: () => void;
  onScanBarcode: () => void;
  onViewReports: () => void;
}

export const QuickActions: React.FC<Props> = ({
  onNewSingleIssue,
  onNewMultiIssue,
  onNewBulkIssue,
  onScanQr,
  onScanBarcode,
  onViewReports,
}) => {
  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
          Quick Dispatch & Issue Actions
        </h3>
        <span className="text-[11px] text-slate-400">Barcode / QR Scanner Enabled</span>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2.5">
        <button
          onClick={onNewSingleIssue}
          className="p-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-xs transition-all shadow-xs flex items-center justify-center gap-2 group"
        >
          <Plus className="w-4 h-4 group-hover:scale-110 transition-transform" />
          <span>New Issue</span>
        </button>

        <button
          onClick={onNewMultiIssue}
          className="p-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-xl font-semibold text-xs transition-all flex items-center justify-center gap-2"
        >
          <Layers className="w-4 h-4 text-blue-500" />
          <span>Multi-Item Issue</span>
        </button>

        <button
          onClick={onNewBulkIssue}
          className="p-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-xl font-semibold text-xs transition-all flex items-center justify-center gap-2"
        >
          <Users className="w-4 h-4 text-purple-500" />
          <span>Bulk Dispatch</span>
        </button>

        <button
          onClick={onScanQr}
          className="p-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-xl font-semibold text-xs transition-all flex items-center justify-center gap-2"
        >
          <QrCode className="w-4 h-4 text-emerald-500" />
          <span>Scan QR</span>
        </button>

        <button
          onClick={onScanBarcode}
          className="p-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-xl font-semibold text-xs transition-all flex items-center justify-center gap-2"
        >
          <Barcode className="w-4 h-4 text-indigo-500" />
          <span>Scan Barcode</span>
        </button>

        <button
          onClick={onViewReports}
          className="p-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-xl font-semibold text-xs transition-all flex items-center justify-center gap-2"
        >
          <FileText className="w-4 h-4 text-amber-500" />
          <span>View Reports</span>
        </button>
      </div>
    </div>
  );
};
