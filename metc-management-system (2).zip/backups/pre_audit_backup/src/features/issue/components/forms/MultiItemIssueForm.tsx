import React, { useState } from 'react';
import type { METCItem, Worker } from '../../../../types';
import type { MultiItemIssuePayload, MultiItemIssueItem, IssuePriority } from '../../types';
import { User, Layers, Plus, Trash2, CheckCircle2, AlertCircle, Search, Sparkles, X } from 'lucide-react';
import { toast } from 'sonner';
import { INITIAL_WORKERS } from '../../../../data/mockData';
import { useWorkerStore } from '../../../../store/useWorkerStore';

interface Props {
  workers: Worker[];
  items: METCItem[];
  currentUser: string;
  onSubmit: (payload: Omit<MultiItemIssuePayload, 'issuedBy'>) => Promise<boolean>;
  onCancel: () => void;
}

export const MultiItemIssueForm: React.FC<Props> = ({
  workers,
  items,
  currentUser,
  onSubmit,
  onCancel,
}) => {
  const storeWorkers = useWorkerStore((s) => s.workers);
  const effectiveWorkers = workers?.length > 0
    ? workers
    : (storeWorkers?.length > 0 ? storeWorkers : INITIAL_WORKERS);

  const [workerSearch, setWorkerSearch] = useState('');
  const [selectedWorker, setSelectedWorker] = useState<Worker | null>(null);
  const [selectedItems, setSelectedItems] = useState<MultiItemIssueItem[]>([]);
  const [remarks, setRemarks] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Item Selector State
  const [addingItemId, setAddingItemId] = useState('');
  const [addingQty, setAddingQty] = useState(1);
  const [addingPriority, setAddingPriority] = useState<IssuePriority>('Medium');
  const [addingReturnDate, setAddingReturnDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 14);
    return d.toISOString().split('T')[0];
  });

  const handleAddItem = () => {
    if (!addingItemId) {
      toast.error('Select an item to add');
      return;
    }

    const item = items.find((i) => i.id === addingItemId);
    if (!item) return;

    if (selectedItems.some((s) => s.itemId === item.id)) {
      toast.error(`"${item.name}" is already added to this transaction list.`);
      return;
    }

    if (addingQty <= 0) {
      toast.error('Quantity must be greater than zero');
      return;
    }

    if (addingQty > item.availableQuantity) {
      toast.error(`Insufficient stock! Only ${item.availableQuantity} available.`);
      return;
    }

    const isConsumable = item.category === 'Consumable';

    const newItem: MultiItemIssueItem = {
      itemId: item.id,
      itemName: item.name,
      itemCategory: item.category,
      assetId: item.code,
      availableStock: item.availableQuantity,
      quantity: addingQty,
      priority: addingPriority,
      expectedReturnDate: isConsumable ? undefined : addingReturnDate,
      isConsumable,
    };

    setSelectedItems([...selectedItems, newItem]);
    setAddingItemId('');
    setAddingQty(1);
  };

  const handleRemoveItem = (itemId: string) => {
    setSelectedItems(selectedItems.filter((i) => i.itemId !== itemId));
  };

  const handleQuickAddWorker = async (name: string) => {
    const trimmed = name.trim();
    if (!trimmed) return;
    try {
      const code = `ME-${Math.floor(100 + Math.random() * 900)}`;
      const newW = await useWorkerStore.getState().addWorker({
        workerCode: code,
        employeeNumber: code,
        name: trimmed.toUpperCase(),
        trade: 'Site Specialist',
        phone: '+65 8123 4000',
        email: `${trimmed.toLowerCase().replace(/\s+/g, '.')}@mountec.sg`,
        site: 'Tuas Mega Logistics Depot',
        projectSite: 'Tuas Mega Logistics Depot',
        department: 'Site Operations',
        branch: 'Tuas Western Logistics Hub',
        company: 'MOUNTEC PTE LTD',
        badgeNumber: code,
        wpId: '0 34100000',
        status: 'Active',
        overdueItemsCount: 0,
        joinedDate: new Date().toISOString().split('T')[0],
      });
      setSelectedWorker(newW);
      setWorkerSearch('');
      toast.success(`Worker "${newW.name}" (${newW.workerCode}) added and selected!`);
    } catch (e) {
      toast.error('Failed to quick-add worker');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedWorker) {
      toast.error('Please select a worker for this multi-item issue.');
      return;
    }

    if (selectedItems.length === 0) {
      toast.error('Please add at least one item to the issue list.');
      return;
    }

    setIsSubmitting(true);

    const payload: Omit<MultiItemIssuePayload, 'issuedBy'> = {
      workerId: selectedWorker.id,
      workerName: selectedWorker.name,
      workerCode: selectedWorker.workerCode,
      department: selectedWorker.department || 'Operations',
      site: selectedWorker.projectSite || 'Main Site',
      remarks,
      items: selectedItems,
    };

    const success = await onSubmit(payload);
    setIsSubmitting(false);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="bg-purple-50 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-900 rounded-2xl p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-600 text-white flex items-center justify-center font-black">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-black text-slate-900 dark:text-slate-100">Multi-Item Issue Transaction</h3>
            <p className="text-xs text-slate-500">Dispatch multiple items to a single worker in one transaction</p>
          </div>
        </div>
      </div>

      {/* WORKER SELECTOR */}
      <div className="space-y-3 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-2xl p-4">
        <div className="flex items-center justify-between">
          <label className="text-xs font-black text-slate-800 dark:text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
            <User className="w-4 h-4 text-purple-500" />
            <span>Target Worker *</span>
          </label>
          {selectedWorker && (
            <span className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Selected
            </span>
          )}
        </div>

        {!selectedWorker ? (
          <div className="space-y-3">
            {/* QUICK WORKER CHIPS */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-[11px]">
                <span className="font-bold text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-purple-500 animate-pulse" />
                  <span>Quick-Select Worker (Click Name):</span>
                </span>
                <span className="text-[10px] text-slate-400 font-mono">
                  {effectiveWorkers.length} available
                </span>
              </div>
              <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto pr-1">
                {effectiveWorkers.map((w) => (
                  <button
                    key={w.id}
                    type="button"
                    onClick={() => setSelectedWorker(w)}
                    className="px-2.5 py-1 text-[11px] font-bold rounded-lg bg-purple-50 hover:bg-purple-600 text-purple-700 hover:text-white dark:bg-purple-950/40 dark:text-purple-300 dark:hover:bg-purple-600 dark:hover:text-white border border-purple-200 dark:border-purple-900/60 transition-all shadow-2xs flex items-center gap-1 cursor-pointer"
                  >
                    <User className="w-3 h-3 opacity-60" />
                    <span>{w.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* SEARCH OR SELECT INPUT */}
            <div className="relative flex items-center">
              <Search className="w-4 h-4 absolute left-3 text-slate-400 pointer-events-none" />
              <input
                type="text"
                value={workerSearch}
                onChange={(e) => setWorkerSearch(e.target.value)}
                placeholder="Search worker by name (e.g. Ramu, Vicky, Raghu) or ID..."
                className="w-full pl-9 pr-8 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-purple-500"
              />
              {workerSearch && (
                <button
                  type="button"
                  onClick={() => setWorkerSearch('')}
                  className="absolute right-2.5 p-0.5 rounded text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                  title="Clear search"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* MATCHING WORKERS LIST */}
            <div className="max-h-40 overflow-y-auto space-y-1 pr-1 divide-y divide-slate-100 dark:divide-slate-800">
              {(() => {
                const filtered = effectiveWorkers.filter((w) => {
                  if (!workerSearch.trim()) return true;
                  const q = workerSearch.toLowerCase();
                  return (
                    w.name.toLowerCase().includes(q) ||
                    w.workerCode.toLowerCase().includes(q) ||
                    (w.trade && w.trade.toLowerCase().includes(q))
                  );
                });

                if (filtered.length === 0 && workerSearch.trim()) {
                  return (
                    <div className="p-3 text-center text-slate-500 space-y-1.5 bg-white dark:bg-slate-900 rounded-xl border border-dashed border-purple-200 dark:border-purple-900">
                      <div className="text-xs font-bold text-slate-800 dark:text-slate-200">
                        Worker &ldquo;{workerSearch}&rdquo; not found
                      </div>
                      <button
                        type="button"
                        onClick={() => handleQuickAddWorker(workerSearch)}
                        className="px-3 py-1 text-xs font-bold text-white bg-purple-600 hover:bg-purple-700 rounded-lg shadow-xs inline-flex items-center gap-1 cursor-pointer"
                      >
                        <User className="w-3 h-3" />
                        <span>Add & Select &ldquo;{workerSearch.toUpperCase()}&rdquo;</span>
                      </button>
                    </div>
                  );
                }

                return filtered.map((w) => (
                  <div
                    key={w.id}
                    onClick={() => {
                      setSelectedWorker(w);
                      setWorkerSearch('');
                    }}
                    className="p-2 rounded-xl cursor-pointer transition-all flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-purple-50 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800"
                  >
                    <div>
                      <div className="font-bold text-xs text-slate-900 dark:text-slate-100">{w.name}</div>
                      <div className="text-[10px] text-slate-500 font-mono">
                        {w.workerCode} • {w.trade} • {w.projectSite}
                      </div>
                    </div>
                    <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-purple-50 text-purple-700 dark:bg-purple-950/60 dark:text-purple-300">
                      Select
                    </span>
                  </div>
                ));
              })()}
            </div>
          </div>
        ) : (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl p-3 flex items-center justify-between">
            <div>
              <div className="text-sm font-black text-slate-900 dark:text-slate-100">{selectedWorker.name}</div>
              <div className="text-xs text-slate-500 font-mono">
                {selectedWorker.workerCode} • {selectedWorker.trade} • {selectedWorker.projectSite}
              </div>
            </div>
            <button
              type="button"
              onClick={() => setSelectedWorker(null)}
              className="px-2.5 py-1 text-xs font-bold text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-950/40 hover:bg-purple-100 rounded-lg transition-colors cursor-pointer"
            >
              Change Worker
            </button>
          </div>
        )}
      </div>

      {/* ADD ITEM SECTION */}
      <div className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl p-4 space-y-3">
        <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">
          Add Item to Dispatch List
        </h4>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <div className="md:col-span-2">
            <label className="block text-[11px] font-bold text-slate-500 mb-1">Select Item</label>
            <select
              value={addingItemId}
              onChange={(e) => setAddingItemId(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
            >
              <option value="">-- Choose Item from Inventory --</option>
              {items.map((item) => (
                <option key={item.id} value={item.id} disabled={item.availableQuantity <= 0}>
                  {item.name} ({item.code}) - Avail: {item.availableQuantity} {item.unit}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-500 mb-1">Quantity</label>
            <input
              type="number"
              min={1}
              value={addingQty}
              onChange={(e) => setAddingQty(parseInt(e.target.value) || 1)}
              className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl font-bold"
            />
          </div>

          <div className="flex items-end">
            <button
              type="button"
              onClick={handleAddItem}
              className="w-full px-4 py-2 text-xs font-bold text-white bg-purple-600 hover:bg-purple-700 rounded-xl shadow-xs flex items-center justify-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Add to List</span>
            </button>
          </div>
        </div>
      </div>

      {/* DISPATCH ITEMS TABLE */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300">
            Selected Dispatch Items ({selectedItems.length})
          </h4>
          {selectedItems.length > 0 && (
            <button
              type="button"
              onClick={() => {
                setSelectedItems([]);
                toast.info('All items cleared from dispatch list.');
              }}
              className="text-xs font-bold text-rose-600 dark:text-rose-400 hover:text-rose-700 dark:hover:text-rose-300 flex items-center gap-1 hover:underline"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear All Items</span>
            </button>
          )}
        </div>

        {selectedItems.length === 0 ? (
          <div className="p-8 text-center bg-slate-50 dark:bg-slate-800/40 border border-dashed border-slate-300 dark:border-slate-700 rounded-2xl">
            <p className="text-xs text-slate-400">No items added to dispatch list yet.</p>
          </div>
        ) : (
          <div className="border border-slate-200 dark:border-slate-700 rounded-2xl overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold">
                <tr>
                  <th className="p-3">Item & Category</th>
                  <th className="p-3">Asset ID</th>
                  <th className="p-3">Available Stock</th>
                  <th className="p-3">Issue Qty</th>
                  <th className="p-3">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800 bg-white dark:bg-slate-900">
                {selectedItems.map((item) => (
                  <tr key={item.itemId}>
                    <td className="p-3">
                      <div className="font-bold text-slate-900 dark:text-slate-100">{item.itemName}</div>
                      <div className="text-[10px] text-slate-500">{item.itemCategory}</div>
                    </td>
                    <td className="p-3 font-mono text-purple-600 dark:text-purple-400 font-bold">{item.assetId}</td>
                    <td className="p-3 font-bold">{item.availableStock}</td>
                    <td className="p-3">
                      <span className="px-2 py-1 bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 font-bold rounded-lg">
                        {item.quantity}
                      </span>
                    </td>
                    <td className="p-3">
                      <button
                        type="button"
                        onClick={() => handleRemoveItem(item.itemId)}
                        className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div>
        <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
          Remarks / Dispatch Notes
        </label>
        <textarea
          rows={2}
          value={remarks}
          onChange={(e) => setRemarks(e.target.value)}
          placeholder="General remarks for this multi-item dispatch..."
          className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl resize-none"
        />
      </div>

      <div className="flex items-center justify-end gap-3">
        <button
          type="button"
          onClick={onCancel}
          className="px-5 py-2.5 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 rounded-xl"
        >
          Cancel
        </button>
        <button
          type="submit"
          disabled={isSubmitting || !selectedWorker || selectedItems.length === 0}
          className="px-6 py-2.5 text-xs font-bold text-white bg-purple-600 hover:bg-purple-700 rounded-xl shadow-md transition-all disabled:opacity-50"
        >
          {isSubmitting ? 'Processing Dispatch...' : `Confirm & Issue ${selectedItems.length} Items`}
        </button>
      </div>
    </form>
  );
};
