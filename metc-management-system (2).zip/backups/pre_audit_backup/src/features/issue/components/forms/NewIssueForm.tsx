import React, { useState, useRef, useEffect } from 'react';
import type { METCItem, Worker } from '../../../../types';
import type { NewSingleIssuePayload, IssuePriority } from '../../types';
import type { AssetCategory } from '../../../../types';
import {
  User,
  Search,
  Package,
  Calendar,
  AlertCircle,
  CheckCircle2,
  PenTool,
  QrCode,
  RotateCcw,
  Sparkles,
  X,
  SearchX,
  Plus,
} from 'lucide-react';
import { toast } from 'sonner';
import { INITIAL_WORKERS } from '../../../../data/mockData';
import { useWorkerStore } from '../../../../store/useWorkerStore';

interface Props {
  workers: Worker[];
  items: METCItem[];
  currentUser: string;
  initialWorkerId?: string;
  initialItemId?: string;
  onSubmit: (payload: Omit<NewSingleIssuePayload, 'issuedBy'>) => Promise<boolean>;
  onCancel: () => void;
  onOpenScanner?: () => void;
}

export const NewIssueForm: React.FC<Props> = ({
  workers,
  items,
  currentUser,
  initialWorkerId,
  initialItemId,
  onSubmit,
  onCancel,
  onOpenScanner,
}) => {
  // Auto-generated code & date
  const [issueCode] = useState(() => `ISS-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`);
  const [issueDate] = useState(() => new Date().toISOString().split('T')[0]);

  // Worker Selection State
  const [workerSearch, setWorkerSearch] = useState('');
  const [selectedWorker, setSelectedWorker] = useState<Worker | null>(null);

  // Item Selection State
  const [itemSearch, setItemSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<AssetCategory | 'All'>('All');
  const [selectedItem, setSelectedItem] = useState<METCItem | null>(null);

  // Form inputs
  const [department, setDepartment] = useState('');
  const [site, setSite] = useState('');
  const [quantity, setQuantity] = useState<number>(1);
  const [purpose, setPurpose] = useState('');
  const [expectedReturnDate, setExpectedReturnDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() + 14); // default 14 days
    return d.toISOString().split('T')[0];
  });
  const [priority, setPriority] = useState<IssuePriority>('Medium');
  const [remarks, setRemarks] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Signature Canvas
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [signatureData, setSignatureData] = useState<string | null>(null);

  const storeWorkers = useWorkerStore((s) => s.workers);
  const effectiveWorkers = (workers && workers.length > 0)
    ? workers
    : (storeWorkers && storeWorkers.length > 0 ? storeWorkers : INITIAL_WORKERS);

  // Set initial selections if passed
  useEffect(() => {
    if (initialWorkerId) {
      const found = effectiveWorkers.find((w) => w.id === initialWorkerId);
      if (found) {
        setSelectedWorker(found);
        setDepartment(found.department || 'Operations');
        setSite(found.projectSite || 'Main Site');
      }
    }
  }, [initialWorkerId, effectiveWorkers]);

  useEffect(() => {
    if (initialItemId) {
      const found = items.find((i) => i.id === initialItemId);
      if (found) {
        setSelectedItem(found);
      }
    }
  }, [initialItemId, items]);

  // Filtered workers list
  const filteredWorkers = effectiveWorkers.filter((w) => {
    if (!workerSearch.trim()) return true;
    const q = workerSearch.toLowerCase();
    return (
      w.name.toLowerCase().includes(q) ||
      w.workerCode.toLowerCase().includes(q) ||
      (w.employeeNumber && w.employeeNumber.toLowerCase().includes(q)) ||
      (w.trade && w.trade.toLowerCase().includes(q)) ||
      (w.projectSite && w.projectSite.toLowerCase().includes(q))
    );
  });

  const handleQuickAddWorker = async (name: string) => {
    const trimmed = name.trim();
    if (!trimmed) return;
    try {
      const code = `ME-${Math.floor(100 + Math.random() * 900)}`;
      const newW = await useWorkerStore.getState().addWorker({
        workerCode: code,
        employeeNumber: code,
        name: trimmed.toUpperCase(),
        trade: 'Site Specialist',
        phone: '+65 8123 4000',
        email: `${trimmed.toLowerCase().replace(/\s+/g, '.')}@mountec.sg`,
        site: 'Tuas Mega Logistics Depot',
        projectSite: 'Tuas Mega Logistics Depot',
        department: 'Site Operations',
        branch: 'Tuas Western Logistics Hub',
        company: 'MOUNTEC PTE LTD',
        badgeNumber: code,
        wpId: '0 34100000',
        status: 'Active',
        overdueItemsCount: 0,
        joinedDate: new Date().toISOString().split('T')[0],
      });
      setSelectedWorker(newW);
      setDepartment('Site Operations');
      setSite('Tuas Mega Logistics Depot');
      setWorkerSearch('');
      toast.success(`Worker "${newW.name}" (${newW.workerCode}) added and selected!`);
    } catch (e) {
      toast.error('Failed to quick-add worker');
    }
  };

  // Filtered items list
  const filteredItems = items.filter((item) => {
    if (categoryFilter !== 'All' && item.category !== categoryFilter) return false;
    if (!itemSearch.trim()) return true;
    const q = itemSearch.toLowerCase();
    return (
      item.name.toLowerCase().includes(q) ||
      item.code.toLowerCase().includes(q) ||
      item.category.toLowerCase().includes(q) ||
      item.location.toLowerCase().includes(q)
    );
  });

  const handleSelectWorker = (w: Worker) => {
    if (w.status === 'Inactive') {
      toast.error(`Worker ${w.name} is Inactive and cannot receive issued assets.`);
      return;
    }
    setSelectedWorker(w);
    setDepartment(w.trade || 'Operations');
    setSite(w.projectSite || 'Main Site');
  };

  const handleSelectItem = (item: METCItem) => {
    if (item.availableQuantity <= 0) {
      toast.error(`"${item.name}" has zero available stock!`);
      return;
    }
    setSelectedItem(item);
    setQuantity(1);
  };

  const handleClearItem = () => {
    setSelectedItem(null);
    setQuantity(1);
    setItemSearch('');
  };

  const handleClearAll = () => {
    setSelectedWorker(null);
    setSelectedItem(null);
    setWorkerSearch('');
    setItemSearch('');
    setCategoryFilter('All');
    setDepartment('');
    setSite('');
    setQuantity(1);
    setPurpose('');
    setRemarks('');
    clearCanvas();
    toast.info('Form inputs and selections cleared.');
  };

  // Canvas Drawing Handlers
  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    setIsDrawing(true);
    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    ctx.beginPath();
    ctx.moveTo(clientX - rect.left, clientY - rect.top);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    ctx.lineTo(clientX - rect.left, clientY - rect.top);
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
    ctx.stroke();
  };

  const stopDrawing = () => {
    if (!isDrawing) return;
    setIsDrawing(false);
    const canvas = canvasRef.current;
    if (canvas) {
      setSignatureData(canvas.toDataURL());
    }
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
    setSignatureData(null);
  };

  const isConsumable = selectedItem?.category === 'Consumable';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedWorker) {
      toast.error('Please select a worker for this issue.');
      return;
    }

    if (!selectedItem) {
      toast.error('Please select an item to issue.');
      return;
    }

    if (quantity <= 0) {
      toast.error('Quantity must be greater than zero.');
      return;
    }

    if (quantity > selectedItem.availableQuantity) {
      toast.error(`Quantity exceeds available stock (${selectedItem.availableQuantity} ${selectedItem.unit}).`);
      return;
    }

    setIsSubmitting(true);

    const payload: Omit<NewSingleIssuePayload, 'issuedBy'> = {
      workerId: selectedWorker.id,
      workerName: selectedWorker.name,
      workerCode: selectedWorker.workerCode,
      department: department || selectedWorker.department || 'Operations',
      site: site || selectedWorker.projectSite || 'Main Site',
      itemId: selectedItem.id,
      itemName: selectedItem.name,
      itemCategory: selectedItem.category,
      assetId: selectedItem.code,
      serialNumber: (selectedItem as any).serialNumber || undefined,
      quantity,
      purpose,
      expectedReturnDate: isConsumable ? undefined : expectedReturnDate,
      priority,
      remarks,
      signatureUrl: signatureData || undefined,
      isConsumable,
    };

    const success = await onSubmit(payload);
    setIsSubmitting(false);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* HEADER META BAR */}
      <div className="bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center font-black text-sm shadow-xs">
            ISS
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Transaction Code</span>
              <span className="font-mono text-xs font-bold bg-blue-200 dark:bg-blue-900 text-blue-900 dark:text-blue-200 px-2 py-0.5 rounded-md">
                {issueCode}
              </span>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">
              Enterprise Dispatch Record • Date: <strong>{issueDate}</strong>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleClearAll}
            className="px-3 py-1.5 text-xs font-bold bg-white dark:bg-slate-800 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-900 rounded-xl hover:bg-rose-50 dark:hover:bg-rose-950/40 flex items-center gap-1.5 shadow-2xs transition-all"
            title="Reset and clear all inputs and selections"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Clear All</span>
          </button>
          {onOpenScanner && (
            <button
              type="button"
              onClick={onOpenScanner}
              className="px-3 py-1.5 text-xs font-bold bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 border border-slate-300 dark:border-slate-700 rounded-xl hover:bg-slate-50 flex items-center gap-1.5 shadow-2xs"
            >
              <QrCode className="w-3.5 h-3.5 text-emerald-500" />
              <span>Scan QR / Barcode</span>
            </button>
          )}
          <div className="text-right text-xs">
            <span className="text-slate-400 block">Issued By</span>
            <span className="font-bold text-slate-800 dark:text-slate-200">{currentUser}</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* STEP 1: WORKER SELECTION */}
        <div className="space-y-3 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-2xl p-4">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-black text-slate-800 dark:text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
              <User className="w-4 h-4 text-blue-500" />
              <span>1. Assign Worker</span>
            </h4>
            {selectedWorker && (
              <span className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Selected
              </span>
            )}
          </div>

          {!selectedWorker ? (
            <div className="space-y-3">
              {/* QUICK WORKER CHIPS (CLICK TO POP NAME IN) */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-bold text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-blue-500 animate-pulse" />
                    <span>Quick-Select Worker (Click Name):</span>
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {effectiveWorkers.length} workers registered
                  </span>
                </div>
                <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto pr-1">
                  {effectiveWorkers.map((w) => (
                    <button
                      key={w.id}
                      type="button"
                      onClick={() => handleSelectWorker(w)}
                      className="px-2.5 py-1 text-[11px] font-bold rounded-lg bg-blue-50 hover:bg-blue-600 text-blue-700 hover:text-white dark:bg-blue-950/40 dark:text-blue-300 dark:hover:bg-blue-600 dark:hover:text-white border border-blue-200 dark:border-blue-900/60 transition-all shadow-2xs flex items-center gap-1 cursor-pointer"
                    >
                      <User className="w-3 h-3 opacity-60" />
                      <span>{w.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* SEARCH INPUT */}
              <div className="relative flex items-center">
                <Search className="w-4 h-4 absolute left-3 text-slate-400 pointer-events-none" />
                <input
                  type="text"
                  value={workerSearch}
                  onChange={(e) => setWorkerSearch(e.target.value)}
                  placeholder="Type name (e.g. Ramu, Vicky, Raghu) or ID..."
                  className="w-full pl-9 pr-8 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-500"
                />
                {workerSearch && (
                  <button
                    type="button"
                    onClick={() => setWorkerSearch('')}
                    className="absolute right-2.5 p-0.5 rounded text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                    title="Clear search"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* FILTERED WORKERS LIST OR QUICK ADD */}
              <div className="max-h-52 overflow-y-auto space-y-1.5 pr-1 divide-y divide-slate-100 dark:divide-slate-800">
                {filteredWorkers.length === 0 ? (
                  <div className="p-4 text-center text-slate-500 space-y-2 bg-white dark:bg-slate-900 rounded-xl border border-dashed border-blue-200 dark:border-blue-900">
                    <SearchX className="w-6 h-6 mx-auto text-blue-500" />
                    <div className="text-xs font-bold text-slate-800 dark:text-slate-200">
                      Worker &ldquo;{workerSearch}&rdquo; is not yet in list
                    </div>
                    <div className="text-[11px] text-slate-500">
                      Click below to add &ldquo;{workerSearch.toUpperCase()}&rdquo; to the app instantly:
                    </div>
                    <button
                      type="button"
                      onClick={() => handleQuickAddWorker(workerSearch)}
                      className="px-3.5 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add & Select &ldquo;{workerSearch.toUpperCase()}&rdquo;</span>
                    </button>
                  </div>
                ) : (
                  <>
                    {filteredWorkers.map((w) => (
                      <div
                        key={w.id}
                        onClick={() => handleSelectWorker(w)}
                        className={`p-2.5 rounded-xl cursor-pointer transition-all flex items-center justify-between ${
                          w.status === 'Inactive'
                            ? 'opacity-50 bg-slate-100 dark:bg-slate-900 cursor-not-allowed'
                            : 'bg-white dark:bg-slate-900 hover:bg-blue-50 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800'
                        }`}
                      >
                        <div>
                          <div className="font-bold text-xs text-slate-900 dark:text-slate-100">{w.name}</div>
                          <div className="text-[10px] text-slate-500 flex items-center gap-2 mt-0.5">
                            <span className="font-mono text-blue-600 dark:text-blue-400 font-bold">{w.workerCode}</span>
                            <span>•</span>
                            <span>{w.trade}</span>
                            <span>•</span>
                            <span>{w.projectSite}</span>
                          </div>
                        </div>
                        <span className="px-2.5 py-1 rounded-lg text-[10px] font-bold bg-blue-50 hover:bg-blue-100 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300">
                          Select →
                        </span>
                      </div>
                    ))}

                    {/* OPTIONAL QUICK ADD IF TYPING A SPECIFIC NAME */}
                    {workerSearch.trim().length > 2 &&
                      !filteredWorkers.some((w) => w.name.toLowerCase() === workerSearch.trim().toLowerCase()) && (
                        <div className="pt-2 text-center">
                          <button
                            type="button"
                            onClick={() => handleQuickAddWorker(workerSearch)}
                            className="text-xs text-blue-600 dark:text-blue-400 hover:underline font-bold inline-flex items-center gap-1"
                          >
                            <Plus className="w-3 h-3" />
                            <span>Add &ldquo;{workerSearch.toUpperCase()}&rdquo; as a new worker</span>
                          </button>
                        </div>
                      )}
                  </>
                )}
              </div>
            </div>
          ) : (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl p-3 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-black text-slate-900 dark:text-slate-100">{selectedWorker.name}</div>
                  <div className="text-xs text-slate-500 font-mono">{selectedWorker.workerCode} • {selectedWorker.trade}</div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedWorker(null);
                      setWorkerSearch('');
                    }}
                    className="px-2 py-1 text-xs font-bold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors flex items-center gap-1"
                    title="Clear selected worker"
                  >
                    <X className="w-3.5 h-3.5" />
                    <span>Clear</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedWorker(null)}
                    className="px-2.5 py-1 text-xs font-bold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/40 hover:bg-blue-100 rounded-lg transition-colors"
                  >
                    Change Worker
                  </button>
                </div>
              </div>

              {/* WORKER SUMMARY BADGES */}
              <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-100 dark:border-slate-800 text-center">
                <div className="bg-blue-50 dark:bg-blue-950/40 p-1.5 rounded-lg">
                  <div className="text-[10px] text-slate-500">Current Issued</div>
                  <div className="text-xs font-bold text-blue-600">{selectedWorker.assignedItemsCount || 0} items</div>
                </div>
                <div className="bg-amber-50 dark:bg-amber-950/40 p-1.5 rounded-lg">
                  <div className="text-[10px] text-slate-500">Overdue</div>
                  <div className="text-xs font-bold text-amber-600">0 items</div>
                </div>
                <div className="bg-rose-50 dark:bg-rose-950/40 p-1.5 rounded-lg">
                  <div className="text-[10px] text-slate-500">Lost</div>
                  <div className="text-xs font-bold text-rose-600">0 items</div>
                </div>
              </div>
            </div>
          )}

          {/* Department & Site */}
          <div className="grid grid-cols-2 gap-3 pt-2">
            <div>
              <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300 mb-1">
                Department *
              </label>
              <input
                type="text"
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                placeholder="e.g. Civil / MEP"
                className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl"
              />
            </div>
            <div>
              <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300 mb-1">
                Project Site *
              </label>
              <input
                type="text"
                value={site}
                onChange={(e) => setSite(e.target.value)}
                placeholder="e.g. Tower A"
                className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl"
              />
            </div>
          </div>
        </div>

        {/* STEP 2: ITEM SELECTION & REAL-TIME STOCK */}
        <div className="space-y-3 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-2xl p-4">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-black text-slate-800 dark:text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
              <Package className="w-4 h-4 text-purple-500" />
              <span>2. Select Item / Asset</span>
            </h4>
            {selectedItem && (
              <span className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Selected
              </span>
            )}
          </div>

          {!selectedItem ? (
            <div className="space-y-2">
              <div className="flex gap-2">
                <div className="relative flex-1 flex items-center">
                  <Search className="w-4 h-4 absolute left-3 text-slate-400 pointer-events-none" />
                  <input
                    type="text"
                    value={itemSearch}
                    onChange={(e) => setItemSearch(e.target.value)}
                    placeholder="Search by name, asset ID, category..."
                    className="w-full pl-9 pr-8 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-purple-500"
                  />
                  {itemSearch && (
                    <button
                      type="button"
                      onClick={() => setItemSearch('')}
                      className="absolute right-2.5 p-0.5 rounded text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                      title="Clear search"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
                <select
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value as any)}
                  className="px-2.5 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
                >
                  <option value="All">All Categories</option>
                  <option value="Material">Material</option>
                  <option value="Equipment">Equipment</option>
                  <option value="Tool">Tool</option>
                  <option value="Consumable">Consumable</option>
                  <option value="PPE">PPE</option>
                </select>
              </div>

              <div className="max-h-48 overflow-y-auto space-y-1.5 pr-1 divide-y divide-slate-100 dark:divide-slate-800">
                {filteredItems.length === 0 ? (
                  <div className="p-4 text-center text-slate-400 space-y-1 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                    <SearchX className="w-5 h-5 mx-auto text-amber-500" />
                    <div className="text-xs font-bold text-slate-700 dark:text-slate-300">
                      {itemSearch ? 'No matching items found' : 'No items in inventory'}
                    </div>
                    <div className="text-[10px]">
                      {itemSearch ? `No assets matching "${itemSearch}"` : 'Please add new assets from Materials/Equipment/Tools/Consumables/PPE inventory pages.'}
                    </div>
                  </div>
                ) : (
                  filteredItems.map((item) => (
                    <div
                      key={item.id}
                      onClick={() => handleSelectItem(item)}
                      className={`p-2.5 rounded-xl cursor-pointer transition-all flex items-center justify-between ${
                        item.availableQuantity <= 0
                          ? 'opacity-50 bg-slate-100 dark:bg-slate-900 cursor-not-allowed'
                          : 'bg-white dark:bg-slate-900 hover:bg-purple-50 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800'
                      }`}
                    >
                      <div>
                        <div className="font-bold text-xs text-slate-900 dark:text-slate-100">{item.name}</div>
                        <div className="text-[10px] text-slate-500 flex items-center gap-2 mt-0.5">
                          <span className="font-mono text-purple-600 dark:text-purple-400">{item.code}</span>
                          <span>•</span>
                          <span className="px-1.5 py-0.2 rounded bg-slate-100 dark:bg-slate-800 font-semibold">{item.category}</span>
                          <span>•</span>
                          <span>{item.location}</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-xs font-extrabold text-blue-600 dark:text-blue-400">
                          {item.availableQuantity} {item.unit}
                        </div>
                        <div className="text-[10px] text-slate-400">Available</div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          ) : (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl p-3 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-black text-slate-900 dark:text-slate-100">{selectedItem.name}</div>
                  <div className="text-xs text-slate-500 font-mono">
                    {selectedItem.code} • Category: {selectedItem.category} • Location: {selectedItem.location}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleClearItem}
                    className="px-2 py-1 text-xs font-bold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors flex items-center gap-1"
                    title="Clear selected item"
                  >
                    <X className="w-3.5 h-3.5" />
                    <span>Clear</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedItem(null)}
                    className="px-2.5 py-1 text-xs font-bold text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-950/40 hover:bg-purple-100 rounded-lg transition-colors"
                  >
                    Change Item
                  </button>
                </div>
              </div>

              {/* REAL TIME STOCK INDICATOR */}
              <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  <span className="text-xs font-bold text-emerald-800 dark:text-emerald-200">Real-time Stock</span>
                </div>
                <div className="text-right">
                  <span className="text-sm font-black text-emerald-700 dark:text-emerald-300">
                    {selectedItem.availableQuantity} {selectedItem.unit}
                  </span>
                  <span className="text-[10px] text-emerald-600 block">Ready to issue</span>
                </div>
              </div>
            </div>
          )}

          {/* QUANTITY & EXPECTED RETURN */}
          <div className="grid grid-cols-2 gap-3 pt-2">
            <div>
              <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300 mb-1">
                Quantity to Issue *
              </label>
              <input
                type="number"
                min={1}
                max={selectedItem?.availableQuantity || 9999}
                value={quantity}
                onChange={(e) => setQuantity(parseInt(e.target.value) || 1)}
                className="w-full px-3 py-2 text-xs font-extrabold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300 mb-1">
                Expected Return Date {isConsumable && '(Not Required for Consumables)'}
              </label>
              <input
                type="date"
                disabled={isConsumable}
                value={expectedReturnDate}
                onChange={(e) => setExpectedReturnDate(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl disabled:opacity-40"
              />
            </div>
          </div>
        </div>
      </div>

      {/* ADDITIONAL DISPATCH PARAMETERS */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-2xl p-4">
        <div>
          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
            Priority Level
          </label>
          <select
            value={priority}
            onChange={(e) => setPriority(e.target.value as IssuePriority)}
            className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl font-bold"
          >
            <option value="Low">Low Priority</option>
            <option value="Medium">Medium Priority</option>
            <option value="High">High Priority</option>
            <option value="Critical">Critical Priority</option>
          </select>
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
            Dispatch Purpose / Work Order
          </label>
          <input
            type="text"
            value={purpose}
            onChange={(e) => setPurpose(e.target.value)}
            placeholder="e.g. Electrical wiring at Level 4 / Slab casting"
            className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl"
          />
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
            Remarks & Condition Notes
          </label>
          <input
            type="text"
            value={remarks}
            onChange={(e) => setRemarks(e.target.value)}
            placeholder="e.g. Verified good working condition, battery full"
            className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl"
          />
        </div>
      </div>

      {/* DIGITAL SIGNATURE CANVAS */}
      <div className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-2xl p-4 space-y-2">
        <div className="flex items-center justify-between">
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
            <PenTool className="w-3.5 h-3.5 text-blue-500" />
            <span>Worker Digital Signature (Optional)</span>
          </label>
          <button
            type="button"
            onClick={clearCanvas}
            className="text-[11px] font-bold text-rose-600 dark:text-rose-400 hover:underline flex items-center gap-1"
          >
            <RotateCcw className="w-3 h-3" />
            Clear Signature
          </button>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl overflow-hidden shadow-2xs">
          <canvas
            ref={canvasRef}
            width={500}
            height={100}
            onMouseDown={startDrawing}
            onMouseMove={draw}
            onMouseUp={stopDrawing}
            onMouseLeave={stopDrawing}
            onTouchStart={startDrawing}
            onTouchMove={draw}
            onTouchEnd={stopDrawing}
            className="w-full touch-none cursor-crosshair bg-white"
          />
        </div>
        <p className="text-[10px] text-slate-400 text-center">
          Worker signs above to acknowledge receipt of issued assets.
        </p>
      </div>

      {/* FORM ACTION BUTTONS */}
      <div className="flex items-center justify-end gap-3 pt-2">
        <button
          type="button"
          onClick={onCancel}
          className="px-5 py-2.5 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700 rounded-xl transition-all"
        >
          Cancel
        </button>
        <button
          type="submit"
          disabled={isSubmitting || !selectedWorker || !selectedItem}
          className="px-6 py-2.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-md transition-all disabled:opacity-50 flex items-center gap-2"
        >
          {isSubmitting ? 'Processing Dispatch...' : 'Confirm & Issue Item'}
        </button>
      </div>
    </form>
  );
};
