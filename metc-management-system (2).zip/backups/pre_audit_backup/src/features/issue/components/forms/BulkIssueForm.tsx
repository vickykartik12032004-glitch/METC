import React, { useState } from 'react';
import type { METCItem, Worker } from '../../../../types';
import type { BulkWorkerIssuePayload, IssuePriority } from '../../types';
import { Users, CheckSquare, Square, AlertCircle, Send } from 'lucide-react';
import { toast } from 'sonner';
import { INITIAL_WORKERS } from '../../../../data/mockData';
import { useWorkerStore } from '../../../../store/useWorkerStore';

interface Props {
  workers: Worker[];
  items: METCItem[];
  currentUser: string;
  onSubmit: (payload: Omit<BulkWorkerIssuePayload, 'issuedBy'>) => Promise<boolean>;
  onCancel: () => void;
}

export const BulkIssueForm: React.FC<Props> = ({
  workers,
  items,
  currentUser,
  onSubmit,
  onCancel,
}) => {
  const storeWorkers = useWorkerStore((s) => s.workers);
  const effectiveWorkers = workers?.length > 0
    ? workers
    : (storeWorkers?.length > 0 ? storeWorkers : INITIAL_WORKERS);

  const [selectedWorkerIds, setSelectedWorkerIds] = useState<string[]>([]);
  const [selectedItemIds, setSelectedItemIds] = useState<string[]>([]);
  const [site, setSite] = useState('Main Project Site');
  const [department, setDepartment] = useState('Site Operations');
  const [purpose, setPurpose] = useState('Bulk Safety & Tool Distribution');
  const [priority, setPriority] = useState<IssuePriority>('Medium');
  const [remarks, setRemarks] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const toggleWorker = (id: string) => {
    setSelectedWorkerIds((prev) =>
      prev.includes(id) ? prev.filter((wId) => wId !== id) : [...prev, id]
    );
  };

  const toggleAllWorkers = () => {
    if (selectedWorkerIds.length === effectiveWorkers.length) {
      setSelectedWorkerIds([]);
    } else {
      setSelectedWorkerIds(effectiveWorkers.map((w) => w.id));
    }
  };

  const toggleItem = (id: string) => {
    setSelectedItemIds((prev) =>
      prev.includes(id) ? prev.filter((iId) => iId !== id) : [...prev, id]
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (selectedWorkerIds.length === 0) {
      toast.error('Please select at least one worker for bulk issue.');
      return;
    }

    if (selectedItemIds.length === 0) {
      toast.error('Please select at least one item for bulk issue.');
      return;
    }

    setIsSubmitting(true);

    const payload: Omit<BulkWorkerIssuePayload, 'issuedBy'> = {
      workerIds: selectedWorkerIds,
      itemIds: selectedItemIds,
      site,
      department,
      purpose,
      priority,
      remarks,
    };

    const success = await onSubmit(payload);
    setIsSubmitting(false);
  };

  const totalCalculatedTransactions = selectedWorkerIds.length * selectedItemIds.length;

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-900 rounded-2xl p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-black">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-black text-slate-900 dark:text-slate-100">Bulk Issue & Dispatch Wizard</h3>
            <p className="text-xs text-slate-500">Assign multiple items to a team or shift of workers simultaneously</p>
          </div>
        </div>

        <div className="text-right">
          <span className="text-[10px] text-slate-400 block uppercase font-bold">Planned Dispatches</span>
          <span className="text-lg font-black text-indigo-600 dark:text-indigo-400">
            {totalCalculatedTransactions} Records
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* SELECT WORKERS */}
        <div className="space-y-2 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-2xl p-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-700">
            <h4 className="text-xs font-black text-slate-800 dark:text-slate-200 uppercase tracking-wider">
              1. Select Workers ({selectedWorkerIds.length}/{effectiveWorkers.length})
            </h4>
            <button
              type="button"
              onClick={toggleAllWorkers}
              className="text-xs font-bold text-indigo-600 hover:underline"
            >
              {selectedWorkerIds.length === effectiveWorkers.length ? 'Deselect All' : 'Select All Workers'}
            </button>
          </div>

          <div className="max-h-56 overflow-y-auto space-y-1 pr-1">
            {effectiveWorkers.map((w) => {
              const isSelected = selectedWorkerIds.includes(w.id);
              return (
                <div
                  key={w.id}
                  onClick={() => toggleWorker(w.id)}
                  className={`p-2.5 rounded-xl cursor-pointer transition-all flex items-center justify-between ${
                    isSelected
                      ? 'bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-300 dark:border-indigo-800'
                      : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    {isSelected ? (
                      <CheckSquare className="w-4 h-4 text-indigo-600" />
                    ) : (
                      <Square className="w-4 h-4 text-slate-400" />
                    )}
                    <div>
                      <div className="font-bold text-xs text-slate-900 dark:text-slate-100">{w.name}</div>
                      <div className="text-[10px] text-slate-500 font-mono">{w.workerCode} • {w.trade}</div>
                    </div>
                  </div>
                  <span className="text-[10px] text-slate-400">{w.projectSite}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* SELECT ITEMS */}
        <div className="space-y-2 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-2xl p-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-700">
            <h4 className="text-xs font-black text-slate-800 dark:text-slate-200 uppercase tracking-wider">
              2. Select Items ({selectedItemIds.length}/{items.length})
            </h4>
          </div>

          <div className="max-h-56 overflow-y-auto space-y-1 pr-1">
            {items.map((item) => {
              const isSelected = selectedItemIds.includes(item.id);
              return (
                <div
                  key={item.id}
                  onClick={() => toggleItem(item.id)}
                  className={`p-2.5 rounded-xl cursor-pointer transition-all flex items-center justify-between ${
                    isSelected
                      ? 'bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-300 dark:border-indigo-800'
                      : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    {isSelected ? (
                      <CheckSquare className="w-4 h-4 text-indigo-600" />
                    ) : (
                      <Square className="w-4 h-4 text-slate-400" />
                    )}
                    <div>
                      <div className="font-bold text-xs text-slate-900 dark:text-slate-100">{item.name}</div>
                      <div className="text-[10px] text-slate-500 font-mono">{item.code} • {item.category}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-bold text-blue-600">{item.availableQuantity} {item.unit}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* COMMON PARAMETERS */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-2xl p-4">
        <div>
          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Target Site</label>
          <input
            type="text"
            value={site}
            onChange={(e) => setSite(e.target.value)}
            className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl"
          />
        </div>
        <div>
          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Department</label>
          <input
            type="text"
            value={department}
            onChange={(e) => setDepartment(e.target.value)}
            className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl"
          />
        </div>
        <div>
          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Purpose / Work Order</label>
          <input
            type="text"
            value={purpose}
            onChange={(e) => setPurpose(e.target.value)}
            className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl"
          />
        </div>
      </div>

      <div className="flex items-center justify-end gap-3">
        <button
          type="button"
          onClick={onCancel}
          className="px-5 py-2.5 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 rounded-xl"
        >
          Cancel
        </button>
        <button
          type="submit"
          disabled={isSubmitting || totalCalculatedTransactions === 0}
          className="px-6 py-2.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-md transition-all disabled:opacity-50 flex items-center gap-2"
        >
          <Send className="w-4 h-4" />
          <span>{isSubmitting ? 'Executing Bulk Issue...' : `Confirm Bulk Dispatch (${totalCalculatedTransactions})`}</span>
        </button>
      </div>
    </form>
  );
};
