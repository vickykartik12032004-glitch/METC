import React, { useState } from 'react';
import type { METCItem, Worker } from '../../../../types';
import { QrCode, Barcode, X, CheckCircle, Search, Camera } from 'lucide-react';
import { toast } from 'sonner';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  items: METCItem[];
  workers: Worker[];
  onSelectScannedItem?: (item: METCItem) => void;
  onSelectScannedWorker?: (worker: Worker) => void;
}

export const QRBarcodeScannerModal: React.FC<Props> = ({
  isOpen,
  onClose,
  items,
  workers,
  onSelectScannedItem,
  onSelectScannedWorker,
}) => {
  const [scanCode, setScanCode] = useState('');
  const [isScanning, setIsScanning] = useState(false);

  if (!isOpen) return null;

  const handleSimulateScan = () => {
    setIsScanning(true);
    setTimeout(() => {
      setIsScanning(false);
      const codeToSearch = scanCode.trim().toUpperCase();

      if (!codeToSearch) {
        toast.error('Enter a QR/Barcode string or pick a code below');
        return;
      }

      // Check item code
      const foundItem = items.find(
        (i) => i.code.toUpperCase() === codeToSearch || i.name.toUpperCase().includes(codeToSearch)
      );

      if (foundItem) {
        toast.success(`Scanned Item: ${foundItem.name} (${foundItem.code})`);
        if (onSelectScannedItem) onSelectScannedItem(foundItem);
        onClose();
        return;
      }

      // Check worker code
      const foundWorker = workers.find(
        (w) =>
          w.workerCode.toUpperCase() === codeToSearch ||
          w.badgeNumber?.toUpperCase() === codeToSearch ||
          w.name.toUpperCase().includes(codeToSearch)
      );

      if (foundWorker) {
        toast.success(`Scanned Worker Badge: ${foundWorker.name} (${foundWorker.workerCode})`);
        if (onSelectScannedWorker) onSelectScannedWorker(foundWorker);
        onClose();
        return;
      }

      toast.error(`Code "${codeToSearch}" not found in system database.`);
    }, 800);
  };

  const sampleItemCodes = items.slice(0, 4);
  const sampleWorkerCodes = workers.slice(0, 4);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4">
        {/* HEADER */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-300 flex items-center justify-center">
              <QrCode className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                Enterprise Barcode / QR Scanner
              </h3>
              <p className="text-[11px] text-slate-500">
                Scan asset barcodes or worker identification badges
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* SCANNER VIEWFINDER MOCK */}
        <div className="relative bg-slate-950 rounded-2xl h-48 flex flex-col items-center justify-center border-2 border-dashed border-emerald-500/50 overflow-hidden">
          <div className="absolute inset-x-0 h-0.5 bg-emerald-500 shadow-[0_0_15px_#10b981] animate-bounce" />
          <Camera className="w-8 h-8 text-emerald-400/80 mb-2" />
          <p className="text-xs text-slate-300 font-medium">Position Barcode / QR Code inside frame</p>
          <p className="text-[10px] text-slate-500 mt-1">Camera Feed Active • Auto-Focusing...</p>
        </div>

        {/* MANUAL INPUT */}
        <div className="space-y-2">
          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
            Manual Scanner Input / Code String
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              value={scanCode}
              onChange={(e) => setScanCode(e.target.value)}
              placeholder="e.g. EQP-101, TOL-303, WRK-001..."
              className="flex-1 px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-mono uppercase font-bold"
            />
            <button
              onClick={handleSimulateScan}
              disabled={isScanning}
              className="px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs disabled:opacity-50 flex items-center gap-1.5"
            >
              <Search className="w-3.5 h-3.5" />
              <span>{isScanning ? 'Decoding...' : 'Decode Scan'}</span>
            </button>
          </div>
        </div>

        {/* QUICK SAMPLES FOR TEST */}
        <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
          <span className="text-[10px] font-bold text-slate-400 block uppercase">
            Click Quick Sample Codes To Test
          </span>

          <div className="flex flex-wrap gap-1.5">
            {sampleItemCodes.map((i) => (
              <button
                key={i.id}
                type="button"
                onClick={() => {
                  setScanCode(i.code);
                  if (onSelectScannedItem) onSelectScannedItem(i);
                  toast.success(`Selected Scanned Item: ${i.name}`);
                  onClose();
                }}
                className="px-2.5 py-1 text-[11px] font-mono font-bold bg-slate-100 dark:bg-slate-800 hover:bg-emerald-100 dark:hover:bg-emerald-950 text-slate-700 dark:text-slate-200 rounded-lg border border-slate-200 dark:border-slate-700"
              >
                Item: {i.code}
              </button>
            ))}

            {sampleWorkerCodes.map((w) => (
              <button
                key={w.id}
                type="button"
                onClick={() => {
                  setScanCode(w.workerCode);
                  if (onSelectScannedWorker) onSelectScannedWorker(w);
                  toast.success(`Selected Scanned Worker: ${w.name}`);
                  onClose();
                }}
                className="px-2.5 py-1 text-[11px] font-mono font-bold bg-slate-100 dark:bg-slate-800 hover:bg-blue-100 dark:hover:bg-blue-950 text-slate-700 dark:text-slate-200 rounded-lg border border-slate-200 dark:border-slate-700"
              >
                Badge: {w.workerCode}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
