import React, { useRef } from 'react';
import type { EnterpriseIssue } from '../../types';
import { Printer, X, ShieldCheck, QrCode, Barcode } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  issue: EnterpriseIssue | null;
}

export const IssueSlipModal: React.FC<Props> = ({ isOpen, onClose, issue }) => {
  const printRef = useRef<HTMLDivElement | null>(null);

  if (!isOpen || !issue) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs animate-in fade-in duration-150 print:bg-white print:p-0">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-2xl w-full p-6 shadow-2xl space-y-6 print:border-none print:shadow-none print:max-w-none print:w-full print:rounded-none">
        {/* HEADER CONTROLS (Hidden on Print) */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800 print:hidden">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-blue-600" />
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Printable Material & Tool Dispatch Slip
            </h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5"
            >
              <Printer className="w-4 h-4" />
              <span>Print Slip</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* PRINTABLE SLIP CONTENT AREA */}
        <div ref={printRef} className="p-6 bg-white text-slate-900 rounded-2xl border border-slate-200 space-y-6 font-sans">
          {/* SLIP HEADER */}
          <div className="flex items-center justify-between border-b-2 border-slate-900 pb-4">
            <div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-slate-900 text-white font-black flex items-center justify-center text-xs">
                  MOUNTEC
                </div>
                <div>
                  <h1 className="text-lg font-black tracking-tight uppercase">MOUNTEC CONSTRUCTION GROUP</h1>
                  <p className="text-[10px] text-slate-600 font-semibold">Enterprise Equipment & Material Dispatch Slip</p>
                </div>
              </div>
            </div>

            <div className="text-right">
              <div className="text-xs font-mono font-black text-blue-700 bg-blue-50 px-2.5 py-1 rounded-md border border-blue-200">
                {issue.issueCode}
              </div>
              <p className="text-[10px] text-slate-500 mt-1">Issue Date: {issue.issueDate?.split('T')[0]}</p>
            </div>
          </div>

          {/* WORKER & LOCATION DETAILS */}
          <div className="grid grid-cols-2 gap-4 text-xs bg-slate-50 p-4 rounded-xl border border-slate-200">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase block">WORKER DETAILS</span>
              <p className="font-bold text-slate-900 text-sm mt-0.5">{issue.workerName}</p>
              <p className="text-slate-600 font-mono">Code: {issue.workerCode || 'N/A'}</p>
              <p className="text-slate-600">Department: {issue.department}</p>
            </div>

            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase block">SITE & LOCATION</span>
              <p className="font-bold text-slate-900 mt-0.5">{issue.site}</p>
              <p className="text-slate-600">Expected Return: <strong>{issue.expectedReturnDate || 'N/A (Consumable)'}</strong></p>
              <p className="text-slate-600">Priority: <strong className="uppercase">{issue.priority}</strong></p>
            </div>
          </div>

          {/* ITEM DETAILS TABLE */}
          <div className="border border-slate-200 rounded-xl overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 font-bold text-slate-700 border-b border-slate-200">
                <tr>
                  <th className="p-3">Asset Tag / ID</th>
                  <th className="p-3">Item Description</th>
                  <th className="p-3">Category</th>
                  <th className="p-3 text-right">Quantity</th>
                </tr>
              </thead>
              <tbody>
                <tr className="divide-y divide-slate-100">
                  <td className="p-3 font-mono font-bold text-blue-700">{issue.assetId}</td>
                  <td className="p-3 font-bold">{issue.itemName} {issue.serialNumber && `(SN: ${issue.serialNumber})`}</td>
                  <td className="p-3">{issue.itemCategory}</td>
                  <td className="p-3 text-right font-black text-sm">{issue.quantity}</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* REMARKS */}
          {issue.remarks && (
            <div className="text-xs bg-slate-50 p-3 rounded-xl border border-slate-200">
              <span className="font-bold text-slate-500">Remarks / Conditions:</span> {issue.remarks}
            </div>
          )}

          {/* SIGNATURES & VERIFICATION */}
          <div className="grid grid-cols-2 gap-6 pt-6 border-t border-slate-200">
            <div className="text-center space-y-2">
              <div className="h-16 border-b border-dashed border-slate-400 flex items-center justify-center">
                {issue.signatureUrl ? (
                  <img src={issue.signatureUrl} alt="Signature" className="h-12 object-contain" />
                ) : (
                  <span className="text-[11px] text-slate-300 italic">Worker Signature Here</span>
                )}
              </div>
              <p className="text-xs font-bold text-slate-800">{issue.workerName}</p>
              <p className="text-[10px] text-slate-400">Worker Acknowledgment</p>
            </div>

            <div className="text-center space-y-2">
              <div className="h-16 border-b border-dashed border-slate-400 flex items-center justify-center">
                <span className="text-xs font-bold text-slate-800">{issue.issuedBy}</span>
              </div>
              <p className="text-xs font-bold text-slate-800">{issue.issuedBy}</p>
              <p className="text-[10px] text-slate-400">Authorized Store Keeper</p>
            </div>
          </div>

          {/* QR & BARCODE REPRESENTATION */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-100 text-[10px] text-slate-400">
            <div className="flex items-center gap-2">
              <QrCode className="w-6 h-6 text-slate-800" />
              <span>Verify Code: {issue.issueCode}</span>
            </div>
            <div className="flex items-center gap-2 font-mono">
              <Barcode className="w-10 h-6 text-slate-800" />
              <span>*{issue.issueCode}*</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
