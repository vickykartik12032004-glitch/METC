import React from 'react';
import type { EnterpriseIssue } from '../../types';
import { StatusBadge } from '../../../../components/common/StatusBadge';
import { formatDateTime } from '../../../../lib/utils';
import {
  X,
  User,
  Package,
  Calendar,
  Clock,
  FileText,
  PenTool,
  CheckCircle2,
  Printer,
  History,
  Tag,
} from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  issue: EnterpriseIssue | null;
  onPrintSlip?: (issue: EnterpriseIssue) => void;
}

export const IssueDetailsModal: React.FC<Props> = ({
  isOpen,
  onClose,
  issue,
  onPrintSlip,
}) => {
  if (!isOpen || !issue) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-3xl w-full max-h-[90vh] overflow-y-auto p-6 shadow-2xl space-y-6">
        {/* HEADER BAR */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="font-mono text-xs font-black text-blue-600 dark:text-blue-400 bg-blue-100 dark:bg-blue-950 px-2.5 py-0.5 rounded-md">
                {issue.issueCode}
              </span>
              <StatusBadge status={issue.status} />
            </div>
            <h2 className="text-xl font-black text-slate-900 dark:text-slate-100">
              Dispatch Transaction Details
            </h2>
          </div>

          <div className="flex items-center gap-2">
            {onPrintSlip && (
              <button
                onClick={() => onPrintSlip(issue)}
                className="px-3 py-1.5 text-xs font-bold text-white bg-purple-600 hover:bg-purple-700 rounded-xl shadow-xs flex items-center gap-1.5"
              >
                <Printer className="w-4 h-4" />
                <span>Print Slip</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* 3 COLUMN INFORMATION GRID */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* WORKER CARD */}
          <div className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-2xl p-4 space-y-2">
            <h4 className="text-xs font-black text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
              <User className="w-4 h-4 text-blue-500" />
              <span>Worker Information</span>
            </h4>
            <div>
              <div className="font-extrabold text-sm text-slate-900 dark:text-slate-100">{issue.workerName}</div>
              <div className="text-xs text-slate-500 font-mono mt-0.5">{issue.workerCode || 'N/A'}</div>
            </div>
            <div className="text-xs text-slate-600 dark:text-slate-300 space-y-1 pt-2 border-t border-slate-200/60 dark:border-slate-700/60">
              <div><strong>Department:</strong> {issue.department}</div>
              <div><strong>Site:</strong> {issue.site}</div>
            </div>
          </div>

          {/* ITEM CARD */}
          <div className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-2xl p-4 space-y-2">
            <h4 className="text-xs font-black text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
              <Package className="w-4 h-4 text-purple-500" />
              <span>Item & Asset</span>
            </h4>
            <div>
              <div className="font-extrabold text-sm text-slate-900 dark:text-slate-100">{issue.itemName}</div>
              <div className="text-xs text-purple-600 font-mono font-bold mt-0.5">{issue.assetId}</div>
            </div>
            <div className="text-xs text-slate-600 dark:text-slate-300 space-y-1 pt-2 border-t border-slate-200/60 dark:border-slate-700/60">
              <div><strong>Category:</strong> {issue.itemCategory}</div>
              <div><strong>Quantity Issued:</strong> {issue.quantity} units</div>
              {issue.serialNumber && <div><strong>Serial Number:</strong> {issue.serialNumber}</div>}
            </div>
          </div>

          {/* TRANSACTION METRICS */}
          <div className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-2xl p-4 space-y-2">
            <h4 className="text-xs font-black text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-emerald-500" />
              <span>Dates & Priority</span>
            </h4>
            <div className="text-xs space-y-1.5 text-slate-700 dark:text-slate-200">
              <div><strong>Issued Date:</strong> {issue.issueDate ? formatDateTime(issue.issueDate) : 'N/A'}</div>
              <div><strong>Expected Return:</strong> {issue.expectedReturnDate || 'N/A (Consumable)'}</div>
              <div>
                <strong>Priority:</strong>{' '}
                <span className="px-2 py-0.5 bg-slate-200 dark:bg-slate-700 rounded-md font-bold text-[10px]">
                  {issue.priority}
                </span>
              </div>
              <div><strong>Issued By:</strong> {issue.issuedBy}</div>
            </div>
          </div>
        </div>

        {/* PURPOSE & REMARKS */}
        {(issue.purpose || issue.remarks) && (
          <div className="bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-2">
            {issue.purpose && (
              <div>
                <span className="text-[11px] font-bold text-slate-400 uppercase block">Purpose / Work Order</span>
                <p className="text-xs text-slate-800 dark:text-slate-200 font-medium">{issue.purpose}</p>
              </div>
            )}
            {issue.remarks && (
              <div>
                <span className="text-[11px] font-bold text-slate-400 uppercase block">Remarks</span>
                <p className="text-xs text-slate-800 dark:text-slate-200 font-medium">{issue.remarks}</p>
              </div>
            )}
          </div>
        )}

        {/* DIGITAL SIGNATURE PREVIEW */}
        {issue.signatureUrl && (
          <div className="bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase flex items-center gap-1.5">
              <PenTool className="w-3.5 h-3.5 text-blue-500" />
              <span>Worker Digital Signature</span>
            </span>
            <div className="bg-white p-2 rounded-xl border border-slate-200 max-w-xs">
              <img src={issue.signatureUrl} alt="Signature" className="h-16 object-contain mx-auto" />
            </div>
          </div>
        )}

        {/* TIMELINE */}
        <div className="space-y-3">
          <h4 className="text-xs font-black text-slate-800 dark:text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
            <History className="w-4 h-4 text-blue-500" />
            <span>Transaction Lifecycle Timeline</span>
          </h4>

          <div className="relative pl-6 border-l-2 border-blue-500/30 space-y-4">
            {(issue.timeline || []).map((tl, idx) => (
              <div key={idx} className="relative">
                <div className="absolute -left-[31px] top-0.5 w-4 h-4 rounded-full bg-blue-600 border-2 border-white dark:border-slate-900" />
                <div className="text-xs font-bold text-slate-900 dark:text-slate-100">{tl.action}</div>
                <div className="text-[11px] text-slate-500">
                  {formatDateTime(tl.date)} • By: {tl.by}
                </div>
                {tl.notes && <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">{tl.notes}</p>}
              </div>
            ))}
          </div>
        </div>

        {/* CLOSE BUTTON */}
        <div className="flex justify-end pt-4 border-t border-slate-200 dark:border-slate-800">
          <button
            onClick={onClose}
            className="px-6 py-2 text-xs font-bold text-slate-700 bg-slate-100 dark:bg-slate-800 dark:text-slate-300 hover:bg-slate-200 rounded-xl"
          >
            Close Details
          </button>
        </div>
      </div>
    </div>
  );
};
