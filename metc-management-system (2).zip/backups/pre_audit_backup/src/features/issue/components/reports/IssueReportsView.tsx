import React, { useState, useMemo } from 'react';
import type { EnterpriseIssue } from '../../types';
import { ExportButton } from '../../../../components/common/ExportButton';
import { FileBarChart2, FileText, Download, Filter, Building, User, Tag } from 'lucide-react';

interface Props {
  issues: EnterpriseIssue[];
}

export const IssueReportsView: React.FC<Props> = ({ issues }) => {
  const [reportType, setReportType] = useState<
    'register' | 'summary' | 'worker' | 'site' | 'category'
  >('register');

  // Issue Register Export Data
  const registerColumns = [
    { header: 'Issue Code', key: 'issueCode' },
    { header: 'Worker Name', key: 'workerName' },
    { header: 'Department', key: 'department' },
    { header: 'Site', key: 'site' },
    { header: 'Item Name', key: 'itemName' },
    { header: 'Asset ID', key: 'assetId' },
    { header: 'Category', key: 'itemCategory' },
    { header: 'Qty', key: 'quantity' },
    { header: 'Issue Date', key: 'issueDate' },
    { header: 'Expected Return', key: 'expectedReturnDate' },
    { header: 'Issued By', key: 'issuedBy' },
    { header: 'Status', key: 'status' },
  ];

  // Worker Issue Report Aggregation
  const workerReportData = useMemo(() => {
    const map = new Map<string, { workerName: string; totalIssued: number; active: number; overdue: number }>();

    for (const iss of issues) {
      const existing = map.get(iss.workerId) || {
        workerName: iss.workerName,
        totalIssued: 0,
        active: 0,
        overdue: 0,
      };

      existing.totalIssued += iss.quantity;
      if (iss.status === 'Active') existing.active += iss.quantity;
      if (iss.status === 'Overdue') existing.overdue += iss.quantity;

      map.set(iss.workerId, existing);
    }

    return Array.from(map.values());
  }, [issues]);

  const workerReportColumns = [
    { header: 'Worker Name', key: 'workerName' },
    { header: 'Total Quantity Issued', key: 'totalIssued' },
    { header: 'Currently Active Qty', key: 'active' },
    { header: 'Overdue Qty', key: 'overdue' },
  ];

  // Site Issue Report Aggregation
  const siteReportData = useMemo(() => {
    const map = new Map<string, { site: string; totalTransactions: number; active: number; overdue: number }>();

    for (const iss of issues) {
      const existing = map.get(iss.site) || {
        site: iss.site,
        totalTransactions: 0,
        active: 0,
        overdue: 0,
      };

      existing.totalTransactions += 1;
      if (iss.status === 'Active') existing.active += 1;
      if (iss.status === 'Overdue') existing.overdue += 1;

      map.set(iss.site, existing);
    }

    return Array.from(map.values());
  }, [issues]);

  const siteReportColumns = [
    { header: 'Project Site', key: 'site' },
    { header: 'Total Transactions', key: 'totalTransactions' },
    { header: 'Active Issues', key: 'active' },
    { header: 'Overdue Issues', key: 'overdue' },
  ];

  // Category Report Aggregation
  const categoryReportData = useMemo(() => {
    const map = new Map<string, { category: string; count: number; totalQty: number }>();

    for (const iss of issues) {
      const existing = map.get(iss.itemCategory) || {
        category: iss.itemCategory,
        count: 0,
        totalQty: 0,
      };

      existing.count += 1;
      existing.totalQty += iss.quantity;

      map.set(iss.itemCategory, existing);
    }

    return Array.from(map.values());
  }, [issues]);

  const categoryReportColumns = [
    { header: 'Asset Category', key: 'category' },
    { header: 'Dispatch Count', key: 'count' },
    { header: 'Total Items Issued', key: 'totalQty' },
  ];

  return (
    <div className="space-y-6">
      {/* REPORT TYPE SELECTOR */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h3 className="text-sm font-black text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <FileBarChart2 className="w-4 h-4 text-amber-500" />
            <span>Enterprise Issue Analytics & PDF/Excel Exporter</span>
          </h3>
          <p className="text-xs text-slate-500">
            Generate printable registers, worker usage audits, site dispatch summaries
          </p>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
          {[
            { id: 'register', label: 'Issue Register' },
            { id: 'worker', label: 'Worker Report' },
            { id: 'site', label: 'Site Report' },
            { id: 'category', label: 'Category Report' },
          ].map((type) => (
            <button
              key={type.id}
              onClick={() => setReportType(type.id as any)}
              className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
                reportType === type.id
                  ? 'bg-amber-500 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
              }`}
            >
              {type.label}
            </button>
          ))}
        </div>
      </div>

      {/* REPORT DATA TABLE & EXPORT ACTION */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-black text-slate-800 dark:text-slate-200 uppercase tracking-wider">
            {reportType === 'register' && 'Complete Issue Dispatch Register'}
            {reportType === 'worker' && 'Worker Allocation & Usage Report'}
            {reportType === 'site' && 'Project Site Dispatch Summary'}
            {reportType === 'category' && 'Category Distribution Report'}
          </h4>

          <div>
            {reportType === 'register' && (
              <ExportButton title="Issue Register Report" columns={registerColumns} data={issues} filename="Issue_Register_Report" />
            )}
            {reportType === 'worker' && (
              <ExportButton title="Worker Issue Summary" columns={workerReportColumns} data={workerReportData} filename="Worker_Issue_Report" />
            )}
            {reportType === 'site' && (
              <ExportButton title="Site Issue Summary" columns={siteReportColumns} data={siteReportData} filename="Site_Issue_Report" />
            )}
            {reportType === 'category' && (
              <ExportButton title="Category Issue Summary" columns={categoryReportColumns} data={categoryReportData} filename="Category_Issue_Report" />
            )}
          </div>
        </div>

        {/* REPORT TABLE */}
        <div className="overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-xl">
          {reportType === 'register' && (
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800 font-bold text-slate-600 dark:text-slate-300">
                <tr>
                  <th className="p-3">Issue Code</th>
                  <th className="p-3">Worker</th>
                  <th className="p-3">Item</th>
                  <th className="p-3">Category</th>
                  <th className="p-3">Site</th>
                  <th className="p-3">Qty</th>
                  <th className="p-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {issues.map((i) => (
                  <tr key={i.id}>
                    <td className="p-3 font-mono font-bold text-blue-600">{i.issueCode}</td>
                    <td className="p-3 font-bold">{i.workerName}</td>
                    <td className="p-3">{i.itemName}</td>
                    <td className="p-3">{i.itemCategory}</td>
                    <td className="p-3">{i.site}</td>
                    <td className="p-3 font-bold">{i.quantity}</td>
                    <td className="p-3">{i.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {reportType === 'worker' && (
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800 font-bold text-slate-600 dark:text-slate-300">
                <tr>
                  <th className="p-3">Worker Name</th>
                  <th className="p-3">Total Qty Issued</th>
                  <th className="p-3">Active Items</th>
                  <th className="p-3">Overdue Items</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {workerReportData.map((w, idx) => (
                  <tr key={idx}>
                    <td className="p-3 font-bold">{w.workerName}</td>
                    <td className="p-3 font-bold text-blue-600">{w.totalIssued}</td>
                    <td className="p-3 font-bold text-emerald-600">{w.active}</td>
                    <td className="p-3 font-bold text-rose-600">{w.overdue}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {reportType === 'site' && (
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800 font-bold text-slate-600 dark:text-slate-300">
                <tr>
                  <th className="p-3">Project Site</th>
                  <th className="p-3">Total Transactions</th>
                  <th className="p-3">Active Issues</th>
                  <th className="p-3">Overdue Issues</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {siteReportData.map((s, idx) => (
                  <tr key={idx}>
                    <td className="p-3 font-bold">{s.site}</td>
                    <td className="p-3 font-bold text-blue-600">{s.totalTransactions}</td>
                    <td className="p-3 font-bold text-emerald-600">{s.active}</td>
                    <td className="p-3 font-bold text-rose-600">{s.overdue}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {reportType === 'category' && (
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800 font-bold text-slate-600 dark:text-slate-300">
                <tr>
                  <th className="p-3">Asset Category</th>
                  <th className="p-3">Dispatch Count</th>
                  <th className="p-3">Total Items Issued</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {categoryReportData.map((c, idx) => (
                  <tr key={idx}>
                    <td className="p-3 font-bold">{c.category}</td>
                    <td className="p-3 font-bold text-purple-600">{c.count}</td>
                    <td className="p-3 font-bold text-blue-600">{c.totalQty}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};
