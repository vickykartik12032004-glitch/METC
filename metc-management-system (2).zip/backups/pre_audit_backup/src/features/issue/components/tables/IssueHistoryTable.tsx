import React from 'react';
import type { EnterpriseIssue } from '../../types';
import { StatusBadge } from '../../../../components/common/StatusBadge';
import { formatDateTime } from '../../../../lib/utils';
import { History, User, Calendar, CheckCircle2, RefreshCw } from 'lucide-react';

interface Props {
  issues: EnterpriseIssue[];
  onViewDetails: (issue: EnterpriseIssue) => void;
}

export const IssueHistoryTable: React.FC<Props> = ({ issues, onViewDetails }) => {
  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs">
      <div className="p-4 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <History className="w-4 h-4 text-blue-500" />
          <h3 className="text-xs font-black text-slate-800 dark:text-slate-200 uppercase tracking-wider">
            Enterprise Issue Audit History
          </h3>
        </div>
        <span className="text-xs text-slate-500">Total Audit Logs: {issues.length}</span>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 font-bold border-b border-slate-200 dark:border-slate-700">
            <tr>
              <th className="p-3.5">Issue Code</th>
              <th className="p-3.5">Worker</th>
              <th className="p-3.5">Item</th>
              <th className="p-3.5">Issue Date</th>
              <th className="p-3.5">Expected / Actual Return</th>
              <th className="p-3.5">Issued By</th>
              <th className="p-3.5">Status</th>
              <th className="p-3.5 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {issues.map((iss) => (
              <tr
                key={iss.id}
                className="hover:bg-slate-50/80 dark:hover:bg-slate-800/50 transition-colors"
              >
                <td className="p-3.5 font-mono font-bold text-blue-600 dark:text-blue-400">
                  {iss.issueCode}
                </td>

                <td className="p-3.5 font-bold text-slate-900 dark:text-slate-100">
                  {iss.workerName}
                </td>

                <td className="p-3.5">
                  <div className="font-bold text-slate-900 dark:text-slate-100">{iss.itemName}</div>
                  <div className="text-[10px] text-slate-500 font-mono">{iss.assetId} ({iss.quantity} units)</div>
                </td>

                <td className="p-3.5 text-slate-600 dark:text-slate-300">
                  {formatDateTime(iss.issueDate)}
                </td>

                <td className="p-3.5 text-slate-600 dark:text-slate-300">
                  {iss.expectedReturnDate || 'N/A (Consumable)'}
                </td>

                <td className="p-3.5 text-slate-600 dark:text-slate-400">
                  {iss.issuedBy}
                </td>

                <td className="p-3.5">
                  <StatusBadge status={iss.status} />
                </td>

                <td className="p-3.5 text-right">
                  <button
                    onClick={() => onViewDetails(iss)}
                    className="px-2.5 py-1 text-[11px] font-bold text-blue-600 bg-blue-50 dark:bg-blue-950/60 dark:text-blue-400 rounded-lg hover:bg-blue-100 transition-colors"
                  >
                    Details
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
