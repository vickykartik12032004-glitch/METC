import React, { useState } from 'react';
import type { EnterpriseIssue } from '../../types';
import { StatusBadge } from '../../../../components/common/StatusBadge';
import { formatDateTime } from '../../../../lib/utils';
import { PackageX, RotateCcw, AlertTriangle, CheckSquare, Square, Calendar } from 'lucide-react';
import { toast } from 'sonner';

interface Props {
  pendingIssues: EnterpriseIssue[];
  onQuickReturn: (issue: EnterpriseIssue) => void;
  onRefresh: () => void;
}

export const PendingReturnsTable: React.FC<Props> = ({
  pendingIssues,
  onQuickReturn,
  onRefresh,
}) => {
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const toggleSelectAll = () => {
    if (selectedIds.length === pendingIssues.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(pendingIssues.map((i) => i.id));
    }
  };

  const handleBatchReturn = () => {
    if (selectedIds.length === 0) return;
    toast.success(`Batch processed return for ${selectedIds.length} items!`);
    setSelectedIds([]);
    onRefresh();
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs space-y-3 p-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h3 className="text-sm font-black text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <PackageX className="w-4 h-4 text-amber-500" />
            <span>Pending Returns Control Center</span>
          </h3>
          <p className="text-xs text-slate-500">
            Track active & overdue items due for return to site warehouse
          </p>
        </div>

        {selectedIds.length > 0 && (
          <button
            onClick={handleBatchReturn}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Process Batch Return ({selectedIds.length})</span>
          </button>
        )}
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 font-bold border-b border-slate-200 dark:border-slate-700">
            <tr>
              <th className="p-3">
                <button onClick={toggleSelectAll} className="flex items-center gap-1">
                  {selectedIds.length === pendingIssues.length && pendingIssues.length > 0 ? (
                    <CheckSquare className="w-4 h-4 text-blue-600" />
                  ) : (
                    <Square className="w-4 h-4 text-slate-400" />
                  )}
                </button>
              </th>
              <th className="p-3">Issue Code</th>
              <th className="p-3">Worker Name</th>
              <th className="p-3">Item & Category</th>
              <th className="p-3">Qty Issued</th>
              <th className="p-3">Expected Return</th>
              <th className="p-3">Status</th>
              <th className="p-3 text-right">Quick Return</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {pendingIssues.length === 0 ? (
              <tr>
                <td colSpan={8} className="p-8 text-center text-slate-400">
                  All issued assets have been returned or accounted for! Zero pending returns.
                </td>
              </tr>
            ) : (
              pendingIssues.map((iss) => {
                const isSelected = selectedIds.includes(iss.id);
                return (
                  <tr
                    key={iss.id}
                    className={`hover:bg-slate-50/80 dark:hover:bg-slate-800/50 transition-colors ${
                      isSelected ? 'bg-blue-50/50 dark:bg-blue-950/30' : ''
                    }`}
                  >
                    <td className="p-3">
                      <button onClick={() => toggleSelect(iss.id)}>
                        {isSelected ? (
                          <CheckSquare className="w-4 h-4 text-blue-600" />
                        ) : (
                          <Square className="w-4 h-4 text-slate-400" />
                        )}
                      </button>
                    </td>

                    <td className="p-3 font-mono font-bold text-blue-600 dark:text-blue-400">
                      {iss.issueCode}
                    </td>

                    <td className="p-3 font-bold text-slate-900 dark:text-slate-100">
                      {iss.workerName}
                    </td>

                    <td className="p-3">
                      <div className="font-bold text-slate-900 dark:text-slate-100">{iss.itemName}</div>
                      <div className="text-[10px] text-slate-500 font-mono">{iss.assetId}</div>
                    </td>

                    <td className="p-3">
                      <span className="font-bold text-slate-800 dark:text-slate-200">{iss.quantity}</span>
                    </td>

                    <td className="p-3">
                      <div className="flex items-center gap-1 text-slate-600 dark:text-slate-300">
                        <Calendar className="w-3 h-3 text-slate-400" />
                        <span>{iss.expectedReturnDate || 'N/A'}</span>
                      </div>
                    </td>

                    <td className="p-3">
                      <StatusBadge status={iss.status} />
                    </td>

                    <td className="p-3 text-right">
                      <button
                        onClick={() => onQuickReturn(iss)}
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1 ml-auto"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>Return Item</span>
                      </button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
