import React, { useState } from 'react';
import type { EnterpriseIssue } from '../../types';
import { StatusBadge } from '../../../../components/common/StatusBadge';
import { formatDateTime } from '../../../../lib/utils';
import {
  User,
  Calendar,
  Eye,
  Printer,
  RotateCcw,
  AlertOctagon,
  Clock,
  Send,
  Building2,
  Package,
  LayoutGrid,
  List
} from 'lucide-react';
import { toast } from 'sonner';

interface Props {
  issues: EnterpriseIssue[];
  onViewDetails: (issue: EnterpriseIssue) => void;
  onPrintSlip: (issue: EnterpriseIssue) => void;
  onQuickReturn: (issue: EnterpriseIssue) => void;
  onMarkLost: (issue: EnterpriseIssue) => void;
}

export const ActiveIssuesTable: React.FC<Props> = ({
  issues,
  onViewDetails,
  onPrintSlip,
  onQuickReturn,
  onMarkLost,
}) => {
  const [viewMode, setViewMode] = useState<'cards' | 'table' | 'auto'>('auto');

  const getDaysRemaining = (expectedReturnDate?: string) => {
    if (!expectedReturnDate) return { text: 'N/A (Consumable)', color: 'text-slate-400', isOverdue: false };
    const exp = new Date(expectedReturnDate).getTime();
    const now = new Date().getTime();
    const diffDays = Math.ceil((exp - now) / (1000 * 3600 * 24));

    if (diffDays < 0) {
      return { text: `${Math.abs(diffDays)} days overdue`, color: 'text-rose-600 dark:text-rose-400 font-bold', isOverdue: true };
    } else if (diffDays === 0) {
      return { text: 'Due Today', color: 'text-amber-600 dark:text-amber-400 font-bold', isOverdue: false };
    } else {
      return { text: `${diffDays} days remaining`, color: 'text-emerald-600 dark:text-emerald-400 font-medium', isOverdue: false };
    }
  };

  const handleSendReminder = (issue: EnterpriseIssue) => {
    toast.success(`Reminder notification sent to ${issue.workerName} for ${issue.itemName} (${issue.issueCode})`);
  };

  if (issues.length === 0) {
    return (
      <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
        <Package className="w-12 h-12 text-slate-300 dark:text-slate-700 mx-auto mb-3" />
        <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">No Active Issues</h3>
        <p className="text-xs text-slate-500 mt-1">No active issue records matching criteria.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Mobile/Desktop View Mode Switcher Toolbar */}
      <div className="flex items-center justify-between pb-1">
        <span className="text-xs text-slate-500 font-medium">
          Showing <strong className="text-slate-900 dark:text-slate-100">{issues.length}</strong> active issues
        </span>

        <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-0.5 rounded-lg border border-slate-200 dark:border-slate-700">
          <button
            type="button"
            onClick={() => setViewMode('cards')}
            title="Card View"
            className={`p-1.5 rounded-md text-xs font-medium transition-all ${
              viewMode === 'cards' || viewMode === 'auto'
                ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-2xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <LayoutGrid className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => setViewMode('table')}
            title="Table Spreadsheet View"
            className={`p-1.5 rounded-md text-xs font-medium transition-all ${
              viewMode === 'table'
                ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-2xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <List className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* MOBILE RESPONSIVE CARDS VIEW */}
      <div className={`${viewMode === 'table' ? 'hidden' : viewMode === 'cards' ? 'grid' : 'grid md:hidden'} grid-cols-1 sm:grid-cols-2 gap-3`}>
        {issues.map((iss) => {
          const daysInfo = getDaysRemaining(iss.expectedReturnDate);
          return (
            <div
              key={iss.id}
              className={`bg-white dark:bg-slate-900 border rounded-2xl p-4 shadow-xs space-y-3 transition-all ${
                daysInfo.isOverdue
                  ? 'border-rose-300 dark:border-rose-900/60 bg-rose-50/10 dark:bg-rose-950/10'
                  : 'border-slate-200 dark:border-slate-800'
              }`}
            >
              {/* Header: Issue Code & Status */}
              <div className="flex items-start justify-between gap-2">
                <div>
                  <span className="font-mono font-bold text-sm text-blue-600 dark:text-blue-400 block">
                    {iss.issueCode}
                  </span>
                  <div className="text-[10px] text-slate-400">Issued by {iss.issuedBy}</div>
                </div>
                <StatusBadge status={iss.status} />
              </div>

              {/* Worker & Item Info */}
              <div className="bg-slate-50 dark:bg-slate-800/50 p-3 rounded-xl space-y-2 text-xs">
                {/* Worker */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 font-bold text-slate-900 dark:text-slate-100">
                    <User className="w-3.5 h-3.5 text-blue-500" />
                    <span>{iss.workerName}</span>
                  </div>
                  <span className="text-[10px] text-slate-500">{iss.department}</span>
                </div>

                {/* Item */}
                <div className="flex items-center justify-between pt-1 border-t border-slate-200/60 dark:border-slate-700/60">
                  <div className="min-w-0 pr-2">
                    <div className="font-bold text-slate-800 dark:text-slate-200 truncate">{iss.itemName}</div>
                    <div className="text-[10px] text-slate-400 font-mono">{iss.assetId}</div>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 font-extrabold text-xs shrink-0">
                    Qty: {iss.quantity}
                  </span>
                </div>
              </div>

              {/* Dates & Overdue Status */}
              <div className="flex items-center justify-between text-xs px-1">
                <div className="text-slate-500">
                  <span className="text-[10px] text-slate-400 block">Expected Return:</span>
                  <div className="flex items-center gap-1 font-medium text-slate-700 dark:text-slate-300">
                    <Calendar className="w-3 h-3 text-slate-400" />
                    <span>{iss.expectedReturnDate || 'Non-Returnable'}</span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-[10px] text-slate-400 block">Status:</span>
                  <span className={daysInfo.color}>{daysInfo.text}</span>
                </div>
              </div>

              {/* Touch Action Bar */}
              <div className="pt-2 flex items-center justify-between border-t border-slate-100 dark:border-slate-800 gap-1">
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => onViewDetails(iss)}
                    className="px-2.5 py-1.5 rounded-lg bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 dark:hover:bg-blue-900/60 text-blue-700 dark:text-blue-300 font-bold text-xs flex items-center gap-1 transition-colors"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Details</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onPrintSlip(iss)}
                    className="p-1.5 rounded-lg text-slate-500 hover:text-purple-600 hover:bg-purple-50 dark:hover:bg-slate-800 transition-colors"
                    title="Print Slip"
                  >
                    <Printer className="w-4 h-4" />
                  </button>
                </div>

                {(iss.status === 'Active' || iss.status === 'Overdue') && (
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => onQuickReturn(iss)}
                      className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1 shadow-2xs transition-colors"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Return</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleSendReminder(iss)}
                      className="p-1.5 rounded-lg text-amber-600 hover:bg-amber-50 dark:hover:bg-slate-800 transition-colors"
                      title="Send Reminder"
                    >
                      <Send className="w-4 h-4" />
                    </button>

                    <button
                      type="button"
                      onClick={() => onMarkLost(iss)}
                      className="p-1.5 rounded-lg text-rose-600 hover:bg-rose-50 dark:hover:bg-slate-800 transition-colors"
                      title="Report Lost"
                    >
                      <AlertOctagon className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* DESKTOP SPREADSHEET TABLE VIEW */}
      <div className={`${viewMode === 'cards' ? 'hidden' : viewMode === 'table' ? 'block' : 'hidden md:block'} bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs`}>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 font-bold border-b border-slate-200 dark:border-slate-700">
              <tr>
                <th className="p-3.5">Issue Number & Code</th>
                <th className="p-3.5">Worker & Dept</th>
                <th className="p-3.5">Item & Asset ID</th>
                <th className="p-3.5">Qty</th>
                <th className="p-3.5">Issue Date</th>
                <th className="p-3.5">Expected Return</th>
                <th className="p-3.5">Days Remaining</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {issues.map((iss) => {
                const daysInfo = getDaysRemaining(iss.expectedReturnDate);
                return (
                  <tr
                    key={iss.id}
                    className="hover:bg-slate-50/80 dark:hover:bg-slate-800/50 transition-colors"
                  >
                    {/* Issue Code */}
                    <td className="p-3.5">
                      <span className="font-mono font-bold text-blue-600 dark:text-blue-400 block">
                        {iss.issueCode}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        By: {iss.issuedBy}
                      </span>
                    </td>

                    {/* Worker */}
                    <td className="p-3.5">
                      <div className="flex items-center gap-1.5 font-bold text-slate-900 dark:text-slate-100">
                        <User className="w-3.5 h-3.5 text-blue-500" />
                        <span>{iss.workerName}</span>
                      </div>
                      <div className="text-[10px] text-slate-500 mt-0.5">
                        {iss.department} • {iss.site}
                      </div>
                    </td>

                    {/* Item */}
                    <td className="p-3.5">
                      <div className="font-extrabold text-slate-900 dark:text-slate-100">
                        {iss.itemName}
                      </div>
                      <div className="text-[10px] text-slate-500 font-mono">
                        {iss.assetId} {iss.serialNumber && `(SN: ${iss.serialNumber})`}
                      </div>
                    </td>

                    {/* Qty */}
                    <td className="p-3.5">
                      <span className="px-2 py-0.5 bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 font-black rounded-md">
                        {iss.quantity}
                      </span>
                    </td>

                    {/* Issue Date */}
                    <td className="p-3.5 text-slate-600 dark:text-slate-300">
                      {iss.issueDate ? formatDateTime(iss.issueDate) : 'N/A'}
                    </td>

                    {/* Expected Return */}
                    <td className="p-3.5">
                      {iss.expectedReturnDate ? (
                        <div className="flex items-center gap-1 text-slate-700 dark:text-slate-300">
                          <Calendar className="w-3 h-3 text-slate-400" />
                          <span>{iss.expectedReturnDate}</span>
                        </div>
                      ) : (
                        <span className="text-slate-400 italic">Non-Returnable</span>
                      )}
                    </td>

                    {/* Days Remaining */}
                    <td className="p-3.5">
                      <span className={daysInfo.color}>{daysInfo.text}</span>
                    </td>

                    {/* Status */}
                    <td className="p-3.5">
                      <StatusBadge status={iss.status} />
                    </td>

                    {/* Actions */}
                    <td className="p-3.5 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => onViewDetails(iss)}
                          title="View Complete Details"
                          className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                        >
                          <Eye className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => onPrintSlip(iss)}
                          title="Print Issue Slip"
                          className="p-1.5 text-slate-500 hover:text-purple-600 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                        >
                          <Printer className="w-4 h-4" />
                        </button>

                        {iss.status === 'Active' || iss.status === 'Overdue' ? (
                          <>
                            <button
                              onClick={() => onQuickReturn(iss)}
                              title="Process Item Return"
                              className="p-1.5 text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/50 rounded-lg transition-colors"
                            >
                              <RotateCcw className="w-4 h-4" />
                            </button>

                            <button
                              onClick={() => handleSendReminder(iss)}
                              title="Send Overdue Reminder"
                              className="p-1.5 text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-950/50 rounded-lg transition-colors"
                            >
                              <Send className="w-4 h-4" />
                            </button>

                            <button
                              onClick={() => onMarkLost(iss)}
                              title="Report Lost Asset"
                              className="p-1.5 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/50 rounded-lg transition-colors"
                            >
                              <AlertOctagon className="w-4 h-4" />
                            </button>
                          </>
                        ) : null}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
