import { supabase, isSupabaseConfigured } from '../../../lib/supabase';
import { useTransactionStore } from '../../../store/useTransactionStore';
import { useAssetStore } from '../../../store/useAssetStore';
import { useWorkerStore } from '../../../store/useWorkerStore';
import { useNotificationStore } from '../../../store/useNotificationStore';
import { logActivity } from '../../../services/activityLogService';
import type {
  EnterpriseIssue,
  NewSingleIssuePayload,
  MultiItemIssuePayload,
  BulkWorkerIssuePayload,
  IssueKPIs,
  IssueStatus,
} from '../types';
import type { METCItem, Worker, IssueRecord } from '../../../types';

/**
 * Maps Supabase issue_transactions database row to EnterpriseIssue
 */
export function mapDbToEnterpriseIssue(row: any): EnterpriseIssue {
  const issueDateStr = row.issue_date || row.created_at || new Date().toISOString();
  const expDateStr = row.expected_return_date || null;
  const isOverdue =
    row.status === 'Active' &&
    expDateStr &&
    new Date(expDateStr).getTime() < new Date().getTime();

  return {
    id: row.id,
    issueCode: row.issue_code || `ISS-${row.id.slice(0, 6)}`,
    itemId: row.item_id,
    itemName: row.item_name || 'Asset Item',
    itemCategory: row.item_category || 'Tool',
    assetId: row.asset_id || row.code || 'AST-000',
    serialNumber: row.serial_number || undefined,
    workerId: row.worker_id,
    workerName: row.worker_name || 'Worker',
    workerCode: row.worker_code || undefined,
    department: row.department || 'Operations',
    site: row.site || row.project_site || 'Main Site',
    quantity: row.quantity || 1,
    purpose: row.purpose || undefined,
    issueDate: issueDateStr,
    expectedReturnDate: expDateStr || undefined,
    priority: row.priority || 'Medium',
    remarks: row.remarks || undefined,
    issuedBy: row.issued_by || 'Store Keeper',
    signatureUrl: row.signature_url || undefined,
    status: isOverdue ? 'Overdue' : (row.status as IssueStatus) || 'Active',
    isConsumable: row.item_category === 'Consumable' || row.is_consumable || false,
    returnedQuantity: row.returned_quantity || 0,
    timeline: row.timeline || [
      {
        id: `tl-1`,
        date: issueDateStr,
        action: 'Created',
        by: row.issued_by || 'Store Keeper',
        notes: `Issued ${row.quantity}x ${row.item_name} to ${row.worker_name}`,
      },
    ],
    attachments: row.attachments || [],
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

/**
 * Helper to check serialized item active duplicate assignment
 */
export function isSerializedItemAlreadyIssued(
  itemId: string,
  serialNumber?: string,
  existingIssues: EnterpriseIssue[] = []
): { isIssued: boolean; issuedToWorker?: string } {
  if (!serialNumber && !itemId) return { isIssued: false };

  const activeIssue = existingIssues.find(
    (i) =>
      i.status === 'Active' &&
      ((serialNumber && i.serialNumber === serialNumber) || i.itemId === itemId)
  );

  if (activeIssue) {
    return {
      isIssued: true,
      issuedToWorker: activeIssue.workerName,
    };
  }

  return { isIssued: false };
}

/**
 * Fetch all issues (combining Supabase & Zustand store)
 */
export async function fetchAllIssues(): Promise<EnterpriseIssue[]> {
  const storeIssues = useTransactionStore.getState().issues;

  if (!isSupabaseConfigured) {
    return storeIssues.map((si) => {
      const expDate = si.expectedReturnDate;
      const isOverdue =
        si.status === 'Active' && expDate && new Date(expDate).getTime() < new Date().getTime();
      return {
        id: si.id,
        issueCode: si.issueCode,
        itemId: si.itemId,
        itemName: si.itemName,
        itemCategory: si.itemCategory,
        assetId: si.itemId,
        workerId: si.workerId,
        workerName: si.workerName,
        department: 'Site Operations',
        site: si.projectSite,
        quantity: si.quantity,
        issueDate: si.issueDate,
        expectedReturnDate: si.expectedReturnDate,
        priority: 'Medium',
        remarks: si.remarks,
        issuedBy: si.issuedBy,
        status: isOverdue ? 'Overdue' : (si.status as IssueStatus),
        isConsumable: si.itemCategory === 'Consumable',
        timeline: [
          {
            id: `tl-${si.id}`,
            date: si.issueDate,
            action: 'Created',
            by: si.issuedBy,
            notes: `Issued ${si.quantity}x ${si.itemName}`,
          },
        ],
      };
    });
  }

  try {
    const { data, error } = await supabase
      .from('issue_transactions')
      .select('*')
      .order('created_at', { ascending: false });

    if (error || !data || data.length === 0) {
      // Fallback to store
      return storeIssues.map((si) => ({
        id: si.id,
        issueCode: si.issueCode,
        itemId: si.itemId,
        itemName: si.itemName,
        itemCategory: si.itemCategory,
        assetId: si.itemId,
        workerId: si.workerId,
        workerName: si.workerName,
        department: 'Site Operations',
        site: si.projectSite,
        quantity: si.quantity,
        issueDate: si.issueDate,
        expectedReturnDate: si.expectedReturnDate,
        priority: 'Medium',
        remarks: si.remarks,
        issuedBy: si.issuedBy,
        status: si.status as IssueStatus,
        isConsumable: si.itemCategory === 'Consumable',
      }));
    }

    return data.map(mapDbToEnterpriseIssue);
  } catch (err) {
    console.warn('Notice loading issues from Supabase:', err);
    return [];
  }
}

/**
 * Execute Stock Deduction & Holder Update across Asset Store & Supabase
 */
export async function executeStockAndHolderUpdate(
  itemId: string,
  quantityToIssue: number,
  workerName: string,
  workerId: string,
  isConsumable: boolean
) {
  const assetStore = useAssetStore.getState();
  const allAssets = assetStore.getAllAssets();
  const item = allAssets.find((a) => a.id === itemId || a.code === itemId);

  if (item) {
    const currentAvail = item.availableQuantity ?? item.quantity ?? 0;
    const newAvail = Math.max(0, currentAvail - quantityToIssue);
    const newStatus = newAvail === 0 ? 'Out of Stock' : newAvail <= (item.minQuantityThreshold || 5) ? 'Low Stock' : 'Issued';

    if (item.category === 'Material') {
      assetStore.updateMaterial(item.id, { availableQuantity: newAvail });
    } else if (item.category === 'Equipment') {
      assetStore.updateEquipment(item.id, { availableQuantity: newAvail, status: newStatus as any });
    } else if (item.category === 'Tool') {
      assetStore.updateTool(item.id, { availableQuantity: newAvail, status: newStatus as any });
    } else if (item.category === 'Consumable') {
      assetStore.updateConsumable(item.id, { availableQuantity: newAvail });
    } else if (item.category === 'PPE') {
      assetStore.updatePPE(item.id, { availableQuantity: newAvail });
    }

    // Sync to Supabase metc_items if configured
    if (isSupabaseConfigured) {
      try {
        await (supabase as any)
          .from('metc_items')
          .update({
            available_quantity: newAvail,
            current_holder: isConsumable ? null : workerName,
            status: newStatus,
            updated_at: new Date().toISOString(),
          })
          .eq('id', item.id);
      } catch (e) {
        console.warn('Notice updating metc_items on Supabase:', e);
      }
    }

    // Trigger Notification if Low Stock
    if (newAvail <= (item.minQuantityThreshold || 5)) {
      useNotificationStore.getState().addNotification({
        title: `Low Stock Warning: ${item.name}`,
        message: `Available quantity of ${item.name} dropped to ${newAvail} ${item.unit}. Please reorder soon.`,
        type: 'warning',
      });
    }
  }

  // Update Worker's assignedItemsCount
  const workerStore = useWorkerStore.getState();
  const worker = workerStore.workers.find((w) => w.id === workerId);
  if (worker && !isConsumable) {
    const newCount = (worker.assignedItemsCount || 0) + quantityToIssue;
    workerStore.updateWorker(worker.id, { assignedItemsCount: newCount });

    if (isSupabaseConfigured) {
      try {
        await (supabase as any)
          .from('workers')
          .update({
            assigned_items_count: newCount,
            updated_at: new Date().toISOString(),
          })
          .eq('id', worker.id);
      } catch (e) {
        console.warn('Notice updating worker assigned_items_count on Supabase:', e);
      }
    }
  }
}

/**
 * Create a Single Issue Transaction with full automatic system updates
 */
export async function createSingleIssue(
  payload: NewSingleIssuePayload
): Promise<{ success: boolean; issue?: EnterpriseIssue; error?: string }> {
  // 1. Stock Validation
  const assetStore = useAssetStore.getState();
  const allAssets = assetStore.getAllAssets();
  const asset = allAssets.find((a) => a.id === payload.itemId || a.code === payload.itemId);

  if (!asset) {
    return { success: false, error: 'Item not found in inventory master database.' };
  }

  if (asset.availableQuantity < payload.quantity) {
    return {
      success: false,
      error: `Insufficient stock! Only ${asset.availableQuantity} ${asset.unit} available for ${asset.name}.`,
    };
  }

  // 2. Validate Worker Status
  const workerStore = useWorkerStore.getState();
  const worker = workerStore.workers.find((w) => w.id === payload.workerId);
  if (worker && worker.status === 'Inactive') {
    return { success: false, error: `Cannot issue to worker ${worker.name} (Status: Inactive).` };
  }

  // 3. Generate Issue Code
  const year = new Date().getFullYear();
  const randomNum = Math.floor(1000 + Math.random() * 9000);
  const issueCode = `ISS-${year}-${randomNum}`;
  const now = new Date().toISOString();

  const isConsumable = payload.itemCategory === 'Consumable' || payload.isConsumable;

  const newIssue: EnterpriseIssue = {
    id: `iss-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    issueCode,
    itemId: payload.itemId,
    itemName: payload.itemName,
    itemCategory: payload.itemCategory,
    assetId: payload.assetId || asset.code,
    serialNumber: payload.serialNumber,
    workerId: payload.workerId,
    workerName: payload.workerName,
    workerCode: payload.workerCode,
    department: payload.department,
    site: payload.site,
    quantity: payload.quantity,
    purpose: payload.purpose,
    issueDate: now,
    expectedReturnDate: isConsumable ? undefined : payload.expectedReturnDate,
    priority: payload.priority || 'Medium',
    remarks: payload.remarks,
    issuedBy: payload.issuedBy,
    signatureUrl: payload.signatureUrl,
    status: isConsumable ? 'Returned' : 'Active', // Consumables record consumption immediately
    isConsumable,
    timeline: [
      {
        id: `tl-1`,
        date: now,
        action: 'Created',
        by: payload.issuedBy,
        notes: isConsumable
          ? `Issued & Consumed ${payload.quantity}x ${payload.itemName}`
          : `Issued ${payload.quantity}x ${payload.itemName} to ${payload.workerName} at ${payload.site}`,
      },
    ],
    attachments: [],
    createdAt: now,
    updatedAt: now,
  };

  // 4. Update Zustand Transaction Store
  useTransactionStore.getState().addIssue({
    itemId: newIssue.itemId,
    itemName: newIssue.itemName,
    itemCategory: newIssue.itemCategory,
    workerId: newIssue.workerId,
    workerName: newIssue.workerName,
    quantity: newIssue.quantity,
    issueDate: newIssue.issueDate,
    expectedReturnDate: newIssue.expectedReturnDate,
    projectSite: newIssue.site,
    issuedBy: newIssue.issuedBy,
    remarks: newIssue.remarks,
  });

  // 5. Automatic Stock & Holder Update
  await executeStockAndHolderUpdate(
    payload.itemId,
    payload.quantity,
    payload.workerName,
    payload.workerId,
    Boolean(isConsumable)
  );

  // 6. Log Activity
  useTransactionStore.getState().addActivity({
    action: 'Issued',
    targetType: 'Asset',
    targetName: `${payload.itemName} (${payload.quantity} units)`,
    user: payload.issuedBy,
    details: `Issued to worker ${payload.workerName} (${payload.department}) for ${payload.site}`,
  });

  await logActivity(
    'create_issue',
    'issue_transactions',
    newIssue.id,
    {
      issueCode,
      workerName: payload.workerName,
      itemName: payload.itemName,
      quantity: payload.quantity,
      site: payload.site,
    },
    payload.issuedBy
  );

  // 7. Generate Notification
  useNotificationStore.getState().addNotification({
    title: `Item Issued: ${issueCode}`,
    message: `${payload.quantity}x ${payload.itemName} successfully issued to ${payload.workerName} at ${payload.site}.`,
    type: 'success',
  });

  // 8. Write to Supabase if available
  if (isSupabaseConfigured) {
    try {
      await (supabase as any).from('issue_transactions').insert({
        id: newIssue.id,
        issue_code: newIssue.issueCode,
        item_id: newIssue.itemId,
        item_name: newIssue.itemName,
        item_category: newIssue.itemCategory,
        asset_id: newIssue.assetId,
        serial_number: newIssue.serialNumber,
        worker_id: newIssue.workerId,
        worker_name: newIssue.workerName,
        worker_code: newIssue.workerCode,
        department: newIssue.department,
        site: newIssue.site,
        quantity: newIssue.quantity,
        purpose: newIssue.purpose,
        issue_date: newIssue.issueDate,
        expected_return_date: newIssue.expectedReturnDate,
        priority: newIssue.priority,
        remarks: newIssue.remarks,
        issued_by: newIssue.issuedBy,
        signature_url: newIssue.signatureUrl,
        status: newIssue.status,
        is_consumable: newIssue.isConsumable,
        timeline: newIssue.timeline,
        created_at: now,
        updated_at: now,
      });
    } catch (e) {
      console.warn('Notice saving issue transaction to Supabase:', e);
    }
  }

  return { success: true, issue: newIssue };
}

/**
 * Execute Multi-Item Issue Transaction
 */
export async function createMultiItemIssue(
  payload: MultiItemIssuePayload
): Promise<{ success: boolean; issues?: EnterpriseIssue[]; errors?: string[] }> {
  const errors: string[] = [];
  const createdIssues: EnterpriseIssue[] = [];

  for (const itemPayload of payload.items) {
    const singlePayload: NewSingleIssuePayload = {
      workerId: payload.workerId,
      workerName: payload.workerName,
      workerCode: payload.workerCode,
      department: payload.department,
      site: payload.site,
      itemId: itemPayload.itemId,
      itemName: itemPayload.itemName,
      itemCategory: itemPayload.itemCategory,
      assetId: itemPayload.assetId,
      serialNumber: itemPayload.serialNumber,
      quantity: itemPayload.quantity,
      purpose: itemPayload.purpose || payload.remarks,
      expectedReturnDate: itemPayload.expectedReturnDate,
      priority: itemPayload.priority || 'Medium',
      remarks: payload.remarks,
      issuedBy: payload.issuedBy,
      signatureUrl: payload.signatureUrl,
      isConsumable: itemPayload.isConsumable,
    };

    const result = await createSingleIssue(singlePayload);
    if (result.success && result.issue) {
      createdIssues.push(result.issue);
    } else if (result.error) {
      errors.push(`${itemPayload.itemName}: ${result.error}`);
    }
  }

  if (createdIssues.length > 0) {
    return { success: true, issues: createdIssues, errors };
  }

  return { success: false, errors };
}

/**
 * Execute Bulk Worker & Item Issue Transaction
 */
export async function createBulkIssue(
  payload: BulkWorkerIssuePayload
): Promise<{ success: boolean; totalCreated: number; errors?: string[] }> {
  const workerStore = useWorkerStore.getState();
  const assetStore = useAssetStore.getState();
  const allWorkers = workerStore.workers;
  const allAssets = assetStore.getAllAssets();

  const selectedWorkers = allWorkers.filter((w) => payload.workerIds.includes(w.id));
  const selectedItems = allAssets.filter((a) => payload.itemIds.includes(a.id));

  let totalCreated = 0;
  const errors: string[] = [];

  for (const worker of selectedWorkers) {
    for (const item of selectedItems) {
      const singlePayload: NewSingleIssuePayload = {
        workerId: worker.id,
        workerName: worker.name,
        workerCode: worker.workerCode,
        department: payload.department || worker.trade || 'Operations',
        site: payload.site || worker.projectSite || 'Main Site',
        itemId: item.id,
        itemName: item.name,
        itemCategory: item.category,
        assetId: item.code,
        quantity: 1,
        purpose: payload.purpose,
        expectedReturnDate: payload.expectedReturnDate,
        priority: payload.priority,
        remarks: payload.remarks,
        issuedBy: payload.issuedBy,
        isConsumable: item.category === 'Consumable',
      };

      const result = await createSingleIssue(singlePayload);
      if (result.success) {
        totalCreated++;
      } else if (result.error) {
        errors.push(`${worker.name} -> ${item.name}: ${result.error}`);
      }
    }
  }

  return { success: totalCreated > 0, totalCreated, errors };
}

/**
 * Quick Return of an Issued Item
 */
export async function processIssueReturn(
  issueId: string,
  quantityReturned: number,
  condition: 'Good' | 'Damaged' | 'Needs Repair',
  notes: string,
  receivedBy: string
): Promise<boolean> {
  const transactionStore = useTransactionStore.getState();
  const assetStore = useAssetStore.getState();
  const workerStore = useWorkerStore.getState();

  const issue = transactionStore.issues.find((i) => i.id === issueId);
  if (!issue) return false;

  // 1. Update issue status in transaction store
  transactionStore.updateIssueStatus(issueId, 'Returned');

  // 2. Add return record
  transactionStore.addReturn({
    issueId: issue.id,
    itemId: issue.itemId,
    itemName: issue.itemName,
    workerId: issue.workerId,
    workerName: issue.workerName,
    quantityReturned,
    returnDate: new Date().toISOString(),
    conditionOnReturn: condition,
    receivedBy,
    notes,
  });

  // 3. Restore Stock in asset store
  const allAssets = assetStore.getAllAssets();
  const asset = allAssets.find((a) => a.id === issue.itemId);
  if (asset) {
    const newAvail = (asset.availableQuantity || 0) + quantityReturned;
    if (asset.category === 'Material') assetStore.updateMaterial(asset.id, { availableQuantity: newAvail });
    else if (asset.category === 'Equipment')
      assetStore.updateEquipment(asset.id, { availableQuantity: newAvail, status: 'Available' });
    else if (asset.category === 'Tool')
      assetStore.updateTool(asset.id, { availableQuantity: newAvail, status: 'Available' });
    else if (asset.category === 'Consumable') assetStore.updateConsumable(asset.id, { availableQuantity: newAvail });
    else if (asset.category === 'PPE') assetStore.updatePPE(asset.id, { availableQuantity: newAvail });
  }

  // 4. Reduce Worker Assigned Items Count
  const worker = workerStore.workers.find((w) => w.id === issue.workerId);
  if (worker) {
    const newCount = Math.max(0, (worker.assignedItemsCount || 0) - quantityReturned);
    workerStore.updateWorker(worker.id, { assignedItemsCount: newCount });
  }

  // 5. Activity Log & Notification
  logActivity('return_item', 'issue_transactions', issueId, { condition, notes }, receivedBy);
  useNotificationStore.getState().addNotification({
    title: `Item Returned: ${issue.itemName}`,
    message: `${quantityReturned}x ${issue.itemName} returned by ${issue.workerName} in ${condition} condition.`,
    type: 'info',
  });

  // 6. Supabase update
  if (isSupabaseConfigured) {
    try {
      await (supabase as any)
        .from('issue_transactions')
        .update({
          status: 'Returned',
          returned_quantity: quantityReturned,
          updated_at: new Date().toISOString(),
        })
        .eq('id', issueId);
    } catch (e) {
      console.warn('Notice updating issue return on Supabase:', e);
    }
  }

  return true;
}

/**
 * Mark Issue Item as Lost
 */
export async function markIssueAsLost(
  issueId: string,
  notes: string,
  reportedBy: string,
  estimatedValue?: number
): Promise<boolean> {
  const transactionStore = useTransactionStore.getState();
  const issue = transactionStore.issues.find((i) => i.id === issueId);
  if (!issue) return false;

  transactionStore.updateIssueStatus(issueId, 'Lost');
  transactionStore.addLostItem({
    itemId: issue.itemId,
    itemName: issue.itemName,
    workerId: issue.workerId,
    workerName: issue.workerName,
    quantityLost: issue.quantity,
    reportedDate: new Date().toISOString(),
    location: issue.projectSite,
    estimatedValue: estimatedValue || 150,
    incidentDetails: notes,
    actionTaken: 'Under Investigation',
    status: 'Reported',
    reportedBy,
  });

  logActivity('mark_lost', 'issue_transactions', issueId, { notes }, reportedBy);
  useNotificationStore.getState().addNotification({
    title: `Item Reported Lost: ${issue.itemName}`,
    message: `${issue.itemName} issued to ${issue.workerName} was reported lost.`,
    type: 'error',
  });

  if (isSupabaseConfigured) {
    try {
      await (supabase as any)
        .from('issue_transactions')
        .update({ status: 'Lost', updated_at: new Date().toISOString() })
        .eq('id', issueId);
    } catch (e) {
      console.warn('Notice marking issue lost on Supabase:', e);
    }
  }

  return true;
}

/**
 * Compute KPI Statistics from Issue Array
 */
export function calculateIssueKPIs(issues: EnterpriseIssue[]): IssueKPIs {
  const todayStr = new Date().toISOString().split('T')[0];

  const totalIssuedToday = issues.filter((i) => i.issueDate?.startsWith(todayStr)).length;
  const activeIssues = issues.filter((i) => i.status === 'Active').length;
  const overdueIssues = issues.filter((i) => i.status === 'Overdue').length;
  const returnedToday = issues.filter((i) => i.status === 'Returned' && i.updatedAt?.startsWith(todayStr)).length;
  const pendingReturns = activeIssues + overdueIssues;
  const itemsUnderRepair = issues.filter((i) => i.status === 'Repair').length;
  const lostItems = issues.filter((i) => i.status === 'Lost').length;

  return {
    totalIssuedToday,
    activeIssues,
    overdueIssues,
    returnedToday,
    pendingReturns,
    itemsUnderRepair,
    lostItems,
  };
}
