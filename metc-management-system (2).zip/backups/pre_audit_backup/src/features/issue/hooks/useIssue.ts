import { useState, useEffect, useMemo, useCallback } from 'react';
import { useTransactionStore } from '../../../store/useTransactionStore';
import { useAssetStore } from '../../../store/useAssetStore';
import { useWorkerStore } from '../../../store/useWorkerStore';
import { useAuthStore } from '../../../store/useAuthStore';
import {
  fetchAllIssues,
  createSingleIssue,
  createMultiItemIssue,
  createBulkIssue,
  processIssueReturn,
  markIssueAsLost,
  calculateIssueKPIs,
} from '../services/issue.service';
import type {
  EnterpriseIssue,
  IssueFilters,
  IssueKPIs,
  NewSingleIssuePayload,
  MultiItemIssuePayload,
  BulkWorkerIssuePayload,
} from '../types';
import { toast } from 'sonner';

export function useIssue() {
  const { user } = useAuthStore();
  const currentUserName = user?.name || 'Store Keeper';

  const [issues, setIssues] = useState<EnterpriseIssue[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [selectedIssueId, setSelectedIssueId] = useState<string | null>(null);

  // Filters State
  const [filters, setFilters] = useState<IssueFilters>({
    status: 'All',
    category: 'All',
    site: 'All',
    department: 'All',
    searchQuery: '',
  });

  const rawTransactionIssues = useTransactionStore((s) => s.issues);
  const materials = useAssetStore((s) => s.materials);
  const equipment = useAssetStore((s) => s.equipment);
  const tools = useAssetStore((s) => s.tools);
  const consumables = useAssetStore((s) => s.consumables);
  const ppe = useAssetStore((s) => s.ppe);

  const rawAssets = useMemo(
    () => [...materials, ...equipment, ...tools, ...consumables, ...(ppe || [])],
    [materials, equipment, tools, consumables, ppe]
  );
  const rawWorkers = useWorkerStore((s) => s.workers);

  // Load Issue Data
  const reloadIssues = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchAllIssues();
      setIssues(data);
    } catch (err) {
      console.error('Error reloading issue records:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    reloadIssues();
  }, [reloadIssues, rawTransactionIssues.length]);

  // Derived Options
  const categoryOptions = useMemo(() => {
    const categories = Array.from(new Set(rawAssets.map((a) => a.category)));
    return ['All', ...categories];
  }, [rawAssets]);

  const siteOptions = useMemo(() => {
    const sites = Array.from(
      new Set([
        ...rawAssets.map((a) => a.location),
        ...rawWorkers.map((w) => w.projectSite),
        ...issues.map((i) => i.site),
      ])
    ).filter(Boolean);
    return ['All', ...sites];
  }, [rawAssets, rawWorkers, issues]);

  const departmentOptions = useMemo(() => {
    const depts = Array.from(
      new Set([...rawWorkers.map((w) => w.trade), ...issues.map((i) => i.trade)])
    ).filter(Boolean);
    return ['All', ...depts];
  }, [rawWorkers, issues]);

  // Filtered Issues List
  const filteredIssues = useMemo(() => {
    return issues.filter((iss) => {
      // Search
      if (filters.searchQuery) {
        const query = filters.searchQuery.toLowerCase();
        const matchesQuery =
          iss.issueCode.toLowerCase().includes(query) ||
          iss.workerName.toLowerCase().includes(query) ||
          (iss.workerCode && iss.workerCode.toLowerCase().includes(query)) ||
          iss.itemName.toLowerCase().includes(query) ||
          iss.assetId.toLowerCase().includes(query) ||
          (iss.serialNumber && iss.serialNumber.toLowerCase().includes(query)) ||
          iss.site.toLowerCase().includes(query) ||
          iss.trade.toLowerCase().includes(query);

        if (!matchesQuery) return false;
      }

      // Status
      if (filters.status !== 'All' && iss.status !== filters.status) return false;

      // Category
      if (filters.category !== 'All' && iss.itemCategory !== filters.category) return false;

      // Site
      if (filters.site !== 'All' && iss.site !== filters.site) return false;

      // Department
      if (filters.trade !== 'All' && iss.trade !== filters.trade) return false;

      // Date Range
      if (filters.issueDateFrom && iss.issueDate < filters.issueDateFrom) return false;
      if (filters.issueDateTo && iss.issueDate > filters.issueDateTo) return false;

      return true;
    });
  }, [issues, filters]);

  // Active Issue Object
  const activeIssue = useMemo(() => {
    if (!selectedIssueId) return issues[0] || null;
    return issues.find((i) => i.id === selectedIssueId) || issues[0] || null;
  }, [issues, selectedIssueId]);

  // KPI Stats
  const kpiStats: IssueKPIs = useMemo(() => {
    return calculateIssueKPIs(issues);
  }, [issues]);

  // Pending Returns list
  const pendingReturnsList = useMemo(() => {
    return issues.filter((i) => i.status === 'Active' || i.status === 'Overdue');
  }, [issues]);

  // Actions
  const handleSingleIssue = async (payload: Omit<NewSingleIssuePayload, 'issuedBy'>) => {
    const fullPayload: NewSingleIssuePayload = {
      ...payload,
      issuedBy: currentUserName,
    };

    const res = await createSingleIssue(fullPayload);
    if (res.success && res.issue) {
      toast.success(`Successfully issued ${res.issue.itemName} to ${res.issue.workerName} (${res.issue.issueCode})`);
      await reloadIssues();
      return true;
    } else {
      toast.error(res.error || 'Failed to process issue transaction.');
      return false;
    }
  };

  const handleMultiIssue = async (payload: Omit<MultiItemIssuePayload, 'issuedBy'>) => {
    const fullPayload: MultiItemIssuePayload = {
      ...payload,
      issuedBy: currentUserName,
    };

    const res = await createMultiItemIssue(fullPayload);
    if (res.success) {
      toast.success(`Issued ${res.issues?.length || 0} items to ${payload.workerName}`);
      await reloadIssues();
      return true;
    } else {
      toast.error(res.errors?.join(', ') || 'Failed multi-item dispatch.');
      return false;
    }
  };

  const handleBulkIssue = async (payload: Omit<BulkWorkerIssuePayload, 'issuedBy'>) => {
    const fullPayload: BulkWorkerIssuePayload = {
      ...payload,
      issuedBy: currentUserName,
    };

    const res = await createBulkIssue(fullPayload);
    if (res.success) {
      toast.success(`Bulk dispatch completed! ${res.totalCreated} total issue records created.`);
      await reloadIssues();
      return true;
    } else {
      toast.error('Bulk dispatch encountered errors. Please check stock and parameters.');
      return false;
    }
  };

  const handleReturnItem = async (
    issueId: string,
    quantityReturned: number,
    condition: 'Good' | 'Damaged' | 'Needs Repair',
    notes: string
  ) => {
    const ok = await processIssueReturn(issueId, quantityReturned, condition, notes, currentUserName);
    if (ok) {
      toast.success('Return logged successfully & stock restored.');
      await reloadIssues();
      return true;
    }
    toast.error('Failed to process return.');
    return false;
  };

  const handleMarkLost = async (issueId: string, notes: string) => {
    const ok = await markIssueAsLost(issueId, notes, currentUserName);
    if (ok) {
      toast.success('Asset marked as lost.');
      await reloadIssues();
      return true;
    }
    toast.error('Failed to mark item as lost.');
    return false;
  };

  return {
    issues,
    filteredIssues,
    pendingReturnsList,
    activeIssue,
    selectedIssueId,
    setSelectedIssueId,
    loading,
    filters,
    setFilters,
    categoryOptions,
    siteOptions,
    departmentOptions,
    kpiStats,
    rawAssets,
    rawWorkers,
    reloadIssues,
    handleSingleIssue,
    handleMultiIssue,
    handleBulkIssue,
    handleReturnItem,
    handleMarkLost,
  };
}
