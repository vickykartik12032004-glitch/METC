import type { AssetCategory } from '../../types';

export type IssueStatus = 'Active' | 'Overdue' | 'Returned' | 'Repair' | 'Lost' | 'Cancelled' | 'Partially Returned';
export type IssuePriority = 'Low' | 'Medium' | 'High' | 'Critical';

export interface IssueTimelineEvent {
  id: string;
  date: string;
  action: 'Created' | 'Edited' | 'Returned' | 'Transferred' | 'Repair' | 'Lost' | 'Cancelled' | 'Reminder Sent';
  by: string;
  notes?: string;
}

export interface IssueAttachment {
  id: string;
  name: string;
  url: string;
  uploadedAt: string;
}

export interface EnterpriseIssue {
  id: string;
  issueCode: string; // e.g. ISS-2026-0891
  itemId: string;
  itemName: string;
  itemCategory: AssetCategory;
  assetId: string; // Code / Asset Tag e.g. EQP-101
  serialNumber?: string;
  workerId: string;
  workerName: string;
  workerCode?: string;
  department: string;
  site: string; // Project Site
  quantity: number;
  purpose?: string;
  issueDate: string;
  expectedReturnDate?: string;
  priority: IssuePriority;
  remarks?: string;
  issuedBy: string;
  signatureUrl?: string; // Digital Signature Data URL
  status: IssueStatus;
  isConsumable?: boolean;
  returnedQuantity?: number;
  timeline?: IssueTimelineEvent[];
  attachments?: IssueAttachment[];
  createdAt?: string;
  updatedAt?: string;
}

export interface IssueKPIs {
  totalIssuedToday: number;
  activeIssues: number;
  overdueIssues: number;
  returnedToday: number;
  pendingReturns: number;
  itemsUnderRepair: number;
  lostItems: number;
}

export interface IssueFilters {
  status: IssueStatus | 'All';
  category: AssetCategory | 'All';
  site: string;
  department: string;
  issueDateFrom?: string;
  issueDateTo?: string;
  searchQuery: string;
}

export interface MultiItemIssueItem {
  itemId: string;
  itemName: string;
  itemCategory: AssetCategory;
  assetId: string;
  serialNumber?: string;
  availableStock: number;
  quantity: number;
  purpose?: string;
  expectedReturnDate?: string;
  priority: IssuePriority;
  isConsumable?: boolean;
}

export interface NewSingleIssuePayload {
  workerId: string;
  workerName: string;
  workerCode?: string;
  department: string;
  site: string;
  itemId: string;
  itemName: string;
  itemCategory: AssetCategory;
  assetId: string;
  serialNumber?: string;
  quantity: number;
  purpose?: string;
  expectedReturnDate?: string;
  priority: IssuePriority;
  remarks?: string;
  issuedBy: string;
  signatureUrl?: string;
  isConsumable?: boolean;
}

export interface MultiItemIssuePayload {
  workerId: string;
  workerName: string;
  workerCode?: string;
  department: string;
  site: string;
  issuedBy: string;
  remarks?: string;
  signatureUrl?: string;
  items: MultiItemIssueItem[];
}

export interface BulkWorkerIssuePayload {
  workerIds: string[];
  itemIds: string[];
  site: string;
  department: string;
  purpose: string;
  expectedReturnDate?: string;
  priority: IssuePriority;
  issuedBy: string;
  remarks?: string;
}

export interface IssueReportData {
  title: string;
  generatedAt: string;
  totalRecords: number;
  data: any[];
}
