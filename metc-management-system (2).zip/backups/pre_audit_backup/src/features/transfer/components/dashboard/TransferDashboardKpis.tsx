import React from 'react';
import { 
  CalendarCheck, 
  Clock, 
  CheckCircle, 
  XOctagon, 
  Building, 
  MapPin, 
  ArrowRightLeft 
} from 'lucide-react';

interface TransferKPIs {
  todayTransfers: number;
  pendingTransfers: number;
  completedTransfers: number;
  cancelledTransfers: number;
  siteTransfers: number;
  branchTransfers: number;
}

interface Props {
  kpis: TransferKPIs;
  onFilterStatus?: (status: string) => void;
}

export const TransferDashboardKpis: React.FC<Props> = ({ kpis, onFilterStatus }) => {
  const cards = [
    {
      title: "Today's Transfers",
      value: kpis.todayTransfers,
      sub: 'Initiated today',
      icon: CalendarCheck,
      color: 'text-blue-600 dark:text-blue-400',
      bg: 'bg-blue-50 dark:bg-blue-950/40 border-blue-200 dark:border-blue-900',
      statusKey: 'All',
    },
    {
      title: 'Pending Transfers',
      value: kpis.pendingTransfers,
      sub: 'Awaiting approval',
      icon: Clock,
      color: 'text-amber-600 dark:text-amber-400',
      bg: 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-900',
      statusKey: 'Pending',
    },
    {
      title: 'Completed',
      value: kpis.completedTransfers,
      sub: 'Successfully transferred',
      icon: CheckCircle,
      color: 'text-emerald-600 dark:text-emerald-400',
      bg: 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-900',
      statusKey: 'Completed',
    },
    {
      title: 'Cancelled',
      value: kpis.cancelledTransfers,
      sub: 'Rejected or cancelled',
      icon: XOctagon,
      color: 'text-rose-600 dark:text-rose-400',
      bg: 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-900',
      statusKey: 'Cancelled',
    },
    {
      title: 'Site Transfers',
      value: kpis.siteTransfers,
      sub: 'Between project sites',
      icon: MapPin,
      color: 'text-indigo-600 dark:text-indigo-400',
      bg: 'bg-indigo-50 dark:bg-indigo-950/40 border-indigo-200 dark:border-indigo-900',
      statusKey: 'All',
    },
    {
      title: 'Branch Transfers',
      value: kpis.branchTransfers,
      sub: 'Inter-branch movements',
      icon: Building,
      color: 'text-purple-600 dark:text-purple-400',
      bg: 'bg-purple-50 dark:bg-purple-950/40 border-purple-200 dark:border-purple-900',
      statusKey: 'All',
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
      {cards.map((card, idx) => {
        const Icon = card.icon;
        return (
          <div
            key={idx}
            onClick={() => onFilterStatus && onFilterStatus(card.statusKey)}
            className={`p-3.5 rounded-2xl border ${card.bg} transition-all hover:scale-[1.02] cursor-pointer shadow-xs flex flex-col justify-between`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-bold text-slate-600 dark:text-slate-300 truncate">
                {card.title}
              </span>
              <Icon className={`w-4 h-4 ${card.color} shrink-0`} />
            </div>
            <div>
              <div className={`text-2xl font-black ${card.color}`}>{card.value}</div>
              <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5 truncate">
                {card.sub}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};
