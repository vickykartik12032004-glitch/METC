import React from 'react';
import { ArrowRightLeft, QrCode, ScanBarcode, FileBarChart2, Layers } from 'lucide-react';

interface Props {
  onAction: (action: 'new' | 'bulk' | 'qr' | 'barcode' | 'reports') => void;
}

export const TransferQuickActions: React.FC<Props> = ({ onAction }) => {
  const actions = [
    {
      label: 'New Transfer',
      description: 'Single item movement',
      icon: ArrowRightLeft,
      action: 'new' as const,
      color: 'bg-blue-50 text-blue-600 dark:bg-blue-950/40 dark:text-blue-400',
    },
    {
      label: 'Bulk Transfer',
      description: 'Multiple items at once',
      icon: Layers,
      action: 'bulk' as const,
      color: 'bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400',
    },
    {
      label: 'Scan QR',
      description: 'Transfer by QR code',
      icon: QrCode,
      action: 'qr' as const,
      color: 'bg-indigo-50 text-indigo-600 dark:bg-indigo-950/40 dark:text-indigo-400',
    },
    {
      label: 'Scan Barcode',
      description: 'Scan item barcode',
      icon: ScanBarcode,
      action: 'barcode' as const,
      color: 'bg-purple-50 text-purple-600 dark:bg-purple-950/40 dark:text-purple-400',
    },
    {
      label: 'View Reports',
      description: 'Transfer analytics',
      icon: FileBarChart2,
      action: 'reports' as const,
      color: 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400',
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
      {actions.map((action, idx) => {
        const Icon = action.icon;
        return (
          <button
            key={idx}
            onClick={() => onAction(action.action)}
            className="flex flex-col sm:flex-row items-center sm:items-start gap-3 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800/80 transition-all text-center sm:text-left shadow-xs group"
          >
            <div className={`p-2.5 rounded-xl ${action.color} group-hover:scale-110 transition-transform shrink-0`}>
              <Icon className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-900 dark:text-slate-100">{action.label}</div>
              <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">{action.description}</div>
            </div>
          </button>
        );
      })}
    </div>
  );
};
