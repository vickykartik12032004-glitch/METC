import React from 'react';
import { TransferRecord } from '../../../../types';
import { formatDateTime } from '../../../../lib/utils';
import { StatusBadge } from '../../../../components/common/StatusBadge';
import { SearchBox } from '../../../../components/ui/SearchBox';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '../../../../components/ui/Table';
import { Button } from '../../../../components/ui/Button';
import { Eye, Printer } from 'lucide-react';

interface Props {
  transfers: TransferRecord[];
  filters: any;
  setFilters: (f: any) => void;
  onViewDetails: (t: TransferRecord) => void;
  onPrintSlip: (t: TransferRecord) => void;
}

export const TransferHistoryTable: React.FC<Props> = ({ transfers, filters, setFilters, onViewDetails, onPrintSlip }) => {
  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800">
        <div className="flex-1 w-full max-w-md">
          <SearchBox
            value={filters.search}
            onChange={(val) => setFilters({ ...filters, search: val })}
            placeholder="Search transfer code, item, location..."
          />
        </div>
        <div className="flex gap-2">
          <select
            value={filters.transferType}
            onChange={(e) => setFilters({ ...filters, transferType: e.target.value })}
            className="px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
          >
            <option value="All">All Types</option>
            <option value="Worker to Worker">Worker to Worker</option>
            <option value="Worker to Store">Worker to Store</option>
            <option value="Store to Worker">Store to Worker</option>
            <option value="Site to Site">Site to Site</option>
            <option value="Branch to Branch">Branch to Branch</option>
          </select>
          <select
            value={filters.status}
            onChange={(e) => setFilters({ ...filters, status: e.target.value })}
            className="px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
          >
            <option value="All">All Statuses</option>
            <option value="Completed">Completed</option>
            <option value="Cancelled">Cancelled</option>
            <option value="Rejected">Rejected</option>
          </select>
        </div>
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Transfer Ref</TableHead>
            <TableHead>Item</TableHead>
            <TableHead>Type</TableHead>
            <TableHead>From</TableHead>
            <TableHead>To</TableHead>
            <TableHead>Date</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {transfers.length === 0 ? (
            <TableRow>
              <TableCell colSpan={8} className="text-center py-8 text-slate-500">
                No transfer history found matching criteria
              </TableCell>
            </TableRow>
          ) : (
            transfers.map((t) => (
              <TableRow key={t.id}>
                <TableCell>
                  <div className="font-bold text-slate-900 dark:text-slate-100">{t.transferCode}</div>
                </TableCell>
                <TableCell>
                  <div className="font-semibold text-slate-800 dark:text-slate-200">{t.itemName}</div>
                  <div className="text-[10px] text-slate-500">Qty: {t.quantity}</div>
                </TableCell>
                <TableCell>
                  <div className="text-xs font-medium text-slate-600 dark:text-slate-400">{t.transferType || 'Standard'}</div>
                </TableCell>
                <TableCell>
                  <div className="font-medium text-slate-800 dark:text-slate-200">{t.fromLocation}</div>
                </TableCell>
                <TableCell>
                  <div className="font-medium text-slate-800 dark:text-slate-200">{t.toLocation}</div>
                </TableCell>
                <TableCell className="text-xs text-slate-600 dark:text-slate-400">
                  {formatDateTime(t.transferDate)}
                </TableCell>
                <TableCell>
                  <StatusBadge status={t.status} />
                </TableCell>
                <TableCell className="text-right space-x-1">
                  <Button variant="outline" size="xs" onClick={() => onViewDetails(t)} icon={<Eye className="w-3.5 h-3.5" />}>View</Button>
                  <Button variant="outline" size="xs" onClick={() => onPrintSlip(t)} icon={<Printer className="w-3.5 h-3.5 text-blue-500" />}>Slip</Button>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
};
