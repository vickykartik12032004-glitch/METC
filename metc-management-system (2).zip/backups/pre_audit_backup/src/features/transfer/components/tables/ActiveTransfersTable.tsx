import React, { useState } from 'react';
import { TransferRecord } from '../../../../types';
import { formatDateTime } from '../../../../lib/utils';
import { StatusBadge } from '../../../../components/common/StatusBadge';
import { SearchBox } from '../../../../components/ui/SearchBox';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '../../../../components/ui/Table';
import { Button } from '../../../../components/ui/Button';
import { Eye, Printer, CheckCircle, ArrowRight, Package, LayoutGrid, List } from 'lucide-react';
import { useAuthStore } from '../../../../store/useAuthStore';
import { useTransactionStore } from '../../../../store/useTransactionStore';
import { toast } from 'sonner';

interface Props {
  transfers: TransferRecord[];
  filters: any;
  setFilters: (f: any) => void;
  onViewDetails: (t: TransferRecord) => void;
  onPrintSlip: (t: TransferRecord) => void;
}

export const ActiveTransfersTable: React.FC<Props> = ({ transfers, filters, setFilters, onViewDetails, onPrintSlip }) => {
  const { user } = useAuthStore();
  const { updateTransferStatus } = useTransactionStore();
  const [viewMode, setViewMode] = useState<'cards' | 'table' | 'auto'>('auto');

  const handleApprove = (t: TransferRecord) => {
    updateTransferStatus(t.id, 'In Transit');
    toast.success(`Transfer ${t.transferCode} approved`);
  };

  const handleComplete = (t: TransferRecord) => {
    updateTransferStatus(t.id, 'Completed');
    toast.success(`Transfer ${t.transferCode} marked as completed`);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="flex-1 w-full max-w-md">
          <SearchBox
            value={filters.search}
            onChange={(val) => setFilters({ ...filters, search: val })}
            placeholder="Search transfer code, item, location..."
          />
        </div>
        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto justify-between sm:justify-end">
          <div className="flex items-center gap-2">
            <select
              value={filters.transferType}
              onChange={(e) => setFilters({ ...filters, transferType: e.target.value })}
              className="px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
            >
              <option value="All">All Types</option>
              <option value="Worker to Worker">Worker to Worker</option>
              <option value="Worker to Store">Worker to Store</option>
              <option value="Store to Worker">Store to Worker</option>
              <option value="Site to Site">Site to Site</option>
              <option value="Branch to Branch">Branch to Branch</option>
            </select>
            <select
              value={filters.status}
              onChange={(e) => setFilters({ ...filters, status: e.target.value })}
              className="px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
            >
              <option value="All">All Statuses</option>
              <option value="Pending">Pending</option>
              <option value="In Transit">In Transit</option>
            </select>
          </div>

          <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-0.5 rounded-lg border border-slate-200 dark:border-slate-700">
            <button
              type="button"
              onClick={() => setViewMode('cards')}
              title="Card View"
              className={`p-1.5 rounded-md text-xs font-medium transition-all ${
                viewMode === 'cards' || viewMode === 'auto'
                  ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-2xs'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setViewMode('table')}
              title="Table Spreadsheet View"
              className={`p-1.5 rounded-md text-xs font-medium transition-all ${
                viewMode === 'table'
                  ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-2xs'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* MOBILE RESPONSIVE CARDS VIEW */}
      <div className={`${viewMode === 'table' ? 'hidden' : viewMode === 'cards' ? 'grid' : 'grid md:hidden'} grid-cols-1 sm:grid-cols-2 gap-3`}>
        {transfers.length === 0 ? (
          <div className="col-span-full p-12 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
            <Package className="w-12 h-12 text-slate-300 dark:text-slate-700 mx-auto mb-3" />
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">No Active Transfers</h3>
            <p className="text-xs text-slate-500 mt-1">No transfers matching active filter criteria.</p>
          </div>
        ) : (
          transfers.map((t) => (
            <div
              key={t.id}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs space-y-3 hover:border-slate-300 dark:hover:border-slate-700 transition-all"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <span className="font-mono font-bold text-sm text-blue-600 dark:text-blue-400 block">
                    {t.transferCode}
                  </span>
                  <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
                    <span>{t.transferType || 'Standard'}</span>
                    <span>•</span>
                    <span>{formatDateTime(t.transferDate)}</span>
                  </div>
                </div>
                <StatusBadge status={t.status} />
              </div>

              {/* Item Details */}
              <div className="flex items-center justify-between bg-slate-50 dark:bg-slate-800/50 p-2.5 rounded-xl">
                <div className="min-w-0 pr-2">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block">Asset</span>
                  <div className="font-bold text-slate-900 dark:text-slate-100 text-xs truncate">{t.itemName}</div>
                </div>
                <span className="px-2 py-0.5 rounded bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 font-extrabold text-xs shrink-0">
                  Qty: {t.quantity}
                </span>
              </div>

              {/* From / To Route */}
              <div className="flex items-center justify-between text-xs bg-slate-50/50 dark:bg-slate-800/20 p-2 rounded-xl border border-slate-100 dark:border-slate-800">
                <div className="min-w-0 flex-1">
                  <span className="text-[10px] text-slate-400 block uppercase font-bold">Origin</span>
                  <div className="font-bold text-slate-800 dark:text-slate-200 truncate">{t.fromLocation}</div>
                </div>
                <ArrowRight className="w-4 h-4 text-blue-500 mx-2 shrink-0" />
                <div className="min-w-0 flex-1 text-right">
                  <span className="text-[10px] text-slate-400 block uppercase font-bold">Destination</span>
                  <div className="font-bold text-slate-800 dark:text-slate-200 truncate">{t.toLocation}</div>
                </div>
              </div>

              {/* Touch Action Bar */}
              <div className="pt-2 flex items-center justify-between border-t border-slate-100 dark:border-slate-800 gap-1">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onViewDetails(t)}
                  icon={<Eye className="w-3.5 h-3.5" />}
                >
                  Details
                </Button>

                <div className="flex items-center gap-1">
                  {t.status === 'Pending' && (
                    <Button
                      variant="primary"
                      size="sm"
                      onClick={() => handleApprove(t)}
                      icon={<CheckCircle className="w-3.5 h-3.5" />}
                      className="bg-emerald-600 hover:bg-emerald-700 font-bold"
                    >
                      Approve
                    </Button>
                  )}
                  {t.status === 'In Transit' && (
                    <Button
                      variant="primary"
                      size="sm"
                      onClick={() => handleComplete(t)}
                      icon={<CheckCircle className="w-3.5 h-3.5" />}
                      className="bg-blue-600 hover:bg-blue-700 font-bold"
                    >
                      Complete
                    </Button>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* DESKTOP SPREADSHEET TABLE VIEW */}
      <div className={`${viewMode === 'cards' ? 'hidden' : viewMode === 'table' ? 'block' : 'hidden md:block'} bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs`}>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Transfer Ref</TableHead>
              <TableHead>Item</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>From</TableHead>
              <TableHead>To</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {transfers.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-8 text-slate-500">
                  No active transfers found matching criteria
                </TableCell>
              </TableRow>
            ) : (
              transfers.map((t) => (
                <TableRow key={t.id}>
                  <TableCell>
                    <div className="font-bold text-slate-900 dark:text-slate-100">{t.transferCode}</div>
                  </TableCell>
                  <TableCell>
                    <div className="font-semibold text-slate-800 dark:text-slate-200">{t.itemName}</div>
                    <div className="text-[10px] text-slate-500">Qty: {t.quantity}</div>
                  </TableCell>
                  <TableCell>
                    <div className="text-xs font-medium text-slate-600 dark:text-slate-400">{t.transferType || 'Standard'}</div>
                  </TableCell>
                  <TableCell>
                    <div className="font-medium text-slate-800 dark:text-slate-200">{t.fromLocation}</div>
                  </TableCell>
                  <TableCell>
                    <div className="font-medium text-slate-800 dark:text-slate-200">{t.toLocation}</div>
                  </TableCell>
                  <TableCell className="text-xs text-slate-600 dark:text-slate-400">
                    {formatDateTime(t.transferDate)}
                  </TableCell>
                  <TableCell>
                    <StatusBadge status={t.status} />
                  </TableCell>
                  <TableCell className="text-right space-x-1">
                    {t.status === 'Pending' && (
                      <Button variant="outline" size="xs" onClick={() => handleApprove(t)} icon={<CheckCircle className="w-3.5 h-3.5 text-emerald-500" />}>Approve</Button>
                    )}
                    {t.status === 'In Transit' && (
                      <Button variant="primary" size="xs" onClick={() => handleComplete(t)} icon={<CheckCircle className="w-3.5 h-3.5" />}>Complete</Button>
                    )}
                    <Button variant="outline" size="xs" onClick={() => onViewDetails(t)} icon={<Eye className="w-3.5 h-3.5" />}>View</Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};
