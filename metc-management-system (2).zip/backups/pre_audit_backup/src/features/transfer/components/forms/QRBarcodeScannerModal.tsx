import React from 'react';
import { Modal } from '../../../../components/ui/Modal';
import { Button } from '../../../../components/ui/Button';
import { QrCode, X } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onScan: (code: string) => void;
}

export const QRBarcodeScannerModal: React.FC<Props> = ({ isOpen, onClose, onScan }) => {
  if (!isOpen) return null;

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Scan QR Code" size="md">
      <div className="flex flex-col items-center justify-center p-8 text-center">
        <QrCode className="w-16 h-16 text-slate-300 mb-4" />
        <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100 mb-2">Scanner Active</h3>
        <p className="text-sm text-slate-500 mb-8 max-w-sm">
          Please point your device camera at the item's QR code or barcode to initiate transfer.
        </p>
        
        {/* Mocking a successful scan for demo */}
        <Button 
          variant="primary" 
          onClick={() => onScan('QR-12345')}
        >
          Simulate Scan Success
        </Button>
      </div>
    </Modal>
  );
};
