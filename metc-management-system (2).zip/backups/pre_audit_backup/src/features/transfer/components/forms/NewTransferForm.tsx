import React, { useState } from 'react';
import { useAuthStore } from '../../../../store/useAuthStore';
import { useAssetStore } from '../../../../store/useAssetStore';
import { useWorkerStore } from '../../../../store/useWorkerStore';
import { createTransfer } from '../../services/transfer.service';
import { Button } from '../../../../components/ui/Button';
import { toast } from 'sonner';

interface Props {
  onSubmit: () => void;
  onCancel: () => void;
}

export const NewTransferForm: React.FC<Props> = ({ onSubmit, onCancel }) => {
  const { user } = useAuthStore();
  const { getAllAssets } = useAssetStore();
  const { workers } = useWorkerStore();
  
  const allAssets = getAllAssets();

  const [transferType, setTransferType] = useState('Worker to Worker');
  const [selectedItemId, setSelectedItemId] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [fromId, setFromId] = useState('');
  const [toId, setToId] = useState('');
  const [reason, setReason] = useState('');
  
  const selectedItem = allAssets.find(a => a.id === selectedItemId);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedItem) return toast.error('Please select an item to transfer');
    if (quantity < 1) return toast.error('Quantity must be at least 1');
    if (!fromId || !toId) return toast.error('Please specify both source and destination');
    if (fromId === toId) return toast.error('Source and destination cannot be the same');

    try {
      createTransfer({
        transferType: transferType as any,
        itemId: selectedItem.id,
        itemName: selectedItem.name,
        itemCategory: selectedItem.category,
        assetId: selectedItem.code,
        quantity,
        fromLocation: fromId,
        toLocation: toId,
        reason,
        initiatedBy: user?.name || 'Admin'
      });
      toast.success('Transfer created successfully');
      onSubmit();
    } catch (err: any) {
      toast.error(err.message || 'Failed to create transfer');
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm max-w-3xl mx-auto">
      <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100 mb-4">Initiate New Transfer</h2>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Transfer Type</label>
            <select
              value={transferType}
              onChange={(e) => {
                setTransferType(e.target.value);
                setFromId('');
                setToId('');
              }}
              className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            >
              <option value="Worker to Worker">Worker to Worker</option>
              <option value="Worker to Store">Worker to Store</option>
              <option value="Store to Worker">Store to Worker</option>
              <option value="Site to Site">Site to Site</option>
              <option value="Branch to Branch">Branch to Branch</option>
              <option value="Store to Site">Store to Site</option>
              <option value="Site to Store">Site to Store</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Select Item</label>
            <select
              value={selectedItemId}
              onChange={(e) => setSelectedItemId(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              required
            >
              <option value="">-- Search & Select Asset --</option>
              {allAssets.map(a => (
                <option key={a.id} value={a.id}>
                  {a.code} - {a.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">From Location / Worker</label>
            {transferType.includes('Worker') && transferType.startsWith('Worker') ? (
               <select
                 value={fromId}
                 onChange={(e) => setFromId(e.target.value)}
                 className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
                 required
               >
                 <option value="">-- Select Worker --</option>
                 {workers.map(w => <option key={w.id} value={w.name}>{w.name}</option>)}
               </select>
            ) : (
               <input
                 type="text"
                 value={fromId}
                 onChange={(e) => setFromId(e.target.value)}
                 placeholder="e.g. Main Site, HQ Store"
                 className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
                 required
               />
            )}
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">To Location / Worker</label>
            {transferType.includes('Worker') && transferType.endsWith('Worker') ? (
               <select
                 value={toId}
                 onChange={(e) => setToId(e.target.value)}
                 className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
                 required
               >
                 <option value="">-- Select Worker --</option>
                 {workers.map(w => <option key={w.id} value={w.name}>{w.name}</option>)}
               </select>
            ) : (
               <input
                 type="text"
                 value={toId}
                 onChange={(e) => setToId(e.target.value)}
                 placeholder="e.g. Jurong Site, Branch B"
                 className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
                 required
               />
            )}
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Quantity</label>
            <input
              type="number"
              min={1}
              value={quantity}
              onChange={(e) => setQuantity(parseInt(e.target.value) || 1)}
              className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
              required
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Transfer Reason / Remarks</label>
          <textarea
            rows={3}
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl resize-none font-medium"
            placeholder="Explain reason for transfer..."
          />
        </div>

        <div className="flex justify-end gap-3 pt-4 border-t border-slate-100 dark:border-slate-800">
          <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
          <Button type="submit" variant="primary">Initiate Transfer</Button>
        </div>
      </form>
    </div>
  );
};
