import React, { useState } from 'react';
import { Button } from '../../../../components/ui/Button';
import { useAssetStore } from '../../../../store/useAssetStore';
import { useWorkerStore } from '../../../../store/useWorkerStore';
import { createTransfer } from '../../services/transfer.service';
import { useAuthStore } from '../../../../store/useAuthStore';
import { toast } from 'sonner';

interface Props {
  onSubmit: () => void;
  onCancel: () => void;
}

export const BulkTransferForm: React.FC<Props> = ({ onSubmit, onCancel }) => {
  const { user } = useAuthStore();
  const { getAllAssets } = useAssetStore();
  const { workers } = useWorkerStore();
  
  const allAssets = getAllAssets();

  const [transferType, setTransferType] = useState('Worker to Worker');
  const [selectedItemIds, setSelectedItemIds] = useState<string[]>([]);
  const [fromId, setFromId] = useState('');
  const [toId, setToId] = useState('');
  const [reason, setReason] = useState('');

  const toggleSelect = (id: string) => {
    setSelectedItemIds(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  const toggleAll = () => {
    if (selectedItemIds.length === allAssets.length) {
      setSelectedItemIds([]);
    } else {
      setSelectedItemIds(allAssets.map(a => a.id));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedItemIds.length === 0) return toast.error('Please select at least one item');
    if (!fromId || !toId) return toast.error('Please specify both source and destination');
    if (fromId === toId) return toast.error('Source and destination cannot be the same');

    try {
      selectedItemIds.forEach(id => {
        const item = allAssets.find(a => a.id === id);
        if (item) {
          createTransfer({
            transferType: transferType as any,
            itemId: item.id,
            itemName: item.name,
            itemCategory: item.category,
            assetId: item.code,
            quantity: 1, // Defaulting to 1 for bulk selecting items
            fromLocation: fromId,
            toLocation: toId,
            reason,
            initiatedBy: user?.name || 'Admin'
          });
        }
      });
      
      toast.success(`Successfully initiated ${selectedItemIds.length} transfers`);
      onSubmit();
    } catch (err: any) {
      toast.error(err.message || 'Failed to process bulk transfers');
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">Bulk Transfer Processing</h2>
          <p className="text-xs text-slate-500">Transfer multiple items to a single destination.</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-100 dark:border-slate-800">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Transfer Type</label>
            <select
              value={transferType}
              onChange={(e) => {
                setTransferType(e.target.value);
                setFromId('');
                setToId('');
              }}
              className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
            >
              <option value="Worker to Worker">Worker to Worker</option>
              <option value="Worker to Store">Worker to Store</option>
              <option value="Store to Worker">Store to Worker</option>
              <option value="Site to Site">Site to Site</option>
              <option value="Branch to Branch">Branch to Branch</option>
              <option value="Store to Site">Store to Site</option>
              <option value="Site to Store">Site to Store</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">From</label>
            {transferType.includes('Worker') && transferType.startsWith('Worker') ? (
               <select
                 value={fromId}
                 onChange={(e) => setFromId(e.target.value)}
                 className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
                 required
               >
                 <option value="">-- Select Worker --</option>
                 {workers.map(w => <option key={w.id} value={w.name}>{w.name}</option>)}
               </select>
            ) : (
               <input
                 type="text"
                 value={fromId}
                 onChange={(e) => setFromId(e.target.value)}
                 placeholder="e.g. Main Site"
                 className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
                 required
               />
            )}
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">To</label>
            {transferType.includes('Worker') && transferType.endsWith('Worker') ? (
               <select
                 value={toId}
                 onChange={(e) => setToId(e.target.value)}
                 className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
                 required
               >
                 <option value="">-- Select Worker --</option>
                 {workers.map(w => <option key={w.id} value={w.name}>{w.name}</option>)}
               </select>
            ) : (
               <input
                 type="text"
                 value={toId}
                 onChange={(e) => setToId(e.target.value)}
                 placeholder="e.g. Jurong Site"
                 className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
                 required
               />
            )}
          </div>
        </div>

        <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
          <div className="max-h-80 overflow-y-auto">
            <table className="w-full text-left text-xs text-slate-600 dark:text-slate-300">
              <thead className="bg-slate-50 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 sticky top-0">
                <tr>
                  <th className="py-2.5 px-3 w-10">
                    <input type="checkbox" checked={selectedItemIds.length === allAssets.length && allAssets.length > 0} onChange={toggleAll} className="rounded border-slate-300 text-blue-600 focus:ring-blue-500" />
                  </th>
                  <th className="py-2.5 px-3 font-semibold">Asset ID</th>
                  <th className="py-2.5 px-3 font-semibold">Name</th>
                  <th className="py-2.5 px-3 font-semibold">Category</th>
                  <th className="py-2.5 px-3 font-semibold">Status</th>
                </tr>
              </thead>
              <tbody>
                {allAssets.map(a => (
                  <tr key={a.id} className="border-b border-slate-100 dark:border-slate-800/50 hover:bg-slate-50 dark:hover:bg-slate-800/30">
                    <td className="py-2.5 px-3">
                      <input type="checkbox" checked={selectedItemIds.includes(a.id)} onChange={() => toggleSelect(a.id)} className="rounded border-slate-300 text-blue-600 focus:ring-blue-500" />
                    </td>
                    <td className="py-2.5 px-3 font-medium text-slate-900 dark:text-slate-100 font-mono">{a.code}</td>
                    <td className="py-2.5 px-3 font-medium text-slate-800 dark:text-slate-200">{a.name}</td>
                    <td className="py-2.5 px-3">{a.category}</td>
                    <td className="py-2.5 px-3">{a.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Transfer Reason / Remarks</label>
          <input
            type="text"
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
            placeholder="Reason for bulk transfer..."
          />
        </div>

        <div className="flex justify-between items-center pt-4">
          <span className="text-xs font-semibold text-slate-500">{selectedItemIds.length} items selected</span>
          <div className="flex gap-3">
            <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
            <Button type="submit" variant="primary" disabled={selectedItemIds.length === 0}>
              Process {selectedItemIds.length} Transfers
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
};
