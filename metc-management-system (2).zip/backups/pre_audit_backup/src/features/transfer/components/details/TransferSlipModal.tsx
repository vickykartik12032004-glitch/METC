import React, { useRef } from 'react';
import { TransferRecord } from '../../../../types';
import { Modal } from '../../../../components/ui/Modal';
import { Button } from '../../../../components/ui/Button';
import { formatDateTime } from '../../../../lib/utils';
import { Printer, QrCode } from 'lucide-react';
import { DEFAULT_COMPANY } from '../../../../constants';

interface Props {
  transferRecord: TransferRecord;
  isOpen: boolean;
  onClose: () => void;
}

export const TransferSlipModal: React.FC<Props> = ({ transferRecord, isOpen, onClose }) => {
  const printRef = useRef<HTMLDivElement>(null);

  if (!transferRecord) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Transfer Slip" size="xl">
      <div className="space-y-6">
        <div className="flex justify-end gap-2 print:hidden mb-4">
          <Button variant="primary" size="sm" icon={<Printer className="w-4 h-4" />} onClick={handlePrint}>
            Print Slip
          </Button>
        </div>

        <div 
          ref={printRef}
          className="bg-white p-8 border border-slate-200 rounded-xl shadow-sm text-slate-900 max-w-3xl mx-auto print:border-none print:shadow-none print:p-0"
        >
          {/* Header */}
          <div className="flex justify-between items-start border-b-2 border-slate-900 pb-6 mb-6">
            <div>
              <h1 className="text-2xl font-black tracking-tight uppercase">{DEFAULT_COMPANY.name}</h1>
              <p className="text-sm font-medium text-slate-500 mt-1">Enterprise Asset Transfer Slip</p>
            </div>
            <div className="text-right">
              <div className="flex flex-col items-end">
                <QrCode className="w-16 h-16 mb-2 text-slate-800" />
                <p className="text-xs font-mono font-bold">{transferRecord.transferCode}</p>
              </div>
            </div>
          </div>

          {/* Details */}
          <div className="grid grid-cols-2 gap-8 mb-8">
            <div className="space-y-4">
              <div>
                <p className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">From</p>
                <p className="text-base font-bold">{transferRecord.fromLocation}</p>
              </div>
              <div>
                <p className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">To</p>
                <p className="text-base font-bold">{transferRecord.toLocation}</p>
              </div>
            </div>
            
            <div className="space-y-4">
              <div>
                <p className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">Transfer Date & Time</p>
                <p className="text-sm font-semibold">{formatDateTime(transferRecord.transferDate)}</p>
              </div>
              <div>
                <p className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">Initiated By</p>
                <p className="text-sm font-semibold">{transferRecord.initiatedBy}</p>
              </div>
            </div>
          </div>

          {/* Items Table */}
          <table className="w-full text-left mb-8 border border-slate-200">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="p-3 text-xs font-bold text-slate-700">Item Details</th>
                <th className="p-3 text-xs font-bold text-slate-700">Type</th>
                <th className="p-3 text-xs font-bold text-slate-700">Qty</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-slate-100">
                <td className="p-3">
                  <p className="font-bold">{transferRecord.itemName}</p>
                  <p className="text-[10px] font-mono text-slate-500 mt-0.5">{transferRecord.itemId}</p>
                </td>
                <td className="p-3 font-semibold text-sm">{transferRecord.transferType || 'Standard'}</td>
                <td className="p-3 font-bold">{transferRecord.quantity}</td>
              </tr>
            </tbody>
          </table>

          {/* Remarks */}
          <div className="mb-12">
            <p className="text-[10px] font-bold uppercase text-slate-400 tracking-wider mb-2">Remarks</p>
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg text-sm min-h-[60px]">
              {transferRecord.reason || transferRecord.notes || 'None'}
            </div>
          </div>

          {/* Signatures */}
          <div className="grid grid-cols-2 gap-12 pt-16 border-t border-slate-200">
            <div className="text-center">
              <div className="border-b-2 border-slate-900 w-full mb-2"></div>
              <p className="text-xs font-bold">Issuer Signature</p>
              <p className="text-[10px] text-slate-500">{transferRecord.fromLocation}</p>
            </div>
            <div className="text-center">
              <div className="border-b-2 border-slate-900 w-full mb-2"></div>
              <p className="text-xs font-bold">Receiver Signature</p>
              <p className="text-[10px] text-slate-500">{transferRecord.toLocation}</p>
            </div>
          </div>

          {/* Footer */}
          <div className="text-center mt-12 pt-6 border-t border-slate-100">
            <p className="text-[10px] text-slate-500 font-medium">Generated by {DEFAULT_COMPANY.tagline}</p>
          </div>
        </div>
      </div>
    </Modal>
  );
};
