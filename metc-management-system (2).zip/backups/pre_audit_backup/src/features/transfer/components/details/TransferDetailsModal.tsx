import React from 'react';
import { TransferRecord } from '../../../../types';
import { Modal } from '../../../../components/ui/Modal';
import { Button } from '../../../../components/ui/Button';
import { formatDateTime } from '../../../../lib/utils';
import { StatusBadge } from '../../../../components/common/StatusBadge';
import { Printer, X } from 'lucide-react';

interface Props {
  transferRecord: TransferRecord;
  isOpen: boolean;
  onClose: () => void;
  onPrintSlip: () => void;
}

export const TransferDetailsModal: React.FC<Props> = ({ transferRecord, isOpen, onClose, onPrintSlip }) => {
  if (!transferRecord) return null;

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Transfer Details" size="lg">
      <div className="space-y-6">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="bg-slate-50 dark:bg-slate-800 p-3 rounded-xl border border-slate-100 dark:border-slate-700">
            <span className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Transfer Code</span>
            <span className="font-mono font-bold text-slate-900 dark:text-slate-100">{transferRecord.transferCode}</span>
          </div>
          <div className="bg-slate-50 dark:bg-slate-800 p-3 rounded-xl border border-slate-100 dark:border-slate-700">
            <span className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Transfer Type</span>
            <span className="font-semibold text-slate-900 dark:text-slate-100">{transferRecord.transferType || 'Standard'}</span>
          </div>
          <div className="bg-slate-50 dark:bg-slate-800 p-3 rounded-xl border border-slate-100 dark:border-slate-700">
            <span className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Date Initiated</span>
            <span className="font-semibold text-slate-900 dark:text-slate-100 text-sm">{formatDateTime(transferRecord.transferDate)}</span>
          </div>
          <div className="bg-slate-50 dark:bg-slate-800 p-3 rounded-xl border border-slate-100 dark:border-slate-700">
            <span className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Status</span>
            <StatusBadge status={transferRecord.status} />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 mb-3 border-b border-slate-200 dark:border-slate-800 pb-2">Item Details</h4>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-slate-500">Asset Name</span>
                <span className="font-semibold text-slate-900 dark:text-slate-100">{transferRecord.itemName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Quantity</span>
                <span className="font-bold text-blue-600 dark:text-blue-400">{transferRecord.quantity}</span>
              </div>
              {transferRecord.assetId && (
                <div className="flex justify-between">
                  <span className="text-slate-500">Asset ID</span>
                  <span className="font-mono text-slate-900 dark:text-slate-100">{transferRecord.assetId}</span>
                </div>
              )}
            </div>
          </div>
          
          <div>
            <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 mb-3 border-b border-slate-200 dark:border-slate-800 pb-2">Movement</h4>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-slate-500">From</span>
                <span className="font-semibold text-slate-900 dark:text-slate-100">{transferRecord.fromLocation}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">To</span>
                <span className="font-semibold text-slate-900 dark:text-slate-100">{transferRecord.toLocation}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Initiated By</span>
                <span className="font-medium text-slate-900 dark:text-slate-100">{transferRecord.initiatedBy}</span>
              </div>
            </div>
          </div>
        </div>

        <div>
          <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 mb-2">Remarks / Reason</h4>
          <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-xl text-sm text-slate-700 dark:text-slate-300 min-h-[60px] border border-slate-200 dark:border-slate-700">
            {transferRecord.reason || transferRecord.notes || 'No remarks provided.'}
          </div>
        </div>

        <div className="flex justify-end gap-3 pt-4 border-t border-slate-100 dark:border-slate-800">
          <Button variant="outline" onClick={onClose} icon={<X className="w-4 h-4" />}>Close</Button>
          <Button variant="primary" onClick={() => { onClose(); onPrintSlip(); }} icon={<Printer className="w-4 h-4" />}>Print Transfer Slip</Button>
        </div>
      </div>
    </Modal>
  );
};
