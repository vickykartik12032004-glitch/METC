import { useTransactionStore } from '../../../store/useTransactionStore';
import { useAssetStore } from '../../../store/useAssetStore';
import { useWorkerStore } from '../../../store/useWorkerStore';
import { TransferRecord } from '../../../types';
import { useNotificationStore } from '../../../store/useNotificationStore';
import { logActivity } from '../../../services/activityLogService';

export function createTransfer(payload: Partial<TransferRecord>): TransferRecord {
  const transactionStore = useTransactionStore.getState();
  const assetStore = useAssetStore.getState();
  const workerStore = useWorkerStore.getState();

  const newTransfer: TransferRecord = {
    id: `transfer-${Date.now()}`,
    transferCode: `TRF-${new Date().getFullYear()}${(Math.floor(Math.random() * 9000) + 1000)}`,
    status: 'Pending',
    transferDate: new Date().toISOString(),
    ...payload
  } as TransferRecord;

  // Additional automatic updates logic goes here (e.g. reserving items)
  
  transactionStore.addTransfer(newTransfer);

  useNotificationStore.getState().addNotification({
    title: `Transfer Created: ${newTransfer.transferCode}`,
    message: `${newTransfer.itemName} transfer initiated from ${newTransfer.fromLocation} to ${newTransfer.toLocation}.`,
    type: 'info',
  });
  
  logActivity('create_transfer', 'transfers', newTransfer.id, {
    from: newTransfer.fromLocation,
    to: newTransfer.toLocation,
    type: newTransfer.transferType
  }, payload.initiatedBy || 'System');

  return newTransfer;
}

export function bulkTransfer(payloads: Partial<TransferRecord>[]): TransferRecord[] {
  return payloads.map(p => createTransfer(p));
}
