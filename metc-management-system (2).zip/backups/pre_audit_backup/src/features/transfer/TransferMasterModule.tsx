import React, { useState } from 'react';
import { useTransfer } from './hooks/useTransfer';
import { TransferDashboardKpis } from './components/dashboard/TransferDashboardKpis';
import { TransferQuickActions } from './components/dashboard/TransferQuickActions';
import { NewTransferForm } from './components/forms/NewTransferForm';
import { BulkTransferForm } from './components/forms/BulkTransferForm';
import { ActiveTransfersTable } from './components/tables/ActiveTransfersTable';
import { TransferHistoryTable } from './components/tables/TransferHistoryTable';
import { TransferDetailsModal } from './components/details/TransferDetailsModal';
import { TransferSlipModal } from './components/details/TransferSlipModal';
import { QRBarcodeScannerModal } from './components/forms/QRBarcodeScannerModal';

import {
  LayoutDashboard,
  Plus,
  History,
  RotateCcw,
  CheckSquare,
  FileBarChart2,
  ArrowRightLeft,
  Clock
} from 'lucide-react';
import { toast } from 'sonner';
import { TransferRecord } from '../../types';

export type TransferTabType =
  | 'dashboard'
  | 'new'
  | 'active'
  | 'history'
  | 'bulk'
  | 'reports';

export const TransferMasterModule: React.FC = () => {
  const {
    transfers,
    filteredTransfers,
    kpis,
    filters,
    setFilters,
  } = useTransfer();

  const [activeTab, setActiveTab] = useState<TransferTabType>('dashboard');
  const [selectedTransferForDetails, setSelectedTransferForDetails] = useState<TransferRecord | null>(null);
  const [selectedTransferForSlip, setSelectedTransferForSlip] = useState<TransferRecord | null>(null);
  const [isScannerOpen, setIsScannerOpen] = useState(false);

  const tabs = [
    { id: 'dashboard', label: 'Transfer Dashboard', icon: LayoutDashboard },
    { id: 'new', label: 'New Transfer', icon: Plus },
    { id: 'active', label: 'Active Transfers', icon: Clock },
    { id: 'history', label: 'Transfer History', icon: History },
    { id: 'bulk', label: 'Bulk Transfer', icon: CheckSquare },
    { id: 'reports', label: 'Reports', icon: FileBarChart2 },
  ];

  const activeTransfers = filteredTransfers.filter(t => t.status === 'Pending' || t.status === 'In Transit');
  const historyTransfers = filteredTransfers.filter(t => t.status === 'Completed' || t.status === 'Rejected' || t.status === 'Cancelled');

  return (
    <div className="space-y-6">
      {/* Header and Tabs */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-4">
          <div>
            <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100 tracking-tight">Enterprise Transfer Management</h1>
            <p className="text-xs text-slate-500 mt-1">Manage asset movements between workers, stores, sites, and branches</p>
          </div>
        </div>

        <div className="flex items-center gap-1 overflow-x-auto pb-1 scrollbar-hide">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id as TransferTabType)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                activeTab === t.id
                  ? 'bg-blue-50 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              <t.icon className="w-4 h-4" />
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content Area */}
      {activeTab === 'dashboard' && (
        <div className="space-y-6">
          <TransferDashboardKpis kpis={kpis} onFilterStatus={(status) => {
            if (status === 'Pending' || status === 'In Transit') {
              setFilters({ ...filters, status });
              setActiveTab('active');
            } else {
              setFilters({ ...filters, status });
              setActiveTab('history');
            }
          }} />
          <TransferQuickActions onAction={(action) => {
            if (action === 'new') setActiveTab('new');
            if (action === 'bulk') setActiveTab('bulk');
            if (action === 'qr' || action === 'barcode') setIsScannerOpen(true);
            if (action === 'reports') setActiveTab('reports');
          }} />
        </div>
      )}

      {activeTab === 'new' && (
        <NewTransferForm 
          onSubmit={() => setActiveTab('active')}
          onCancel={() => setActiveTab('dashboard')} 
        />
      )}

      {activeTab === 'bulk' && (
        <BulkTransferForm 
          onSubmit={() => setActiveTab('active')}
          onCancel={() => setActiveTab('dashboard')} 
        />
      )}

      {activeTab === 'active' && (
        <ActiveTransfersTable 
          transfers={activeTransfers} 
          filters={filters}
          setFilters={setFilters}
          onViewDetails={setSelectedTransferForDetails} 
          onPrintSlip={setSelectedTransferForSlip}
        />
      )}

      {activeTab === 'history' && (
        <TransferHistoryTable 
          transfers={historyTransfers} 
          filters={filters}
          setFilters={setFilters}
          onViewDetails={setSelectedTransferForDetails} 
          onPrintSlip={setSelectedTransferForSlip}
        />
      )}

      {activeTab === 'reports' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-8 text-center text-slate-500">
          <FileBarChart2 className="w-12 h-12 mx-auto mb-4 text-slate-300" />
          <h2 className="text-lg font-bold text-slate-700 dark:text-slate-200">Transfer Reports & Analytics</h2>
          <p className="text-sm mt-2">Generate PDF and Excel reports for worker, site, and branch transfers.</p>
        </div>
      )}

      {/* Modals */}
      {selectedTransferForDetails && (
        <TransferDetailsModal 
          transferRecord={selectedTransferForDetails} 
          isOpen={Boolean(selectedTransferForDetails)} 
          onClose={() => setSelectedTransferForDetails(null)} 
          onPrintSlip={() => setSelectedTransferForSlip(selectedTransferForDetails)}
        />
      )}

      {selectedTransferForSlip && (
        <TransferSlipModal 
          transferRecord={selectedTransferForSlip} 
          isOpen={Boolean(selectedTransferForSlip)} 
          onClose={() => setSelectedTransferForSlip(null)} 
        />
      )}

      {isScannerOpen && (
        <QRBarcodeScannerModal
          isOpen={isScannerOpen}
          onClose={() => setIsScannerOpen(false)}
          onScan={(code) => {
             setIsScannerOpen(false);
             toast.success(`Scanned: ${code}`);
             setActiveTab('new');
             // Need a way to pass initial asset to NewTransferForm
          }}
        />
      )}
    </div>
  );
};
