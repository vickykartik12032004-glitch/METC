import { useMemo, useState } from 'react';
import { useTransactionStore } from '../../../store/useTransactionStore';
import { useAssetStore } from '../../../store/useAssetStore';
import { useWorkerStore } from '../../../store/useWorkerStore';

export const useTransfer = () => {
  const { transfers } = useTransactionStore();
  const { workers } = useWorkerStore();
  const assetStore = useAssetStore();
  
  const [filters, setFilters] = useState({
    search: '',
    status: 'All',
    transferType: 'All',
  });

  const kpis = useMemo(() => {
    const todayStr = new Date().toISOString().split('T')[0];
    const todayTransfers = transfers.filter(t => t.transferDate.startsWith(todayStr)).length;
    
    const pendingTransfers = transfers.filter(t => t.status === 'Pending').length;
    const completedTransfers = transfers.filter(t => t.status === 'Completed').length;
    const cancelledTransfers = transfers.filter(t => t.status === 'Cancelled').length;
    
    const siteTransfers = transfers.filter(t => t.transferType === 'Site to Site' || t.transferType === 'Store to Site' || t.transferType === 'Site to Store').length;
    const branchTransfers = transfers.filter(t => t.transferType === 'Branch to Branch').length;

    return {
      todayTransfers,
      pendingTransfers,
      completedTransfers,
      cancelledTransfers,
      siteTransfers,
      branchTransfers,
    };
  }, [transfers]);

  const filteredTransfers = useMemo(() => {
    return transfers.filter(t => {
      const matchesSearch = 
        t.transferCode.toLowerCase().includes(filters.search.toLowerCase()) ||
        t.itemName.toLowerCase().includes(filters.search.toLowerCase()) ||
        t.fromLocation.toLowerCase().includes(filters.search.toLowerCase()) ||
        t.toLocation.toLowerCase().includes(filters.search.toLowerCase());
        
      const matchesStatus = filters.status === 'All' || t.status === filters.status;
      const matchesType = filters.transferType === 'All' || t.transferType === filters.transferType;
      
      return matchesSearch && matchesStatus && matchesType;
    });
  }, [transfers, filters]);

  return {
    transfers,
    filteredTransfers,
    kpis,
    filters,
    setFilters,
  };
};
