import { AssetCategory } from '../../types';

export type WorkerStatus = 'Active' | 'Inactive' | 'On Leave' | 'Resigned' | 'Terminated';

export type DocumentType = 
  | 'Passport'
  | 'Work Permit'
  | 'Training Certificate'
  | 'Driving License'
  | 'Safety Certificate'
  | 'Medical Certificate'
  | 'Other';

export interface WorkerDocument {
  id: string;
  workerId: string;
  title: string;
  docType: DocumentType;
  fileUrl: string;
  expiryDate?: string;
  status: 'Valid' | 'Expiring Soon' | 'Expired' | 'Missing';
  uploadedAt: string;
}

export interface EnterpriseWorker {
  id: string;
  workerCode: string; // Worker ID e.g. WRK-2026-001
  employeeNumber: string; // Employee Number e.g. EMP-9981
  name: string;
  gender?: 'Male' | 'Female' | 'Other';
  dateOfBirth?: string;
  nationality?: string;
  phone: string;
  email?: string;
  trade: string; // e.g., Electrician, Welder, Mason, Operator
  department: string; // e.g. Civil Engineering, MEP, Safety
  branch: string; // e.g. HQ, North Division
  site: string; // e.g., Tower A Site, Metro Line 3
  company: string; // e.g. MOUNTEC PTE LTD
  supervisor?: string;
  joiningDate: string;
  status: WorkerStatus;
  badgeNumber: string;
  wpId?: string;
  emergencyContact?: string;
  emergencyPhone?: string;
  address?: string;
  remarks?: string;
  photoUrl?: string;
  assignedItemsCount: number;
  overdueItemsCount: number;
  documents?: WorkerDocument[];
  createdAt?: string;
  updatedAt?: string;
}

export interface WorkerKPIs {
  currentIssuedItems: number;
  returnedItems: number;
  overdueItems: number;
  lostItems: number;
  damagedItems: number;
  repairItems: number;
  totalIssues: number;
}

export interface OverdueItemRecord {
  id: string;
  issueCode: string;
  workerId: string;
  workerName: string;
  workerPhone?: string;
  itemId: string;
  itemName: string;
  itemCategory: AssetCategory;
  itemCode: string;
  photoUrl?: string;
  issueDate: string;
  expectedReturnDate: string;
  daysOverdue: number;
  priorityBadge: 'High' | 'Medium' | 'Low';
  site: string;
  quantity: number;
}

export interface ItemHistoryEvent {
  id: string;
  type: 'Issued' | 'Returned' | 'Transferred' | 'Repair' | 'Lost' | 'Disposed';
  date: string;
  itemCode: string;
  itemName: string;
  category: AssetCategory;
  quantity: number;
  details: string;
  handledBy: string;
  status?: string;
}
