import { supabase, isSupabaseConfigured } from '../../../lib/supabase';
import type { EnterpriseWorker, WorkerDocument, WorkerKPIs, OverdueItemRecord, ItemHistoryEvent, WorkerStatus } from '../types';
import { INITIAL_WORKERS, INITIAL_ISSUES, INITIAL_RETURNS, INITIAL_TRANSFERS, INITIAL_REPAIRS, INITIAL_LOST } from '../../../data/mockData';
import { logActivity } from '../../../services/activityLogService';
import { cloudApi } from '../../../services/apiClient';
import { useWorkerStore } from '../../../store/useWorkerStore';

/**
 * Mapping helper for Supabase Worker DB Row -> EnterpriseWorker interface
 */
export function mapDbWorkerToEnterpriseWorker(row: any): EnterpriseWorker {
  return {
    id: row.id,
    workerCode: row.workerCode || row.worker_id || `WRK-${String(row.id).slice(0, 5)}`,
    employeeNumber: row.employeeNumber || row.employee_number || row.badgeNumber || `EMP-${String(row.id).slice(0, 5)}`,
    name: row.name || 'Unnamed Worker',
    gender: row.gender || 'Male',
    dateOfBirth: row.dateOfBirth || row.date_of_birth || undefined,
    nationality: row.nationality || 'Local',
    phone: row.phone || 'N/A',
    email: row.email || undefined,
    trade: row.trade || 'General Worker',
    department: row.department || 'Site Operations',
    branch: row.branch || 'Main Branch',
    site: row.site || row.site_id || row.project_site || row.projectSite || 'Tuas Mega Logistics Depot',
    company: row.company || 'MOUNTEC PTE LTD',
    supervisor: row.supervisor || undefined,
    joiningDate: row.joiningDate || row.joinedDate || row.joining_date || new Date().toISOString().split('T')[0],
    status: (row.status as WorkerStatus) || 'Active',
    badgeNumber: row.badgeNumber || row.badge_number || row.employeeNumber || `BDG-${String(row.id).slice(0, 4)}`,
    wpId: row.wpId || row.wp_id || row.idNumber || row.wpNumber || undefined,
    emergencyContact: row.emergencyContact || row.emergency_contact || undefined,
    emergencyPhone: row.emergencyPhone || row.emergency_phone || undefined,
    address: row.address || undefined,
    remarks: row.remarks || undefined,
    photoUrl: row.photoUrl || row.photo_url || undefined,
    assignedItemsCount: row.assignedItemsCount || row.assigned_items_count || 0,
    overdueItemsCount: row.overdueItemsCount || row.overdue_items_count || 0,
    documents: row.documents || [],
    createdAt: row.createdAt || row.created_at,
    updatedAt: row.updatedAt || row.updated_at,
  };
}

/**
 * Initial mock documents for offline fallback
 */
export const MOCK_WORKER_DOCUMENTS: Record<string, WorkerDocument[]> = {
  'wrk-004': [
    {
      id: 'doc-401',
      workerId: 'wrk-004',
      title: 'BCA CoreTrade Specialist Card',
      docType: 'Training Certificate',
      fileUrl: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=300',
      expiryDate: '2027-11-30',
      status: 'Valid',
      uploadedAt: '2024-01-20',
    },
    {
      id: 'doc-402',
      workerId: 'wrk-004',
      title: 'Work Permit (MOM Singapore)',
      docType: 'Work Permit',
      fileUrl: 'https://images.unsplash.com/photo-1544717305-2782549b5136?w=300',
      expiryDate: '2026-12-31',
      status: 'Valid',
      uploadedAt: '2024-01-16',
    },
  ],
  'wrk-005': [
    {
      id: 'doc-501',
      workerId: 'wrk-005',
      title: 'Structural 6G AWS D1.1 Welding Pass',
      docType: 'Training Certificate',
      fileUrl: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=300',
      expiryDate: '2027-08-15',
      status: 'Valid',
      uploadedAt: '2024-02-05',
    },
    {
      id: 'doc-502',
      workerId: 'wrk-005',
      title: 'Hot Work Safety Assessor Clearance',
      docType: 'Safety Certificate',
      fileUrl: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=300',
      expiryDate: '2026-10-01',
      status: 'Valid',
      uploadedAt: '2024-02-10',
    },
  ],
  'wrk-009': [
    {
      id: 'doc-901',
      workerId: 'wrk-009',
      title: 'EMA Licensed Electrical Worker (LEW)',
      docType: 'Training Certificate',
      fileUrl: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=300',
      expiryDate: '2028-05-10',
      status: 'Valid',
      uploadedAt: '2024-02-25',
    },
    {
      id: 'doc-902',
      workerId: 'wrk-009',
      title: 'High Voltage Safety Protocol (HSE)',
      docType: 'Safety Certificate',
      fileUrl: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=300',
      expiryDate: '2026-09-15',
      status: 'Valid',
      uploadedAt: '2024-03-01',
    },
  ],
  'wrk-012': [
    {
      id: 'doc-1201',
      workerId: 'wrk-012',
      title: 'Site Operations & Logistics Certificate',
      docType: 'Training Certificate',
      fileUrl: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=300',
      expiryDate: '2028-01-01',
      status: 'Valid',
      uploadedAt: '2024-03-05',
    },
    {
      id: 'doc-1202',
      workerId: 'wrk-012',
      title: 'Building Construction Safety Supervisor (BCSS)',
      docType: 'Safety Certificate',
      fileUrl: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=300',
      expiryDate: '2027-04-12',
      status: 'Valid',
      uploadedAt: '2024-03-10',
    },
  ],
  'wrk-026': [
    {
      id: 'doc-2601',
      workerId: 'wrk-026',
      title: 'MOM Rigger & Slinger Certification',
      docType: 'Training Certificate',
      fileUrl: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=300',
      expiryDate: '2027-06-30',
      status: 'Valid',
      uploadedAt: '2024-03-20',
    },
    {
      id: 'doc-2602',
      workerId: 'wrk-026',
      title: 'Work-At-Height (WAH) for Supervisors',
      docType: 'Safety Certificate',
      fileUrl: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=300',
      expiryDate: '2026-11-20',
      status: 'Valid',
      uploadedAt: '2024-03-22',
    },
  ],
  'wrk-027': [
    {
      id: 'doc-2701',
      workerId: 'wrk-027',
      title: 'Heavy Plant & Mobile Crane Operator License',
      docType: 'Driving License',
      fileUrl: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=300',
      expiryDate: '2028-09-18',
      status: 'Valid',
      uploadedAt: '2024-04-15',
    },
  ],
  'wrk-028': [
    {
      id: 'doc-2801',
      workerId: 'wrk-028',
      title: 'Advanced Formwork & Masonry Certification',
      docType: 'Training Certificate',
      fileUrl: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=300',
      expiryDate: '2027-12-01',
      status: 'Valid',
      uploadedAt: '2024-05-08',
    },
  ],
  'wrk-029': [
    {
      id: 'doc-2901',
      workerId: 'wrk-029',
      title: 'WSH Officer (WSHO) Registered License',
      docType: 'Safety Certificate',
      fileUrl: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=300',
      expiryDate: '2027-10-31',
      status: 'Valid',
      uploadedAt: '2024-05-25',
    },
  ],
};

/**
 * Enterprise Worker Directory initialized from the enterprise workforce records
 */
export const INITIAL_ENTERPRISE_WORKERS: EnterpriseWorker[] = [
  {
    id: 'wrk-004',
    workerCode: 'ME-004',
    employeeNumber: 'ME-004',
    name: 'RAJENDIRAN RAMU',
    gender: 'Male',
    dateOfBirth: '1989-04-12',
    nationality: 'India',
    phone: '+65 8123 4004',
    email: 'rajendiran.ramu@mountec.sg',
    trade: 'Senior Pipefitter',
    department: 'Mechanical & Electrical MEP',
    branch: 'Tuas Western Logistics Hub',
    site: 'Tuas Mega Logistics Depot',
    company: 'MOUNTEC PTE LTD',
    supervisor: 'Elena Rostova',
    joiningDate: '2024-01-15',
    status: 'Active',
    badgeNumber: 'ME-004',
    wpId: '0 38830686',
    emergencyContact: 'R. Lakshmi (Spouse)',
    emergencyPhone: '+65 9123 4004',
    address: 'Block 24 Tuas South Dormitory, Singapore',
    remarks: 'WP/ID NO: 0 38830686 - Certified high-pressure piping specialist',
    photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200',
    assignedItemsCount: 0,
    overdueItemsCount: 0,
    documents: MOCK_WORKER_DOCUMENTS['wrk-004'] || [],
    createdAt: '2024-01-15T08:00:00Z',
    updatedAt: '2024-01-15T08:00:00Z',
  },
  {
    id: 'wrk-005',
    workerCode: 'ME-005',
    employeeNumber: 'ME-005',
    name: 'RAMU ELUMALAI',
    gender: 'Male',
    dateOfBirth: '1987-08-23',
    nationality: 'India',
    phone: '+65 8123 4005',
    email: 'ramu.elumalai@mountec.sg',
    trade: 'Structural Welder',
    department: 'Structural Works',
    branch: 'Tuas Western Logistics Hub',
    site: 'Tuas Mega Logistics Depot',
    company: 'MOUNTEC PTE LTD',
    supervisor: 'Elena Rostova',
    joiningDate: '2024-02-01',
    status: 'Active',
    badgeNumber: 'ME-005',
    wpId: '0 38889257',
    emergencyContact: 'E. Kamala (Family)',
    emergencyPhone: '+65 9123 4005',
    address: 'Block 18 Jurong Penjuru Dormitory, Singapore',
    remarks: 'WP/ID NO: 0 38889257 - AWS D1.1 certified 6G pipe and structural welder',
    photoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200',
    assignedItemsCount: 0,
    overdueItemsCount: 0,
    documents: MOCK_WORKER_DOCUMENTS['wrk-005'] || [],
    createdAt: '2024-02-01T08:00:00Z',
    updatedAt: '2024-02-01T08:00:00Z',
  },
  {
    id: 'wrk-009',
    workerCode: 'ME-009',
    employeeNumber: 'ME-009',
    name: 'PANNEER SELVAM VENKATESAN',
    gender: 'Male',
    dateOfBirth: '1991-11-05',
    nationality: 'India',
    phone: '+65 8123 4009',
    email: 'panneerselvam.v@mountec.sg',
    trade: 'Electrical Technician',
    department: 'Mechanical & Electrical MEP',
    branch: 'Main HQ International Plaza',
    site: 'Changi Airport Terminal 5 Expansion',
    company: 'MOUNTEC PTE LTD',
    supervisor: 'Aaron Wong',
    joiningDate: '2024-02-20',
    status: 'Active',
    badgeNumber: 'ME-009',
    wpId: '0 37194166',
    emergencyContact: 'V. Sundari (Spouse)',
    emergencyPhone: '+65 9123 4009',
    address: 'Block 32 Tampines Industrial Lodge, Singapore',
    remarks: 'WP/ID NO: 0 37194166 - Licensed Electrical Worker (LEW)',
    photoUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=200',
    assignedItemsCount: 0,
    overdueItemsCount: 0,
    documents: MOCK_WORKER_DOCUMENTS['wrk-009'] || [],
    createdAt: '2024-02-20T08:00:00Z',
    updatedAt: '2024-02-20T08:00:00Z',
  },
  {
    id: 'wrk-012',
    workerCode: 'ME-012',
    employeeNumber: 'ME-012',
    name: 'KSHTRIY VICKY KARTIK',
    gender: 'Male',
    dateOfBirth: '1995-03-12',
    nationality: 'Singapore',
    phone: '+65 8123 4012',
    email: 'vickykartik12032004@gmail.com',
    trade: 'Site Operations Specialist',
    department: 'Site Operations',
    branch: 'Main HQ International Plaza',
    site: 'Corporate HQ - Marina Bay',
    company: 'MOUNTEC PTE LTD',
    supervisor: 'Super Admin',
    joiningDate: '2024-03-01',
    status: 'Active',
    badgeNumber: 'ME-012',
    wpId: '0 39505754',
    emergencyContact: 'K. Ravi (Father)',
    emergencyPhone: '+65 9123 4012',
    address: '10 Anson Road, International Plaza, Singapore',
    remarks: 'WP/ID NO: 0 39505754 - Site operations lead and central asset coordinator',
    photoUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=200',
    assignedItemsCount: 0,
    overdueItemsCount: 0,
    documents: MOCK_WORKER_DOCUMENTS['wrk-012'] || [],
    createdAt: '2024-03-01T08:00:00Z',
    updatedAt: '2024-03-01T08:00:00Z',
  },
  {
    id: 'wrk-026',
    workerCode: 'ME-026',
    employeeNumber: 'ME-026',
    name: 'HOSSAIN MOHAMMAD RAKIB',
    gender: 'Male',
    dateOfBirth: '1993-07-14',
    nationality: 'Bangladesh',
    phone: '+65 8123 4026',
    email: 'rakib.hossain@mountec.sg',
    trade: 'Scaffolding & Rigging Specialist',
    department: 'Site Operations',
    branch: 'Tuas Western Logistics Hub',
    site: 'Tuas Mega Logistics Depot',
    company: 'MOUNTEC PTE LTD',
    supervisor: 'David Tan',
    joiningDate: '2024-03-15',
    status: 'Active',
    badgeNumber: 'ME-026',
    wpId: '0 34098121',
    emergencyContact: 'M. Fatima (Family)',
    emergencyPhone: '+65 9123 4026',
    address: 'Tuas South Dormitory, Singapore',
    remarks: 'WP/ID NO: 0 34098121 - Certified Scaffolder',
    photoUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=200',
    assignedItemsCount: 0,
    overdueItemsCount: 0,
    documents: [],
    createdAt: '2024-03-15T08:00:00Z',
    updatedAt: '2024-03-15T08:00:00Z',
  },
  {
    id: 'wrk-027',
    workerCode: 'ME-027',
    employeeNumber: 'ME-027',
    name: 'MANI RAGHU',
    gender: 'Male',
    dateOfBirth: '1986-09-30',
    nationality: 'India',
    phone: '+65 8123 4027',
    email: 'mani.raghu@mountec.sg',
    trade: 'Heavy Machinery Operator',
    department: 'Civil Engineering',
    branch: 'Main HQ International Plaza',
    site: 'Changi Airport Terminal 5 Expansion',
    company: 'MOUNTEC PTE LTD',
    supervisor: 'Aaron Wong',
    joiningDate: '2024-04-10',
    status: 'Active',
    badgeNumber: 'ME-027',
    wpId: '0 34117349',
    emergencyContact: 'R. Valli (Spouse)',
    emergencyPhone: '+65 9123 4027',
    address: 'Block 12 Changi Lodge II, Singapore',
    remarks: 'WP/ID NO: 0 34117349 - Licensed crane, excavator, and heavy telehandler operator',
    photoUrl: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&q=80&w=200',
    assignedItemsCount: 0,
    overdueItemsCount: 0,
    documents: MOCK_WORKER_DOCUMENTS['wrk-027'] || [],
    createdAt: '2024-04-10T08:00:00Z',
    updatedAt: '2024-04-10T08:00:00Z',
  },
  {
    id: 'wrk-028',
    workerCode: 'ME-028',
    employeeNumber: 'ME-028',
    name: 'RATHINASAMY AYYAPPAN',
    gender: 'Male',
    dateOfBirth: '1990-12-05',
    nationality: 'India',
    phone: '+65 8123 4028',
    email: 'r.ayyappan@mountec.sg',
    trade: 'Mechanical & Rigging Specialist',
    department: 'Site Operations',
    branch: 'Main HQ International Plaza',
    site: 'Tuas Mega Logistics Depot',
    company: 'MOUNTEC PTE LTD',
    supervisor: 'David Tan',
    joiningDate: '2024-05-02',
    status: 'Active',
    badgeNumber: 'ME-028',
    wpId: '0 34125670',
    emergencyContact: 'A. Malar (Spouse)',
    emergencyPhone: '+65 9123 4028',
    address: 'Block 20 Jurong Penjuru Dormitory, Singapore',
    remarks: 'WP/ID NO: 0 34125670 - Rigging & Mechanical specialist',
    photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
    assignedItemsCount: 0,
    overdueItemsCount: 0,
    documents: [],
    createdAt: '2024-05-02T08:00:00Z',
    updatedAt: '2024-05-02T08:00:00Z',
  },
  {
    id: 'wrk-029',
    workerCode: 'ME-029',
    employeeNumber: 'ME-029',
    name: 'CHINNIAH RENGASAMY',
    gender: 'Male',
    dateOfBirth: '1984-06-08',
    nationality: 'India',
    phone: '+65 8123 4029',
    email: 'chinniah.r@mountec.sg',
    trade: 'HSE Safety Coordinator',
    department: 'Safety & Quality Assurance',
    branch: 'Tuas Western Logistics Hub',
    site: 'Tuas Mega Logistics Depot',
    company: 'MOUNTEC PTE LTD',
    supervisor: 'David Tan',
    joiningDate: '2024-05-20',
    status: 'Active',
    badgeNumber: 'ME-029',
    wpId: '0 34138923',
    emergencyContact: 'R. Selvi (Spouse)',
    emergencyPhone: '+65 9123 4029',
    address: 'Block 5 Tuas View Dormitory, Singapore',
    remarks: 'WP/ID NO: 0 34138923 - WSH safety officer, PPE compliance inspector',
    photoUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=200',
    assignedItemsCount: 0,
    overdueItemsCount: 0,
    documents: MOCK_WORKER_DOCUMENTS['wrk-029'] || [],
    createdAt: '2024-05-20T08:00:00Z',
    updatedAt: '2024-05-20T08:00:00Z',
  },
  {
    id: 'wrk-030',
    workerCode: 'ME-030',
    employeeNumber: 'ME-030',
    name: 'PITCHAIYAN PRABAKARAN',
    gender: 'Male',
    dateOfBirth: '1992-04-18',
    nationality: 'India',
    phone: '+65 8123 4030',
    email: 'prabakaran.p@mountec.sg',
    trade: 'Senior Rigging & Scaffolding Lead',
    department: 'Site Operations',
    branch: 'Tuas Western Logistics Hub',
    site: 'Jurong Innovation District Hub',
    company: 'MOUNTEC PTE LTD',
    supervisor: 'K. Rajan',
    joiningDate: '2024-06-01',
    status: 'Active',
    badgeNumber: 'ME-030',
    wpId: '0 3465199-',
    emergencyContact: 'P. Priya (Spouse)',
    emergencyPhone: '+65 9123 4030',
    address: 'Kian Teck Dormitory, Jurong West, Singapore',
    remarks: 'WP/ID NO: 0 3465199- - Certified Rigger & Slinger with WAH Level 3',
    photoUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=200',
    assignedItemsCount: 0,
    overdueItemsCount: 0,
    documents: [],
    createdAt: '2024-06-01T08:00:00Z',
    updatedAt: '2024-06-01T08:00:00Z',
  },
];

const WORKERS_STORAGE_KEY = 'mountec_workers_directory_v3';

export function getLocalWorkers(): EnterpriseWorker[] {
  if (typeof window !== 'undefined') {
    try {
      const stored = localStorage.getItem(WORKERS_STORAGE_KEY);
      if (stored !== null) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.warn('Failed to parse local workers store', e);
    }
  }
  return INITIAL_ENTERPRISE_WORKERS;
}

export function saveLocalWorkers(workers: EnterpriseWorker[]): void {
  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem(WORKERS_STORAGE_KEY, JSON.stringify(workers));
    } catch (e) {
      console.warn('Failed to save local workers store', e);
    }
  }
}

/**
 * Fetch all workers from Central Cloud Database (or fallback to local / Supabase)
 */
export async function fetchWorkersDb(): Promise<EnterpriseWorker[]> {
  // 1. Prioritize authoritative central cloud database
  try {
    const res = await cloudApi.getWorkers();
    if (res && res.success && Array.isArray(res.data)) {
      const enterpriseList = res.data.map(mapDbWorkerToEnterpriseWorker);
      saveLocalWorkers(enterpriseList);
      useWorkerStore.getState().syncAllWorkers(enterpriseList as any);
      return enterpriseList;
    }
  } catch (err) {
    console.warn('[WorkersService] Failed to fetch from cloud server, checking local fallback:', err);
  }

  const local = getLocalWorkers();
  if (!isSupabaseConfigured) return local;

  try {
    const { data, error } = await supabase.from('workers').select('*').order('created_at', { ascending: false });

    if (error || !data || data.length === 0) {
      return local;
    }

    const mapped = data.map(mapDbWorkerToEnterpriseWorker);
    saveLocalWorkers(mapped);
    useWorkerStore.getState().syncAllWorkers(mapped as any);
    return mapped;
  } catch (err) {
    console.error('Error in fetchWorkersDb:', err);
    return local;
  }
}

export async function clearAllWorkersDb(): Promise<void> {
  saveLocalWorkers([]);
  await useWorkerStore.getState().clearAllWorkers();
}

export async function restoreDemoWorkersDb(): Promise<EnterpriseWorker[]> {
  await useWorkerStore.getState().restoreDemoWorkers();
  const res = await fetchWorkersDb();
  return res;
}

/**
 * Create a new worker in Central Cloud Database, Supabase, and local store
 */
export async function createWorkerDb(workerData: Partial<EnterpriseWorker>, userName = 'HR Admin'): Promise<EnterpriseWorker | null> {
  const newId = workerData.id || `wrk-${Date.now()}`;
  const code = workerData.workerCode || `WRK-${Date.now().toString().slice(-6)}`;
  const empNum = workerData.employeeNumber || workerData.badgeNumber || `EMP-${Date.now().toString().slice(-4)}`;

  const newWorker: EnterpriseWorker = {
    id: newId,
    workerCode: code,
    employeeNumber: empNum,
    name: workerData.name || 'New Worker',
    gender: workerData.gender || 'Male',
    dateOfBirth: workerData.dateOfBirth,
    nationality: workerData.nationality || 'Local',
    phone: workerData.phone || '',
    email: workerData.email || '',
    trade: workerData.trade || 'General Worker',
    department: workerData.department || 'Site Operations',
    branch: workerData.branch || 'Main Branch',
    site: workerData.site || 'Tuas Mega Logistics Depot',
    company: workerData.company || 'MOUNTEC PTE LTD',
    supervisor: workerData.supervisor || 'Site Manager',
    joiningDate: workerData.joiningDate || new Date().toISOString().split('T')[0],
    status: workerData.status || 'Active',
    badgeNumber: workerData.badgeNumber || empNum,
    emergencyContact: workerData.emergencyContact || '',
    emergencyPhone: workerData.emergencyPhone || '',
    address: workerData.address || '',
    remarks: workerData.remarks || '',
    photoUrl: workerData.photoUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
    assignedItemsCount: workerData.assignedItemsCount || 0,
    overdueItemsCount: 0,
    documents: workerData.documents || [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  // 1. Central Cloud Server (Single Source of Truth)
  try {
    const res = await cloudApi.createWorker(newWorker);
    if (res && res.data) {
      const createdWorker = mapDbWorkerToEnterpriseWorker(res.data);
      const current = getLocalWorkers();
      saveLocalWorkers([createdWorker, ...current.filter((w) => w.id !== createdWorker.id)]);
      useWorkerStore.getState().applyRemoteWorkerCreated(createdWorker as any);
      await logActivity('Created', 'Worker', createdWorker.id, { details: `Registered worker ${createdWorker.name} (${createdWorker.workerCode})` }, userName);
      return createdWorker;
    }
  } catch (err) {
    console.warn('[WorkersService] Failed to post worker to central cloud API:', err);
  }

  // 2. Supabase if configured
  if (isSupabaseConfigured) {
    try {
      const insertRow = {
        worker_id: newWorker.workerCode,
        employee_number: newWorker.employeeNumber,
        name: newWorker.name,
        photo_url: newWorker.photoUrl,
        phone: newWorker.phone,
        email: newWorker.email,
        trade: newWorker.trade,
        company: newWorker.company,
        status: newWorker.status,
        joining_date: newWorker.joiningDate,
        remarks: newWorker.remarks,
      };

      const { data, error } = await (supabase as any).from('workers').insert(insertRow).select().single();
      if (!error && data) {
        const created = mapDbWorkerToEnterpriseWorker(data);
        const current = getLocalWorkers();
        saveLocalWorkers([created, ...current.filter((w) => w.id !== created.id)]);
        useWorkerStore.getState().applyRemoteWorkerCreated(created as any);
        await logActivity('Created', 'Worker', created.id, { details: `Registered worker ${created.name} (${created.workerCode})` }, userName);
        return created;
      }
    } catch (err) {
      console.error('Error creating worker on Supabase:', err);
    }
  }

  // 3. Local fallback
  const current = getLocalWorkers();
  saveLocalWorkers([newWorker, ...current]);
  useWorkerStore.getState().applyRemoteWorkerCreated(newWorker as any);
  await logActivity('Created', 'Worker', newWorker.id, { details: `Registered worker ${newWorker.name} (${newWorker.workerCode})` }, userName);
  return newWorker;
}

/**
 * Update worker in Central Cloud Database, Supabase, and local store
 */
export async function updateWorkerDb(id: string, updates: Partial<EnterpriseWorker>, userName = 'HR Admin'): Promise<boolean> {
  const current = getLocalWorkers();
  const updated = current.map((w) => (w.id === id ? { ...w, ...updates, updatedAt: new Date().toISOString() } : w));
  saveLocalWorkers(updated);

  // 1. Central Cloud Server
  try {
    const res = await cloudApi.updateWorker(id, updates);
    if (res && res.data) {
      const serverWorker = mapDbWorkerToEnterpriseWorker(res.data);
      useWorkerStore.getState().applyRemoteWorkerUpdated(serverWorker as any);
    }
  } catch (err) {
    console.warn('[WorkersService] Failed to sync worker update to central cloud server:', err);
  }

  // 2. Supabase if configured
  if (isSupabaseConfigured) {
    try {
      const updateRow: any = {};
      if (updates.name !== undefined) updateRow.name = updates.name;
      if (updates.workerCode !== undefined) updateRow.worker_id = updates.workerCode;
      if (updates.employeeNumber !== undefined) updateRow.employee_number = updates.employeeNumber;
      if (updates.phone !== undefined) updateRow.phone = updates.phone;
      if (updates.email !== undefined) updateRow.email = updates.email;
      if (updates.trade !== undefined) updateRow.trade = updates.trade;
      if (updates.company !== undefined) updateRow.company = updates.company;
      if (updates.status !== undefined) updateRow.status = updates.status;
      if (updates.photoUrl !== undefined) updateRow.photo_url = updates.photoUrl;
      if (updates.joiningDate !== undefined) updateRow.joining_date = updates.joiningDate;
      if (updates.remarks !== undefined) updateRow.remarks = updates.remarks;
      updateRow.updated_at = new Date().toISOString();

      await (supabase as any).from('workers').update(updateRow).eq('id', id);
    } catch (e) {
      console.warn('Notice updating worker on Supabase:', e);
    }
  }

  await logActivity('Updated', 'Worker', id, { details: `Updated profile details for worker ID: ${id}` }, userName);
  return true;
}

/**
 * Delete worker from Central Cloud Database, Supabase, and local store
 */
export async function deleteWorkerDb(id: string, userName = 'HR Admin'): Promise<boolean> {
  const current = getLocalWorkers();
  const filtered = current.filter((w) => w.id !== id);
  saveLocalWorkers(filtered);

  // 1. Central Cloud Server
  try {
    await cloudApi.deleteWorker(id);
    useWorkerStore.getState().applyRemoteWorkerDeleted(id);
  } catch (err) {
    console.warn('[WorkersService] Failed to delete worker on central cloud server:', err);
  }

  // 2. Supabase if configured
  if (isSupabaseConfigured) {
    try {
      await (supabase as any).from('workers').delete().eq('id', id);
    } catch (e) {
      console.warn('Notice deleting worker on Supabase:', e);
    }
  }
  await logActivity('Updated', 'Worker', id, { details: `Archived/Deactivated worker ID: ${id}` }, userName);
  return true;
}

/**
 * Fetch Overdue Items calculated automatically across workers
 */
export function calculateOverdueItems(workers: EnterpriseWorker[]): OverdueItemRecord[] {
  const now = new Date();
  const overdueList: OverdueItemRecord[] = [];

  INITIAL_ISSUES.forEach((iss) => {
    if (iss.expectedReturnDate && iss.status === 'Active') {
      const expected = new Date(iss.expectedReturnDate);
      if (expected < now) {
        const diffTime = Math.abs(now.getTime() - expected.getTime());
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        const matchedWorker = workers.find((w) => w.id === iss.workerId || w.name === iss.workerName);

        let priorityBadge: 'High' | 'Medium' | 'Low' = 'Low';
        if (diffDays > 14) priorityBadge = 'High';
        else if (diffDays > 7) priorityBadge = 'Medium';

        overdueList.push({
          id: `ovd-${iss.id}`,
          issueCode: iss.issueCode,
          workerId: iss.workerId,
          workerName: iss.workerName,
          workerPhone: matchedWorker?.phone || '+1 (555) 456-7890',
          itemId: iss.itemId,
          itemName: iss.itemName,
          itemCategory: iss.itemCategory,
          itemCode: `AST-${iss.itemId.toUpperCase()}`,
          photoUrl: matchedWorker?.photoUrl,
          issueDate: iss.issueDate,
          expectedReturnDate: iss.expectedReturnDate,
          daysOverdue: diffDays,
          priorityBadge,
          site: iss.projectSite,
          quantity: iss.quantity,
        });
      }
    }
  });

  return overdueList;
}

/**
 * Get item history timeline for a specific worker
 */
export function getWorkerItemHistory(workerId: string): ItemHistoryEvent[] {
  const history: ItemHistoryEvent[] = [];

  INITIAL_ISSUES.filter((i) => i.workerId === workerId || i.workerName.toLowerCase().includes('jean') || i.workerName.toLowerCase().includes('marcus')).forEach((i) => {
    history.push({
      id: `hist-iss-${i.id}`,
      type: 'Issued',
      date: i.issueDate,
      itemCode: `AST-${i.itemId.toUpperCase()}`,
      itemName: i.itemName,
      category: i.itemCategory,
      quantity: i.quantity,
      details: i.remarks || `Issued at ${i.projectSite}`,
      handledBy: i.issuedBy,
      status: i.status,
    });
  });

  INITIAL_RETURNS.filter((r) => r.workerId === workerId || r.workerName?.toLowerCase().includes('marcus')).forEach((r) => {
    history.push({
      id: `hist-ret-${r.id}`,
      type: 'Returned',
      date: r.returnDate,
      itemCode: `AST-${r.itemId.toUpperCase()}`,
      itemName: r.itemName,
      category: 'Tool',
      quantity: r.quantityReturned,
      details: `Returned in ${r.conditionOnReturn} condition - ${r.notes || 'No defects'}`,
      handledBy: r.receivedBy,
      status: 'Returned',
    });
  });

  INITIAL_LOST.filter((l) => l.workerId === workerId).forEach((l) => {
    history.push({
      id: `hist-lst-${l.id}`,
      type: 'Lost',
      date: l.reportedDate,
      itemCode: `AST-${l.itemId.toUpperCase()}`,
      itemName: l.itemName,
      category: 'Tool',
      quantity: l.quantityLost,
      details: `Reported lost at ${l.location}: ${l.incidentDetails}`,
      handledBy: l.reportedBy,
      status: l.status,
    });
  });

  return history.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
}

/**
 * Compute KPIs for Worker Dashboard
 */
export function calculateWorkerKPIs(): WorkerKPIs {
  const activeIssues = INITIAL_ISSUES.filter((i) => i.status === 'Active');
  const totalIssued = activeIssues.reduce((sum, i) => sum + i.quantity, 0);
  const totalReturned = INITIAL_RETURNS.reduce((sum, r) => sum + r.quantityReturned, 0);
  const totalLost = INITIAL_LOST.reduce((sum, l) => sum + l.quantityLost, 0);
  const totalRepair = INITIAL_REPAIRS.length;
  const overdueCount = activeIssues.filter((i) => i.expectedReturnDate && new Date(i.expectedReturnDate) < new Date()).length;

  return {
    currentIssuedItems: totalIssued,
    returnedItems: totalReturned,
    overdueItems: overdueCount,
    lostItems: totalLost,
    damagedItems: 1,
    repairItems: totalRepair,
    totalIssues: INITIAL_ISSUES.length + INITIAL_RETURNS.length,
  };
}
