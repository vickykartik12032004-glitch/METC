import React from 'react';
import type { EnterpriseWorker, WorkerKPIs, OverdueItemRecord } from '../../types';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import {
  Package,
  RotateCcw,
  AlertTriangle,
  FileQuestion,
  Wrench,
  Activity,
  Layers,
  Users,
  Building,
  ShieldAlert,
  ArrowUpRight,
  Clock,
  Briefcase
} from 'lucide-react';

interface WorkerDashboardViewProps {
  workers: EnterpriseWorker[];
  kpiStats: WorkerKPIs;
  overdueItems: OverdueItemRecord[];
  onSelectWorker?: (workerId: string) => void;
}

export const WorkerDashboardView: React.FC<WorkerDashboardViewProps> = ({
  workers,
  kpiStats,
  overdueItems,
  onSelectWorker,
}) => {
  // Chart Data: Project Site Distribution
  const siteCounts = workers.reduce((acc, w) => {
    acc[w.site] = (acc[w.site] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const siteChartData = Object.entries(siteCounts).map(([site, count]) => ({
    site,
    count,
  }));

  // Chart Data: Status Distribution
  const statusCounts = workers.reduce((acc, w) => {
    acc[w.status] = (acc[w.status] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const STATUS_COLORS: Record<string, string> = {
    Active: '#10b981',
    'On Leave': '#f59e0b',
    Inactive: '#64748b',
    Resigned: '#ef4444',
    Terminated: '#991b1b',
  };

  const statusChartData = Object.entries(statusCounts).map(([status, value]) => ({
    name: status,
    value,
    color: STATUS_COLORS[status] || '#3b82f6',
  }));

  return (
    <div className="space-y-6">
      {/* KPI CARDS GRID (7 CARDS REQUIRED) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
        {/* 1. CURRENT ISSUED ITEMS */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Issued</span>
            <div className="p-1.5 rounded-lg bg-blue-50 dark:bg-blue-950 text-blue-600">
              <Package className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-xl font-black text-slate-900 dark:text-slate-100">
              {kpiStats.currentIssuedItems}
            </div>
            <p className="text-[10px] font-medium text-slate-500 mt-0.5">Active assigned items</p>
          </div>
        </div>

        {/* 2. RETURNED ITEMS */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Returned</span>
            <div className="p-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950 text-emerald-600">
              <RotateCcw className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-xl font-black text-slate-900 dark:text-slate-100">
              {kpiStats.returnedItems}
            </div>
            <p className="text-[10px] font-medium text-slate-500 mt-0.5">Successfully returned</p>
          </div>
        </div>

        {/* 3. OVERDUE ITEMS */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Overdue</span>
            <div className="p-1.5 rounded-lg bg-rose-50 dark:bg-rose-950 text-rose-600">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-xl font-black text-rose-600 dark:text-rose-400">
              {kpiStats.overdueItems}
            </div>
            <p className="text-[10px] font-medium text-slate-500 mt-0.5">Requires immediate return</p>
          </div>
        </div>

        {/* 4. LOST ITEMS */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Lost</span>
            <div className="p-1.5 rounded-lg bg-amber-50 dark:bg-amber-950 text-amber-600">
              <FileQuestion className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-xl font-black text-slate-900 dark:text-slate-100">
              {kpiStats.lostItems}
            </div>
            <p className="text-[10px] font-medium text-slate-500 mt-0.5">Reported missing</p>
          </div>
        </div>

        {/* 5. DAMAGED ITEMS */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Damaged</span>
            <div className="p-1.5 rounded-lg bg-purple-50 dark:bg-purple-950 text-purple-600">
              <ShieldAlert className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-xl font-black text-slate-900 dark:text-slate-100">
              {kpiStats.damagedItems}
            </div>
            <p className="text-[10px] font-medium text-slate-500 mt-0.5">Defects on return</p>
          </div>
        </div>

        {/* 6. REPAIR ITEMS */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Repair</span>
            <div className="p-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-950 text-indigo-600">
              <Wrench className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-xl font-black text-slate-900 dark:text-slate-100">
              {kpiStats.repairItems}
            </div>
            <p className="text-[10px] font-medium text-slate-500 mt-0.5">In maintenance vendor</p>
          </div>
        </div>

        {/* 7. TOTAL ISSUES */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 shadow-xs flex flex-col justify-between col-span-2 sm:col-span-1">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Total Issues</span>
            <div className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
              <Activity className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-xl font-black text-blue-600 dark:text-blue-400">
              {kpiStats.totalIssues}
            </div>
            <p className="text-[10px] font-medium text-slate-500 mt-0.5">All time transactions</p>
          </div>
        </div>
      </div>

      {/* CHARTS SECTION */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* PROJECT SITE DISTRIBUTION */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <Building className="w-4 h-4 text-blue-500" />
              Project Site Distribution
            </h3>
            <span className="text-xs font-semibold text-slate-500">
              Total Workforce: {workers.length}
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={siteChartData} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                <XAxis dataKey="site" tick={{ fontSize: 10 }} angle={-15} textAnchor="end" />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#334155',
                    color: '#fff',
                    borderRadius: '8px',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="count" fill="#3b82f6" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* WORKFORCE STATUS BREAKDOWN */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
          <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Users className="w-4 h-4 text-emerald-500" />
            Workforce Status
          </h3>

          <div className="h-64 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={statusChartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={80}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {statusChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend formatter={(value) => <span className="text-[11px] font-medium">{value}</span>} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* OVERDUE ITEMS ALERT PANEL */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-500" />
            High Priority Overdue & Non-Returned Items
          </h3>
          <span className="text-xs font-bold text-rose-600 dark:text-rose-400">
            {overdueItems.length} Overdue
          </span>
        </div>

        {overdueItems.length === 0 ? (
          <p className="text-xs text-slate-500 p-4">No overdue items active across site workforce.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {overdueItems.map((item) => (
              <div
                key={item.id}
                onClick={() => onSelectWorker && onSelectWorker(item.workerId)}
                className="p-3.5 bg-rose-50/50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900/60 rounded-xl hover:border-rose-400 cursor-pointer transition-all flex items-center justify-between"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-xs text-slate-900 dark:text-slate-100">
                      {item.workerName}
                    </span>
                    <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-rose-600 text-white">
                      {item.daysOverdue} days late
                    </span>
                  </div>
                  <p className="text-xs font-medium text-slate-700 dark:text-slate-300">
                    Item: <strong className="text-blue-600 dark:text-blue-400">{item.itemName}</strong> ({item.quantity}x)
                  </p>
                  <p className="text-[11px] text-slate-500">Site: {item.site} | Phone: {item.workerPhone}</p>
                </div>
                <ArrowUpRight className="w-4 h-4 text-rose-500 shrink-0" />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
