import React, { useState } from 'react';
import type { EnterpriseWorker, WorkerStatus } from '../types';
import {
  Eye,
  Edit,
  Send,
  RotateCcw,
  ArrowLeftRight,
  Clock,
  Printer,
  UserX,
  UserCheck,
  Package,
  AlertTriangle,
  Phone,
  ShieldCheck,
  Building2,
  MapPin,
  Briefcase,
  LayoutGrid,
  List
} from 'lucide-react';
import { usePermissions } from '../../../hooks/usePermissions';

interface WorkerListTableProps {
  workers: EnterpriseWorker[];
  onViewProfile: (worker: EnterpriseWorker) => void;
  onEditWorker: (worker: EnterpriseWorker) => void;
  onIssueItem: (worker: EnterpriseWorker) => void;
  onReturnItem: (worker: EnterpriseWorker) => void;
  onTransferItem: (worker: EnterpriseWorker) => void;
  onViewHistory: (worker: EnterpriseWorker) => void;
  onPrintCard: (worker: EnterpriseWorker) => void;
  onToggleStatus: (id: string, newStatus: WorkerStatus) => void;
  canEdit?: boolean;
}

export const WorkerListTable: React.FC<WorkerListTableProps> = ({
  workers,
  onViewProfile,
  onEditWorker,
  onIssueItem,
  onReturnItem,
  onTransferItem,
  onViewHistory,
  onPrintCard,
  onToggleStatus,
  canEdit: propCanEdit,
}) => {
  const { canEdit: permCanEdit } = usePermissions();
  const canEdit = propCanEdit ?? permCanEdit;
  const [viewMode, setViewMode] = useState<'cards' | 'table' | 'auto'>('auto');

  if (workers.length === 0) {
    return (
      <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
        <Package className="w-12 h-12 text-slate-300 dark:text-slate-700 mx-auto mb-3" />
        <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">No Workers Found</h3>
        <p className="text-xs text-slate-500 mt-1">Try resetting your search query or department filter.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Mobile/Desktop View Switcher Toolbar */}
      <div className="flex items-center justify-between pb-1">
        <span className="text-xs text-slate-500 font-medium">
          Showing <strong className="text-slate-900 dark:text-slate-100">{workers.length}</strong> personnel profiles
        </span>

        <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-0.5 rounded-lg border border-slate-200 dark:border-slate-700">
          <button
            type="button"
            onClick={() => setViewMode('cards')}
            title="Card View"
            className={`p-1.5 rounded-md text-xs font-medium transition-all ${
              viewMode === 'cards' || viewMode === 'auto'
                ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-2xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <LayoutGrid className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => setViewMode('table')}
            title="Table Spreadsheet View"
            className={`p-1.5 rounded-md text-xs font-medium transition-all ${
              viewMode === 'table'
                ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-2xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <List className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* MOBILE RESPONSIVE CARDS VIEW */}
      <div className={`${viewMode === 'table' ? 'hidden' : viewMode === 'cards' ? 'grid' : 'grid md:hidden'} grid-cols-1 sm:grid-cols-2 gap-3`}>
        {workers.map((worker) => {
          const isActive = worker.status === 'Active';
          return (
            <div
              key={worker.id}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs space-y-3 hover:border-slate-300 dark:hover:border-slate-700 transition-all"
            >
              {/* Top Row: Photo + Name + Status */}
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="relative shrink-0">
                    <img
                      src={worker.photoUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'}
                      alt={worker.name}
                      className="w-12 h-12 rounded-xl object-cover border border-slate-200 dark:border-slate-700 shadow-2xs"
                    />
                    <span
                      className={`absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full ring-2 ring-white dark:ring-slate-900 ${
                        isActive ? 'bg-emerald-500' : 'bg-slate-400'
                      }`}
                    />
                  </div>

                  <div className="min-w-0">
                    <button
                      type="button"
                      onClick={() => onViewProfile(worker)}
                      className="font-bold text-sm text-slate-900 dark:text-slate-100 hover:text-blue-600 dark:hover:text-blue-400 text-left line-clamp-1 transition-colors"
                    >
                      {worker.name}
                    </button>
                    <div className="flex items-center gap-1.5 text-xs text-slate-400 mt-0.5 flex-wrap">
                      <span className="font-mono font-bold text-blue-600 dark:text-blue-400">{worker.workerCode}</span>
                      <span>•</span>
                      <span className="font-mono text-slate-500 text-[11px]">{worker.employeeNumber}</span>
                    </div>
                  </div>
                </div>

                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider shrink-0 ${
                    worker.status === 'Active'
                      ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                      : worker.status === 'On Leave'
                      ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                      : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                  }`}
                >
                  {worker.status}
                </span>
              </div>

              {/* Site & Contact Info */}
              <div className="grid grid-cols-2 gap-2 bg-slate-50 dark:bg-slate-800/50 p-2.5 rounded-xl text-xs">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block">Project Site</span>
                  <div className="font-semibold text-slate-800 dark:text-slate-200 truncate flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                    <span className="truncate">{worker.site}</span>
                  </div>
                </div>

                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block">Phone</span>
                  {worker.phone ? (
                    <a
                      href={`tel:${worker.phone}`}
                      className="text-[11px] text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-0.5 hover:underline truncate"
                    >
                      <Phone className="w-2.5 h-2.5 shrink-0" />
                      <span className="truncate">{worker.phone}</span>
                    </a>
                  ) : (
                    <span className="text-[10px] text-slate-400">No phone</span>
                  )}
                </div>
              </div>

              {/* Items Meter & Badges */}
              <div className="flex items-center justify-between px-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-500">Issued Assets:</span>
                  <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300">
                    {worker.assignedItemsCount} items
                  </span>
                </div>

                {worker.overdueItemsCount > 0 ? (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500 text-white flex items-center gap-1 animate-pulse">
                    <AlertTriangle className="w-3 h-3" />
                    <span>{worker.overdueItemsCount} Overdue</span>
                  </span>
                ) : (
                  <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">
                    ✓ Clean Record
                  </span>
                )}
              </div>

              {/* Touch Action Bar */}
              <div className="pt-2 flex items-center justify-between border-t border-slate-100 dark:border-slate-800 gap-1">
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => onViewProfile(worker)}
                    className="px-2.5 py-1.5 rounded-lg bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 dark:hover:bg-blue-900/60 text-blue-700 dark:text-blue-300 font-bold text-xs flex items-center gap-1 transition-colors"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Profile</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onIssueItem(worker)}
                    className="px-2.5 py-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 font-bold text-xs flex items-center gap-1 transition-colors"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Issue</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onReturnItem(worker)}
                    className="p-1.5 rounded-lg text-slate-500 hover:text-purple-600 hover:bg-purple-50 dark:hover:bg-slate-800 transition-colors"
                    title="Return Asset"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>

                  <button
                    type="button"
                    onClick={() => onPrintCard(worker)}
                    className="p-1.5 rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-slate-800 transition-colors"
                    title="Print ID Badge"
                  >
                    <Printer className="w-4 h-4" />
                  </button>
                </div>

                {canEdit && (
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => onEditWorker(worker)}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-amber-600 hover:bg-amber-50 dark:hover:bg-slate-800 transition-colors"
                      title="Edit Worker"
                    >
                      <Edit className="w-4 h-4" />
                    </button>

                    <button
                      type="button"
                      onClick={() => onToggleStatus(worker.id, worker.status === 'Active' ? 'Inactive' : 'Active')}
                      className={`p-1.5 rounded-lg transition-colors ${
                        worker.status === 'Active'
                          ? 'text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-slate-800'
                          : 'text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-slate-800'
                      }`}
                      title={worker.status === 'Active' ? 'Deactivate Worker' : 'Activate Worker'}
                    >
                      {worker.status === 'Active' ? <UserX className="w-4 h-4" /> : <UserCheck className="w-4 h-4" />}
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* DESKTOP SPREADSHEET TABLE VIEW */}
      <div className={`${viewMode === 'cards' ? 'hidden' : viewMode === 'table' ? 'block' : 'hidden md:block'} bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs`}>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-900/80 border-b border-slate-200 dark:border-slate-800 text-slate-400 uppercase tracking-wider font-semibold">
                <th className="py-3.5 px-4">Photo</th>
                <th className="py-3.5 px-3">Worker ID</th>
                <th className="py-3.5 px-3">Emp No</th>
                <th className="py-3.5 px-4">Full Name</th>
                <th className="py-3.5 px-3">Phone</th>
                <th className="py-3.5 px-3">Site</th>
                <th className="py-3.5 px-3 text-center">Status</th>
                <th className="py-3.5 px-3 text-center">Issued</th>
                <th className="py-3.5 px-3 text-center">Overdue</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium text-slate-700 dark:text-slate-200">
              {workers.map((worker) => (
                <tr
                  key={worker.id}
                  className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors group"
                >
                  {/* PHOTO */}
                  <td className="py-3 px-4">
                    <img
                      src={worker.photoUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'}
                      alt={worker.name}
                      className="w-10 h-10 rounded-xl object-cover border border-slate-200 dark:border-slate-700 shadow-xs"
                    />
                  </td>

                  {/* WORKER ID */}
                  <td className="py-3 px-3">
                    <span className="font-mono font-bold text-blue-600 dark:text-blue-400">
                      {worker.workerCode}
                    </span>
                  </td>

                  {/* EMPLOYEE NUMBER */}
                  <td className="py-3 px-3 font-mono text-slate-500 dark:text-slate-400">
                    {worker.employeeNumber}
                  </td>

                  {/* FULL NAME */}
                  <td className="py-3 px-4">
                    <button
                      onClick={() => onViewProfile(worker)}
                      className="font-bold text-slate-900 dark:text-slate-100 hover:text-blue-600 dark:hover:text-blue-400 text-left transition-colors"
                    >
                      {worker.name}
                    </button>
                    <p className="text-[10px] text-slate-400 font-normal">{worker.badgeNumber}</p>
                  </td>

                  {/* PHONE */}
                  <td className="py-3 px-3 font-semibold text-emerald-600 dark:text-emerald-400 whitespace-nowrap">
                    {worker.phone}
                  </td>

                  {/* SITE */}
                  <td className="py-3 px-3 font-medium text-slate-800 dark:text-slate-200 whitespace-nowrap">
                    {worker.site}
                  </td>

                  {/* STATUS */}
                  <td className="py-3 px-3 text-center">
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                        worker.status === 'Active'
                          ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                          : worker.status === 'On Leave'
                          ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                          : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                      }`}
                    >
                      {worker.status}
                    </span>
                  </td>

                  {/* CURRENT ISSUED ITEMS */}
                  <td className="py-3 px-3 text-center">
                    <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300">
                      {worker.assignedItemsCount}
                    </span>
                  </td>

                  {/* OVERDUE ITEMS */}
                  <td className="py-3 px-3 text-center">
                    {worker.overdueItemsCount > 0 ? (
                      <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-rose-500 text-white shadow-xs">
                        {worker.overdueItemsCount}
                      </span>
                    ) : (
                      <span className="text-slate-400 text-[10px] font-normal">0</span>
                    )}
                  </td>

                  {/* ACTIONS */}
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1">
                      <button
                        onClick={() => onViewProfile(worker)}
                        title="View Profile"
                        className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-slate-800 rounded-lg transition-colors"
                      >
                        <Eye className="w-4 h-4" />
                      </button>

                      {canEdit && (
                        <button
                          onClick={() => onEditWorker(worker)}
                          title="Edit Worker"
                          className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-slate-800 rounded-lg transition-colors"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                      )}

                      <button
                        onClick={() => onIssueItem(worker)}
                        title="Issue Item"
                        className="p-1.5 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-slate-800 rounded-lg transition-colors"
                      >
                        <Send className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => onReturnItem(worker)}
                        title="Return Item"
                        className="p-1.5 text-slate-500 hover:text-purple-600 hover:bg-purple-50 dark:hover:bg-slate-800 rounded-lg transition-colors"
                      >
                        <RotateCcw className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => onTransferItem(worker)}
                        title="Transfer Item"
                        className="p-1.5 text-slate-500 hover:text-amber-600 hover:bg-amber-50 dark:hover:bg-slate-800 rounded-lg transition-colors"
                      >
                        <ArrowLeftRight className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => onPrintCard(worker)}
                        title="Print Worker ID Badge"
                        className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-slate-800 rounded-lg transition-colors"
                      >
                        <Printer className="w-4 h-4" />
                      </button>

                      {canEdit && (
                        <button
                          onClick={() =>
                            onToggleStatus(
                              worker.id,
                              worker.status === 'Active' ? 'Inactive' : 'Active'
                            )
                          }
                          title={worker.status === 'Active' ? 'Deactivate Worker' : 'Activate Worker'}
                          className={`p-1.5 rounded-lg transition-colors ${
                            worker.status === 'Active'
                              ? 'text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-slate-800'
                              : 'text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-slate-800'
                          }`}
                        >
                          {worker.status === 'Active' ? <UserX className="w-4 h-4" /> : <UserCheck className="w-4 h-4" />}
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
