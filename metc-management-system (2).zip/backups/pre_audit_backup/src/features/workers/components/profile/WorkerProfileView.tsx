import React, { useState } from 'react';
import type { EnterpriseWorker, WorkerStatus, DocumentType } from '../../types';
import { getWorkerItemHistory } from '../../services/workers.service';
import { INITIAL_ISSUES } from '../../../../data/mockData';
import { WorkerCardModal } from './WorkerCardModal';
import {
  User,
  Phone,
  Mail,
  Building,
  ShieldCheck,
  Calendar,
  Clock,
  Package,
  FileText,
  Printer,
  Edit,
  UserCheck,
  UserX,
  AlertTriangle,
  Upload,
  CheckCircle,
  ExternalLink,
  Trash2,
  Send,
  RotateCcw,
  Tag,
  MapPin,
  Briefcase,
  AlertCircle
} from 'lucide-react';
import { toast } from 'sonner';
import { usePermissions } from '../../../../hooks/usePermissions';

interface WorkerProfileViewProps {
  worker: EnterpriseWorker | null;
  onEdit: (worker: EnterpriseWorker) => void;
  onIssueItem?: (worker: EnterpriseWorker) => void;
  onReturnItem?: (worker: EnterpriseWorker) => void;
  onStatusChange?: (id: string, newStatus: WorkerStatus) => void;
  onAddDocument?: (workerId: string, doc: any) => void;
  onDeleteDocument?: (workerId: string, docId: string) => void;
  onBackToList?: () => void;
  canEdit?: boolean;
}

export const WorkerProfileView: React.FC<WorkerProfileViewProps> = ({
  worker,
  onEdit,
  onIssueItem,
  onReturnItem,
  onStatusChange,
  onAddDocument,
  onDeleteDocument,
  onBackToList,
  canEdit: propCanEdit,
}) => {
  const { canEdit: permCanEdit } = usePermissions();
  const canEdit = propCanEdit ?? permCanEdit;
  const [activeTab, setActiveTab] = useState<
    'overview' | 'issued' | 'history' | 'overdue' | 'documents' | 'card'
  >('overview');
  const [isCardModalOpen, setIsCardModalOpen] = useState<boolean>(false);

  // Document Upload State inside Profile
  const [docTitle, setDocTitle] = useState('');
  const [docType, setDocType] = useState<DocumentType>('Work Permit');
  const [docExpiry, setDocExpiry] = useState('');
  const [isUploadingDoc, setIsUploadingDoc] = useState(false);

  if (!worker) {
    return (
      <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
        <User className="w-12 h-12 text-slate-300 dark:text-slate-700 mx-auto mb-3" />
        <h3 className="text-base font-bold text-slate-800 dark:text-slate-200">No Worker Selected</h3>
        <p className="text-xs text-slate-500 mt-1">Please select a worker from the directory to view complete HCM profile.</p>
        {onBackToList && (
          <button
            onClick={onBackToList}
            className="mt-4 px-4 py-2 text-xs font-semibold bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Back to Directory
          </button>
        )}
      </div>
    );
  }

  // Calculate Issued Items for this worker
  const workerIssues = INITIAL_ISSUES.filter(
    (i) => i.workerId === worker.id || i.workerName.toLowerCase() === worker.name.toLowerCase()
  );

  // Calculate Overdue Items for this worker
  const now = new Date();
  const overdueIssues = workerIssues.filter((i) => {
    if (i.expectedReturnDate && i.status === 'Active') {
      return new Date(i.expectedReturnDate) < now;
    }
    return false;
  });

  // Fetch Item History
  const historyEvents = getWorkerItemHistory(worker.id);

  const handleUploadDocumentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!docTitle.trim()) {
      toast.error('Document title is required');
      return;
    }

    if (onAddDocument) {
      onAddDocument(worker.id, {
        title: docTitle,
        docType,
        expiryDate: docExpiry || undefined,
        status: docExpiry && new Date(docExpiry) < now ? 'Expired' : 'Valid',
        fileUrl: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=300',
      });
    }

    setDocTitle('');
    setDocExpiry('');
    setIsUploadingDoc(false);
  };

  return (
    <div className="space-y-6">
      {/* TOP PROFILE HEADER CARD */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs relative overflow-hidden">
        {/* Background Decorative Accent */}
        <div className="absolute top-0 right-0 w-80 h-full bg-gradient-to-l from-blue-500/10 via-indigo-500/5 to-transparent pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5 text-center sm:text-left">
            <div className="relative group">
              <img
                src={worker.photoUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'}
                alt={worker.name}
                className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl object-cover border-4 border-slate-100 dark:border-slate-800 shadow-md"
              />
              <span
                className={`absolute -bottom-2 left-1/2 -translate-x-1/2 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase shadow-xs ${
                  worker.status === 'Active'
                    ? 'bg-emerald-500 text-white'
                    : worker.status === 'On Leave'
                    ? 'bg-amber-500 text-white'
                    : 'bg-slate-500 text-white'
                }`}
              >
                {worker.status}
              </span>
            </div>

            <div className="space-y-1.5">
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                <span className="px-2 py-0.5 rounded font-mono text-[11px] font-bold bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300">
                  {worker.workerCode}
                </span>
                <span className="px-2 py-0.5 rounded font-mono text-[11px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                  EMP: {worker.employeeNumber}
                </span>
                <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  {worker.badgeNumber}
                </span>
              </div>

              <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100">
                {worker.name}
              </h1>

              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-x-4 gap-y-1 text-xs text-slate-600 dark:text-slate-400 font-medium">
                <span className="flex items-center gap-1 text-blue-600 dark:text-blue-400 font-bold">
                  <MapPin className="w-3.5 h-3.5" />
                  {worker.site}
                </span>
                <span className="flex items-center gap-1">
                  <Building className="w-3.5 h-3.5 text-slate-400" />
                  {worker.branch}
                </span>
              </div>
            </div>
          </div>

          {/* ACTION BUTTONS */}
          <div className="flex flex-wrap items-center justify-center lg:justify-end gap-2">
            {canEdit ? (
              <button
                onClick={() => onEdit(worker)}
                className="px-3 py-2 text-xs font-semibold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-xl transition-colors flex items-center gap-1.5"
              >
                <Edit className="w-3.5 h-3.5 text-blue-500" />
                <span>Edit Profile</span>
              </button>
            ) : (
              <span className="px-3 py-2 text-xs font-semibold bg-slate-100 dark:bg-slate-800 text-slate-500 rounded-xl border border-slate-200 dark:border-slate-700">
                Viewer Mode
              </span>
            )}

            {onIssueItem && (
              <button
                onClick={() => onIssueItem(worker)}
                className="px-3.5 py-2 text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white rounded-xl shadow-xs transition-colors flex items-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Issue Item</span>
              </button>
            )}

            {onReturnItem && (
              <button
                onClick={() => onReturnItem(worker)}
                className="px-3.5 py-2 text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl shadow-xs transition-colors flex items-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Return Item</span>
              </button>
            )}

            <button
              onClick={() => setIsCardModalOpen(true)}
              className="px-3.5 py-2 text-xs font-bold bg-purple-600 hover:bg-purple-700 text-white rounded-xl shadow-xs transition-colors flex items-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Badge</span>
            </button>

            {canEdit && onStatusChange && (
              <button
                onClick={() =>
                  onStatusChange(worker.id, worker.status === 'Active' ? 'Inactive' : 'Active')
                }
                className={`px-3 py-2 text-xs font-semibold rounded-xl border transition-colors flex items-center gap-1.5 ${
                  worker.status === 'Active'
                    ? 'border-rose-300 dark:border-rose-900 bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 hover:bg-rose-100'
                    : 'border-emerald-300 dark:border-emerald-900 bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-100'
                }`}
              >
                {worker.status === 'Active' ? <UserX className="w-3.5 h-3.5" /> : <UserCheck className="w-3.5 h-3.5" />}
                <span>{worker.status === 'Active' ? 'Deactivate' : 'Activate'}</span>
              </button>
            )}
          </div>
        </div>

        {/* PROFILE NAVIGATION TABS */}
        <div className="flex items-center gap-1 mt-6 pt-4 border-t border-slate-200 dark:border-slate-800 overflow-x-auto no-scrollbar">
          {[
            { id: 'overview', label: 'Overview & Details', icon: User },
            { id: 'issued', label: `Issued Items (${workerIssues.length})`, icon: Package },
            { id: 'history', label: 'Item History', icon: Clock },
            {
              id: 'overdue',
              label: `Overdue (${overdueIssues.length})`,
              icon: AlertTriangle,
              badge: overdueIssues.length > 0 ? overdueIssues.length : null,
            },
            { id: 'documents', label: `Documents (${worker.documents?.length || 0})`, icon: FileText },
            { id: 'card', label: 'ID Card & QR', icon: ShieldCheck },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-2 text-xs font-bold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
                {tab.badge && (
                  <span className="px-1.5 py-0.2 text-[10px] bg-rose-500 text-white rounded-full">
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* TAB CONTENT: 1. OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* PERSONAL & CONTACT INFORMATION */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-2">
              <User className="w-4 h-4 text-blue-500" />
              Personal & Contact Information
            </h3>

            <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-500 font-medium">Full Name:</span>
                <span className="font-bold text-slate-900 dark:text-slate-100">{worker.name}</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-500 font-medium">Worker Code:</span>
                <span className="font-mono font-bold text-blue-600 dark:text-blue-400">{worker.workerCode}</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-500 font-medium">Employee Number:</span>
                <span className="font-mono font-semibold text-slate-800 dark:text-slate-200">{worker.employeeNumber}</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-500 font-medium">Gender / Nationality:</span>
                <span className="font-medium text-slate-800 dark:text-slate-200">{worker.gender || 'Male'} / {worker.nationality}</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-500 font-medium">Date of Birth:</span>
                <span className="font-medium text-slate-800 dark:text-slate-200">{worker.dateOfBirth || '1990-01-01'}</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-500 font-medium">Phone Number:</span>
                <span className="font-bold text-emerald-600 dark:text-emerald-400">{worker.phone}</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-500 font-medium">Email Address:</span>
                <span className="font-medium text-slate-800 dark:text-slate-200">{worker.email || 'Not provided'}</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-500 font-medium">Residential Address:</span>
                <span className="font-medium text-slate-800 dark:text-slate-200 text-right">{worker.address || 'Worker Quarters Sector B'}</span>
              </div>
            </div>
          </div>

          {/* EMPLOYMENT & DEPLOYMENT DETAILS */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-2">
              <Building className="w-4 h-4 text-purple-500" />
              Employment & Site Deployment
            </h3>

            <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-500 font-medium">Branch Division:</span>
                <span className="font-medium text-slate-800 dark:text-slate-200">{worker.branch}</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-500 font-medium">Project Site Assigned:</span>
                <span className="font-bold text-blue-600 dark:text-blue-400">{worker.site}</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-500 font-medium">Site Supervisor:</span>
                <span className="font-medium text-slate-800 dark:text-slate-200">{worker.supervisor || 'Johnathan Miller'}</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-500 font-medium">Joining Date:</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">{worker.joiningDate}</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-500 font-medium">Emergency Contact:</span>
                <span className="font-medium text-amber-600 dark:text-amber-400">
                  {worker.emergencyContact || 'Family Contact'} ({worker.emergencyPhone || '+1 555-999-0011'})
                </span>
              </div>
            </div>

            {worker.remarks && (
              <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700/60 text-xs">
                <span className="font-bold text-slate-700 dark:text-slate-300">Remarks: </span>
                <span className="text-slate-600 dark:text-slate-400">{worker.remarks}</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB CONTENT: 2. CURRENTLY ISSUED ITEMS */}
      {activeTab === 'issued' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <Package className="w-4 h-4 text-blue-500" />
              Active Issued Assets & Tools
            </h3>
            {onIssueItem && (
              <button
                onClick={() => onIssueItem(worker)}
                className="px-3 py-1.5 text-xs font-bold bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-1"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Issue New Item</span>
              </button>
            )}
          </div>

          {workerIssues.length === 0 ? (
            <div className="p-8 text-center bg-slate-50 dark:bg-slate-800/40 rounded-xl">
              <Package className="w-8 h-8 text-slate-300 dark:text-slate-600 mx-auto mb-2" />
              <p className="text-xs font-semibold text-slate-600 dark:text-slate-400">No active items issued to this worker.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 uppercase tracking-wider">
                    <th className="py-3 px-3 font-semibold">Issue Code</th>
                    <th className="py-3 px-3 font-semibold">Item Name</th>
                    <th className="py-3 px-3 font-semibold">Category</th>
                    <th className="py-3 px-3 font-semibold">Qty</th>
                    <th className="py-3 px-3 font-semibold">Issue Date</th>
                    <th className="py-3 px-3 font-semibold">Expected Return</th>
                    <th className="py-3 px-3 font-semibold">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                  {workerIssues.map((iss) => (
                    <tr key={iss.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                      <td className="py-3 px-3 font-mono font-bold text-blue-600 dark:text-blue-400">
                        {iss.issueCode}
                      </td>
                      <td className="py-3 px-3 font-bold text-slate-900 dark:text-slate-100">
                        {iss.itemName}
                      </td>
                      <td className="py-3 px-3">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                          {iss.itemCategory}
                        </span>
                      </td>
                      <td className="py-3 px-3 font-bold text-slate-800 dark:text-slate-200">
                        {iss.quantity}
                      </td>
                      <td className="py-3 px-3 text-slate-600 dark:text-slate-400">
                        {new Date(iss.issueDate).toLocaleDateString()}
                      </td>
                      <td className="py-3 px-3 text-slate-600 dark:text-slate-400">
                        {iss.expectedReturnDate ? new Date(iss.expectedReturnDate).toLocaleDateString() : 'N/A'}
                      </td>
                      <td className="py-3 px-3">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300">
                          {iss.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB CONTENT: 3. ITEM HISTORY TIMELINE */}
      {activeTab === 'history' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
          <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Clock className="w-4 h-4 text-purple-500" />
            Complete Lifecycle Activity History
          </h3>

          {historyEvents.length === 0 ? (
            <p className="text-xs text-slate-500 p-4">No historical transactions logged for this worker.</p>
          ) : (
            <div className="relative border-l-2 border-slate-200 dark:border-slate-800 ml-4 space-y-6 py-2">
              {historyEvents.map((ev) => (
                <div key={ev.id} className="relative pl-6">
                  <span
                    className={`absolute -left-[9px] top-1 w-4 h-4 rounded-full border-2 border-white dark:border-slate-900 ${
                      ev.type === 'Issued'
                        ? 'bg-blue-500'
                        : ev.type === 'Returned'
                        ? 'bg-emerald-500'
                        : ev.type === 'Lost'
                        ? 'bg-rose-500'
                        : 'bg-purple-500'
                    }`}
                  />
                  <div className="bg-slate-50 dark:bg-slate-800/50 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700/60 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-slate-900 dark:text-slate-100">
                        {ev.type}: {ev.itemName} ({ev.quantity}x)
                      </span>
                      <span className="text-[10px] font-mono text-slate-400">
                        {new Date(ev.date).toLocaleString()}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300">{ev.details}</p>
                    <div className="text-[10px] text-slate-400 pt-1">Handled By: {ev.handledBy}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB CONTENT: 4. OVERDUE ITEMS */}
      {activeTab === 'overdue' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
          <h3 className="text-sm font-bold text-rose-600 dark:text-rose-400 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4" />
            Overdue Unreturned Assets
          </h3>

          {overdueIssues.length === 0 ? (
            <div className="p-8 text-center bg-emerald-50 dark:bg-emerald-950/30 rounded-xl border border-emerald-200 dark:border-emerald-800">
              <CheckCircle className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
              <p className="text-xs font-bold text-emerald-800 dark:text-emerald-300">
                Worker has zero overdue items! Perfect compliance.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {overdueIssues.map((iss) => {
                const diffDays = Math.ceil(
                  Math.abs(now.getTime() - new Date(iss.expectedReturnDate!).getTime()) /
                    (1000 * 60 * 60 * 24)
                );
                return (
                  <div
                    key={iss.id}
                    className="p-4 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 rounded-xl flex items-center justify-between"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-slate-900 dark:text-slate-100">{iss.itemName}</span>
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-600 text-white">
                          {diffDays} Days Overdue
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 dark:text-slate-300">
                        Issued Date: {new Date(iss.issueDate).toLocaleDateString()} | Expected Return:{' '}
                        {new Date(iss.expectedReturnDate!).toLocaleDateString()}
                      </p>
                    </div>

                    {onReturnItem && (
                      <button
                        onClick={() => onReturnItem(worker)}
                        className="px-3 py-1.5 text-xs font-bold bg-rose-600 text-white rounded-lg hover:bg-rose-700 shadow-xs"
                      >
                        Process Return
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB CONTENT: 5. DOCUMENTS */}
      {activeTab === 'documents' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <FileText className="w-4 h-4 text-blue-500" />
              Verified Worker Documents & Certificates
            </h3>
            {canEdit && (
              <button
                onClick={() => setIsUploadingDoc(!isUploadingDoc)}
                className="px-3 py-1.5 text-xs font-bold bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-1"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>{isUploadingDoc ? 'Close Form' : 'Upload Document'}</span>
              </button>
            )}
          </div>

          {/* DOCUMENT UPLOAD SUB-FORM */}
          {canEdit && isUploadingDoc && (
            <form
              onSubmit={handleUploadDocumentSubmit}
              className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 space-y-3"
            >
              <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200">
                Upload Passport, Permit, or Safety Certificate
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold mb-1">Document Title *</label>
                  <input
                    type="text"
                    value={docTitle}
                    onChange={(e) => setDocTitle(e.target.value)}
                    placeholder="e.g. AWS Welding License"
                    className="w-full px-3 py-1.5 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold mb-1">Document Type</label>
                  <select
                    value={docType}
                    onChange={(e) => setDocType(e.target.value as any)}
                    className="w-full px-3 py-1.5 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg"
                  >
                    <option value="Passport">Passport</option>
                    <option value="Work Permit">Work Permit</option>
                    <option value="Training Certificate">Training Certificate</option>
                    <option value="Driving License">Driving License</option>
                    <option value="Safety Certificate">Safety Certificate</option>
                    <option value="Medical Certificate">Medical Certificate</option>
                    <option value="Other">Other Documents</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-semibold mb-1">Expiry Date</label>
                  <input
                    type="date"
                    value={docExpiry}
                    onChange={(e) => setDocExpiry(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="submit"
                  className="px-3 py-1.5 text-xs font-bold bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Save Document
                </button>
              </div>
            </form>
          )}

          {/* LIST OF DOCUMENTS */}
          {!worker.documents || worker.documents.length === 0 ? (
            <p className="text-xs text-slate-500 text-center py-6">No documents uploaded yet for this worker.</p>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {worker.documents.map((doc) => (
                <div
                  key={doc.id}
                  className="p-4 bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 rounded-xl flex flex-col justify-between"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300">
                        {doc.docType}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          doc.status === 'Valid'
                            ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                            : 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                        }`}
                      >
                        {doc.status}
                      </span>
                    </div>
                    <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100">{doc.title}</h4>
                    {doc.expiryDate && (
                      <p className="text-[11px] text-slate-500">Expiry: {doc.expiryDate}</p>
                    )}
                  </div>

                  <div className="flex items-center justify-between pt-3 mt-3 border-t border-slate-200 dark:border-slate-700/60">
                    <a
                      href={doc.fileUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs font-semibold text-blue-600 hover:underline flex items-center gap-1"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>View File</span>
                    </a>
                    {canEdit && onDeleteDocument && (
                      <button
                        onClick={() => onDeleteDocument(worker.id, doc.id)}
                        className="text-rose-500 hover:text-rose-700 p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB CONTENT: 6. CARD & QR */}
      {activeTab === 'card' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 text-center space-y-4">
          <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
            Security Badge & QR Scanner Direct Link
          </h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Worker ID card with encrypted QR code payload can be generated and printed instantly for site entry verification.
          </p>
          <button
            onClick={() => setIsCardModalOpen(true)}
            className="px-5 py-2.5 text-xs font-bold bg-purple-600 text-white rounded-xl shadow-md hover:bg-purple-700 transition-colors inline-flex items-center gap-2"
          >
            <Printer className="w-4 h-4" />
            <span>Open & Print Worker ID Card</span>
          </button>
        </div>
      )}

      {/* WORKER CARD MODAL */}
      <WorkerCardModal
        isOpen={isCardModalOpen}
        onClose={() => setIsCardModalOpen(false)}
        worker={worker}
      />
    </div>
  );
};
