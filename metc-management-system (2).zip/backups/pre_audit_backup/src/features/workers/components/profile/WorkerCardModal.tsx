import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import type { EnterpriseWorker } from '../../types';
import { X, Printer, ShieldCheck, QrCode as QrIcon, CheckCircle, Building, MapPin } from 'lucide-react';

interface WorkerCardModalProps {
  isOpen: boolean;
  onClose: () => void;
  worker: EnterpriseWorker | null;
}

export const WorkerCardModal: React.FC<WorkerCardModalProps> = ({
  isOpen,
  onClose,
  worker,
}) => {
  const [qrDataUrl, setQrDataUrl] = useState<string>('');

  useEffect(() => {
    if (worker) {
      const qrPayload = JSON.stringify({
        system: 'MOUNTEC Enterprise HCM',
        workerId: worker.workerCode,
        employeeNumber: worker.employeeNumber,
        name: worker.name,
        site: worker.site,
        status: worker.status,
        verificationUrl: `${window.location.origin}/workers?id=${worker.id}`,
      });

      QRCode.toDataURL(
        qrPayload,
        {
          width: 200,
          margin: 1,
          color: {
            dark: '#0f172a',
            light: '#ffffff',
          },
        },
        (err, url) => {
          if (!err && url) {
            setQrDataUrl(url);
          }
        }
      );
    }
  }, [worker]);

  if (!isOpen || !worker) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl max-w-md w-full overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-900/80">
          <div className="flex items-center gap-2 text-slate-800 dark:text-slate-100">
            <QrIcon className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            <h3 className="text-sm font-bold">Printable Security Worker Badge</h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="p-1.5 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg flex items-center gap-1.5 shadow-xs transition-colors"
            >
              <Printer className="w-4 h-4" />
              <span>Print Card</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* PRINTABLE BADGE AREA */}
        <div className="p-6 flex justify-center bg-slate-100 dark:bg-slate-950 print:p-0 print:bg-white">
          <div className="w-[320px] bg-white text-slate-900 border-2 border-slate-300 rounded-2xl shadow-xl overflow-hidden print:shadow-none print:border-slate-900 print:w-full">
            {/* Top Branding Banner */}
            <div className="bg-gradient-to-r from-slate-900 via-blue-900 to-slate-900 text-white p-4 text-center relative">
              <div className="flex items-center justify-center gap-1.5 mb-1">
                <ShieldCheck className="w-5 h-5 text-blue-400" />
                <span className="font-extrabold tracking-wider text-sm uppercase">MOUNTEC CONSTRUCTION</span>
              </div>
              <p className="text-[10px] text-blue-200 uppercase font-semibold tracking-widest">OFFICIAL SITE SECURITY BADGE</p>
              <div className="absolute top-2 right-2 px-1.5 py-0.5 rounded text-[9px] font-bold bg-emerald-500 text-white">
                VERIFIED
              </div>
            </div>

            {/* Photo & Details */}
            <div className="p-5 flex flex-col items-center text-center">
              <div className="relative mb-3">
                <img
                  src={worker.photoUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'}
                  alt={worker.name}
                  className="w-24 h-24 rounded-2xl object-cover border-4 border-slate-100 shadow-md"
                />
                <span className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-full text-[9px] font-bold bg-blue-600 text-white shadow-xs whitespace-nowrap">
                  {worker.badgeNumber || worker.employeeNumber}
                </span>
              </div>

              <h2 className="text-base font-extrabold text-slate-900 leading-tight">{worker.name}</h2>
              <p className="text-xs font-semibold text-slate-500 mt-0.5">{worker.site}</p>

              <div className="w-full my-3 border-t border-dashed border-slate-200" />

              <div className="w-full text-left space-y-1.5 text-[11px] text-slate-700 px-1">
                <div className="flex justify-between items-center">
                  <span className="text-slate-500 font-medium">Worker ID:</span>
                  <span className="font-bold font-mono text-slate-900">{worker.workerCode}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-500 font-medium">Employee No:</span>
                  <span className="font-bold font-mono text-slate-900">{worker.employeeNumber}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-500 font-medium">Phone:</span>
                  <span className="font-semibold text-slate-800">{worker.phone || 'N/A'}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-500 font-medium">Site Assigned:</span>
                  <span className="font-semibold text-slate-800">{worker.site}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-500 font-medium">Status:</span>
                  <span className="font-semibold text-emerald-600">{worker.status}</span>
                </div>
              </div>

              {/* QR CODE DISPLAY */}
              <div className="mt-4 p-2 bg-slate-50 border border-slate-200 rounded-xl flex flex-col items-center">
                {qrDataUrl ? (
                  <img src={qrDataUrl} alt="Worker QR Code" className="w-24 h-24 object-contain" />
                ) : (
                  <div className="w-24 h-24 bg-slate-200 animate-pulse rounded-lg" />
                )}
                <span className="text-[9px] font-semibold text-slate-500 mt-1">SCAN FOR HCM VERIFICATION</span>
              </div>
            </div>

            {/* Footer */}
            <div className="bg-slate-100 border-t border-slate-200 p-2.5 text-center text-[10px] text-slate-500 font-medium">
              Official Site Identification Badge. If found, return to Site Safety Office.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
