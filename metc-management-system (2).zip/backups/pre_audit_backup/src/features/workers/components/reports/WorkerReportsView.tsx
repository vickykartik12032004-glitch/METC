import React, { useState } from 'react';
import type { EnterpriseWorker, OverdueItemRecord } from '../../types';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';
import {
  FileText,
  Download,
  FileSpreadsheet,
  FileCode,
  Users,
  Package,
  AlertTriangle,
  FileQuestion,
  Building,
  MapPin,
  CheckCircle,
  Filter
} from 'lucide-react';
import { toast } from 'sonner';

interface WorkerReportsViewProps {
  workers: EnterpriseWorker[];
  overdueItems: OverdueItemRecord[];
}

export type ReportType =
  | 'worker-list'
  | 'issued-items'
  | 'overdue-items'
  | 'lost-items'
  | 'department-summary'
  | 'site-summary';

export const WorkerReportsView: React.FC<WorkerReportsViewProps> = ({
  workers,
  overdueItems,
}) => {
  const [selectedReport, setSelectedReport] = useState<ReportType>('worker-list');
  const [selectedSite, setSelectedSite] = useState<string>('All');
  const [selectedStatus, setSelectedStatus] = useState<string>('All');

  // Filtered dataset according to report criteria
  const filteredWorkers = workers.filter((w) => {
    if (selectedSite !== 'All' && w.site !== selectedSite) return false;
    if (selectedStatus !== 'All' && w.status !== selectedStatus) return false;
    return true;
  });

  // Export PDF Handler
  const exportPDF = () => {
    const doc = new jsPDF();
    doc.setFontSize(16);
    doc.text('MOUNTEC Enterprise Worker Management System', 14, 15);
    doc.setFontSize(10);
    doc.text(`Report Type: ${selectedReport.toUpperCase()} | Generated: ${new Date().toLocaleDateString()}`, 14, 22);

    if (selectedReport === 'worker-list') {
      const tableData = filteredWorkers.map((w) => [
        w.workerCode,
        w.employeeNumber,
        w.name,
        w.site,
        w.phone,
        w.status,
      ]);
      autoTable(doc, {
        startY: 28,
        head: [['Worker ID', 'Emp No', 'Name', 'Site', 'Phone', 'Status']],
        body: tableData,
      });
    } else if (selectedReport === 'overdue-items') {
      const tableData = overdueItems.map((item) => [
        item.workerId,
        item.workerName,
        item.itemName,
        item.daysOverdue.toString(),
        item.issueDate,
        item.expectedReturnDate,
        item.site,
      ]);
      autoTable(doc, {
        startY: 28,
        head: [['Worker ID', 'Name', 'Item', 'Days Overdue', 'Issue Date', 'Expected Return', 'Site']],
        body: tableData,
      });
    } else {
      // Default report table
      const tableData = filteredWorkers.map((w) => [
        w.workerCode,
        w.name,
        w.site,
        w.phone,
        w.status,
      ]);
      autoTable(doc, {
        startY: 28,
        head: [['Worker ID', 'Name', 'Site', 'Phone', 'Status']],
        body: tableData,
      });
    }

    doc.save(`${selectedReport}-report-${Date.now()}.pdf`);
    toast.success('PDF report exported successfully!');
  };

  // Export Excel Handler
  const exportExcel = () => {
    let exportData: any[] = [];

    if (selectedReport === 'worker-list') {
      exportData = filteredWorkers.map((w) => ({
        'Worker ID': w.workerCode,
        'Employee Number': w.employeeNumber,
        Name: w.name,
        Site: w.site,
        Phone: w.phone,
        Email: w.email || '',
        Status: w.status,
        'Joining Date': w.joiningDate,
      }));
    } else if (selectedReport === 'overdue-items') {
      exportData = overdueItems.map((item) => ({
        'Worker ID': item.workerId,
        'Worker Name': item.workerName,
        'Item Name': item.itemName,
        Category: item.itemCategory,
        'Days Overdue': item.daysOverdue,
        'Issue Date': item.issueDate,
        'Expected Return': item.expectedReturnDate,
        Site: item.site,
      }));
    } else {
      exportData = filteredWorkers.map((w) => ({
        'Worker ID': w.workerCode,
        Name: w.name,
        Site: w.site,
        Phone: w.phone,
        Status: w.status,
      }));
    }

    const worksheet = XLSX.utils.json_to_sheet(exportData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Worker Report');
    XLSX.writeFile(workbook, `${selectedReport}-report-${Date.now()}.xlsx`);
    toast.success('Excel workbook exported successfully!');
  };

  // Export CSV Handler
  const exportCSV = () => {
    const exportData = filteredWorkers.map((w) => ({
      WorkerID: w.workerCode,
      EmpNo: w.employeeNumber,
      Name: w.name,
      Site: w.site,
      Phone: w.phone,
      Status: w.status,
    }));

    const headers = Object.keys(exportData[0] || {}).join(',');
    const rows = exportData.map((row) => Object.values(row).map((v) => `"${v}"`).join(',')).join('\n');
    const csvContent = 'data:text/csv;charset=utf-8,' + headers + '\n' + rows;

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${selectedReport}-report-${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success('CSV report exported successfully!');
  };

  return (
    <div className="space-y-6">
      {/* REPORT TYPE SELECTION CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {[
          {
            id: 'worker-list',
            title: 'Worker Master List',
            desc: 'Comprehensive directory of registered workers with phone, site & status.',
            icon: Users,
            color: 'text-blue-500 bg-blue-50 dark:bg-blue-950/60 border-blue-200 dark:border-blue-900',
          },
          {
            id: 'issued-items',
            title: 'Issued Items Audit',
            desc: 'Detailed breakdown of all active tools and PPE currently in possession.',
            icon: Package,
            color: 'text-purple-500 bg-purple-50 dark:bg-purple-950/60 border-purple-200 dark:border-purple-900',
          },
          {
            id: 'overdue-items',
            title: 'Overdue Unreturned Report',
            desc: 'High priority list of assets past their scheduled return date.',
            icon: AlertTriangle,
            color: 'text-rose-500 bg-rose-50 dark:bg-rose-950/60 border-rose-200 dark:border-rose-900',
          },
          {
            id: 'lost-items',
            title: 'Lost / Damaged Report',
            desc: 'Incident reports and missing equipment records by worker.',
            icon: FileQuestion,
            color: 'text-amber-500 bg-amber-50 dark:bg-amber-950/60 border-amber-200 dark:border-amber-900',
          },
          {
            id: 'department-summary',
            title: 'Department Breakdown',
            desc: 'Workforce allocation grouped by Civil, MEP, HSE, Heavy Equipment.',
            icon: Building,
            color: 'text-emerald-500 bg-emerald-50 dark:bg-emerald-950/60 border-emerald-200 dark:border-emerald-900',
          },
          {
            id: 'site-summary',
            title: 'Project Site Summary',
            desc: 'Site-by-site worker deployment counts and badge verifications.',
            icon: MapPin,
            color: 'text-indigo-500 bg-indigo-50 dark:bg-indigo-950/60 border-indigo-200 dark:border-indigo-900',
          },
        ].map((rpt) => {
          const Icon = rpt.icon;
          const isSelected = selectedReport === rpt.id;
          return (
            <div
              key={rpt.id}
              onClick={() => setSelectedReport(rpt.id as ReportType)}
              className={`p-4 rounded-2xl border-2 cursor-pointer transition-all flex flex-col justify-between ${
                isSelected
                  ? 'border-blue-600 bg-blue-50/30 dark:bg-blue-950/30 shadow-md scale-[1.01]'
                  : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-slate-300 dark:hover:border-slate-700'
              }`}
            >
              <div className="flex items-start justify-between mb-3">
                <div className={`p-2.5 rounded-xl border ${rpt.color}`}>
                  <Icon className="w-5 h-5" />
                </div>
                {isSelected && (
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-600 text-white">
                    Selected
                  </span>
                )}
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">{rpt.title}</h4>
                <p className="text-xs text-slate-500 mt-1">{rpt.desc}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* FILTER & EXPORT CONTROL BAR */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-300">
              <Filter className="w-4 h-4 text-blue-500" />
              <span>Report Scope Filters:</span>
            </div>

            <select
              value={selectedSite}
              onChange={(e) => setSelectedSite(e.target.value)}
              className="px-3 py-1.5 text-xs bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
            >
              <option value="All">All Sites</option>
              <option value="Tower A Site">Tower A Site</option>
              <option value="Metro Line 3">Metro Line 3</option>
              <option value="Bridge West Project">Bridge West Project</option>
            </select>

            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="px-3 py-1.5 text-xs bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
            >
              <option value="All">All Statuses</option>
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
              <option value="On Leave">On Leave</option>
            </select>
          </div>

          {/* EXPORT BUTTONS */}
          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <button
              onClick={exportPDF}
              className="px-3.5 py-2 text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white rounded-xl shadow-xs transition-colors flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export PDF</span>
            </button>

            <button
              onClick={exportExcel}
              className="px-3.5 py-2 text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl shadow-xs transition-colors flex items-center gap-1.5"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Export Excel</span>
            </button>

            <button
              onClick={exportCSV}
              className="px-3.5 py-2 text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white rounded-xl shadow-xs transition-colors flex items-center gap-1.5"
            >
              <FileCode className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
          </div>
        </div>

        {/* PREVIEW TABLE */}
        <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
          <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">
            Live Report Preview ({filteredWorkers.length} records matched)
          </h4>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 uppercase tracking-wider">
                  <th className="py-2.5 px-3">Worker ID</th>
                  <th className="py-2.5 px-3">Emp No</th>
                  <th className="py-2.5 px-3">Full Name</th>
                  <th className="py-2.5 px-3">Site</th>
                  <th className="py-2.5 px-3">Phone</th>
                  <th className="py-2.5 px-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                {filteredWorkers.slice(0, 10).map((w) => (
                  <tr key={w.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="py-2.5 px-3 font-mono font-bold text-blue-600 dark:text-blue-400">
                      {w.workerCode}
                    </td>
                    <td className="py-2.5 px-3 font-mono">{w.employeeNumber}</td>
                    <td className="py-2.5 px-3 font-bold text-slate-900 dark:text-slate-100">{w.name}</td>
                    <td className="py-2.5 px-3">{w.site}</td>
                    <td className="py-2.5 px-3 text-emerald-600 dark:text-emerald-400">{w.phone}</td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                        {w.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
