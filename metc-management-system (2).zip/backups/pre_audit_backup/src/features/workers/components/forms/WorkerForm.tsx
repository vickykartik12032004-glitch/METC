import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import type { EnterpriseWorker, WorkerStatus } from '../../types';
import { Camera, Upload, Trash2, RotateCw, CheckCircle2, User, Phone, Mail, Building, Shield, Calendar, AlertCircle } from 'lucide-react';

const workerSchema = z.object({
  name: z.string().min(2, 'Full name must be at least 2 characters'),
  workerCode: z.string().min(2, 'Worker ID is required'),
  employeeNumber: z.string().min(2, 'Employee Number is required'),
  gender: z.enum(['Male', 'Female', 'Other']).default('Male'),
  dateOfBirth: z.string().optional(),
  nationality: z.string().min(2, 'Nationality is required'),
  phone: z.string().min(6, 'Valid phone number is required'),
  email: z.string().email('Invalid email address').optional().or(z.literal('')),
  trade: z.string().optional().default('General'),
  department: z.string().optional().default('Operations'),
  branch: z.string().min(2, 'Branch is required'),
  site: z.string().min(2, 'Project Site is required'),
  company: z.string().optional().default('MOUNTEC PTE LTD'),
  supervisor: z.string().optional(),
  joiningDate: z.string().min(1, 'Joining date is required'),
  status: z.enum(['Active', 'Inactive', 'On Leave', 'Resigned', 'Terminated']).default('Active'),
  badgeNumber: z.string().optional(),
  emergencyContact: z.string().optional(),
  emergencyPhone: z.string().optional(),
  address: z.string().optional(),
  remarks: z.string().optional(),
  photoUrl: z.string().optional(),
});

export type WorkerFormValues = z.infer<typeof workerSchema>;

interface WorkerFormProps {
  initialData?: EnterpriseWorker | null;
  onSubmit: (data: WorkerFormValues) => void;
  onCancel: () => void;
  isSubmitting?: boolean;
}

export const WorkerForm: React.FC<WorkerFormProps> = ({
  initialData,
  onSubmit,
  onCancel,
  isSubmitting = false,
}) => {
  const [photoPreview, setPhotoPreview] = useState<string>(
    initialData?.photoUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'
  );
  const [isCropping, setIsCropping] = useState<boolean>(false);
  const [rotation, setRotation] = useState<number>(0);

  const defaultCode = initialData?.workerCode || `WRK-2026-${Math.floor(100 + Math.random() * 900)}`;
  const defaultEmpNum = initialData?.employeeNumber || `EMP-${Math.floor(1000 + Math.random() * 9000)}`;

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm<WorkerFormValues>({
    resolver: zodResolver(workerSchema) as any,
    defaultValues: {
      name: initialData?.name || '',
      workerCode: defaultCode,
      employeeNumber: defaultEmpNum,
      gender: initialData?.gender || 'Male',
      dateOfBirth: initialData?.dateOfBirth || '1990-01-01',
      nationality: initialData?.nationality || 'Local',
      phone: initialData?.phone || '',
      email: initialData?.email || '',
      trade: initialData?.trade || 'Site Electrician',
      department: initialData?.department || 'Electrical MEP',
      branch: initialData?.branch || 'Main HQ',
      site: initialData?.site || 'Tower A Site',
      company: initialData?.company || 'MOUNTEC PTE LTD',
      supervisor: initialData?.supervisor || 'Johnathan Miller',
      joiningDate: initialData?.joiningDate || new Date().toISOString().split('T')[0],
      status: initialData?.status || 'Active',
      badgeNumber: initialData?.badgeNumber || `BDG-${defaultEmpNum}`,
      emergencyContact: initialData?.emergencyContact || '',
      emergencyPhone: initialData?.emergencyPhone || '',
      address: initialData?.address || '',
      remarks: initialData?.remarks || '',
      photoUrl: initialData?.photoUrl || photoPreview,
    },
  });

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setPhotoPreview(result);
        setValue('photoUrl', result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemovePhoto = () => {
    const defaultPlaceholder = 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150';
    setPhotoPreview(defaultPlaceholder);
    setValue('photoUrl', defaultPlaceholder);
  };

  const handleRotate = () => {
    setRotation((prev) => (prev + 90) % 360);
  };

  const handleFormSubmit = (data: WorkerFormValues) => {
    onSubmit({
      ...data,
      photoUrl: photoPreview,
    });
  };

  return (
    <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-6 text-slate-800 dark:text-slate-100">
      {/* PHOTO SECTION */}
      <div className="bg-slate-50 dark:bg-slate-900/50 p-4 rounded-xl border border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center gap-5">
        <div className="relative group">
          <div className="w-24 h-24 rounded-2xl overflow-hidden border-2 border-blue-500 shadow-md bg-slate-200 dark:bg-slate-800 flex items-center justify-center">
            <img
              src={photoPreview}
              alt="Worker preview"
              className="w-full h-full object-cover transition-transform duration-200"
              style={{ transform: `rotate(${rotation}deg)` }}
            />
          </div>
          <label className="absolute -bottom-2 -right-2 p-2 bg-blue-600 hover:bg-blue-700 text-white rounded-full shadow-lg cursor-pointer transition-colors">
            <Camera className="w-4 h-4" />
            <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
          </label>
        </div>

        <div className="flex-1 text-center sm:text-left space-y-2">
          <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">Worker Profile Photo</h4>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Upload clear front-facing headshot for security badge ID card & QR verification. Format: JPG, PNG (Max 5MB)
          </p>
          <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 pt-1">
            <label className="px-3 py-1.5 text-xs font-semibold bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 border border-blue-200 dark:border-blue-800 rounded-lg cursor-pointer hover:bg-blue-100 dark:hover:bg-blue-900 transition-colors flex items-center gap-1.5">
              <Upload className="w-3.5 h-3.5" />
              <span>Upload Photo</span>
              <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
            </label>
            <button
              type="button"
              onClick={handleRotate}
              className="px-3 py-1.5 text-xs font-semibold bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-lg hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors flex items-center gap-1.5"
            >
              <RotateCw className="w-3.5 h-3.5" />
              <span>Rotate</span>
            </button>
            <button
              type="button"
              onClick={handleRemovePhoto}
              className="px-3 py-1.5 text-xs font-semibold bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-900 rounded-lg hover:bg-rose-100 transition-colors flex items-center gap-1.5"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Delete</span>
            </button>
          </div>
        </div>
      </div>

      {/* BASIC & IDENTIFICATION DETAILS */}
      <div className="space-y-4">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-2">
          <User className="w-4 h-4 text-blue-500" />
          Identification & Personal Information
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold mb-1 text-slate-700 dark:text-slate-300">
              Worker ID (Auto / System) *
            </label>
            <input
              type="text"
              {...register('workerCode')}
              className="w-full px-3 py-2 text-xs font-mono font-bold bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-blue-500"
            />
            {errors.workerCode && <p className="text-[11px] text-rose-500 mt-1">{errors.workerCode.message}</p>}
          </div>

          <div>
            <label className="block text-xs font-semibold mb-1 text-slate-700 dark:text-slate-300">
              Employee Number *
            </label>
            <input
              type="text"
              {...register('employeeNumber')}
              className="w-full px-3 py-2 text-xs font-mono bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-blue-500"
            />
            {errors.employeeNumber && <p className="text-[11px] text-rose-500 mt-1">{errors.employeeNumber.message}</p>}
          </div>

          <div>
            <label className="block text-xs font-semibold mb-1 text-slate-700 dark:text-slate-300">
              Security Badge ID
            </label>
            <input
              type="text"
              {...register('badgeNumber')}
              placeholder="e.g. BDG-9981"
              className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="sm:col-span-2">
            <label className="block text-xs font-semibold mb-1 text-slate-700 dark:text-slate-300">
              Full Name *
            </label>
            <input
              type="text"
              {...register('name')}
              placeholder="e.g. Jean-Pierre Dubois"
              className="w-full px-3 py-2 text-xs font-semibold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-blue-500"
            />
            {errors.name && <p className="text-[11px] text-rose-500 mt-1">{errors.name.message}</p>}
          </div>

          <div>
            <label className="block text-xs font-semibold mb-1 text-slate-700 dark:text-slate-300">
              Gender *
            </label>
            <select
              {...register('gender')}
              className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-blue-500"
            >
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Other">Other</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold mb-1 text-slate-700 dark:text-slate-300">
              Date of Birth
            </label>
            <input
              type="date"
              {...register('dateOfBirth')}
              className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold mb-1 text-slate-700 dark:text-slate-300">
              Nationality *
            </label>
            <input
              type="text"
              {...register('nationality')}
              placeholder="e.g. United Kingdom"
              className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-blue-500"
            />
            {errors.nationality && <p className="text-[11px] text-rose-500 mt-1">{errors.nationality.message}</p>}
          </div>
        </div>
      </div>

      {/* CONTACT INFORMATION */}
      <div className="space-y-4 pt-2">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-2">
          <Phone className="w-4 h-4 text-emerald-500" />
          Contact & Address
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold mb-1 text-slate-700 dark:text-slate-300">
              Phone Number *
            </label>
            <input
              type="text"
              {...register('phone')}
              placeholder="+1 (555) 234-5678"
              className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-blue-500"
            />
            {errors.phone && <p className="text-[11px] text-rose-500 mt-1">{errors.phone.message}</p>}
          </div>

          <div>
            <label className="block text-xs font-semibold mb-1 text-slate-700 dark:text-slate-300">
              Email Address
            </label>
            <input
              type="email"
              {...register('email')}
              placeholder="worker@company.com"
              className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-blue-500"
            />
            {errors.email && <p className="text-[11px] text-rose-500 mt-1">{errors.email.message}</p>}
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold mb-1 text-slate-700 dark:text-slate-300">
            Current Residential Address
          </label>
          <input
            type="text"
            {...register('address')}
            placeholder="e.g. Block C, Worker Housing Complex, Sector 4"
            className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      {/* JOB & ASSIGNMENT DETAILS */}
      <div className="space-y-4 pt-2">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-2">
          <Building className="w-4 h-4 text-purple-500" />
          Site Deployment & Organization
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold mb-1 text-slate-700 dark:text-slate-300">
              Project Site *
            </label>
            <select
              {...register('site')}
              className="w-full px-3 py-2 text-xs font-medium bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-blue-500"
            >
              <option value="Tower A Site">Tower A Site</option>
              <option value="Metro Line 3">Metro Line 3</option>
              <option value="Bridge West Project">Bridge West Project</option>
              <option value="Main Central Yard">Main Central Yard</option>
            </select>
            {errors.site && <p className="text-[11px] text-rose-500 mt-1">{errors.site.message}</p>}
          </div>

          <div>
            <label className="block text-xs font-semibold mb-1 text-slate-700 dark:text-slate-300">
              Branch Division *
            </label>
            <select
              {...register('branch')}
              className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-blue-500"
            >
              <option value="Main HQ">Main HQ</option>
              <option value="North Region Branch">North Region Branch</option>
              <option value="Metropolitan Division">Metropolitan Division</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold mb-1 text-slate-700 dark:text-slate-300">
              Site Supervisor
            </label>
            <input
              type="text"
              {...register('supervisor')}
              placeholder="e.g. Johnathan Miller"
              className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold mb-1 text-slate-700 dark:text-slate-300">
              Joining Date *
            </label>
            <input
              type="date"
              {...register('joiningDate')}
              className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold mb-1 text-slate-700 dark:text-slate-300">
              Employment Status *
            </label>
            <select
              {...register('status')}
              className="w-full px-3 py-2 text-xs font-semibold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-blue-500"
            >
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
              <option value="On Leave">On Leave</option>
              <option value="Resigned">Resigned</option>
              <option value="Terminated">Terminated</option>
            </select>
          </div>
        </div>
      </div>

      {/* EMERGENCY CONTACT & REMARKS */}
      <div className="space-y-4 pt-2">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-amber-500" />
          Emergency Contact & Additional Notes
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold mb-1 text-slate-700 dark:text-slate-300">
              Emergency Contact Name
            </label>
            <input
              type="text"
              {...register('emergencyContact')}
              placeholder="Next of kin / Spouse"
              className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold mb-1 text-slate-700 dark:text-slate-300">
              Emergency Contact Phone
            </label>
            <input
              type="text"
              {...register('emergencyPhone')}
              placeholder="+1 (555) 999-0011"
              className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold mb-1 text-slate-700 dark:text-slate-300">
            Remarks & Special Instructions
          </label>
          <textarea
            rows={2}
            {...register('remarks')}
            placeholder="Special certifications, medical allergies, or safety equipment restrictions..."
            className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 resize-none"
          />
        </div>
      </div>

      {/* FORM ACTIONS */}
      <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200 dark:border-slate-800">
        <button
          type="button"
          onClick={onCancel}
          className="px-4 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors"
        >
          Cancel
        </button>
        <button
          type="submit"
          disabled={isSubmitting}
          className="px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-md transition-all flex items-center gap-1.5 disabled:opacity-50"
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>{initialData ? 'Update Worker Profile' : 'Save Worker Profile'}</span>
        </button>
      </div>
    </form>
  );
};
