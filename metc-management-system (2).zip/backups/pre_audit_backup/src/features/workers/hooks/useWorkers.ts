import { useState, useEffect, useMemo, useCallback } from 'react';
import type { EnterpriseWorker, WorkerStatus, WorkerDocument, OverdueItemRecord, WorkerKPIs } from '../types';
import {
  fetchWorkersDb,
  createWorkerDb,
  updateWorkerDb,
  deleteWorkerDb,
  clearAllWorkersDb,
  restoreDemoWorkersDb,
  calculateOverdueItems,
  calculateWorkerKPIs,
  mapDbWorkerToEnterpriseWorker,
} from '../services/workers.service';
import { toast } from 'sonner';

export interface WorkerFilterOptions {
  searchQuery?: string;
  department?: string;
  trade?: string;
  site?: string;
  status?: WorkerStatus | 'All';
  startDate?: string;
  endDate?: string;
}

export function useWorkers() {
  const [workers, setWorkers] = useState<EnterpriseWorker[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Filters State
  const [filters, setFilters] = useState<WorkerFilterOptions>({
    searchQuery: '',
    department: 'All',
    trade: 'All',
    site: 'All',
    status: 'All',
  });

  // Selected Worker for Profile Modal / Subview
  const [selectedWorkerId, setSelectedWorkerId] = useState<string | null>(null);

  // Load Workers on Mount
  const loadWorkers = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchWorkersDb();
      setWorkers(data);
    } catch (err: any) {
      console.error('Failed to load workers:', err);
      setError(err.message || 'Error loading workers');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadWorkers();

    // Listen for live SSE worker synchronization events across devices
    const handleWorkerSync = (e: any) => {
      const detail = e.detail;
      if (!detail) return;
      if (detail.event === 'ALL_WORKERS_CLEARED') {
        setWorkers([]);
        setSelectedWorkerId(null);
      } else if (detail.event === 'DEMO_WORKERS_RESTORED') {
        loadWorkers();
      } else if (detail.event === 'WORKER_CREATED' && detail.data) {
        const mapped = mapDbWorkerToEnterpriseWorker(detail.data);
        setWorkers((prev) => {
          if (prev.some((w) => w.id === mapped.id)) return prev;
          return [mapped, ...prev];
        });
      } else if (detail.event === 'WORKER_UPDATED' && detail.data) {
        const mapped = mapDbWorkerToEnterpriseWorker(detail.data);
        setWorkers((prev) => prev.map((w) => (w.id === mapped.id ? { ...w, ...mapped } : w)));
      } else if (detail.event === 'WORKER_DELETED' && detail.id) {
        setWorkers((prev) => prev.filter((w) => w.id !== detail.id));
      } else {
        loadWorkers();
      }
    };

    const handleFullSync = () => {
      loadWorkers();
    };

    window.addEventListener('mountec:worker_sync', handleWorkerSync);
    window.addEventListener('mountec:full_sync', handleFullSync);
    return () => {
      window.removeEventListener('mountec:worker_sync', handleWorkerSync);
      window.removeEventListener('mountec:full_sync', handleFullSync);
    };
  }, [loadWorkers]);

  // Derived filtered workers list
  const filteredWorkers = useMemo(() => {
    return workers.filter((worker) => {
      // Search Query
      if (filters.searchQuery && filters.searchQuery.trim() !== '') {
        const q = filters.searchQuery.toLowerCase().trim();
        const matchesSearch =
          worker.name.toLowerCase().includes(q) ||
          worker.workerCode.toLowerCase().includes(q) ||
          worker.employeeNumber.toLowerCase().includes(q) ||
          worker.phone.toLowerCase().includes(q) ||
          worker.trade.toLowerCase().includes(q) ||
          worker.department.toLowerCase().includes(q) ||
          worker.site.toLowerCase().includes(q);

        if (!matchesSearch) return false;
      }

      // Department Filter
      if (filters.department && filters.department !== 'All') {
        if (worker.department !== filters.department) return false;
      }

      // Trade Filter
      if (filters.trade && filters.trade !== 'All') {
        if (worker.trade !== filters.trade) return false;
      }

      // Site Filter
      if (filters.site && filters.site !== 'All') {
        if (worker.site !== filters.site) return false;
      }

      // Status Filter
      if (filters.status && filters.status !== 'All') {
        if (worker.status !== filters.status) return false;
      }

      // Joining Date Range Filter
      if (filters.startDate) {
        if (new Date(worker.joiningDate) < new Date(filters.startDate)) return false;
      }
      if (filters.endDate) {
        if (new Date(worker.joiningDate) > new Date(filters.endDate)) return false;
      }

      return true;
    });
  }, [workers, filters]);

  // Extract Unique Filter Options
  const departmentOptions = useMemo(() => {
    const set = new Set(workers.map((w) => w.department).filter(Boolean));
    return ['All', ...Array.from(set)];
  }, [workers]);

  const tradeOptions = useMemo(() => {
    const set = new Set(workers.map((w) => w.trade).filter(Boolean));
    return ['All', ...Array.from(set)];
  }, [workers]);

  const siteOptions = useMemo(() => {
    const set = new Set(workers.map((w) => w.site).filter(Boolean));
    return ['All', ...Array.from(set)];
  }, [workers]);

  // Active Worker object
  const activeWorker = useMemo(() => {
    return workers.find((w) => w.id === selectedWorkerId) || workers[0] || null;
  }, [workers, selectedWorkerId]);

  // Calculated Overdue Items
  const overdueItems = useMemo<OverdueItemRecord[]>(() => {
    return calculateOverdueItems(workers);
  }, [workers]);

  // KPI Statistics
  const kpiStats = useMemo<WorkerKPIs>(() => {
    return calculateWorkerKPIs();
  }, [workers]);

  // Actions
  const handleAddWorker = async (data: Partial<EnterpriseWorker>) => {
    try {
      const created = await createWorkerDb(data);
      if (created) {
        setWorkers((prev) => [created, ...prev]);
        setSelectedWorkerId(created.id);
        toast.success(`Worker ${created.name} (${created.workerCode}) registered successfully`);
        return created;
      }
    } catch (err: any) {
      toast.error('Failed to create worker profile');
    }
    return null;
  };

  const handleUpdateWorker = async (id: string, updates: Partial<EnterpriseWorker>) => {
    try {
      await updateWorkerDb(id, updates);
      setWorkers((prev) => prev.map((w) => (w.id === id ? { ...w, ...updates, updatedAt: new Date().toISOString() } : w)));
      toast.success('Worker profile updated successfully');
    } catch (err) {
      toast.error('Failed to update worker profile');
    }
  };

  const handleToggleWorkerStatus = async (id: string, newStatus: WorkerStatus) => {
    await handleUpdateWorker(id, { status: newStatus });
    toast.info(`Worker status changed to ${newStatus}`);
  };

  const handleDeleteWorker = async (id: string) => {
    try {
      await deleteWorkerDb(id);
      setWorkers((prev) => prev.filter((w) => w.id !== id));
      if (selectedWorkerId === id) {
        setSelectedWorkerId(null);
      }
      toast.success('Worker deleted successfully');
    } catch (err) {
      toast.error('Failed to delete worker');
    }
  };

  const handleAddWorkerDocument = (workerId: string, doc: Omit<WorkerDocument, 'id' | 'workerId' | 'uploadedAt'>) => {
    const newDoc: WorkerDocument = {
      ...doc,
      id: `doc-${Date.now()}`,
      workerId,
      uploadedAt: new Date().toISOString().split('T')[0],
    };

    setWorkers((prev) =>
      prev.map((w) => {
        if (w.id === workerId) {
          const docs = w.documents ? [...w.documents, newDoc] : [newDoc];
          return { ...w, documents: docs };
        }
        return w;
      })
    );
    toast.success(`Document "${doc.title}" uploaded successfully`);
  };

  const handleDeleteWorkerDocument = (workerId: string, docId: string) => {
    setWorkers((prev) =>
      prev.map((w) => {
        if (w.id === workerId && w.documents) {
          return { ...w, documents: w.documents.filter((d) => d.id !== docId) };
        }
        return w;
      })
    );
    toast.info('Document removed');
  };

  const handleClearAllWorkers = async () => {
    setWorkers([]);
    setSelectedWorkerId(null);
    await clearAllWorkersDb();
  };

  const handleRestoreDemoWorkers = async () => {
    setLoading(true);
    try {
      const data = await restoreDemoWorkersDb();
      setWorkers(data);
    } finally {
      setLoading(false);
    }
  };

  return {
    workers,
    filteredWorkers,
    activeWorker,
    selectedWorkerId,
    setSelectedWorkerId,
    loading,
    error,
    filters,
    setFilters,
    departmentOptions,
    tradeOptions,
    siteOptions,
    overdueItems,
    kpiStats,
    reloadWorkers: loadWorkers,
    addWorker: handleAddWorker,
    updateWorker: handleUpdateWorker,
    toggleWorkerStatus: handleToggleWorkerStatus,
    deleteWorker: handleDeleteWorker,
    clearAllWorkers: handleClearAllWorkers,
    restoreDemoWorkers: handleRestoreDemoWorkers,
    addWorkerDocument: handleAddWorkerDocument,
    deleteWorkerDocument: handleDeleteWorkerDocument,
  };
}
