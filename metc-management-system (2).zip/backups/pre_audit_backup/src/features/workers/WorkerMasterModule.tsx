import React, { useState } from 'react';
import { useWorkers } from './hooks/useWorkers';
import { WorkerListTable } from './components/WorkerListTable';
import { WorkerForm } from './components/forms/WorkerForm';
import { WorkerProfileView } from './components/profile/WorkerProfileView';
import { WorkerDashboardView } from './components/dashboard/WorkerDashboardView';
import { WorkerReportsView } from './components/reports/WorkerReportsView';
import { WorkerCardModal } from './components/profile/WorkerCardModal';
import type { EnterpriseWorker } from './types';
import {
  Users,
  UserPlus,
  User,
  LayoutDashboard,
  FileBarChart2,
  Search,
  Filter,
  RefreshCw,
  Plus,
  Send,
  RotateCcw,
  ArrowLeftRight,
  ShieldCheck,
  Building,
  Briefcase,
  MapPin,
  X,
  Trash2,
  AlertTriangle,
  ClipboardList,
  Sparkles,
} from 'lucide-react';
import { toast } from 'sonner';
import { usePermissions } from '../../hooks/usePermissions';
import { Modal } from '../../components/ui/Modal';
import { Button } from '../../components/ui/Button';

export type WorkerTabType = 'all' | 'add' | 'profile' | 'dashboard' | 'reports';

export const WorkerMasterModule: React.FC = () => {
  const { canEdit } = usePermissions();
  const {
    workers,
    filteredWorkers,
    activeWorker,
    selectedWorkerId,
    setSelectedWorkerId,
    loading,
    filters,
    setFilters,
    departmentOptions,
    tradeOptions,
    siteOptions,
    overdueItems,
    kpiStats,
    reloadWorkers,
    addWorker,
    updateWorker,
    toggleWorkerStatus,
    clearAllWorkers,
    restoreDemoWorkers,
    addWorkerDocument,
    deleteWorkerDocument,
  } = useWorkers();

  const [activeTab, setActiveTab] = useState<WorkerTabType>('all');
  const [editingWorker, setEditingWorker] = useState<EnterpriseWorker | null>(null);
  const [cardWorker, setCardWorker] = useState<EnterpriseWorker | null>(null);
  const [isCardModalOpen, setIsCardModalOpen] = useState<boolean>(false);
  const [isClearAllModalOpen, setIsClearAllModalOpen] = useState<boolean>(false);
  const [isBulkImportOpen, setIsBulkImportOpen] = useState<boolean>(false);
  const [bulkWorkerText, setBulkWorkerText] = useState<string>('');
  const [bulkTrade, setBulkTrade] = useState<string>('Site Operations');
  const [bulkSite, setBulkSite] = useState<string>('Tuas Mega Logistics Depot');
  const [isImporting, setIsImporting] = useState<boolean>(false);

  const handleBulkImport = async () => {
    const lines = bulkWorkerText
      .split('\n')
      .map((l) => l.trim())
      .filter((l) => l.length > 0);

    if (lines.length === 0) {
      toast.error('Please enter or paste at least one worker name.');
      return;
    }

    setIsImporting(true);
    let addedCount = 0;
    try {
      for (const line of lines) {
        const parts = line.split(/[,\t]/).map((p) => p.trim());
        const name = parts[0]?.toUpperCase() || line.toUpperCase();
        const trade = parts[1] || bulkTrade;
        const workerCode = parts[2] || `ME-${Math.floor(100 + Math.random() * 900)}`;

        await addWorker({
          name,
          trade,
          workerCode,
          employeeNumber: workerCode,
          site: bulkSite,
          department: 'Site Operations',
          branch: 'Tuas Western Logistics Hub',
          company: 'MOUNTEC PTE LTD',
          phone: '+65 8123 4000',
          email: `${name.toLowerCase().replace(/[^a-z0-9]/g, '.')}@mountec.sg`,
          status: 'Active',
          assignedItemsCount: 0,
          overdueItemsCount: 0,
          joiningDate: new Date().toISOString().split('T')[0],
        });
        addedCount++;
      }

      toast.success(`Successfully added ${addedCount} workers! Their names will now pop up when issuing items.`);
      setBulkWorkerText('');
      setIsBulkImportOpen(false);
      await reloadWorkers();
    } catch (e: any) {
      toast.error(`Error importing workers: ${e.message || 'Unknown error'}`);
    } finally {
      setIsImporting(false);
    }
  };

  // Quick Action Modal States
  const [quickActionModal, setQuickActionModal] = useState<{
    type: 'issue' | 'return' | 'transfer' | null;
    worker: EnterpriseWorker | null;
  }>({ type: null, worker: null });

  // Quick Action Form Fields
  const [quickItemName, setQuickItemName] = useState('');
  const [quickQty, setQuickQty] = useState(1);
  const [quickNotes, setQuickNotes] = useState('');

  const handleSelectWorkerForProfile = (worker: EnterpriseWorker) => {
    setSelectedWorkerId(worker.id);
    setActiveTab('profile');
  };

  const handleOpenEditModal = (worker: EnterpriseWorker) => {
    if (!canEdit) {
      toast.error('Only Admin and Super Admin can edit worker profiles.');
      return;
    }
    setEditingWorker(worker);
  };

  const handlePrintCard = (worker: EnterpriseWorker) => {
    setCardWorker(worker);
    setIsCardModalOpen(true);
  };

  const handleFormSubmit = async (data: any) => {
    if (!canEdit) {
      toast.error('Only Admin and Super Admin can register or edit workers.');
      return;
    }
    if (editingWorker) {
      await updateWorker(editingWorker.id, data);
      setEditingWorker(null);
    } else {
      const created = await addWorker(data);
      if (created) {
        setActiveTab('profile');
      }
    }
  };

  const handleQuickActionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickItemName.trim()) {
      toast.error('Item name is required');
      return;
    }

    const workerName = quickActionModal.worker?.name || 'Worker';
    if (quickActionModal.type === 'issue') {
      toast.success(`Issued ${quickQty}x "${quickItemName}" to ${workerName}`);
    } else if (quickActionModal.type === 'return') {
      toast.success(`Processed return of ${quickQty}x "${quickItemName}" from ${workerName}`);
    } else if (quickActionModal.type === 'transfer') {
      toast.success(`Transferred "${quickItemName}" to new site/worker`);
    }

    setQuickActionModal({ type: null, worker: null });
    setQuickItemName('');
    setQuickQty(1);
    setQuickNotes('');
  };

  return (
    <div className="space-y-6 pb-12">
      {/* TOP HEADER & MODULE TAB BAR */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300">
              SAP SuccessFactors & Oracle HCM Style
            </span>
            <span className="text-xs text-slate-400">• MOUNTEC Enterprise Module</span>
            {!canEdit && (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300 border border-amber-300 dark:border-amber-700/60">
                Viewer (Read-Only)
              </span>
            )}
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100">
            Worker Management System
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage site workforce profiles, trade certifications, security badges, issued tools & PPE compliance.
          </p>
        </div>

        {/* MAIN MENU TABS & ACTIONS */}
        <div className="flex flex-wrap items-center gap-2">
          {canEdit && (
            <>
              <Button
                variant="primary"
                size="sm"
                className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold shadow-xs"
                icon={<ClipboardList className="w-4 h-4 text-white" />}
                onClick={() => setIsBulkImportOpen(true)}
              >
                Paste Worker List
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                icon={<RotateCcw className="w-4 h-4 text-slate-500" />}
                onClick={async () => {
                  await restoreDemoWorkers();
                  await reloadWorkers();
                  toast.success('Company workers restored successfully!');
                }}
              >
                Restore Workers
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="text-rose-600 dark:text-rose-400 border-rose-200 dark:border-rose-900/50 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                icon={<Trash2 className="w-4 h-4 text-rose-500" />}
                onClick={() => setIsClearAllModalOpen(true)}
              >
                Clear All
              </Button>
            </>
          )}

          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar bg-slate-100 dark:bg-slate-800 p-1.5 rounded-xl border border-slate-200 dark:border-slate-700">
            {[
              { id: 'all', label: 'All Workers', icon: Users, badge: workers.length },
              ...(canEdit ? [{ id: 'add', label: 'Add Worker', icon: UserPlus }] : []),
              { id: 'profile', label: 'Worker Profile', icon: User },
              { id: 'dashboard', label: 'Worker Dashboard', icon: LayoutDashboard },
              { id: 'reports', label: 'Worker Reports', icon: FileBarChart2 },
            ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id as WorkerTabType);
                  if (tab.id === 'add') setEditingWorker(null);
                }}
                className={`px-3.5 py-2 text-xs font-bold rounded-lg transition-all flex items-center gap-2 whitespace-nowrap ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
                {tab.badge !== undefined && (
                  <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
                    isActive ? 'bg-blue-700 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200'
                  }`}>
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
          </div>
        </div>
      </div>

      {/* TAB 1: ALL WORKERS (DIRECTORY & TABLE) */}
      {activeTab === 'all' && (
        <div className="space-y-4">
          {/* SEARCH & FILTERS BAR */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
            {/* Search Input */}
            <div className="relative flex-1 flex items-center">
              <Search className="w-4 h-4 absolute left-3.5 text-slate-400 pointer-events-none" />
              <input
                type="text"
                value={filters.searchQuery || ''}
                onChange={(e) => setFilters({ ...filters, searchQuery: e.target.value })}
                onKeyDown={(e) => {
                  if (e.key === 'Escape') {
                    setFilters({ ...filters, searchQuery: '' });
                  }
                }}
                placeholder="Search by Name, Worker ID (WRK-), Phone, Site..."
                className="w-full pl-10 pr-9 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-500 text-slate-900 dark:text-slate-100 placeholder:text-slate-400"
              />
              {filters.searchQuery && (
                <button
                  type="button"
                  onClick={() => setFilters({ ...filters, searchQuery: '' })}
                  className="absolute right-3 p-1 rounded-md text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                  title="Clear search"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Filter Dropdowns */}
            <div className="flex flex-wrap items-center gap-2">
              <select
                value={filters.site || 'All'}
                onChange={(e) => setFilters({ ...filters, site: e.target.value })}
                className="px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
              >
                {siteOptions.map((s) => (
                  <option key={s} value={s}>
                    {s === 'All' ? 'All Project Sites' : s}
                  </option>
                ))}
              </select>

              <select
                value={filters.status || 'All'}
                onChange={(e) => setFilters({ ...filters, status: e.target.value as any })}
                className="px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
              >
                <option value="All">All Statuses</option>
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
                <option value="On Leave">On Leave</option>
                <option value="Resigned">Resigned</option>
                <option value="Terminated">Terminated</option>
              </select>

              <button
                onClick={reloadWorkers}
                title="Refresh Database"
                className="p-2 text-slate-500 hover:text-blue-600 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition-colors"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* TABLE COMPONENT */}
          <WorkerListTable
            workers={filteredWorkers}
            onViewProfile={handleSelectWorkerForProfile}
            onEditWorker={handleOpenEditModal}
            onIssueItem={(w) => setQuickActionModal({ type: 'issue', worker: w })}
            onReturnItem={(w) => setQuickActionModal({ type: 'return', worker: w })}
            onTransferItem={(w) => setQuickActionModal({ type: 'transfer', worker: w })}
            onViewHistory={handleSelectWorkerForProfile}
            onPrintCard={handlePrintCard}
            onToggleStatus={toggleWorkerStatus}
            canEdit={canEdit}
          />
        </div>
      )}

      {/* TAB 2: ADD / EDIT WORKER FORM */}
      {(activeTab === 'add' || editingWorker) && canEdit && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs max-w-4xl mx-auto space-y-4">
          <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
            <div>
              <h2 className="text-lg font-black text-slate-900 dark:text-slate-100">
                {editingWorker ? `Edit Worker Profile: ${editingWorker.name}` : 'Register New Enterprise Worker'}
              </h2>
              <p className="text-xs text-slate-500">
                Fill in complete personal, trade specialization and site assignment credentials.
              </p>
            </div>
            {editingWorker && (
              <button
                onClick={() => setEditingWorker(null)}
                className="p-2 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>

          <WorkerForm
            initialData={editingWorker}
            onSubmit={handleFormSubmit}
            onCancel={() => {
              setEditingWorker(null);
              setActiveTab('all');
            }}
          />
        </div>
      )}

      {/* TAB 3: WORKER PROFILE */}
      {activeTab === 'profile' && (
        <WorkerProfileView
          worker={activeWorker}
          onEdit={handleOpenEditModal}
          onIssueItem={(w) => setQuickActionModal({ type: 'issue', worker: w })}
          onReturnItem={(w) => setQuickActionModal({ type: 'return', worker: w })}
          onStatusChange={toggleWorkerStatus}
          onAddDocument={addWorkerDocument}
          onDeleteDocument={deleteWorkerDocument}
          onBackToList={() => setActiveTab('all')}
          canEdit={canEdit}
        />
      )}

      {/* TAB 4: WORKER DASHBOARD */}
      {activeTab === 'dashboard' && (
        <WorkerDashboardView
          workers={workers}
          kpiStats={kpiStats}
          overdueItems={overdueItems}
          onSelectWorker={(id) => {
            setSelectedWorkerId(id);
            setActiveTab('profile');
          }}
        />
      )}

      {/* TAB 5: WORKER REPORTS */}
      {activeTab === 'reports' && (
        <WorkerReportsView workers={workers} overdueItems={overdueItems} />
      )}

      {/* PRINTABLE BADGE CARD MODAL */}
      <WorkerCardModal
        isOpen={isCardModalOpen}
        onClose={() => setIsCardModalOpen(false)}
        worker={cardWorker}
      />

      {/* QUICK ACTION MODAL (ISSUE / RETURN / TRANSFER) */}
      {quickActionModal.type && quickActionModal.worker && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 capitalize">
                {quickActionModal.type} Item to {quickActionModal.worker.name}
              </h3>
              <button
                onClick={() => setQuickActionModal({ type: null, worker: null })}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleQuickActionSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold mb-1">Item / Asset Name *</label>
                <input
                  type="text"
                  value={quickItemName}
                  onChange={(e) => setQuickItemName(e.target.value)}
                  placeholder="e.g. Bosch Heavy Drill / Safety Helmet"
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1">Quantity</label>
                <input
                  type="number"
                  min={1}
                  value={quickQty}
                  onChange={(e) => setQuickQty(parseInt(e.target.value) || 1)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1">Remarks / Location Notes</label>
                <textarea
                  rows={2}
                  value={quickNotes}
                  onChange={(e) => setQuickNotes(e.target.value)}
                  placeholder="Notes on site allocation, condition or expected return date..."
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl resize-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setQuickActionModal({ type: null, worker: null })}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 dark:bg-slate-800 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs capitalize"
                >
                  Confirm {quickActionModal.type}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Bulk Import Workers Modal */}
      <Modal
        isOpen={isBulkImportOpen}
        onClose={() => setIsBulkImportOpen(false)}
        title="Paste Worker List (Bulk Import)"
        size="md"
      >
        <div className="space-y-4 text-slate-900 dark:text-slate-100">
          <div className="p-3 bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-900/60 rounded-xl text-xs text-indigo-900 dark:text-indigo-200 flex items-start gap-2.5">
            <ClipboardList className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">Paste multiple worker names below</p>
              <p className="text-[11px] text-indigo-700 dark:text-indigo-300 mt-0.5">
                Paste 1 name per line (or <code>Name, Trade, Code</code>). Once added, their names will automatically pop up when issuing materials, tools and equipment!
              </p>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Worker Names (One name per line) *
            </label>
            <textarea
              rows={6}
              value={bulkWorkerText}
              onChange={(e) => setBulkWorkerText(e.target.value)}
              placeholder={`RAJESH KUMAR\nSUNIL VERMA\nAMIT SINGH\nVIKRAM PATEL\nMOHAMMAD RAKIB`}
              className="w-full px-3 py-2 text-xs font-mono bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500"
            />
            <div className="flex items-center justify-between mt-1 text-[11px] text-slate-400">
              <span>
                {bulkWorkerText.split('\n').filter((l) => l.trim().length > 0).length} workers detected
              </span>
              <span>All added workers will immediately autocomplete in the Issue module</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-1">
            <div>
              <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300 mb-1">
                Default Trade / Role
              </label>
              <input
                type="text"
                value={bulkTrade}
                onChange={(e) => setBulkTrade(e.target.value)}
                placeholder="Site Operations"
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
              />
            </div>
            <div>
              <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300 mb-1">
                Default Site Assignment
              </label>
              <input
                type="text"
                value={bulkSite}
                onChange={(e) => setBulkSite(e.target.value)}
                placeholder="Tuas Mega Logistics Depot"
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
            <Button variant="outline" size="sm" onClick={() => setIsBulkImportOpen(false)}>
              Cancel
            </Button>
            <Button
              variant="primary"
              size="sm"
              disabled={isImporting || !bulkWorkerText.trim()}
              onClick={handleBulkImport}
              className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold"
            >
              {isImporting ? 'Importing...' : 'Add All to Worker Directory'}
            </Button>
          </div>
        </div>
      </Modal>

      {/* Clear All Workers Confirmation Modal */}
      <Modal
        isOpen={isClearAllModalOpen}
        onClose={() => setIsClearAllModalOpen(false)}
        title="Delete All Workers"
        size="sm"
      >
        <div className="space-y-4 text-slate-900 dark:text-slate-100">
          <div className="flex items-start gap-3 p-3 bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 rounded-xl text-rose-800 dark:text-rose-200 text-xs">
            <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">Are you sure you want to delete all workers?</p>
              <p className="mt-1 text-[11px] text-rose-700 dark:text-rose-300">
                This will wipe all worker personnel records so you can start fresh and register your own workers from scratch.
              </p>
            </div>
          </div>
          <div className="flex items-center justify-between pt-2 border-t border-slate-200 dark:border-slate-800">
            <Button
              variant="outline"
              size="sm"
              onClick={async () => {
                await restoreDemoWorkers();
                setIsClearAllModalOpen(false);
                toast.info('Restored sample demo workers.');
              }}
              className="text-xs text-slate-500"
            >
              Restore Demo Data
            </Button>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={() => setIsClearAllModalOpen(false)}>
                Cancel
              </Button>
              <Button
                variant="danger"
                size="sm"
                onClick={async () => {
                  await clearAllWorkers();
                  setIsClearAllModalOpen(false);
                  toast.success('All workers cleared! You can now add your new workers.');
                }}
              >
                Yes, Delete All Workers
              </Button>
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
};
