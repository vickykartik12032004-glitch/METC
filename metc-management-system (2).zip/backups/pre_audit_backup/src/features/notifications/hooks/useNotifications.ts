import { useMemo, useState } from 'react';
import { useNotificationStore } from '../../../store/useNotificationStore';
import { useAssetStore } from '../../../store/useAssetStore';
import { useTransactionStore } from '../../../store/useTransactionStore';
import { useMaintenanceStore } from '../../../store/useMaintenanceStore';
import { useWorkerStore } from '../../../store/useWorkerStore';
import { NotificationService } from '../services/notification.service';
import {
  LowStockAlertItem,
  OverdueAlertItem,
  RepairAlertItem,
  MaintenanceAlertItem,
  CalibrationAlertItem,
  WarrantyAlertItem,
  NotificationPriority,
  NotificationModule
} from '../types';
import { toast } from 'sonner';

export const useNotifications = () => {
  const store = useNotificationStore();
  const { materials, equipment, tools, consumables, ppe } = useAssetStore();
  const { issues, returns, transfers, repairs, lostItems } = useTransactionStore();
  const { maintenances } = useMaintenanceStore();
  const { workers } = useWorkerStore();

  // Search & Filter State
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPriority, setSelectedPriority] = useState<string>('All');
  const [selectedStatus, setSelectedStatus] = useState<string>('All');
  const [selectedModule, setSelectedModule] = useState<string>('All');
  const [selectedReadFilter, setSelectedReadFilter] = useState<'All' | 'Unread' | 'Read'>('All');

  // 1. Dynamic Low Stock Alerts
  const lowStockAlerts = useMemo<LowStockAlertItem[]>(() => {
    const allAssets = [...materials, ...equipment, ...tools, ...consumables, ...ppe];
    const alerts: LowStockAlertItem[] = [];

    allAssets.forEach((asset) => {
      const minThreshold = asset.minQuantityThreshold || ('reorderLevel' in asset ? (asset as any).reorderLevel : 10);
      if (asset.quantity <= minThreshold || asset.status === 'Low Stock' || asset.status === 'Out of Stock') {
        const diff = minThreshold - asset.quantity;
        const suggestedReorder = diff > 0 ? diff + Math.ceil(minThreshold * 1.5) : minThreshold * 2;
        
        let priority: NotificationPriority = 'Medium';
        if (asset.quantity === 0 || asset.status === 'Out of Stock') priority = 'Critical';
        else if (asset.quantity <= Math.ceil(minThreshold * 0.5)) priority = 'High';

        alerts.push({
          id: `lowstock-${asset.id}`,
          itemCode: asset.code,
          itemName: asset.name,
          category: asset.category,
          currentStock: asset.quantity,
          minimumStock: minThreshold,
          suggestedReorderQuantity: suggestedReorder,
          priority,
          unit: asset.unit,
          location: asset.location
        });
      }
    });

    return alerts;
  }, [materials, equipment, tools, consumables, ppe]);

  // 2. Dynamic Overdue Alerts
  const overdueAlerts = useMemo<OverdueAlertItem[]>(() => {
    const today = new Date();
    const alerts: OverdueAlertItem[] = [];

    issues.forEach((iss) => {
      if (iss.expectedReturnDate && (iss.status === 'Active' || iss.status === 'Overdue')) {
        const dueDate = new Date(iss.expectedReturnDate);
        if (dueDate < today) {
          const diffMs = today.getTime() - dueDate.getTime();
          const daysOverdue = Math.max(1, Math.floor(diffMs / (1000 * 60 * 60 * 24)));
          
          let priority: NotificationPriority = 'Medium';
          if (daysOverdue >= 15) priority = 'Critical';
          else if (daysOverdue >= 7) priority = 'High';

          const worker = workers.find((w) => w.id === iss.workerId || w.name === iss.workerName);

          alerts.push({
            id: `overdue-${iss.id}`,
            issueCode: iss.issueCode,
            workerId: iss.workerId,
            workerName: iss.workerName,
            itemCode: iss.itemId,
            itemName: iss.itemName,
            expectedReturnDate: iss.expectedReturnDate,
            daysOverdue,
            site: iss.projectSite,
            department: worker?.trade || 'Operations',
            priority
          });
        }
      }
    });

    return alerts;
  }, [issues, workers]);

  // 3. Dynamic Repair Alerts
  const repairAlerts = useMemo<RepairAlertItem[]>(() => {
    return repairs.map((rep) => {
      let status: RepairAlertItem['status'] = 'Repair In Progress';
      if (rep.status === 'Assigned' || rep.status === 'Pending') status = 'Repair Assigned';
      else if (rep.status === 'Completed' || rep.status === 'Repaired') status = 'Repair Completed';
      else if (rep.status === 'Waiting Parts' || rep.status === 'Scheduled') status = 'Repair Delayed';

      let priority: NotificationPriority = 'Medium';
      if (rep.status === 'In Repair' || rep.status === 'Waiting Parts') priority = 'High';
      if (rep.status === 'Beyond Repair') priority = 'Critical';

      return {
        id: `repair-alert-${rep.id}`,
        repairCode: rep.repairCode,
        itemCode: rep.assetId || rep.itemId,
        itemName: rep.itemName,
        status,
        assignedTo: rep.handledBy,
        vendor: rep.repairVendor,
        updatedAt: rep.sentDate || new Date().toISOString(),
        priority
      };
    });
  }, [repairs]);

  // 4. Dynamic Maintenance Alerts
  const maintenanceAlerts = useMemo<MaintenanceAlertItem[]>(() => {
    const today = new Date();
    return (maintenances || []).map((m) => {
      const nextDate = new Date(m.nextMaintenance);
      let maintType: MaintenanceAlertItem['maintenanceType'] = 'Preventive Maintenance Due';
      let priority: NotificationPriority = 'Low';

      if (nextDate < today || m.status === 'Overdue') {
        maintType = 'Maintenance Overdue';
        priority = 'High';
      } else {
        maintType = 'Maintenance Due';
        priority = 'Medium';
      }

      return {
        id: `maint-alert-${m.id}`,
        maintenanceCode: m.maintenanceCode,
        itemCode: m.itemId,
        itemName: m.itemName,
        maintenanceType: maintType,
        dueDate: m.nextMaintenance,
        responsiblePerson: m.responsiblePerson,
        priority
      };
    });
  }, [maintenances]);

  // 5. Dynamic Calibration Alerts
  const calibrationAlerts = useMemo<CalibrationAlertItem[]>(() => {
    const alerts: CalibrationAlertItem[] = [];

    ppe.forEach((p) => {
      if (p.inspectionDueDate) {
        const isExp = new Date(p.inspectionDueDate) < new Date();
        alerts.push({
          id: `calib-${p.id}`,
          calibrationCode: `CAL-${p.code}`,
          itemCode: p.code,
          itemName: p.name,
          status: isExp ? 'Calibration Expired' : 'Calibration Due',
          dueDate: p.inspectionDueDate,
          vendor: p.supplier,
          priority: isExp ? 'High' : 'Medium'
        });
      }
    });

    tools.forEach((t) => {
      if (t.condition === 'Requires Service') {
        alerts.push({
          id: `calib-tool-${t.id}`,
          calibrationCode: `CAL-${t.code}`,
          itemCode: t.code,
          itemName: t.name,
          status: 'Calibration Expired',
          dueDate: new Date().toISOString().split('T')[0],
          vendor: t.supplier || 'Precision Calibration SG',
          priority: 'Critical'
        });
      }
    });

    return alerts;
  }, [ppe, tools]);

  // 6. Dynamic Warranty Alerts
  const warrantyAlerts = useMemo<WarrantyAlertItem[]>(() => {
    return equipment.map((eq) => {
      const nextMaint = new Date(eq.nextMaintenanceDate || '2026-10-01');
      const isExp = nextMaint < new Date();
      return {
        id: `warr-${eq.id}`,
        assetId: eq.serialNumber || eq.code,
        itemCode: eq.code,
        itemName: eq.name,
        status: isExp ? 'Warranty Expired' : 'Warranty Expiring',
        expiryDate: eq.nextMaintenanceDate || '2026-10-01',
        supplier: eq.supplier || eq.manufacturer || 'MOUNTEC Vendor',
        priority: isExp ? 'Medium' : 'Low'
      };
    });
  }, [equipment]);

  // KPI Calculations
  const kpis = useMemo(() => {
    const unreadCount = store.notifications.filter((n) => n.status === 'Unread').length;
    
    const todayStr = new Date().toISOString().split('T')[0];
    const todaysAlertsCount = store.notifications.filter(
      (n) => n.createdAt.startsWith(todayStr) || n.priority === 'Critical' || n.priority === 'High'
    ).length;

    return {
      unreadNotifications: unreadCount,
      todaysAlerts: todaysAlertsCount,
      overdueItems: overdueAlerts.length,
      lowStockAlerts: lowStockAlerts.length,
      repairAlerts: repairAlerts.length,
      warrantyAlerts: warrantyAlerts.length,
      calibrationAlerts: calibrationAlerts.length,
      emailQueue: store.emailQueue.length,
      pushQueue: store.pushQueue.length
    };
  }, [store.notifications, store.emailQueue, store.pushQueue, overdueAlerts, lowStockAlerts, repairAlerts, warrantyAlerts, calibrationAlerts]);

  // Filtered Notifications for Notification Center
  const filteredNotifications = useMemo(() => {
    return store.notifications.filter((notif) => {
      // Read/Unread Filter
      if (selectedReadFilter === 'Unread' && notif.status !== 'Unread') return false;
      if (selectedReadFilter === 'Read' && notif.status !== 'Read') return false;

      // Priority Filter
      if (selectedPriority !== 'All' && notif.priority !== selectedPriority) return false;

      // Status Filter
      if (selectedStatus === 'Pinned' && !notif.isPinned) return false;
      if (selectedStatus === 'Archived' && !notif.isArchived) return false;

      // Module Filter
      if (selectedModule !== 'All' && notif.module !== selectedModule) return false;

      // Search Query
      if (searchTerm.trim() !== '') {
        const query = searchTerm.toLowerCase();
        const matchesTitle = notif.title.toLowerCase().includes(query);
        const matchesMessage = notif.message.toLowerCase().includes(query);
        const matchesItem = notif.itemName?.toLowerCase().includes(query) || notif.itemCode?.toLowerCase().includes(query);
        const matchesWorker = notif.workerName?.toLowerCase().includes(query);
        const matchesModule = notif.module.toLowerCase().includes(query);

        if (!matchesTitle && !matchesMessage && !matchesItem && !matchesWorker && !matchesModule) {
          return false;
        }
      }

      return true;
    });
  }, [store.notifications, searchTerm, selectedPriority, selectedStatus, selectedModule, selectedReadFilter]);

  // System Wide Alert Scan
  const triggerSystemScan = () => {
    let createdCount = 0;

    // 1. Scan Low Stock
    lowStockAlerts.forEach((item) => {
      const exists = store.notifications.some((n) => n.itemCode === item.itemCode && n.module === 'Stock' && n.status === 'Unread');
      if (!exists) {
        NotificationService.createNotification({
          title: `Low Stock Alert: ${item.itemName}`,
          message: `Current stock balance is ${item.currentStock} ${item.unit} (Minimum: ${item.minimumStock}). Suggested reorder: ${item.suggestedReorderQuantity}.`,
          priority: item.priority,
          module: 'Stock',
          itemCode: item.itemCode,
          itemName: item.itemName,
          recipientRole: 'Store Keeper'
        });
        createdCount++;
      }
    });

    // 2. Scan Overdue Items
    overdueAlerts.forEach((item) => {
      const exists = store.notifications.some((n) => n.itemCode === item.itemCode && n.workerName === item.workerName && n.module === 'Issue' && n.status === 'Unread');
      if (!exists) {
        NotificationService.createNotification({
          title: `Overdue Item: ${item.itemName}`,
          message: `Worker ${item.workerName} at ${item.site} is overdue by ${item.daysOverdue} days (Expected: ${item.expectedReturnDate}).`,
          priority: item.priority,
          module: 'Issue',
          itemCode: item.itemCode,
          itemName: item.itemName,
          workerName: item.workerName,
          site: item.site,
          recipientRole: 'Supervisor'
        });
        createdCount++;
      }
    });

    toast.success(`[MOUNTEC System Scan] Evaluation complete`, {
      description: createdCount > 0 ? `Generated ${createdCount} new smart alerts.` : 'All stock levels and operational returns are fully compliant.',
    });
  };

  return {
    kpis,
    notifications: store.notifications,
    filteredNotifications,
    lowStockAlerts,
    overdueAlerts,
    repairAlerts,
    maintenanceAlerts,
    calibrationAlerts,
    warrantyAlerts,
    emailTemplates: store.emailTemplates,
    emailQueue: store.emailQueue,
    pushQueue: store.pushQueue,
    reminderRules: store.reminderRules,
    escalationRules: store.escalationRules,
    history: store.history,
    settings: store.settings,

    // Controls
    searchTerm,
    setSearchTerm,
    selectedPriority,
    setSelectedPriority,
    selectedStatus,
    setSelectedStatus,
    selectedModule,
    setSelectedModule,
    selectedReadFilter,
    setSelectedReadFilter,

    // Service & Store actions
    markAsRead: store.markAsRead,
    markAllAsRead: store.markAllAsRead,
    deleteNotification: store.deleteNotification,
    archiveNotification: store.archiveNotification,
    pinNotification: store.pinNotification,
    clearAll: store.clearAll,
    updateEmailTemplate: store.updateEmailTemplate,
    resetTemplatesToDefault: store.resetTemplatesToDefault,
    addReminderRule: store.addReminderRule,
    toggleReminderRule: store.toggleReminderRule,
    deleteReminderRule: store.deleteReminderRule,
    addEscalationRule: store.addEscalationRule,
    toggleEscalationRule: store.toggleEscalationRule,
    deleteEscalationRule: store.deleteEscalationRule,
    updateSettings: store.updateSettings,
    toggleModuleSetting: store.toggleModuleSetting,
    toggleChannelSetting: store.toggleChannelSetting,
    clearHistory: store.clearHistory,
    clearQueues: store.clearQueues,

    // Dispatchers
    createNotification: NotificationService.createNotification,
    sendEmail: NotificationService.sendEmail,
    sendPush: NotificationService.sendPush,
    scheduleReminder: NotificationService.scheduleReminder,
    triggerSystemScan,
  };
};
