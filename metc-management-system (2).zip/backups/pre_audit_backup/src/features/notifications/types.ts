export type NotificationPriority = 'Low' | 'Medium' | 'High' | 'Critical';

export type NotificationStatus = 'Unread' | 'Read' | 'Archived' | 'Pinned';

export type NotificationChannel = 'In-App' | 'Email' | 'Push';

export type NotificationModule =
  | 'Issue'
  | 'Return'
  | 'Transfer'
  | 'Repair'
  | 'Maintenance'
  | 'Lost'
  | 'Disposed'
  | 'Worker'
  | 'Supplier'
  | 'Site'
  | 'Stock'
  | 'Calibration'
  | 'Warranty';

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  priority: NotificationPriority;
  module: NotificationModule;
  recipientUser?: string;
  recipientRole?: 'Store Keeper' | 'Site Supervisor' | 'Supervisor' | 'Admin' | 'Super Admin' | 'Worker' | 'All';
  status: 'Unread' | 'Read';
  read?: boolean;
  type?: string;
  isPinned?: boolean;
  isArchived?: boolean;
  createdAt: string;
  readAt?: string;
  deliveredAt?: string;
  link?: string;
  itemCode?: string;
  itemName?: string;
  workerName?: string;
  site?: string;
  metadata?: Record<string, any>;
}

export interface LowStockAlertItem {
  id: string;
  itemCode: string;
  itemName: string;
  category: string;
  currentStock: number;
  minimumStock: number;
  suggestedReorderQuantity: number;
  priority: NotificationPriority;
  unit: string;
  location: string;
}

export interface OverdueAlertItem {
  id: string;
  issueCode: string;
  workerId: string;
  workerName: string;
  itemCode: string;
  itemName: string;
  expectedReturnDate: string;
  daysOverdue: number;
  site: string;
  department: string;
  priority: NotificationPriority;
}

export interface RepairAlertItem {
  id: string;
  repairCode: string;
  itemCode: string;
  itemName: string;
  status: 'Repair Assigned' | 'Repair In Progress' | 'Repair Completed' | 'Repair Delayed';
  assignedTo?: string;
  vendor?: string;
  updatedAt: string;
  priority: NotificationPriority;
}

export interface MaintenanceAlertItem {
  id: string;
  maintenanceCode: string;
  itemCode: string;
  itemName: string;
  maintenanceType: 'Preventive Maintenance Due' | 'Maintenance Due' | 'Maintenance Overdue';
  dueDate: string;
  responsiblePerson: string;
  priority: NotificationPriority;
}

export interface CalibrationAlertItem {
  id: string;
  calibrationCode: string;
  itemCode: string;
  itemName: string;
  status: 'Calibration Due' | 'Calibration Expired' | 'Calibration Completed';
  dueDate: string;
  vendor?: string;
  priority: NotificationPriority;
}

export interface WarrantyAlertItem {
  id: string;
  assetId: string;
  itemCode: string;
  itemName: string;
  status: 'Warranty Expiring' | 'Warranty Expired' | 'Warranty Claim Available';
  expiryDate: string;
  supplier: string;
  priority: NotificationPriority;
}

export interface EmailTemplate {
  id: string;
  code: string;
  name: string;
  subject: string;
  bodyHtml: string;
  headerTitle: string; // MOUNTEC PTE LTD
  footerDetails: string;
  module: NotificationModule;
  variables: string[];
  updatedAt: string;
}

export interface PushQueueItem {
  id: string;
  title: string;
  message: string;
  targetRoles: ('Store Keeper' | 'Supervisor' | 'Admin' | 'Worker')[];
  status: 'Pending' | 'Delivered' | 'Failed';
  createdAt: string;
  deliveredAt?: string;
  retryCount: number;
}

export interface EmailQueueItem {
  id: string;
  templateCode: string;
  recipientEmail: string;
  recipientName: string;
  subject: string;
  bodyHtml: string;
  status: 'Pending' | 'Sent' | 'Failed' | 'Bounced';
  createdAt: string;
  sentAt?: string;
  error?: string;
}

export interface ReminderRule {
  id: string;
  name: string;
  module: NotificationModule;
  frequency: 'Daily' | 'Weekly' | 'Monthly' | 'Custom';
  customIntervalDays?: number;
  timeOfDay: string; // e.g. "08:00"
  active: boolean;
  targetRole: 'Store Keeper' | 'Supervisor' | 'Admin' | 'Worker' | 'All';
  lastRun?: string;
  nextRun?: string;
}

export interface EscalationRule {
  id: string;
  name: string;
  module: NotificationModule;
  conditionDays: number; // e.g. Overdue > 3 Days
  actionNotifyRole: 'Supervisor' | 'Admin' | 'Super Admin';
  triggerPriority: NotificationPriority;
  description: string;
  active: boolean;
}

export interface NotificationHistoryItem {
  id: string;
  notificationId: string;
  title: string;
  recipient: string;
  channel: NotificationChannel;
  deliveryStatus: 'Delivered' | 'Sent' | 'Failed' | 'Pending' | 'Bounced';
  createdBy: string;
  createdAt: string;
  deliveredAt?: string;
  readAt?: string;
}

export interface NotificationSettingsState {
  companyName: string;
  senderEmail?: string;
  enableSoundAlerts: boolean;
  autoArchiveDays: number;
  channels: {
    inApp: boolean;
    email: boolean;
    push: boolean;
  };
  modules: {
    Issue: boolean;
    Return: boolean;
    Transfer: boolean;
    Repair: boolean;
    Maintenance: boolean;
    Lost: boolean;
    Warranty: boolean;
    Calibration: boolean;
    Stock: boolean;
  };
}
