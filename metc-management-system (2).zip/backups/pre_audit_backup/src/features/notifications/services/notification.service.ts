import {
  AppNotification,
  EmailQueueItem,
  PushQueueItem,
  ReminderRule,
  NotificationPriority,
  NotificationModule
} from '../types';
import { useNotificationStore } from '../../../store/useNotificationStore';
import { toast } from 'sonner';

export class NotificationService {
  /**
   * Create an in-app notification
   */
  static createNotification(data: {
    title: string;
    message: string;
    priority?: NotificationPriority;
    module?: NotificationModule;
    recipientRole?: 'Store Keeper' | 'Site Supervisor' | 'Supervisor' | 'Admin' | 'Super Admin' | 'Worker' | 'All';
    link?: string;
    itemCode?: string;
    itemName?: string;
    workerName?: string;
    site?: string;
  }): AppNotification {
    const notif: AppNotification = {
      id: `notif-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      title: data.title,
      message: data.message,
      priority: data.priority || 'Medium',
      module: data.module || 'Issue',
      recipientRole: data.recipientRole || 'All',
      status: 'Unread',
      createdAt: new Date().toISOString(),
      link: data.link,
      itemCode: data.itemCode,
      itemName: data.itemName,
      workerName: data.workerName,
      site: data.site,
    };

    const store = useNotificationStore.getState();
    store.addNotification(notif);

    // If critical or high, pop a toast alert
    if (notif.priority === 'Critical' || notif.priority === 'High') {
      toast.error(`[MOUNTEC Alert] ${notif.title}`, {
        description: notif.message,
        duration: 5000,
      });
    }

    return notif;
  }

  /**
   * Send / Queue Email Notification
   */
  static sendEmail(data: {
    templateCode: string;
    recipientEmail: string;
    recipientName: string;
    subject: string;
    bodyHtml: string;
  }): EmailQueueItem {
    const queueItem: EmailQueueItem = {
      id: `email-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      templateCode: data.templateCode,
      recipientEmail: data.recipientEmail,
      recipientName: data.recipientName,
      subject: data.subject,
      bodyHtml: data.bodyHtml,
      status: 'Sent',
      createdAt: new Date().toISOString(),
      sentAt: new Date().toISOString(),
    };

    const store = useNotificationStore.getState();
    store.addEmailToQueue(queueItem);

    toast.success(`[MOUNTEC Email Sent] ${data.subject}`, {
      description: `Dispatched to ${data.recipientName} (${data.recipientEmail})`,
    });

    return queueItem;
  }

  /**
   * Send / Dispatch Push Notification
   */
  static async sendPush(data: {
    title: string;
    message: string;
    targetRoles?: ('Store Keeper' | 'Supervisor' | 'Admin' | 'Worker')[];
  }): Promise<PushQueueItem> {
    const roles = data.targetRoles || ['Store Keeper', 'Supervisor', 'Admin', 'Worker'];

    const pushItem: PushQueueItem = {
      id: `push-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      title: data.title,
      message: data.message,
      targetRoles: roles,
      status: 'Delivered',
      createdAt: new Date().toISOString(),
      deliveredAt: new Date().toISOString(),
      retryCount: 0,
    };

    const store = useNotificationStore.getState();
    store.addPushToQueue(pushItem);

    // Browser Web Notification API integration
    if ('Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification(`MOUNTEC PTE LTD: ${data.title}`, {
          body: data.message,
          icon: '/favicon.ico',
        });
      } catch (err) {
        console.log('Browser push notification fallback to toast:', err);
      }
    }

    toast.info(`[MOUNTEC Push Sent] ${data.title}`, {
      description: `Broadcasted to roles: ${roles.join(', ')}`,
    });

    return pushItem;
  }

  /**
   * Mark a notification as read
   */
  static markAsRead(id: string): void {
    const store = useNotificationStore.getState();
    store.markAsRead(id);
  }

  /**
   * Mark all notifications as read
   */
  static markAllRead(): void {
    const store = useNotificationStore.getState();
    store.markAllAsRead();
  }

  /**
   * Schedule or create a reminder rule
   */
  static scheduleReminder(rule: Omit<ReminderRule, 'id'>): ReminderRule {
    const newRule: ReminderRule = {
      ...rule,
      id: `rule-${Date.now()}`,
      lastRun: new Date().toISOString(),
      nextRun: new Date(Date.now() + 86400000).toISOString(),
    };

    const store = useNotificationStore.getState();
    store.addReminderRule(newRule);

    toast.success(`[MOUNTEC Reminder Engine] Scheduled '${newRule.name}'`, {
      description: `Frequency: ${newRule.frequency} at ${newRule.timeOfDay}`,
    });

    return newRule;
  }
}

export const createNotification = NotificationService.createNotification;
export const sendEmail = NotificationService.sendEmail;
export const sendPush = NotificationService.sendPush;
export const markAsRead = NotificationService.markAsRead;
export const markAllRead = NotificationService.markAllRead;
export const scheduleReminder = NotificationService.scheduleReminder;
