import React, { useState } from 'react';
import { useNotifications } from '../hooks/useNotifications';
import { Card, CardContent } from '../../../components/ui/Card';
import { Button } from '../../../components/ui/Button';
import {
  Bell,
  Search,
  Filter,
  CheckCheck,
  Trash2,
  Pin,
  Archive,
  Download,
  AlertTriangle,
  Info,
  AlertCircle,
  X,
  FileSpreadsheet,
  FileText,
  FileCode,
  Tag,
  Calendar,
  User,
  Building
} from 'lucide-react';
import { formatDateTime } from '../../../lib/utils';
import { toast } from 'sonner';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';

export const NotificationCenter: React.FC = () => {
  const {
    filteredNotifications,
    searchTerm,
    setSearchTerm,
    selectedPriority,
    setSelectedPriority,
    selectedStatus,
    setSelectedStatus,
    selectedModule,
    setSelectedModule,
    selectedReadFilter,
    setSelectedReadFilter,
    markAsRead,
    markAllAsRead,
    deleteNotification,
    archiveNotification,
    pinNotification,
    clearAll
  } = useNotifications();

  const [selectedNotifModal, setSelectedNotifModal] = useState<any | null>(null);

  // Priority color styling
  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'Critical':
        return 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300 border-rose-300 dark:border-rose-800';
      case 'High':
        return 'bg-orange-100 text-orange-700 dark:bg-orange-950 dark:text-orange-300 border-orange-300 dark:border-orange-800';
      case 'Medium':
        return 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300 border-amber-300 dark:border-amber-800';
      default:
        return 'bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300 border-blue-300 dark:border-blue-800';
    }
  };

  // Export handlers
  const exportToExcel = () => {
    const data = filteredNotifications.map((n) => ({
      'Company Name': 'MOUNTEC PTE LTD',
      'Notification ID': n.id,
      Title: n.title,
      Message: n.message,
      Priority: n.priority,
      Module: n.module,
      Recipient: n.recipientRole || 'All',
      Status: n.status,
      'Item Code': n.itemCode || '-',
      Worker: n.workerName || '-',
      'Created Date': n.createdAt
    }));

    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Notifications');
    XLSX.writeFile(wb, `MOUNTEC_Notification_Center_${new Date().toISOString().split('T')[0]}.xlsx`);
    toast.success('Exported Notification Center data to Excel');
  };

  const exportToPDF = () => {
    const doc = new jsPDF();
    doc.setFontSize(14);
    doc.setTextColor(30, 58, 138); // MOUNTEC Blue
    doc.text('MOUNTEC PTE LTD - Enterprise Notification Center Report', 14, 15);
    doc.setFontSize(9);
    doc.setTextColor(100, 116, 139);
    doc.text(`Generated: ${new Date().toLocaleString()} | Total Records: ${filteredNotifications.length}`, 14, 22);

    const tableRows = filteredNotifications.map((n) => [
      n.title,
      n.module,
      n.priority,
      n.status,
      n.recipientRole || 'All',
      n.createdAt.split('T')[0]
    ]);

    autoTable(doc, {
      startY: 28,
      head: [['Title', 'Module', 'Priority', 'Status', 'Recipient Role', 'Date']],
      body: tableRows,
      headStyles: { fillColor: [30, 58, 138] },
      styles: { fontSize: 8 }
    });

    doc.save(`MOUNTEC_Notifications_${new Date().toISOString().split('T')[0]}.pdf`);
    toast.success('Exported Notification Center report to PDF');
  };

  const exportToJSON = () => {
    const jsonStr = JSON.stringify(filteredNotifications, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `MOUNTEC_Notifications_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    toast.success('Exported Notifications to JSON format');
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Bell className="w-5 h-5 text-blue-600" />
            MOUNTEC Enterprise Notification Center
          </h2>
          <p className="text-xs text-slate-500">
            Unified alert logs, status tracking, and critical dispatch history for MOUNTEC PTE LTD
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            icon={<CheckCheck className="w-4 h-4 text-emerald-500" />}
            onClick={() => {
              markAllAsRead();
              toast.success('All notifications marked as read');
            }}
          >
            Mark All Read
          </Button>

          <Button
            variant="outline"
            size="sm"
            icon={<Trash2 className="w-4 h-4 text-rose-500" />}
            onClick={() => {
              clearAll();
              toast.success('Cleared notification feed');
            }}
          >
            Clear Feed
          </Button>

          {/* Export Group */}
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg border border-slate-200 dark:border-slate-700">
            <button
              onClick={exportToExcel}
              title="Export Excel"
              className="p-1.5 hover:bg-white dark:hover:bg-slate-700 rounded text-slate-600 dark:text-slate-300 text-xs flex items-center gap-1 font-semibold"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" /> Excel
            </button>
            <button
              onClick={exportToPDF}
              title="Export PDF"
              className="p-1.5 hover:bg-white dark:hover:bg-slate-700 rounded text-slate-600 dark:text-slate-300 text-xs flex items-center gap-1 font-semibold"
            >
              <FileText className="w-3.5 h-3.5 text-rose-600" /> PDF
            </button>
            <button
              onClick={exportToJSON}
              title="Export JSON"
              className="p-1.5 hover:bg-white dark:hover:bg-slate-700 rounded text-slate-600 dark:text-slate-300 text-xs flex items-center gap-1 font-semibold"
            >
              <FileCode className="w-3.5 h-3.5 text-blue-600" /> JSON
            </button>
          </div>
        </div>
      </div>

      {/* Search and Filters Bar */}
      <Card border className="border-slate-200 dark:border-slate-800">
        <CardContent className="p-4 space-y-3">
          <div className="flex flex-col md:flex-row items-center gap-3">
            {/* Search Bar */}
            <div className="relative flex-1 w-full">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search notifications by title, module, worker, item, or date..."
                className="w-full pl-9 pr-4 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              {searchTerm && (
                <button
                  onClick={() => setSearchTerm('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Read / Unread Toggle */}
            <div className="flex items-center bg-slate-100 dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-800 shrink-0">
              {(['All', 'Unread', 'Read'] as const).map((st) => (
                <button
                  key={st}
                  onClick={() => setSelectedReadFilter(st)}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                    selectedReadFilter === st
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>
          </div>

          {/* Secondary Filter Dropdowns */}
          <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-slate-100 dark:border-slate-800/80 text-xs">
            <span className="font-semibold text-slate-500 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" /> Filters:
            </span>

            {/* Priority Filter */}
            <select
              value={selectedPriority}
              onChange={(e) => setSelectedPriority(e.target.value)}
              className="px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 font-medium focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="All">Priority: All</option>
              <option value="Critical">Critical</option>
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>

            {/* Module Filter */}
            <select
              value={selectedModule}
              onChange={(e) => setSelectedModule(e.target.value)}
              className="px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 font-medium focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="All">Module: All</option>
              <option value="Issue">Issue</option>
              <option value="Return">Return</option>
              <option value="Transfer">Transfer</option>
              <option value="Repair">Repair</option>
              <option value="Maintenance">Maintenance</option>
              <option value="Lost">Lost</option>
              <option value="Stock">Stock / Inventory</option>
              <option value="Calibration">Calibration</option>
              <option value="Warranty">Warranty</option>
              <option value="Worker">Worker</option>
            </select>

            {/* Status Filter */}
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 font-medium focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="All">Status: All</option>
              <option value="Pinned">Pinned Only</option>
              <option value="Archived">Archived Only</option>
            </select>

            {(selectedPriority !== 'All' || selectedModule !== 'All' || selectedStatus !== 'All' || searchTerm) && (
              <button
                onClick={() => {
                  setSelectedPriority('All');
                  setSelectedModule('All');
                  setSelectedStatus('All');
                  setSearchTerm('');
                  setSelectedReadFilter('All');
                }}
                className="text-xs text-rose-600 dark:text-rose-400 font-semibold hover:underline ml-auto"
              >
                Reset Filters
              </button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Notifications List */}
      <div className="space-y-3">
        {filteredNotifications.length === 0 ? (
          <div className="text-center py-16 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
            <Bell className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto mb-3" />
            <h3 className="text-sm font-bold text-slate-700 dark:text-slate-300">No matching notifications found</h3>
            <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
              Try adjusting your search query, status tabs, or module filters.
            </p>
          </div>
        ) : (
          filteredNotifications.map((notif) => (
            <Card
              key={notif.id}
              className={`transition-all ${
                notif.isPinned
                  ? 'border-2 border-blue-500/80 bg-blue-50/20 dark:bg-blue-950/20'
                  : notif.status === 'Unread'
                  ? 'border-l-4 border-l-blue-600 bg-slate-50/60 dark:bg-slate-900/60'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 opacity-85'
              }`}
            >
              <CardContent className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-start gap-3.5 flex-1 min-w-0">
                  {/* Priority Badge */}
                  <span
                    className={`px-2.5 py-1 rounded-lg text-[10px] font-extrabold uppercase tracking-wider border shrink-0 ${getPriorityBadge(
                      notif.priority
                    )}`}
                  >
                    {notif.priority}
                  </span>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h4
                        className="text-sm font-bold text-slate-900 dark:text-slate-100 hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer"
                        onClick={() => setSelectedNotifModal(notif)}
                      >
                        {notif.title}
                      </h4>

                      {notif.isPinned && (
                        <span className="p-1 rounded bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-300 text-[10px] font-bold flex items-center gap-0.5">
                          <Pin className="w-3 h-3" /> Pinned
                        </span>
                      )}

                      {notif.isArchived && (
                        <span className="p-1 rounded bg-slate-100 dark:bg-slate-800 text-slate-500 text-[10px] font-bold flex items-center gap-0.5">
                          <Archive className="w-3 h-3" /> Archived
                        </span>
                      )}
                    </div>

                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 line-clamp-2">{notif.message}</p>

                    <div className="flex items-center gap-3 flex-wrap mt-2.5 text-[11px] text-slate-500">
                      <span className="flex items-center gap-1 font-semibold text-blue-600 dark:text-blue-400">
                        <Tag className="w-3 h-3" /> {notif.module}
                      </span>
                      {notif.recipientRole && (
                        <span className="flex items-center gap-1">
                          <User className="w-3 h-3 text-slate-400" /> Target Role: {notif.recipientRole}
                        </span>
                      )}
                      {notif.site && (
                        <span className="flex items-center gap-1">
                          <Building className="w-3 h-3 text-slate-400" /> {notif.site}
                        </span>
                      )}
                      <span className="flex items-center gap-1 text-slate-400 ml-auto">
                        <Calendar className="w-3 h-3" /> {formatDateTime(notif.createdAt)}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Card Actions */}
                <div className="flex items-center gap-2 shrink-0 self-end md:self-center border-t md:border-t-0 pt-2 md:pt-0 border-slate-100 dark:border-slate-800">
                  <Button
                    variant="ghost"
                    size="sm"
                    icon={<Pin className={`w-3.5 h-3.5 ${notif.isPinned ? 'text-blue-600 fill-blue-600' : 'text-slate-400'}`} />}
                    onClick={() => {
                      pinNotification(notif.id);
                      toast.info(notif.isPinned ? 'Unpinned notification' : 'Pinned notification to top');
                    }}
                    title="Pin / Unpin"
                  />

                  <Button
                    variant="ghost"
                    size="sm"
                    icon={<Archive className={`w-3.5 h-3.5 ${notif.isArchived ? 'text-amber-600' : 'text-slate-400'}`} />}
                    onClick={() => {
                      archiveNotification(notif.id);
                      toast.info(notif.isArchived ? 'Unarchived notification' : 'Archived notification');
                    }}
                    title="Archive"
                  />

                  {notif.status === 'Unread' && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => markAsRead(notif.id)}
                      className="text-xs text-blue-600 border-blue-200 dark:border-blue-800"
                    >
                      Mark Read
                    </Button>
                  )}

                  <Button
                    variant="ghost"
                    size="sm"
                    icon={<Trash2 className="w-3.5 h-3.5 text-rose-500" />}
                    onClick={() => {
                      deleteNotification(notif.id);
                      toast.success('Deleted notification');
                    }}
                    title="Delete"
                  />
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Detail Modal */}
      {selectedNotifModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl relative">
            <button
              onClick={() => setSelectedNotifModal(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2">
              <span className={`px-2.5 py-0.5 rounded text-[10px] font-bold ${getPriorityBadge(selectedNotifModal.priority)}`}>
                {selectedNotifModal.priority} PRIORITY
              </span>
              <span className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase">
                {selectedNotifModal.module} MODULE
              </span>
            </div>

            <div>
              <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100">{selectedNotifModal.title}</h3>
              <p className="text-xs text-slate-400 mt-0.5">MOUNTEC PTE LTD • {formatDateTime(selectedNotifModal.createdAt)}</p>
            </div>

            <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-xl text-xs text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 leading-relaxed">
              {selectedNotifModal.message}
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs text-slate-600 dark:text-slate-400 bg-slate-100/60 dark:bg-slate-900/60 p-3 rounded-lg border border-slate-200/80 dark:border-slate-800">
              <p><strong>Target Role:</strong> {selectedNotifModal.recipientRole || 'All'}</p>
              <p><strong>Status:</strong> {selectedNotifModal.status}</p>
              <p><strong>Item Code:</strong> {selectedNotifModal.itemCode || 'N/A'}</p>
              <p><strong>Worker:</strong> {selectedNotifModal.workerName || 'N/A'}</p>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  markAsRead(selectedNotifModal.id);
                  setSelectedNotifModal(null);
                  toast.success('Marked as read');
                }}
              >
                Mark Read & Close
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
