import React, { useState } from 'react';
import { useNotifications } from '../../hooks/useNotifications';
import { Card, CardContent } from '../../../../components/ui/Card';
import { Button } from '../../../../components/ui/Button';
import {
  History,
  Search,
  Filter,
  FileSpreadsheet,
  FileText,
  FileCode,
  Trash2,
  CheckCircle2,
  XCircle,
  Clock
} from 'lucide-react';
import { formatDateTime } from '../../../../lib/utils';
import { toast } from 'sonner';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';

export const NotificationHistory: React.FC = () => {
  const { history, clearHistory } = useNotifications();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedChannel, setSelectedChannel] = useState<string>('All');

  const filteredHistory = history.filter((item) => {
    if (selectedChannel !== 'All' && item.channel !== selectedChannel) return false;
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      const matchesTitle = item.title.toLowerCase().includes(q);
      const matchesRecipient = item.recipient.toLowerCase().includes(q);
      const matchesCreatedBy = item.createdBy.toLowerCase().includes(q);
      if (!matchesTitle && !matchesRecipient && !matchesCreatedBy) return false;
    }
    return true;
  });

  const exportExcel = () => {
    const data = filteredHistory.map((h) => ({
      'Company Name': 'MOUNTEC PTE LTD',
      'History ID': h.id,
      Title: h.title,
      Recipient: h.recipient,
      Channel: h.channel,
      'Delivery Status': h.deliveryStatus,
      'Created By': h.createdBy,
      'Created At': h.createdAt,
      'Delivered At': h.deliveredAt || '-'
    }));

    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Notification History');
    XLSX.writeFile(wb, `MOUNTEC_Notification_History_${new Date().toISOString().split('T')[0]}.xlsx`);
    toast.success('Exported Notification History to Excel');
  };

  const exportPDF = () => {
    const doc = new jsPDF();
    doc.setFontSize(14);
    doc.setTextColor(30, 58, 138);
    doc.text('MOUNTEC PTE LTD - Notification History Telemetry Report', 14, 15);

    const rows = filteredHistory.map((h) => [
      h.title,
      h.recipient,
      h.channel,
      h.deliveryStatus,
      h.createdBy,
      h.createdAt.split('T')[0]
    ]);

    autoTable(doc, {
      startY: 22,
      head: [['Title', 'Recipient', 'Channel', 'Status', 'Created By', 'Date']],
      body: rows,
      headStyles: { fillColor: [30, 58, 138] },
      styles: { fontSize: 8 }
    });

    doc.save(`MOUNTEC_Notification_History_${new Date().toISOString().split('T')[0]}.pdf`);
    toast.success('Exported Notification History to PDF');
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <History className="w-5 h-5 text-indigo-600" />
            Dispatch & Delivery History Logs
          </h2>
          <p className="text-xs text-slate-500">
            Immutable audit trail of all generated alerts, email queues, and push broadcasts for MOUNTEC PTE LTD.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            icon={<FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />}
            onClick={exportExcel}
            className="text-xs"
          >
            Excel
          </Button>

          <Button
            variant="outline"
            size="sm"
            icon={<FileText className="w-3.5 h-3.5 text-rose-600" />}
            onClick={exportPDF}
            className="text-xs"
          >
            PDF
          </Button>

          <Button
            variant="ghost"
            size="sm"
            icon={<Trash2 className="w-3.5 h-3.5 text-rose-500" />}
            onClick={() => {
              clearHistory();
              toast.success('Cleared notification audit logs');
            }}
            className="text-xs text-rose-600"
          >
            Clear Log
          </Button>
        </div>
      </div>

      {/* Filters Bar */}
      <Card border className="border-slate-200 dark:border-slate-800">
        <CardContent className="p-4 flex flex-col md:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search history by title, recipient, or dispatcher..."
              className="w-full pl-9 pr-4 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100"
            />
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <span className="text-xs font-semibold text-slate-500">Channel:</span>
            <select
              value={selectedChannel}
              onChange={(e) => setSelectedChannel(e.target.value)}
              className="p-2 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs font-medium"
            >
              <option value="All">All Channels</option>
              <option value="In-App">In-App</option>
              <option value="Email">Email</option>
              <option value="Push">Push</option>
            </select>
          </div>
        </CardContent>
      </Card>

      {/* History Log Table */}
      <Card border className="border-slate-200 dark:border-slate-800">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-semibold border-b border-slate-200 dark:border-slate-700">
                <tr>
                  <th className="p-3">Title / Subject</th>
                  <th className="p-3">Recipient</th>
                  <th className="p-3">Channel</th>
                  <th className="p-3">Delivery Status</th>
                  <th className="p-3">Dispatcher / Created By</th>
                  <th className="p-3">Timestamp</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredHistory.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50 dark:hover:bg-slate-900/50">
                    <td className="p-3 font-semibold text-slate-900 dark:text-slate-100">{item.title}</td>
                    <td className="p-3 text-slate-600 dark:text-slate-400 font-medium">{item.recipient}</td>
                    <td className="p-3">
                      <span className="px-2 py-0.5 rounded font-bold text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                        {item.channel}
                      </span>
                    </td>
                    <td className="p-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          item.deliveryStatus === 'Delivered' || item.deliveryStatus === 'Sent'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                        }`}
                      >
                        {item.deliveryStatus}
                      </span>
                    </td>
                    <td className="p-3 text-slate-500">{item.createdBy}</td>
                    <td className="p-3 text-slate-400">{formatDateTime(item.createdAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
