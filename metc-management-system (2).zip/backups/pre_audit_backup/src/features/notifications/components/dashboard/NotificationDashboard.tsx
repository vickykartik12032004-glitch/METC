import React from 'react';
import { useNotifications } from '../../hooks/useNotifications';
import { Card, CardContent } from '../../../../components/ui/Card';
import { Button } from '../../../../components/ui/Button';
import {
  Bell,
  AlertTriangle,
  Clock,
  PackageX,
  Wrench,
  ShieldCheck,
  Award,
  Mail,
  Send,
  RefreshCw,
  Zap,
  CheckCircle2,
  AlertCircle,
  ExternalLink
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { motion } from 'motion/react';
import { formatDateTime } from '../../../../lib/utils';

interface NotificationDashboardProps {
  onNavigateTab: (tab: string) => void;
}

export const NotificationDashboard: React.FC<NotificationDashboardProps> = ({ onNavigateTab }) => {
  const { kpis, notifications, triggerSystemScan, markAsRead } = useNotifications();

  // Priority chart data
  const priorityData = [
    { name: 'Critical', value: notifications.filter((n) => n.priority === 'Critical').length, color: '#f43f5e' },
    { name: 'High', value: notifications.filter((n) => n.priority === 'High').length, color: '#f97316' },
    { name: 'Medium', value: notifications.filter((n) => n.priority === 'Medium').length, color: '#eab308' },
    { name: 'Low', value: notifications.filter((n) => n.priority === 'Low').length, color: '#3b82f6' },
  ];

  // Module chart data
  const moduleCounts: Record<string, number> = {};
  notifications.forEach((n) => {
    moduleCounts[n.module] = (moduleCounts[n.module] || 0) + 1;
  });

  const moduleData = Object.keys(moduleCounts).map((mod) => ({
    module: mod,
    count: moduleCounts[mod],
  }));

  const kpiCards = [
    {
      title: 'Unread Notifications',
      value: kpis.unreadNotifications,
      subtext: 'Requires user review',
      icon: <Bell className="w-5 h-5 text-blue-500" />,
      bg: 'bg-blue-500/10 border-blue-500/20 text-blue-600 dark:text-blue-400',
      tab: 'center'
    },
    {
      title: "Today's Alerts",
      value: kpis.todaysAlerts,
      subtext: 'Active smart triggers',
      icon: <Zap className="w-5 h-5 text-amber-500" />,
      bg: 'bg-amber-500/10 border-amber-500/20 text-amber-600 dark:text-amber-400',
      tab: 'center'
    },
    {
      title: 'Overdue Items',
      value: kpis.overdueItems,
      subtext: 'Pass return date',
      icon: <Clock className="w-5 h-5 text-rose-500" />,
      bg: 'bg-rose-500/10 border-rose-500/20 text-rose-600 dark:text-rose-400',
      tab: 'alerts'
    },
    {
      title: 'Low Stock Alerts',
      value: kpis.lowStockAlerts,
      subtext: 'Below min threshold',
      icon: <PackageX className="w-5 h-5 text-orange-500" />,
      bg: 'bg-orange-500/10 border-orange-500/20 text-orange-600 dark:text-orange-400',
      tab: 'alerts'
    },
    {
      title: 'Repair Alerts',
      value: kpis.repairAlerts,
      subtext: 'In progress or delayed',
      icon: <Wrench className="w-5 h-5 text-indigo-500" />,
      bg: 'bg-indigo-500/10 border-indigo-500/20 text-indigo-600 dark:text-indigo-400',
      tab: 'alerts'
    },
    {
      title: 'Warranty Alerts',
      value: kpis.warrantyAlerts,
      subtext: 'Expiring or claims',
      icon: <ShieldCheck className="w-5 h-5 text-emerald-500" />,
      bg: 'bg-emerald-500/10 border-emerald-500/20 text-emerald-600 dark:text-emerald-400',
      tab: 'alerts'
    },
    {
      title: 'Calibration Alerts',
      value: kpis.calibrationAlerts,
      subtext: 'Due or expired audit',
      icon: <Award className="w-5 h-5 text-cyan-500" />,
      bg: 'bg-cyan-500/10 border-cyan-500/20 text-cyan-600 dark:text-cyan-400',
      tab: 'alerts'
    },
    {
      title: 'Email Queue',
      value: kpis.emailQueue,
      subtext: 'Outbound emails',
      icon: <Mail className="w-5 h-5 text-purple-500" />,
      bg: 'bg-purple-500/10 border-purple-500/20 text-purple-600 dark:text-purple-400',
      tab: 'templates'
    },
    {
      title: 'Push Queue',
      value: kpis.pushQueue,
      subtext: 'Browser push tasks',
      icon: <Send className="w-5 h-5 text-teal-500" />,
      bg: 'bg-teal-500/10 border-teal-500/20 text-teal-600 dark:text-teal-400',
      tab: 'push'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner & Quick Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 rounded-2xl text-white border border-slate-800 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/30 text-blue-300 border border-blue-400/30 uppercase tracking-widest">
              MOUNTEC PTE LTD
            </span>
            <span className="text-xs text-slate-400">Enterprise Operations</span>
          </div>
          <h2 className="text-xl font-extrabold tracking-tight mt-1">Notification & Alert Command Dashboard</h2>
          <p className="text-xs text-slate-300 mt-1 max-w-2xl">
            Real-time monitoring across in-app telemetry, low stock watchers, overdue equipment escalation, email dispatches, and browser push notifications.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <Button
            variant="primary"
            icon={<RefreshCw className="w-4 h-4" />}
            onClick={triggerSystemScan}
            className="bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs shadow-lg"
          >
            Run System Alert Scan
          </Button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-9 gap-3">
        {kpiCards.map((kpi, idx) => (
          <motion.div
            key={kpi.title}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.03 }}
          >
            <Card
              className={`hover:shadow-md transition-all cursor-pointer border ${kpi.bg}`}
              onClick={() => onNavigateTab(kpi.tab)}
            >
              <CardContent className="p-3.5 flex flex-col justify-between h-full">
                <div className="flex items-center justify-between">
                  <span className="p-2 rounded-xl bg-white/80 dark:bg-slate-900/80 shadow-xs border border-slate-200 dark:border-slate-800">
                    {kpi.icon}
                  </span>
                  <span className="text-xs font-bold text-slate-500 hover:text-slate-900 dark:hover:text-white">
                    <ExternalLink className="w-3.5 h-3.5" />
                  </span>
                </div>
                <div className="mt-3">
                  <p className="text-2xl font-black tracking-tight">{kpi.value}</p>
                  <p className="text-[11px] font-bold truncate mt-0.5">{kpi.title}</p>
                  <p className="text-[9px] opacity-75 truncate">{kpi.subtext}</p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Analytics Charts & Live Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Module Activity Bar Chart */}
        <Card className="lg:col-span-2 border border-slate-200 dark:border-slate-800">
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                  Alert Volume by Operational Module
                </h3>
                <p className="text-xs text-slate-500">Distribution of active alerts across MOUNTEC inventory & logistics</p>
              </div>
              <span className="text-xs font-medium text-slate-400 bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded-md">
                Live Data
              </span>
            </div>

            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={moduleData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <XAxis dataKey="module" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0f172a',
                      borderColor: '#334155',
                      borderRadius: '8px',
                      color: '#f8fafc',
                      fontSize: '12px'
                    }}
                  />
                  <Bar dataKey="count" fill="#3b82f6" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Priority Pie Chart */}
        <Card className="border border-slate-200 dark:border-slate-800">
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">Priority Breakdown</h3>
                <p className="text-xs text-slate-500">Severity categorization</p>
              </div>
            </div>

            <div className="h-48 w-full flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={priorityData}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={75}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {priorityData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>

            <div className="grid grid-cols-2 gap-2 mt-2 pt-3 border-t border-slate-200 dark:border-slate-800">
              {priorityData.map((p) => (
                <div key={p.name} className="flex items-center justify-between px-2 py-1 rounded bg-slate-50 dark:bg-slate-900/50">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: p.color }} />
                    <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">{p.name}</span>
                  </div>
                  <span className="text-xs font-bold text-slate-900 dark:text-slate-100">{p.value}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Live Recent Notifications Feed */}
      <Card className="border border-slate-200 dark:border-slate-800">
        <CardContent className="p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">Live In-App Alert Stream</h3>
              <p className="text-xs text-slate-500">Latest active alerts registered in MOUNTEC PTE LTD system</p>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onNavigateTab('center')}
              className="text-xs font-semibold text-blue-600 dark:text-blue-400"
            >
              View Full Notification Center →
            </Button>
          </div>

          <div className="space-y-3">
            {notifications.slice(0, 5).map((notif) => (
              <div
                key={notif.id}
                className={`p-3.5 rounded-xl border transition-all flex items-start gap-3.5 ${
                  notif.status === 'Unread'
                    ? 'bg-blue-50/50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-900/50'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 opacity-80'
                }`}
              >
                <div
                  className={`p-2 rounded-xl shrink-0 font-bold text-xs ${
                    notif.priority === 'Critical'
                      ? 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300'
                      : notif.priority === 'High'
                      ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                      : notif.priority === 'Medium'
                      ? 'bg-yellow-100 text-yellow-700 dark:bg-yellow-950 dark:text-yellow-300'
                      : 'bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300'
                  }`}
                >
                  {notif.priority}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">{notif.title}</p>
                    <span className="text-[10px] text-slate-400 shrink-0">{formatDateTime(notif.createdAt)}</span>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 line-clamp-2">{notif.message}</p>
                  <div className="flex items-center gap-3 mt-2 text-[10px] text-slate-500">
                    <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 font-medium">
                      Module: {notif.module}
                    </span>
                    {notif.recipientRole && (
                      <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 font-medium">
                        Role: {notif.recipientRole}
                      </span>
                    )}
                    {notif.site && <span>Site: {notif.site}</span>}
                  </div>
                </div>

                {notif.status === 'Unread' && (
                  <button
                    onClick={() => markAsRead(notif.id)}
                    className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline shrink-0"
                  >
                    Mark read
                  </button>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
