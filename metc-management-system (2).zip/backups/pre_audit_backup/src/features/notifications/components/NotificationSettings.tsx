import React from 'react';
import { useNotifications } from '../hooks/useNotifications';
import { Card, CardContent } from '../../../components/ui/Card';
import { Button } from '../../../components/ui/Button';
import {
  Settings,
  Bell,
  Mail,
  Send,
  Building,
  CheckCircle2,
  ShieldAlert,
  Save
} from 'lucide-react';
import { toast } from 'sonner';

export const NotificationSettings: React.FC = () => {
  const { settings, toggleModuleSetting, toggleChannelSetting, updateSettings } = useNotifications();

  return (
    <div className="space-y-6">
      {/* Title */}
      <div>
        <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
          <Settings className="w-5 h-5 text-slate-700 dark:text-slate-300" />
          Notification System Configurations & Module Triggers
        </h2>
        <p className="text-xs text-slate-500">
          Global dispatch rules, corporate identity preferences, and active delivery channels for MOUNTEC PTE LTD.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Module Enable / Disable Toggles */}
        <Card border className="border-slate-200 dark:border-slate-800">
          <CardContent className="p-5 space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-blue-600" />
              Operational Module Notification Triggers
            </h3>

            <div className="space-y-2">
              {Object.keys(settings.modules).map((moduleKey) => {
                const isEnabled = settings.modules[moduleKey as keyof typeof settings.modules];
                return (
                  <div
                    key={moduleKey}
                    className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800"
                  >
                    <div>
                      <p className="text-xs font-bold text-slate-900 dark:text-slate-100 capitalize">
                        {moduleKey} Notifications
                      </p>
                      <p className="text-[10px] text-slate-400">
                        Dispatch automatic alerts when {moduleKey} events occur.
                      </p>
                    </div>

                    <button
                      onClick={() => {
                        toggleModuleSetting(moduleKey as any);
                        toast.info(`Updated trigger setting for ${moduleKey}`);
                      }}
                      className={`px-3 py-1 text-xs font-bold rounded-lg transition-colors ${
                        isEnabled
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : 'bg-slate-200 text-slate-500 dark:bg-slate-800'
                      }`}
                    >
                      {isEnabled ? 'ENABLED' : 'DISABLED'}
                    </button>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Channel Toggles & Company Branding */}
        <div className="space-y-6">
          <Card border className="border-slate-200 dark:border-slate-800">
            <CardContent className="p-5 space-y-4">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <Bell className="w-4 h-4 text-purple-600" />
                Active Delivery Channels
              </h3>

              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  <div className="flex items-center gap-2.5">
                    <Bell className="w-4 h-4 text-blue-600" />
                    <div>
                      <p className="text-xs font-bold text-slate-900 dark:text-slate-100">In-App Notification Center</p>
                      <p className="text-[10px] text-slate-400">Real-time badges & sound alerts inside application</p>
                    </div>
                  </div>
                  <button
                    onClick={() => toggleChannelSetting('inApp')}
                    className={`px-3 py-1 text-xs font-bold rounded-lg ${
                      settings.channels.inApp ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-500'
                    }`}
                  >
                    {settings.channels.inApp ? 'ACTIVE' : 'OFF'}
                  </button>
                </div>

                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  <div className="flex items-center gap-2.5">
                    <Mail className="w-4 h-4 text-purple-600" />
                    <div>
                      <p className="text-xs font-bold text-slate-900 dark:text-slate-100">Email Notifications</p>
                      <p className="text-[10px] text-slate-400">SMTP / SendGrid dispatch to worker & supervisor emails</p>
                    </div>
                  </div>
                  <button
                    onClick={() => toggleChannelSetting('email')}
                    className={`px-3 py-1 text-xs font-bold rounded-lg ${
                      settings.channels.email ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-500'
                    }`}
                  >
                    {settings.channels.email ? 'ACTIVE' : 'OFF'}
                  </button>
                </div>

                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  <div className="flex items-center gap-2.5">
                    <Send className="w-4 h-4 text-teal-600" />
                    <div>
                      <p className="text-xs font-bold text-slate-900 dark:text-slate-100">Browser Push Notifications</p>
                      <p className="text-[10px] text-slate-400">Web Push API service worker alerts</p>
                    </div>
                  </div>
                  <button
                    onClick={() => toggleChannelSetting('push')}
                    className={`px-3 py-1 text-xs font-bold rounded-lg ${
                      settings.channels.push ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-500'
                    }`}
                  >
                    {settings.channels.push ? 'ACTIVE' : 'OFF'}
                  </button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Company Identity */}
          <Card border className="border-slate-200 dark:border-slate-800 bg-slate-900 text-white">
            <CardContent className="p-5 space-y-3">
              <div className="flex items-center gap-2">
                <Building className="w-5 h-5 text-blue-400" />
                <h3 className="text-sm font-bold">Corporate Sender Metadata</h3>
              </div>

              <div className="space-y-1 text-xs text-slate-300">
                <p><strong>Company Name:</strong> {settings.companyName}</p>
                <p><strong>Default Sender Address:</strong> {settings.senderEmail}</p>
                <p><strong>Standard Header Logo:</strong> Embedded in all 11 HTML Email templates</p>
              </div>

              <div className="pt-2">
                <Button
                  variant="primary"
                  size="sm"
                  onClick={() => toast.success('Configuration saved for MOUNTEC PTE LTD')}
                  className="bg-blue-600 text-white font-semibold text-xs"
                >
                  Save System Configurations
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};
