import React, { useState } from 'react';
import { useNotifications } from '../../hooks/useNotifications';
import { Card, CardContent } from '../../../../components/ui/Card';
import { Button } from '../../../../components/ui/Button';
import {
  Mail,
  Edit,
  Eye,
  Send,
  RotateCcw,
  Code,
  Check,
  Building2,
  X,
  FileCode
} from 'lucide-react';
import { toast } from 'sonner';
import { EmailTemplate } from '../../types';

export const EmailTemplates: React.FC = () => {
  const { emailTemplates, updateEmailTemplate, resetTemplatesToDefault, sendEmail } = useNotifications();

  const [selectedTemplate, setSelectedTemplate] = useState<EmailTemplate>(emailTemplates[0] || {} as EmailTemplate);
  const [activeViewMode, setActiveViewMode] = useState<'editor' | 'preview'>('preview');

  // Edit fields
  const [editSubject, setEditSubject] = useState(selectedTemplate.subject || '');
  const [editBodyHtml, setEditBodyHtml] = useState(selectedTemplate.bodyHtml || '');

  // Test Send State
  const [showTestModal, setShowTestModal] = useState(false);
  const [testEmail, setTestEmail] = useState('supervisor@mountec.sg');
  const [testName, setTestName] = useState('Marcus Vance');

  const handleSelectTemplate = (tmpl: EmailTemplate) => {
    setSelectedTemplate(tmpl);
    setEditSubject(tmpl.subject);
    setEditBodyHtml(tmpl.bodyHtml);
  };

  const handleSaveTemplate = () => {
    updateEmailTemplate(selectedTemplate.id, {
      subject: editSubject,
      bodyHtml: editBodyHtml
    });
    toast.success(`Saved template modifications for '${selectedTemplate.name}'`);
  };

  const handleSendTestEmail = () => {
    // Substitute variables for preview/test
    let formattedBody = editBodyHtml
      .replace(/{WORKER_NAME}/g, testName)
      .replace(/{ITEM_NAME}/g, 'Bosch GBH 18V Rotary Drill')
      .replace(/{QUANTITY}/g, '2 Units')
      .replace(/{ISSUE_CODE}/g, 'ISS-2025-099')
      .replace(/{RETURN_CODE}/g, 'RET-2025-088')
      .replace(/{TRANSFER_CODE}/g, 'TRF-2025-077')
      .replace(/{REPAIR_CODE}/g, 'REP-2025-066')
      .replace(/{INCIDENT_CODE}/g, 'LST-2025-055')
      .replace(/{DUE_DATE}/g, new Date(Date.now() + 604800000).toLocaleDateString())
      .replace(/{SITE}/g, 'Tower A Site')
      .replace(/{CONDITION}/g, 'Good Condition')
      .replace(/{RECEIVED_BY}/g, 'David Vance')
      .replace(/{FROM_LOCATION}/g, 'Warehouse Main Yard')
      .replace(/{TO_LOCATION}/g, 'Tower A Site Yard')
      .replace(/{STATUS}/g, 'Completed')
      .replace(/{VENDOR}/g, 'Liebherr Factory Service Dept.')
      .replace(/{ISSUE_DESC}/g, 'Motor vibration and gear overheating inspection')
      .replace(/{ESTIMATED_DATE}/g, '2026-08-15')
      .replace(/{COST}/g, '4,500.00')
      .replace(/{LOCATION}/g, 'Tower A West Wing')
      .replace(/{ESTIMATED_VALUE}/g, '280.00')
      .replace(/{CURRENT_QTY}/g, '5 Bags')
      .replace(/{MIN_THRESHOLD}/g, '50 Bags')
      .replace(/{SUGGESTED_REORDER}/g, '100 Bags')
      .replace(/{DAYS_OVERDUE}/g, '4')
      .replace(/{RESPONSIBLE_PERSON}/g, 'Alexander Wright')
      .replace(/{MAINT_TYPE}/g, 'Quarterly Calibration')
      .replace(/{EXPIRY_DATE}/g, '2026-09-30')
      .replace(/{SUPPLIER}/g, 'LafargeHolcim Structural Cement')
      .replace(/{FOOTER}/g, selectedTemplate.footerDetails);

    sendEmail({
      templateCode: selectedTemplate.code,
      recipientEmail: testEmail,
      recipientName: testName,
      subject: editSubject.replace(/{ITEM_NAME}/g, 'Bosch Rotary Drill').replace(/{ISSUE_CODE}/g, 'ISS-2025-099'),
      bodyHtml: formattedBody
    });

    setShowTestModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Mail className="w-5 h-5 text-purple-600" />
            Editable MOUNTEC Enterprise Email Templates
          </h2>
          <p className="text-xs text-slate-500">
            Customize official email communications complete with MOUNTEC PTE LTD header logo branding and corporate footer details.
          </p>
        </div>

        <Button
          variant="outline"
          size="sm"
          icon={<RotateCcw className="w-4 h-4 text-slate-500" />}
          onClick={() => {
            resetTemplatesToDefault();
            toast.success('Reset all email templates to MOUNTEC defaults');
          }}
          className="text-xs font-semibold"
        >
          Reset All to Defaults
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Template Selection List */}
        <Card border className="border-slate-200 dark:border-slate-800">
          <CardContent className="p-4 space-y-2">
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-400 mb-2">
              Support Email Templates ({emailTemplates.length})
            </h3>

            <div className="space-y-1 max-h-[600px] overflow-y-auto pr-1">
              {emailTemplates.map((tmpl) => (
                <button
                  key={tmpl.id}
                  onClick={() => handleSelectTemplate(tmpl)}
                  className={`w-full text-left p-3 rounded-xl transition-all border ${
                    selectedTemplate.id === tmpl.id
                      ? 'bg-purple-600 text-white font-bold border-purple-600 shadow-md'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold truncate">{tmpl.name}</span>
                    <span
                      className={`text-[9px] px-2 py-0.5 rounded font-mono ${
                        selectedTemplate.id === tmpl.id ? 'bg-purple-700 text-purple-100' : 'bg-slate-100 text-slate-500 dark:bg-slate-800'
                      }`}
                    >
                      {tmpl.module}
                    </span>
                  </div>
                  <p className={`text-[10px] mt-1 truncate ${selectedTemplate.id === tmpl.id ? 'text-purple-200' : 'text-slate-400'}`}>
                    {tmpl.subject}
                  </p>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Right Editor & Live Preview Canvas */}
        <Card border className="lg:col-span-2 border-slate-200 dark:border-slate-800">
          <CardContent className="p-5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200 dark:border-slate-800">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">{selectedTemplate.name}</h3>
                <span className="text-[10px] font-mono text-slate-400">Template Code: {selectedTemplate.code}</span>
              </div>

              <div className="flex items-center gap-2">
                <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-lg">
                  <button
                    onClick={() => setActiveViewMode('preview')}
                    className={`px-3 py-1 text-xs font-semibold rounded-md flex items-center gap-1 ${
                      activeViewMode === 'preview' ? 'bg-white dark:bg-slate-900 text-purple-600 shadow-xs' : 'text-slate-500'
                    }`}
                  >
                    <Eye className="w-3.5 h-3.5" /> Live Preview
                  </button>
                  <button
                    onClick={() => setActiveViewMode('editor')}
                    className={`px-3 py-1 text-xs font-semibold rounded-md flex items-center gap-1 ${
                      activeViewMode === 'editor' ? 'bg-white dark:bg-slate-900 text-purple-600 shadow-xs' : 'text-slate-500'
                    }`}
                  >
                    <Code className="w-3.5 h-3.5" /> HTML Editor
                  </button>
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  icon={<Send className="w-3.5 h-3.5 text-purple-600" />}
                  onClick={() => setShowTestModal(true)}
                  className="text-xs"
                >
                  Send Test
                </Button>

                <Button
                  variant="primary"
                  size="sm"
                  icon={<Check className="w-3.5 h-3.5" />}
                  onClick={handleSaveTemplate}
                  className="bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs"
                >
                  Save Changes
                </Button>
              </div>
            </div>

            {/* Subject Field */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Subject Line</label>
              <input
                type="text"
                value={editSubject}
                onChange={(e) => setEditSubject(e.target.value)}
                className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs font-bold text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            {/* Dynamic Merge Variables Chips */}
            <div>
              <span className="text-[11px] font-semibold text-slate-500">Available Merge Tags: </span>
              <div className="flex flex-wrap gap-1 mt-1">
                {selectedTemplate.variables?.map((v) => (
                  <button
                    key={v}
                    onClick={() => setEditBodyHtml((prev) => prev + ` ${v} `)}
                    className="px-2 py-0.5 rounded bg-purple-50 text-purple-700 dark:bg-purple-950 dark:text-purple-300 font-mono text-[10px] border border-purple-200 dark:border-purple-800 hover:bg-purple-100"
                    title="Click to insert tag"
                  >
                    {v}
                  </button>
                ))}
              </div>
            </div>

            {/* Editor or Preview Area */}
            {activeViewMode === 'editor' ? (
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Body HTML Template</label>
                <textarea
                  rows={16}
                  value={editBodyHtml}
                  onChange={(e) => setEditBodyHtml(e.target.value)}
                  className="w-full p-3 rounded-xl bg-slate-900 text-slate-100 font-mono text-xs border border-slate-800 focus:outline-none focus:ring-2 focus:ring-purple-500 leading-relaxed"
                />
              </div>
            ) : (
              <div className="p-4 bg-slate-100 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 min-h-[400px]">
                <div
                  className="bg-white rounded-lg p-6 shadow-sm max-w-xl mx-auto text-slate-800"
                  dangerouslySetInnerHTML={{
                    __html: editBodyHtml
                      .replace(/{WORKER_NAME}/g, 'Marcus Vance')
                      .replace(/{ITEM_NAME}/g, 'Portland Cement Grade 53')
                      .replace(/{QUANTITY}/g, '250 Bags')
                      .replace(/{ISSUE_CODE}/g, 'ISS-2025-001')
                      .replace(/{RETURN_CODE}/g, 'RET-2025-001')
                      .replace(/{TRANSFER_CODE}/g, 'TRF-2025-001')
                      .replace(/{REPAIR_CODE}/g, 'REP-2025-001')
                      .replace(/{INCIDENT_CODE}/g, 'LST-2025-001')
                      .replace(/{DUE_DATE}/g, '2026-08-15')
                      .replace(/{SITE}/g, 'Tower A Site')
                      .replace(/{CONDITION}/g, 'Good')
                      .replace(/{RECEIVED_BY}/g, 'David Vance')
                      .replace(/{FROM_LOCATION}/g, 'Warehouse Main Yard')
                      .replace(/{TO_LOCATION}/g, 'Tower A Site Yard')
                      .replace(/{STATUS}/g, 'Completed')
                      .replace(/{VENDOR}/g, 'Liebherr Factory Service Dept.')
                      .replace(/{ISSUE_DESC}/g, 'Slewing gear mechanism vibration check')
                      .replace(/{ESTIMATED_DATE}/g, '2026-08-20')
                      .replace(/{COST}/g, '4,500.00')
                      .replace(/{LOCATION}/g, 'Tower A West Wing')
                      .replace(/{ESTIMATED_VALUE}/g, '220.00')
                      .replace(/{CURRENT_QTY}/g, '5')
                      .replace(/{MIN_THRESHOLD}/g, '50')
                      .replace(/{SUGGESTED_REORDER}/g, '100')
                      .replace(/{DAYS_OVERDUE}/g, '4')
                      .replace(/{RESPONSIBLE_PERSON}/g, 'Alexander Wright')
                      .replace(/{MAINT_TYPE}/g, 'Preventive Service')
                      .replace(/{EXPIRY_DATE}/g, '2026-10-15')
                      .replace(/{SUPPLIER}/g, 'Caterpillar Inc.')
                      .replace(/{FOOTER}/g, selectedTemplate.footerDetails)
                  }}
                />
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* TEST SEND MODAL */}
      {showTestModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl relative">
            <button onClick={() => setShowTestModal(false)} className="absolute top-4 right-4 text-slate-400">
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100">Send Test Email Simulation</h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Recipient Name</label>
                <input
                  type="text"
                  value={testName}
                  onChange={(e) => setTestName(e.target.value)}
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Recipient Email</label>
                <input
                  type="email"
                  value={testEmail}
                  onChange={(e) => setTestEmail(e.target.value)}
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" size="sm" onClick={() => setShowTestModal(false)}>
                Cancel
              </Button>
              <Button variant="primary" size="sm" onClick={handleSendTestEmail} className="bg-purple-600 text-white">
                Dispatch Test
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
