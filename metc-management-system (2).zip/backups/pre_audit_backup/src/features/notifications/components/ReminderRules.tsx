import React, { useState } from 'react';
import { useNotifications } from '../hooks/useNotifications';
import { Card, CardContent } from '../../../components/ui/Card';
import { Button } from '../../../components/ui/Button';
import {
  Clock,
  Plus,
  Trash2,
  Calendar,
  AlertCircle,
  ShieldAlert,
  Zap,
  CheckCircle,
  X,
  Layers
} from 'lucide-react';
import { toast } from 'sonner';
import { ReminderRule, EscalationRule, NotificationModule } from '../types';

export const ReminderRules: React.FC = () => {
  const {
    reminderRules,
    escalationRules,
    addReminderRule,
    toggleReminderRule,
    deleteReminderRule,
    addEscalationRule,
    toggleEscalationRule,
    deleteEscalationRule
  } = useNotifications();

  // Modal states
  const [showAddReminderModal, setShowAddReminderModal] = useState(false);
  const [showAddEscalationModal, setShowAddEscalationModal] = useState(false);

  // New Reminder Form State
  const [newReminderName, setNewReminderName] = useState('');
  const [newReminderModule, setNewReminderModule] = useState<NotificationModule>('Issue');
  const [newReminderFrequency, setNewReminderFrequency] = useState<'Daily' | 'Weekly' | 'Monthly' | 'Custom'>('Daily');
  const [newReminderTime, setNewReminderTime] = useState('08:00');
  const [newReminderRole, setNewReminderRole] = useState<'Store Keeper' | 'Supervisor' | 'Admin' | 'Worker' | 'All'>('Supervisor');

  // New Escalation Form State
  const [newEscalationName, setNewEscalationName] = useState('');
  const [newEscalationDays, setNewEscalationDays] = useState(3);
  const [newEscalationRole, setNewEscalationRole] = useState<'Supervisor' | 'Admin' | 'Super Admin'>('Supervisor');
  const [newEscalationPriority, setNewEscalationPriority] = useState<'Medium' | 'High' | 'Critical'>('Medium');

  // Handle Add Reminder
  const handleSaveReminder = () => {
    if (!newReminderName.trim()) {
      toast.error('Please enter a reminder rule name');
      return;
    }

    const rule: ReminderRule = {
      id: `rule-${Date.now()}`,
      name: newReminderName,
      module: newReminderModule,
      frequency: newReminderFrequency,
      timeOfDay: newReminderTime,
      active: true,
      targetRole: newReminderRole,
      lastRun: new Date().toISOString(),
      nextRun: new Date(Date.now() + 86400000).toISOString()
    };

    addReminderRule(rule);
    setShowAddReminderModal(false);
    setNewReminderName('');
    toast.success(`Created reminder rule '${rule.name}'`);
  };

  // Handle Add Escalation
  const handleSaveEscalation = () => {
    if (!newEscalationName.trim()) {
      toast.error('Please enter an escalation rule name');
      return;
    }

    const rule: EscalationRule = {
      id: `esc-${Date.now()}`,
      name: newEscalationName,
      module: 'Issue',
      conditionDays: newEscalationDays,
      actionNotifyRole: newEscalationRole,
      triggerPriority: newEscalationPriority,
      description: `Overdue > ${newEscalationDays} days automatically dispatches a ${newEscalationPriority} alert to ${newEscalationRole}.`,
      active: true
    };

    addEscalationRule(rule);
    setShowAddEscalationModal(false);
    setNewEscalationName('');
    toast.success(`Created escalation rule '${rule.name}'`);
  };

  return (
    <div className="space-y-8">
      {/* SECTION 1: REMINDER ENGINE */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <Clock className="w-5 h-5 text-blue-600" />
              Automated Reminder Schedule Engine
            </h2>
            <p className="text-xs text-slate-500">
              Configure automated cron dispatches for daily overdue audits, weekly stock checks, and monthly maintenance reminders.
            </p>
          </div>

          <Button
            variant="primary"
            size="sm"
            icon={<Plus className="w-4 h-4" />}
            onClick={() => setShowAddReminderModal(true)}
            className="bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs"
          >
            Create Reminder Rule
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {reminderRules.map((rule) => (
            <Card key={rule.id} border className={`border ${rule.active ? 'border-blue-200 dark:border-blue-900' : 'border-slate-200 opacity-60'}`}>
              <CardContent className="p-4 flex items-start justify-between gap-3">
                <div className="space-y-2 flex-1">
                  <div className="flex items-center gap-2">
                    <span className={`w-2.5 h-2.5 rounded-full ${rule.active ? 'bg-emerald-500 animate-pulse' : 'bg-slate-300'}`} />
                    <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">{rule.name}</h4>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 text-xs">
                    <span className="px-2 py-0.5 rounded bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 font-bold">
                      {rule.frequency} @ {rule.timeOfDay}
                    </span>
                    <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 font-medium">
                      Module: {rule.module}
                    </span>
                    <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 font-medium">
                      Role: {rule.targetRole}
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-400">
                    Next Trigger: {rule.nextRun ? new Date(rule.nextRun).toLocaleString() : 'Scheduled'}
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => toggleReminderRule(rule.id)}
                    className={`px-2.5 py-1 text-xs font-bold rounded-lg transition-colors ${
                      rule.active
                        ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                        : 'bg-slate-100 text-slate-500 dark:bg-slate-800'
                    }`}
                  >
                    {rule.active ? 'ACTIVE' : 'DISABLED'}
                  </button>

                  <button
                    onClick={() => {
                      deleteReminderRule(rule.id);
                      toast.success('Deleted reminder rule');
                    }}
                    className="p-1 text-slate-400 hover:text-rose-600"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* SECTION 2: ESCALATION RULES */}
      <div className="space-y-4 pt-6 border-t border-slate-200 dark:border-slate-800">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-rose-600" />
              Multi-Tier Escalation Matrix Rules
            </h2>
            <p className="text-xs text-slate-500">
              Automatic escalation ladder for unreturned assets and unresolved maintenance delays.
            </p>
          </div>

          <Button
            variant="outline"
            size="sm"
            icon={<Plus className="w-4 h-4 text-rose-600" />}
            onClick={() => setShowAddEscalationModal(true)}
            className="text-rose-600 border-rose-200 hover:bg-rose-50 dark:border-rose-900 font-semibold text-xs"
          >
            Add Escalation Rule
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {escalationRules.map((esc) => (
            <Card key={esc.id} border className="border-rose-200 dark:border-rose-950 bg-rose-50/20 dark:bg-rose-950/10">
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="p-1.5 rounded-lg bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 font-extrabold text-[10px] uppercase">
                    Condition: Overdue &gt; {esc.conditionDays} Days
                  </span>
                  <button
                    onClick={() => deleteEscalationRule(esc.id)}
                    className="text-slate-400 hover:text-rose-600"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">{esc.name}</h4>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">{esc.description}</p>

                <div className="flex items-center justify-between pt-2 border-t border-rose-100 dark:border-rose-900/50 text-xs">
                  <span className="font-bold text-rose-700 dark:text-rose-400">
                    Notify: {esc.actionNotifyRole}
                  </span>
                  <span className="px-2 py-0.5 rounded font-bold text-[10px] bg-rose-200 text-rose-900 dark:bg-rose-900 dark:text-rose-100">
                    {esc.triggerPriority} Alert
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* CREATE REMINDER MODAL */}
      {showAddReminderModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl relative">
            <button onClick={() => setShowAddReminderModal(false)} className="absolute top-4 right-4 text-slate-400">
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100">Create New Reminder Rule</h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Rule Name</label>
                <input
                  type="text"
                  value={newReminderName}
                  onChange={(e) => setNewReminderName(e.target.value)}
                  placeholder="e.g. Daily Morning Overdue Asset Dispatch"
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Frequency</label>
                  <select
                    value={newReminderFrequency}
                    onChange={(e: any) => setNewReminderFrequency(e.target.value)}
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
                  >
                    <option value="Daily">Daily</option>
                    <option value="Weekly">Weekly</option>
                    <option value="Monthly">Monthly</option>
                    <option value="Custom">Custom Interval</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Time of Day</label>
                  <input
                    type="time"
                    value={newReminderTime}
                    onChange={(e) => setNewReminderTime(e.target.value)}
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Module</label>
                  <select
                    value={newReminderModule}
                    onChange={(e: any) => setNewReminderModule(e.target.value)}
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
                  >
                    <option value="Issue">Issue</option>
                    <option value="Stock">Stock</option>
                    <option value="Maintenance">Maintenance</option>
                    <option value="Calibration">Calibration</option>
                    <option value="Warranty">Warranty</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Target Role</label>
                  <select
                    value={newReminderRole}
                    onChange={(e: any) => setNewReminderRole(e.target.value)}
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
                  >
                    <option value="Store Keeper">Store Keeper</option>
                    <option value="Supervisor">Supervisor</option>
                    <option value="Admin">Admin</option>
                    <option value="Worker">Worker</option>
                    <option value="All">All Roles</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" size="sm" onClick={() => setShowAddReminderModal(false)}>
                Cancel
              </Button>
              <Button variant="primary" size="sm" onClick={handleSaveReminder} className="bg-blue-600 text-white">
                Save Rule
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* CREATE ESCALATION MODAL */}
      {showAddEscalationModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl relative">
            <button onClick={() => setShowAddEscalationModal(false)} className="absolute top-4 right-4 text-slate-400">
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100">Create Escalation Rule</h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Escalation Name</label>
                <input
                  type="text"
                  value={newEscalationName}
                  onChange={(e) => setNewEscalationName(e.target.value)}
                  placeholder="e.g. Overdue > 10 Days Critical Notice"
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Condition (Days Overdue &gt;)</label>
                <input
                  type="number"
                  value={newEscalationDays}
                  onChange={(e) => setNewEscalationDays(Number(e.target.value))}
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Notify Role</label>
                  <select
                    value={newEscalationRole}
                    onChange={(e: any) => setNewEscalationRole(e.target.value)}
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
                  >
                    <option value="Supervisor">Supervisor</option>
                    <option value="Admin">Admin</option>
                    <option value="Super Admin">Super Admin</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Alert Priority</label>
                  <select
                    value={newEscalationPriority}
                    onChange={(e: any) => setNewEscalationPriority(e.target.value)}
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
                  >
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                    <option value="Critical">Critical</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" size="sm" onClick={() => setShowAddEscalationModal(false)}>
                Cancel
              </Button>
              <Button variant="primary" size="sm" onClick={handleSaveEscalation} className="bg-rose-600 text-white">
                Save Escalation Rule
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
