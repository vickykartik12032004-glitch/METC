import React, { useState } from 'react';
import { useNotifications } from '../hooks/useNotifications';
import { Card, CardContent } from '../../../components/ui/Card';
import { Button } from '../../../components/ui/Button';
import {
  AlertTriangle,
  PackageX,
  Clock,
  Wrench,
  ShieldCheck,
  Award,
  Send,
  ShoppingCart,
  PhoneCall,
  RotateCcw,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { toast } from 'sonner';

export const SmartAlerts: React.FC = () => {
  const {
    lowStockAlerts,
    overdueAlerts,
    repairAlerts,
    maintenanceAlerts,
    calibrationAlerts,
    warrantyAlerts,
    sendEmail,
    sendPush
  } = useNotifications();

  const [activeSubTab, setActiveSubTab] = useState<
    'lowstock' | 'overdue' | 'repair' | 'maintenance' | 'calibration' | 'warranty'
  >('lowstock');

  // Trigger reorder notification
  const handleReorderTrigger = (item: any) => {
    sendEmail({
      templateCode: 'LOW_STOCK_ALERT',
      recipientEmail: 'procurement@mountec.sg',
      recipientName: 'Procurement Manager',
      subject: `MOUNTEC PTE LTD: Low Stock Reorder Requisition for ${item.itemName}`,
      bodyHtml: `<p>Auto-generated reorder requisition for ${item.itemName}. Current stock: ${item.currentStock}, Min threshold: ${item.minimumStock}. Reorder Qty: ${item.suggestedReorderQuantity}</p>`
    });

    sendPush({
      title: `Low Stock Reorder Triggered: ${item.itemName}`,
      message: `Reorder request of ${item.suggestedReorderQuantity} ${item.unit} sent to Procurement.`,
      targetRoles: ['Store Keeper', 'Admin']
    });

    toast.success(`Triggered reorder requisition for ${item.itemName}`);
  };

  // Trigger overdue reminder
  const handleOverdueReminderTrigger = (item: any) => {
    sendEmail({
      templateCode: 'OVERDUE_REMINDER',
      recipientEmail: 'worker@mountec.sg',
      recipientName: item.workerName,
      subject: `MOUNTEC PTE LTD: URGENT OVERDUE ITEM DEMAND - ${item.itemName}`,
      bodyHtml: `<p>Dear ${item.workerName}, your issued item ${item.itemName} at ${item.site} is overdue by ${item.daysOverdue} days. Please return immediately.</p>`
    });

    sendPush({
      title: `Overdue Item Demand: ${item.workerName}`,
      message: `Direct notice sent for ${item.itemName} (${item.daysOverdue} days overdue).`,
      targetRoles: ['Supervisor', 'Worker']
    });

    toast.success(`Overdue reminder dispatched to ${item.workerName}`);
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div>
        <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-amber-500" />
          Smart Telemetry & Operational Alerts
        </h2>
        <p className="text-xs text-slate-500">
          Automated rule monitors for stock depletion, overdue equipment returns, repair delays, and calibration compliance.
        </p>
      </div>

      {/* Sub Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-slate-200 dark:border-slate-800">
        <button
          onClick={() => setActiveSubTab('lowstock')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
            activeSubTab === 'lowstock'
              ? 'bg-orange-600 text-white shadow-md'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
          }`}
        >
          <PackageX className="w-4 h-4" /> Low Stock Alerts ({lowStockAlerts.length})
        </button>

        <button
          onClick={() => setActiveSubTab('overdue')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
            activeSubTab === 'overdue'
              ? 'bg-rose-600 text-white shadow-md'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
          }`}
        >
          <Clock className="w-4 h-4" /> Overdue Alerts ({overdueAlerts.length})
        </button>

        <button
          onClick={() => setActiveSubTab('repair')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
            activeSubTab === 'repair'
              ? 'bg-indigo-600 text-white shadow-md'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
          }`}
        >
          <Wrench className="w-4 h-4" /> Repair Alerts ({repairAlerts.length})
        </button>

        <button
          onClick={() => setActiveSubTab('maintenance')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
            activeSubTab === 'maintenance'
              ? 'bg-sky-600 text-white shadow-md'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
          }`}
        >
          <AlertCircle className="w-4 h-4" /> Maintenance Alerts ({maintenanceAlerts.length})
        </button>

        <button
          onClick={() => setActiveSubTab('calibration')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
            activeSubTab === 'calibration'
              ? 'bg-teal-600 text-white shadow-md'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
          }`}
        >
          <Award className="w-4 h-4" /> Calibration Alerts ({calibrationAlerts.length})
        </button>

        <button
          onClick={() => setActiveSubTab('warranty')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
            activeSubTab === 'warranty'
              ? 'bg-emerald-600 text-white shadow-md'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
          }`}
        >
          <ShieldCheck className="w-4 h-4" /> Warranty Alerts ({warrantyAlerts.length})
        </button>
      </div>

      {/* Tab Content 1: Low Stock */}
      {activeSubTab === 'lowstock' && (
        <Card border className="border-slate-200 dark:border-slate-800">
          <CardContent className="p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">Low Stock Smart Monitors</h3>
                <p className="text-xs text-slate-500">Triggered automatically when Current Stock ≤ Minimum Safety Stock</p>
              </div>
              <span className="text-xs font-bold px-2.5 py-1 rounded bg-orange-100 text-orange-700 dark:bg-orange-950 dark:text-orange-300">
                {lowStockAlerts.length} Depleted Items
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-semibold border-b border-slate-200 dark:border-slate-700">
                  <tr>
                    <th className="p-3">Item Name / Code</th>
                    <th className="p-3">Current Stock</th>
                    <th className="p-3">Min Safety Threshold</th>
                    <th className="p-3">Suggested Reorder Qty</th>
                    <th className="p-3">Priority</th>
                    <th className="p-3">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {lowStockAlerts.map((item) => (
                    <tr key={item.id} className="hover:bg-slate-50 dark:hover:bg-slate-900/50">
                      <td className="p-3 font-semibold text-slate-900 dark:text-slate-100">
                        {item.itemName}
                        <span className="block text-[10px] text-slate-400 font-mono">{item.itemCode} • {item.location}</span>
                      </td>
                      <td className="p-3 text-rose-600 dark:text-rose-400 font-bold">
                        {item.currentStock} {item.unit}
                      </td>
                      <td className="p-3 text-slate-600 dark:text-slate-400">
                        {item.minimumStock} {item.unit}
                      </td>
                      <td className="p-3 text-emerald-600 dark:text-emerald-400 font-bold">
                        +{item.suggestedReorderQuantity} {item.unit}
                      </td>
                      <td className="p-3">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            item.priority === 'Critical'
                              ? 'bg-rose-100 text-rose-700'
                              : 'bg-amber-100 text-amber-700'
                          }`}
                        >
                          {item.priority}
                        </span>
                      </td>
                      <td className="p-3">
                        <Button
                          variant="outline"
                          size="sm"
                          icon={<ShoppingCart className="w-3.5 h-3.5 text-blue-600" />}
                          onClick={() => handleReorderTrigger(item)}
                          className="text-xs text-blue-600 border-blue-200 hover:bg-blue-50"
                        >
                          Reorder Requisition
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Tab Content 2: Overdue */}
      {activeSubTab === 'overdue' && (
        <Card border className="border-slate-200 dark:border-slate-800">
          <CardContent className="p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">Overdue Equipment Return Monitor</h3>
                <p className="text-xs text-slate-500">Triggered automatically when Expected Return Date has passed</p>
              </div>
              <span className="text-xs font-bold px-2.5 py-1 rounded bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300">
                {overdueAlerts.length} Overdue Items
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-semibold border-b border-slate-200 dark:border-slate-700">
                  <tr>
                    <th className="p-3">Worker / Trade</th>
                    <th className="p-3">Item / Voucher</th>
                    <th className="p-3">Days Overdue</th>
                    <th className="p-3">Site / Department</th>
                    <th className="p-3">Priority</th>
                    <th className="p-3">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {overdueAlerts.map((item) => (
                    <tr key={item.id} className="hover:bg-slate-50 dark:hover:bg-slate-900/50">
                      <td className="p-3 font-semibold text-slate-900 dark:text-slate-100">
                        {item.workerName}
                        <span className="block text-[10px] text-slate-400">{item.department}</span>
                      </td>
                      <td className="p-3 text-slate-800 dark:text-slate-200 font-medium">
                        {item.itemName}
                        <span className="block text-[10px] text-slate-400 font-mono">{item.issueCode}</span>
                      </td>
                      <td className="p-3 text-rose-600 dark:text-rose-400 font-extrabold text-sm">
                        {item.daysOverdue} Days
                        <span className="block text-[10px] font-normal text-slate-400">Due: {item.expectedReturnDate}</span>
                      </td>
                      <td className="p-3 text-slate-600 dark:text-slate-400">
                        {item.site}
                      </td>
                      <td className="p-3">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            item.priority === 'Critical'
                              ? 'bg-rose-100 text-rose-700'
                              : 'bg-amber-100 text-amber-700'
                          }`}
                        >
                          {item.priority}
                        </span>
                      </td>
                      <td className="p-3">
                        <Button
                          variant="outline"
                          size="sm"
                          icon={<Send className="w-3.5 h-3.5 text-rose-600" />}
                          onClick={() => handleOverdueReminderTrigger(item)}
                          className="text-xs text-rose-600 border-rose-200 hover:bg-rose-50"
                        >
                          Send Escalated Notice
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Tab Content 3: Repair */}
      {activeSubTab === 'repair' && (
        <Card border className="border-slate-200 dark:border-slate-800">
          <CardContent className="p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">Repair Status Alerts</h3>
                <p className="text-xs text-slate-500">Notifies on Repair Assigned, In Progress, Completed, or Delayed</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {repairAlerts.map((rep) => (
                <div key={rep.id} className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300">
                        {rep.status}
                      </span>
                      <span className="text-xs font-mono text-slate-400">{rep.repairCode}</span>
                    </div>
                    <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100 mt-1">{rep.itemName}</h4>
                    <p className="text-xs text-slate-500 mt-1">Vendor: {rep.vendor || 'In-House Workshop'} • Handled by: {rep.assignedTo}</p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => toast.success(`Repair status notification updated for ${rep.repairCode}`)}
                    className="self-center text-xs"
                  >
                    View Ticket
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Tab Content 4: Maintenance */}
      {activeSubTab === 'maintenance' && (
        <Card border className="border-slate-200 dark:border-slate-800">
          <CardContent className="p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">Preventive Maintenance Schedule</h3>
                <p className="text-xs text-slate-500">Notifies on Maintenance Due, Overdue, and Preventive Schedule</p>
              </div>
            </div>

            <div className="space-y-3">
              {maintenanceAlerts.map((m) => (
                <div key={m.id} className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-blue-600">{m.maintenanceType}</span>
                      <span className="text-xs text-slate-400">Due: {m.dueDate}</span>
                    </div>
                    <p className="text-sm font-bold text-slate-900 dark:text-slate-100 mt-0.5">{m.itemName}</p>
                    <p className="text-xs text-slate-500">Responsible Engineer: {m.responsiblePerson}</p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => toast.success(`Scheduled maintenance check for ${m.itemName}`)}
                    className="text-xs"
                  >
                    Log Service
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Tab Content 5: Calibration */}
      {activeSubTab === 'calibration' && (
        <Card border className="border-slate-200 dark:border-slate-800">
          <CardContent className="p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">Instrument & Safety Calibration Alerts</h3>
                <p className="text-xs text-slate-500">Notifies on Calibration Due, Expired, and Completed</p>
              </div>
            </div>

            <div className="space-y-3">
              {calibrationAlerts.map((cal) => (
                <div key={cal.id} className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${cal.status === 'Calibration Expired' ? 'bg-rose-100 text-rose-700' : 'bg-amber-100 text-amber-700'}`}>
                        {cal.status}
                      </span>
                      <span className="text-xs font-mono text-slate-400">{cal.calibrationCode}</span>
                    </div>
                    <p className="text-sm font-bold text-slate-900 dark:text-slate-100 mt-0.5">{cal.itemName}</p>
                    <p className="text-xs text-slate-500">Due Date: {cal.dueDate} • Vendor: {cal.vendor || 'MOUNTTEC Quality Lab'}</p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => toast.success(`Triggered calibration order for ${cal.itemName}`)}
                    className="text-xs text-teal-600 border-teal-200 hover:bg-teal-50"
                  >
                    Schedule Audit
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Tab Content 6: Warranty */}
      {activeSubTab === 'warranty' && (
        <Card border className="border-slate-200 dark:border-slate-800">
          <CardContent className="p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">Equipment Warranty Alerts</h3>
                <p className="text-xs text-slate-500">Notifies on Warranty Expiring, Expired, and Claim Available</p>
              </div>
            </div>

            <div className="space-y-3">
              {warrantyAlerts.map((w) => (
                <div key={w.id} className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300">
                        {w.status}
                      </span>
                      <span className="text-xs font-mono text-slate-400">SN: {w.assetId}</span>
                    </div>
                    <p className="text-sm font-bold text-slate-900 dark:text-slate-100 mt-0.5">{w.itemName}</p>
                    <p className="text-xs text-slate-500">Supplier: {w.supplier} • Expiry: {w.expiryDate}</p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => toast.success(`Filed warranty claim notice for ${w.itemName}`)}
                    className="text-xs text-emerald-600 border-emerald-200 hover:bg-emerald-50"
                  >
                    Claim Support
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
