import React, { useState, useEffect } from 'react';
import { useNotifications } from '../hooks/useNotifications';
import { Card, CardContent } from '../../../components/ui/Card';
import { Button } from '../../../components/ui/Button';
import {
  Send,
  Bell,
  Users,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Shield,
  Clock,
  Trash2
} from 'lucide-react';
import { toast } from 'sonner';
import { formatDateTime } from '../../../lib/utils';

export const PushNotifications: React.FC = () => {
  const { pushQueue, sendPush, clearQueues } = useNotifications();

  // Browser Permission State
  const [permission, setPermission] = useState<NotificationPermission>(
    'Notification' in window ? Notification.permission : 'default'
  );

  // Form State
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [selectedRoles, setSelectedRoles] = useState<('Store Keeper' | 'Supervisor' | 'Admin' | 'Worker')[]>([
    'Store Keeper',
    'Supervisor',
    'Admin'
  ]);

  useEffect(() => {
    if ('Notification' in window) {
      setPermission(Notification.permission);
    }
  }, []);

  const requestPermission = async () => {
    if (!('Notification' in window)) {
      toast.error('Browser push notifications are not supported in this environment.');
      return;
    }

    try {
      const res = await Notification.requestPermission();
      setPermission(res);
      if (res === 'granted') {
        toast.success('Push notification permission granted!');
      } else {
        toast.warning('Push notification permission was denied or dismissed.');
      }
    } catch (err) {
      toast.error('Failed to request notification permission.');
    }
  };

  const toggleRole = (role: 'Store Keeper' | 'Supervisor' | 'Admin' | 'Worker') => {
    setSelectedRoles((prev) =>
      prev.includes(role) ? prev.filter((r) => r !== role) : [...prev, role]
    );
  };

  const handleBroadcast = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !message.trim()) {
      toast.error('Please enter both title and message.');
      return;
    }

    if (selectedRoles.length === 0) {
      toast.error('Please select at least one target role.');
      return;
    }

    await sendPush({
      title,
      message,
      targetRoles: selectedRoles
    });

    setTitle('');
    setMessage('');
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Send className="w-5 h-5 text-teal-600" />
            Push Notification Broadcast & Telemetry Queue
          </h2>
          <p className="text-xs text-slate-500">
            Dispatch instant web/mobile push alerts directly to site personnel, store keepers, and site supervisors.
          </p>
        </div>

        {/* Permission Badge */}
        <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 p-2 rounded-xl border border-slate-200 dark:border-slate-700">
          <span className="text-xs font-semibold text-slate-600 dark:text-slate-300">Browser Permission:</span>
          <span
            className={`px-2.5 py-0.5 rounded text-[10px] font-extrabold uppercase ${
              permission === 'granted'
                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
            }`}
          >
            {permission}
          </span>
          {permission !== 'granted' && (
            <Button variant="outline" size="sm" onClick={requestPermission} className="text-xs">
              Enable Push
            </Button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Form: Broadcast Push */}
        <Card border className="border-slate-200 dark:border-slate-800">
          <CardContent className="p-5 space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <Bell className="w-4 h-4 text-teal-600" />
              Broadcast Instant Push Alert
            </h3>

            <form onSubmit={handleBroadcast} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Target Roles</label>
                <div className="grid grid-cols-2 gap-2">
                  {(['Store Keeper', 'Supervisor', 'Admin', 'Worker'] as const).map((role) => (
                    <button
                      type="button"
                      key={role}
                      onClick={() => toggleRole(role)}
                      className={`p-2 rounded-lg text-xs font-semibold border transition-all ${
                        selectedRoles.includes(role)
                          ? 'bg-teal-600 text-white border-teal-600 shadow-xs'
                          : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      {role}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Push Alert Title</label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. URGENT: Tower Crane A Inspection"
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Push Message Body</label>
                <textarea
                  rows={4}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Enter explicit message for site supervisors or store keepers..."
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <Button
                type="submit"
                variant="primary"
                icon={<Send className="w-4 h-4" />}
                className="w-full bg-teal-600 hover:bg-teal-500 text-white font-semibold text-xs py-2.5 shadow-md"
              >
                Dispatch Push Notification
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Right Table: Push Delivery Queue */}
        <Card border className="lg:col-span-2 border-slate-200 dark:border-slate-800">
          <CardContent className="p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">Dispatched Push Telemetry Logs</h3>
                <p className="text-xs text-slate-500">Live delivery confirmation log across registered device tokens</p>
              </div>

              <Button variant="ghost" size="sm" onClick={clearQueues} className="text-xs text-slate-400 hover:text-rose-600">
                Clear Logs
              </Button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-semibold border-b border-slate-200 dark:border-slate-700">
                  <tr>
                    <th className="p-3">Title / Message</th>
                    <th className="p-3">Target Roles</th>
                    <th className="p-3">Delivery Status</th>
                    <th className="p-3">Delivered At</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {pushQueue.map((item) => (
                    <tr key={item.id} className="hover:bg-slate-50 dark:hover:bg-slate-900/50">
                      <td className="p-3">
                        <p className="font-bold text-slate-900 dark:text-slate-100">{item.title}</p>
                        <p className="text-[11px] text-slate-500 line-clamp-1">{item.message}</p>
                      </td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 font-medium text-slate-700 dark:text-slate-300">
                          {item.targetRoles.join(', ')}
                        </span>
                      </td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                          {item.status}
                        </span>
                      </td>
                      <td className="p-3 text-slate-400">
                        {item.deliveredAt ? formatDateTime(item.deliveredAt) : 'Pending'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
