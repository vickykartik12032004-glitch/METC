import {
  EmailTemplate,
  ReminderRule,
  EscalationRule,
  NotificationSettingsState,
  AppNotification,
  NotificationHistoryItem
} from '../types';

export const MOUNTEC_COMPANY_HEADER = 'MOUNTEC PTE LTD';
export const MOUNTEC_COMPANY_FOOTER = `
  <div style="margin-top: 24px; padding-t: 16px; border-top: 1px solid #e2e8f0; text-align: center; font-size: 11px; color: #64748b; font-family: sans-serif;">
    <p style="margin: 0; font-weight: bold; color: #1e293b;">MOUNTEC PTE LTD</p>
    <p style="margin: 4px 0 0 0;">Enterprise Materials, Equipment, Tools & Consumables Management System</p>
    <p style="margin: 2px 0 0 0;">Singapore • Tel: +65 6789 0123 • Email: notifications@mountec.sg</p>
    <p style="margin: 8px 0 0 0; font-size: 10px; color: #94a3b8;">Confidential Automated Notice. © 2026 MOUNTEC PTE LTD. All rights reserved.</p>
  </div>
`;

export const INITIAL_EMAIL_TEMPLATES: EmailTemplate[] = [
  {
    id: 'tmpl-issue',
    code: 'ISSUE_CONFIRMATION',
    name: 'Issue Confirmation',
    subject: 'MOUNTEC PTE LTD: Asset Issued Notification #{ISSUE_CODE}',
    headerTitle: MOUNTEC_COMPANY_HEADER,
    footerDetails: MOUNTEC_COMPANY_FOOTER,
    module: 'Issue',
    variables: ['{WORKER_NAME}', '{ITEM_NAME}', '{QUANTITY}', '{ISSUE_CODE}', '{DUE_DATE}', '{SITE}'],
    updatedAt: '2026-02-01T10:00:00Z',
    bodyHtml: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden; background: #ffffff;">
        <div style="background: #1e3a8a; padding: 20px; text-align: center;">
          <h2 style="color: #ffffff; margin: 0; font-size: 20px;">MOUNTEC PTE LTD</h2>
          <p style="color: #93c5fd; margin: 4px 0 0 0; font-size: 12px; letter-spacing: 1px;">OFFICIAL ASSET ISSUE ADVICE</p>
        </div>
        <div style="padding: 24px; color: #334155;">
          <p>Dear <strong>{WORKER_NAME}</strong>,</p>
          <p>The following asset has been officially issued to you from the MOUNTEC PTE LTD store inventory:</p>
          <div style="background: #f8fafc; border-left: 4px solid #2563eb; padding: 16px; margin: 16px 0; border-radius: 4px;">
            <p style="margin: 4px 0;"><strong>Issue Voucher:</strong> {ISSUE_CODE}</p>
            <p style="margin: 4px 0;"><strong>Item Name:</strong> {ITEM_NAME}</p>
            <p style="margin: 4px 0;"><strong>Quantity:</strong> {QUANTITY}</p>
            <p style="margin: 4px 0;"><strong>Site Location:</strong> {SITE}</p>
            <p style="margin: 4px 0; color: #dc2626;"><strong>Expected Return Date:</strong> {DUE_DATE}</p>
          </div>
          <p style="font-size: 13px; color: #64748b;">Please inspect the condition of the issued item upon receipt and ensure it is returned to the storekeeper on or before the due date.</p>
        </div>
        {FOOTER}
      </div>
    `
  },
  {
    id: 'tmpl-return',
    code: 'RETURN_CONFIRMATION',
    name: 'Return Confirmation',
    subject: 'MOUNTEC PTE LTD: Asset Return Receipt #{RETURN_CODE}',
    headerTitle: MOUNTEC_COMPANY_HEADER,
    footerDetails: MOUNTEC_COMPANY_FOOTER,
    module: 'Return',
    variables: ['{WORKER_NAME}', '{ITEM_NAME}', '{QUANTITY}', '{RETURN_CODE}', '{CONDITION}', '{RECEIVED_BY}'],
    updatedAt: '2026-02-01T10:00:00Z',
    bodyHtml: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden; background: #ffffff;">
        <div style="background: #15803d; padding: 20px; text-align: center;">
          <h2 style="color: #ffffff; margin: 0; font-size: 20px;">MOUNTEC PTE LTD</h2>
          <p style="color: #bbf7d0; margin: 4px 0 0 0; font-size: 12px; letter-spacing: 1px;">OFFICIAL ASSET RETURN RECEIPT</p>
        </div>
        <div style="padding: 24px; color: #334155;">
          <p>Dear <strong>{WORKER_NAME}</strong>,</p>
          <p>We confirm that the following item has been successfully returned and logged back into inventory:</p>
          <div style="background: #f0fdf4; border-left: 4px solid #16a34a; padding: 16px; margin: 16px 0; border-radius: 4px;">
            <p style="margin: 4px 0;"><strong>Return Code:</strong> {RETURN_CODE}</p>
            <p style="margin: 4px 0;"><strong>Item Name:</strong> {ITEM_NAME}</p>
            <p style="margin: 4px 0;"><strong>Returned Quantity:</strong> {QUANTITY}</p>
            <p style="margin: 4px 0;"><strong>Condition:</strong> {CONDITION}</p>
            <p style="margin: 4px 0;"><strong>Received By:</strong> {RECEIVED_BY}</p>
          </div>
          <p style="font-size: 13px; color: #64748b;">Thank you for maintaining MOUNTEC safety and asset care standards.</p>
        </div>
        {FOOTER}
      </div>
    `
  },
  {
    id: 'tmpl-transfer',
    code: 'TRANSFER_CONFIRMATION',
    name: 'Transfer Confirmation',
    subject: 'MOUNTEC PTE LTD: Transfer Notice #{TRANSFER_CODE}',
    headerTitle: MOUNTEC_COMPANY_HEADER,
    footerDetails: MOUNTEC_COMPANY_FOOTER,
    module: 'Transfer',
    variables: ['{TRANSFER_CODE}', '{ITEM_NAME}', '{QUANTITY}', '{FROM_LOCATION}', '{TO_LOCATION}', '{STATUS}'],
    updatedAt: '2026-02-01T10:00:00Z',
    bodyHtml: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden; background: #ffffff;">
        <div style="background: #6b21a8; padding: 20px; text-align: center;">
          <h2 style="color: #ffffff; margin: 0; font-size: 20px;">MOUNTEC PTE LTD</h2>
          <p style="color: #e9d5ff; margin: 4px 0 0 0; font-size: 12px; letter-spacing: 1px;">INTER-SITE ASSET TRANSFER ADVICE</p>
        </div>
        <div style="padding: 24px; color: #334155;">
          <p>Inter-site asset transfer request has been updated:</p>
          <div style="background: #faf5ff; border-left: 4px solid #9333ea; padding: 16px; margin: 16px 0; border-radius: 4px;">
            <p style="margin: 4px 0;"><strong>Transfer Code:</strong> {TRANSFER_CODE}</p>
            <p style="margin: 4px 0;"><strong>Item Transferred:</strong> {ITEM_NAME}</p>
            <p style="margin: 4px 0;"><strong>Quantity:</strong> {QUANTITY}</p>
            <p style="margin: 4px 0;"><strong>From:</strong> {FROM_LOCATION}</p>
            <p style="margin: 4px 0;"><strong>To:</strong> {TO_LOCATION}</p>
            <p style="margin: 4px 0;"><strong>Transfer Status:</strong> {STATUS}</p>
          </div>
        </div>
        {FOOTER}
      </div>
    `
  },
  {
    id: 'tmpl-repair-assigned',
    code: 'REPAIR_ASSIGNMENT',
    name: 'Repair Assignment',
    subject: 'MOUNTEC PTE LTD: Repair Order Assigned #{REPAIR_CODE}',
    headerTitle: MOUNTEC_COMPANY_HEADER,
    footerDetails: MOUNTEC_COMPANY_FOOTER,
    module: 'Repair',
    variables: ['{REPAIR_CODE}', '{ITEM_NAME}', '{VENDOR}', '{ISSUE_DESC}', '{ESTIMATED_DATE}'],
    updatedAt: '2026-02-01T10:00:00Z',
    bodyHtml: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden; background: #ffffff;">
        <div style="background: #c2410c; padding: 20px; text-align: center;">
          <h2 style="color: #ffffff; margin: 0; font-size: 20px;">MOUNTEC PTE LTD</h2>
          <p style="color: #ffedd5; margin: 4px 0 0 0; font-size: 12px; letter-spacing: 1px;">EQUIPMENT REPAIR WORK ORDER</p>
        </div>
        <div style="padding: 24px; color: #334155;">
          <p>A new repair order has been created and assigned to the service vendor:</p>
          <div style="background: #fff7ed; border-left: 4px solid #ea580c; padding: 16px; margin: 16px 0; border-radius: 4px;">
            <p style="margin: 4px 0;"><strong>Repair Ticket:</strong> {REPAIR_CODE}</p>
            <p style="margin: 4px 0;"><strong>Equipment:</strong> {ITEM_NAME}</p>
            <p style="margin: 4px 0;"><strong>Service Vendor:</strong> {VENDOR}</p>
            <p style="margin: 4px 0;"><strong>Issue Summary:</strong> {ISSUE_DESC}</p>
            <p style="margin: 4px 0;"><strong>Est. Completion:</strong> {ESTIMATED_DATE}</p>
          </div>
        </div>
        {FOOTER}
      </div>
    `
  },
  {
    id: 'tmpl-repair-completed',
    code: 'REPAIR_COMPLETION',
    name: 'Repair Completion',
    subject: 'MOUNTEC PTE LTD: Repair Completed #{REPAIR_CODE}',
    headerTitle: MOUNTEC_COMPANY_HEADER,
    footerDetails: MOUNTEC_COMPANY_FOOTER,
    module: 'Repair',
    variables: ['{REPAIR_CODE}', '{ITEM_NAME}', '{COST}', '{STATUS}'],
    updatedAt: '2026-02-01T10:00:00Z',
    bodyHtml: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden; background: #ffffff;">
        <div style="background: #15803d; padding: 20px; text-align: center;">
          <h2 style="color: #ffffff; margin: 0; font-size: 20px;">MOUNTEC PTE LTD</h2>
          <p style="color: #bbf7d0; margin: 4px 0 0 0; font-size: 12px; letter-spacing: 1px;">REPAIR COMPLETION NOTICE</p>
        </div>
        <div style="padding: 24px; color: #334155;">
          <p>The repair process for the following equipment has been completed and verified:</p>
          <div style="background: #f0fdf4; border-left: 4px solid #16a34a; padding: 16px; margin: 16px 0; border-radius: 4px;">
            <p style="margin: 4px 0;"><strong>Repair Ticket:</strong> {REPAIR_CODE}</p>
            <p style="margin: 4px 0;"><strong>Equipment:</strong> {ITEM_NAME}</p>
            <p style="margin: 4px 0;"><strong>Final Repair Cost:</strong> ${'{COST}'}</p>
            <p style="margin: 4px 0;"><strong>Status:</strong> Available / Passed Quality Inspection</p>
          </div>
        </div>
        {FOOTER}
      </div>
    `
  },
  {
    id: 'tmpl-lost',
    code: 'LOST_ITEM_NOTIFICATION',
    name: 'Lost Item Report',
    subject: 'MOUNTEC PTE LTD: CRITICAL - Lost Asset Incident #{INCIDENT_CODE}',
    headerTitle: MOUNTEC_COMPANY_HEADER,
    footerDetails: MOUNTEC_COMPANY_FOOTER,
    module: 'Lost',
    variables: ['{INCIDENT_CODE}', '{ITEM_NAME}', '{WORKER_NAME}', '{LOCATION}', '{ESTIMATED_VALUE}'],
    updatedAt: '2026-02-01T10:00:00Z',
    bodyHtml: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden; background: #ffffff;">
        <div style="background: #991b1b; padding: 20px; text-align: center;">
          <h2 style="color: #ffffff; margin: 0; font-size: 20px;">MOUNTEC PTE LTD</h2>
          <p style="color: #fca5a5; margin: 4px 0 0 0; font-size: 12px; letter-spacing: 1px;">SECURITY & ASSET LOSS INCIDENT ADVICE</p>
        </div>
        <div style="padding: 24px; color: #334155;">
          <p style="color: #991b1b; font-weight: bold;">Attention Site Supervisor & Store Keeper,</p>
          <p>A missing or lost asset has been reported in the MOUNTEC system:</p>
          <div style="background: #fef2f2; border-left: 4px solid #dc2626; padding: 16px; margin: 16px 0; border-radius: 4px;">
            <p style="margin: 4px 0;"><strong>Report Ref:</strong> {INCIDENT_CODE}</p>
            <p style="margin: 4px 0;"><strong>Item Name:</strong> {ITEM_NAME}</p>
            <p style="margin: 4px 0;"><strong>Reported By / Worker:</strong> {WORKER_NAME}</p>
            <p style="margin: 4px 0;"><strong>Location:</strong> {LOCATION}</p>
            <p style="margin: 4px 0;"><strong>Est. Financial Impact:</strong> ${'{ESTIMATED_VALUE}'}</p>
          </div>
        </div>
        {FOOTER}
      </div>
    `
  },
  {
    id: 'tmpl-lowstock',
    code: 'LOW_STOCK_ALERT',
    name: 'Low Stock Alert',
    subject: 'MOUNTEC PTE LTD: ALERT - Low Stock Level for {ITEM_NAME}',
    headerTitle: MOUNTEC_COMPANY_HEADER,
    footerDetails: MOUNTEC_COMPANY_FOOTER,
    module: 'Stock',
    variables: ['{ITEM_NAME}', '{CURRENT_QTY}', '{MIN_THRESHOLD}', '{SUGGESTED_REORDER}'],
    updatedAt: '2026-02-01T10:00:00Z',
    bodyHtml: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden; background: #ffffff;">
        <div style="background: #d97706; padding: 20px; text-align: center;">
          <h2 style="color: #ffffff; margin: 0; font-size: 20px;">MOUNTEC PTE LTD</h2>
          <p style="color: #fef3c7; margin: 4px 0 0 0; font-size: 12px; letter-spacing: 1px;">AUTOMATED INVENTORY LOW STOCK ALERT</p>
        </div>
        <div style="padding: 24px; color: #334155;">
          <p>Current stock balance has reached or fallen below the established safety threshold:</p>
          <div style="background: #fffbeb; border-left: 4px solid #f59e0b; padding: 16px; margin: 16px 0; border-radius: 4px;">
            <p style="margin: 4px 0;"><strong>Inventory Item:</strong> {ITEM_NAME}</p>
            <p style="margin: 4px 0; color: #b45309;"><strong>Current Quantity:</strong> {CURRENT_QTY}</p>
            <p style="margin: 4px 0;"><strong>Minimum Threshold:</strong> {MIN_THRESHOLD}</p>
            <p style="margin: 4px 0; color: #15803d; font-weight: bold;"><strong>Suggested Reorder Quantity:</strong> {SUGGESTED_REORDER}</p>
          </div>
          <p style="font-size: 13px; color: #64748b;">Please initiate procurement requisition to prevent operational downtime.</p>
        </div>
        {FOOTER}
      </div>
    `
  },
  {
    id: 'tmpl-overdue',
    code: 'OVERDUE_REMINDER',
    name: 'Overdue Reminder',
    subject: 'MOUNTEC PTE LTD: OVERDUE ITEM NOTICE - {ITEM_NAME}',
    headerTitle: MOUNTEC_COMPANY_HEADER,
    footerDetails: MOUNTEC_COMPANY_FOOTER,
    module: 'Issue',
    variables: ['{WORKER_NAME}', '{ITEM_NAME}', '{DAYS_OVERDUE}', '{DUE_DATE}', '{SITE}'],
    updatedAt: '2026-02-01T10:00:00Z',
    bodyHtml: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden; background: #ffffff;">
        <div style="background: #b91c1c; padding: 20px; text-align: center;">
          <h2 style="color: #ffffff; margin: 0; font-size: 20px;">MOUNTEC PTE LTD</h2>
          <p style="color: #fecaca; margin: 4px 0 0 0; font-size: 12px; letter-spacing: 1px;">URGENT ASSET RETURN OVERDUE DEMAND</p>
        </div>
        <div style="padding: 24px; color: #334155;">
          <p>Dear <strong>{WORKER_NAME}</strong>,</p>
          <p>According to MOUNTEC PTE LTD store records, the expected return date for your issued item has expired:</p>
          <div style="background: #fef2f2; border-left: 4px solid #ef4444; padding: 16px; margin: 16px 0; border-radius: 4px;">
            <p style="margin: 4px 0;"><strong>Item:</strong> {ITEM_NAME}</p>
            <p style="margin: 4px 0;"><strong>Due Return Date:</strong> {DUE_DATE}</p>
            <p style="margin: 4px 0; color: #b91c1c; font-weight: bold;"><strong>Days Overdue:</strong> {DAYS_OVERDUE} Days</p>
            <p style="margin: 4px 0;"><strong>Assigned Site:</strong> {SITE}</p>
          </div>
          <p style="font-size: 13px; color: #b91c1c;">Failure to return equipment promptly may trigger administrative escalation to your supervisor.</p>
        </div>
        {FOOTER}
      </div>
    `
  },
  {
    id: 'tmpl-maintenance',
    code: 'MAINTENANCE_REMINDER',
    name: 'Maintenance Reminder',
    subject: 'MOUNTEC PTE LTD: Scheduled Preventive Maintenance Notice - {ITEM_NAME}',
    headerTitle: MOUNTEC_COMPANY_HEADER,
    footerDetails: MOUNTEC_COMPANY_FOOTER,
    module: 'Maintenance',
    variables: ['{ITEM_NAME}', '{DUE_DATE}', '{RESPONSIBLE_PERSON}', '{MAINT_TYPE}'],
    updatedAt: '2026-02-01T10:00:00Z',
    bodyHtml: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden; background: #ffffff;">
        <div style="background: #0369a1; padding: 20px; text-align: center;">
          <h2 style="color: #ffffff; margin: 0; font-size: 20px;">MOUNTEC PTE LTD</h2>
          <p style="color: #bae6fd; margin: 4px 0 0 0; font-size: 12px; letter-spacing: 1px;">PREVENTIVE MAINTENANCE SCHEDULE</p>
        </div>
        <div style="padding: 24px; color: #334155;">
          <p>Preventive maintenance for the following machinery / equipment is due:</p>
          <div style="background: #f0f9ff; border-left: 4px solid #0284c7; padding: 16px; margin: 16px 0; border-radius: 4px;">
            <p style="margin: 4px 0;"><strong>Equipment:</strong> {ITEM_NAME}</p>
            <p style="margin: 4px 0;"><strong>Type:</strong> {MAINT_TYPE}</p>
            <p style="margin: 4px 0;"><strong>Scheduled Date:</strong> {DUE_DATE}</p>
            <p style="margin: 4px 0;"><strong>Responsible Engineer:</strong> {RESPONSIBLE_PERSON}</p>
          </div>
        </div>
        {FOOTER}
      </div>
    `
  },
  {
    id: 'tmpl-calibration',
    code: 'CALIBRATION_REMINDER',
    name: 'Calibration Reminder',
    subject: 'MOUNTEC PTE LTD: Calibration & Safety Audit Notice - {ITEM_NAME}',
    headerTitle: MOUNTEC_COMPANY_HEADER,
    footerDetails: MOUNTEC_COMPANY_FOOTER,
    module: 'Calibration',
    variables: ['{ITEM_NAME}', '{DUE_DATE}', '{VENDOR}', '{STATUS}'],
    updatedAt: '2026-02-01T10:00:00Z',
    bodyHtml: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden; background: #ffffff;">
        <div style="background: #0f766e; padding: 20px; text-align: center;">
          <h2 style="color: #ffffff; margin: 0; font-size: 20px;">MOUNTEC PTE LTD</h2>
          <p style="color: #99f6e4; margin: 4px 0 0 0; font-size: 12px; letter-spacing: 1px;">PRECISION CALIBRATION & SAFETY COMPLIANCE</p>
        </div>
        <div style="padding: 24px; color: #334155;">
          <p>Equipment laser / instrument calibration audit due:</p>
          <div style="background: #f0fdfa; border-left: 4px solid #0d9488; padding: 16px; margin: 16px 0; border-radius: 4px;">
            <p style="margin: 4px 0;"><strong>Instrument / Tool:</strong> {ITEM_NAME}</p>
            <p style="margin: 4px 0;"><strong>Calibration Expiry / Due:</strong> {DUE_DATE}</p>
            <p style="margin: 4px 0;"><strong>Accredited Vendor:</strong> {VENDOR}</p>
            <p style="margin: 4px 0;"><strong>Current Status:</strong> {STATUS}</p>
          </div>
        </div>
        {FOOTER}
      </div>
    `
  },
  {
    id: 'tmpl-warranty',
    code: 'WARRANTY_REMINDER',
    name: 'Warranty Expiry Reminder',
    subject: 'MOUNTEC PTE LTD: Equipment Warranty Renewal / Claim Alert - {ITEM_NAME}',
    headerTitle: MOUNTEC_COMPANY_HEADER,
    footerDetails: MOUNTEC_COMPANY_FOOTER,
    module: 'Warranty',
    variables: ['{ITEM_NAME}', '{EXPIRY_DATE}', '{SUPPLIER}', '{STATUS}'],
    updatedAt: '2026-02-01T10:00:00Z',
    bodyHtml: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden; background: #ffffff;">
        <div style="background: #4338ca; padding: 20px; text-align: center;">
          <h2 style="color: #ffffff; margin: 0; font-size: 20px;">MOUNTEC PTE LTD</h2>
          <p style="color: #c7d2fe; margin: 4px 0 0 0; font-size: 12px; letter-spacing: 1px;">EQUIPMENT WARRANTY & ASSET PROTECTION</p>
        </div>
        <div style="padding: 24px; color: #334155;">
          <p>OEM manufacturer warranty notice for MOUNTEC machinery asset:</p>
          <div style="background: #eef2ff; border-left: 4px solid #4f46e5; padding: 16px; margin: 16px 0; border-radius: 4px;">
            <p style="margin: 4px 0;"><strong>Asset Name:</strong> {ITEM_NAME}</p>
            <p style="margin: 4px 0;"><strong>Warranty Expiration:</strong> {EXPIRY_DATE}</p>
            <p style="margin: 4px 0;"><strong>Supplier / OEM:</strong> {SUPPLIER}</p>
            <p style="margin: 4px 0;"><strong>Alert Condition:</strong> {STATUS}</p>
          </div>
        </div>
        {FOOTER}
      </div>
    `
  }
];

export const INITIAL_REMINDER_RULES: ReminderRule[] = [
  {
    id: 'rule-daily-overdue',
    name: 'Daily Overdue Asset Audit',
    module: 'Issue',
    frequency: 'Daily',
    timeOfDay: '08:00',
    active: true,
    targetRole: 'Supervisor',
    lastRun: '2026-07-29T08:00:00Z',
    nextRun: '2026-07-30T08:00:00Z'
  },
  {
    id: 'rule-weekly-stock',
    name: 'Weekly Minimum Stock & Reorder Check',
    module: 'Stock',
    frequency: 'Weekly',
    timeOfDay: '09:00',
    active: true,
    targetRole: 'Store Keeper',
    lastRun: '2026-07-27T09:00:00Z',
    nextRun: '2026-08-03T09:00:00Z'
  },
  {
    id: 'rule-monthly-maintenance',
    name: 'Monthly Preventive Maintenance Audit',
    module: 'Maintenance',
    frequency: 'Monthly',
    timeOfDay: '10:00',
    active: true,
    targetRole: 'Admin',
    lastRun: '2026-07-01T10:00:00Z',
    nextRun: '2026-08-01T10:00:00Z'
  },
  {
    id: 'rule-calibration-biweekly',
    name: 'Survey Tool Calibration Expiry Monitor',
    module: 'Calibration',
    frequency: 'Weekly',
    timeOfDay: '08:30',
    active: true,
    targetRole: 'Supervisor',
    lastRun: '2026-07-28T08:30:00Z',
    nextRun: '2026-08-04T08:30:00Z'
  }
];

export const INITIAL_ESCALATION_RULES: EscalationRule[] = [
  {
    id: 'esc-3day',
    name: 'Level 1: Overdue > 3 Days Escalation',
    module: 'Issue',
    conditionDays: 3,
    actionNotifyRole: 'Supervisor',
    triggerPriority: 'Medium',
    description: 'When an item is overdue by more than 3 days, trigger an alert to the Site Supervisor.',
    active: true
  },
  {
    id: 'esc-7day',
    name: 'Level 2: Overdue > 7 Days Escalation',
    module: 'Issue',
    conditionDays: 7,
    actionNotifyRole: 'Admin',
    triggerPriority: 'High',
    description: 'When an item is overdue by more than 7 days, notify the Admin and lock worker reissue permission.',
    active: true
  },
  {
    id: 'esc-15day',
    name: 'Level 3: Overdue > 15 Days Critical Escalation',
    module: 'Issue',
    conditionDays: 15,
    actionNotifyRole: 'Super Admin',
    triggerPriority: 'Critical',
    description: 'Overdue > 15 days triggers Critical Priority Alert, auto-flags item as potentially lost, and notifies Super Admin.',
    active: true
  }
];

export const INITIAL_NOTIFICATION_SETTINGS: NotificationSettingsState = {
  companyName: 'MOUNTEC PTE LTD',
  senderEmail: 'notifications@mountec.sg',
  enableSoundAlerts: true,
  autoArchiveDays: 30,
  channels: {
    inApp: true,
    email: true,
    push: true
  },
  modules: {
    Issue: true,
    Return: true,
    Transfer: true,
    Repair: true,
    Maintenance: true,
    Lost: true,
    Warranty: true,
    Calibration: true,
    Stock: true
  }
};

export const INITIAL_APP_NOTIFICATIONS: AppNotification[] = [];

export const INITIAL_NOTIFICATION_HISTORY: NotificationHistoryItem[] = [];

