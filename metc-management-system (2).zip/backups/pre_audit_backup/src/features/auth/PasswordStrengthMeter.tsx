import React from 'react';
import { Check, X } from 'lucide-react';

interface PasswordStrengthMeterProps {
  password?: string;
}

export interface PasswordRulesResult {
  minLength: boolean;
  hasUppercase: boolean;
  hasLowercase: boolean;
  hasNumber: boolean;
  hasSpecialChar: boolean;
  score: number; // 0 to 5
}

export function evaluatePassword(password: string = ''): PasswordRulesResult {
  const minLength = password.length >= 8;
  const hasUppercase = /[A-Z]/.test(password);
  const hasLowercase = /[a-z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  const hasSpecialChar = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password);

  const rules = [minLength, hasUppercase, hasLowercase, hasNumber, hasSpecialChar];
  const score = rules.filter(Boolean).length;

  return {
    minLength,
    hasUppercase,
    hasLowercase,
    hasNumber,
    hasSpecialChar,
    score,
  };
}

export const PasswordStrengthMeter: React.FC<PasswordStrengthMeterProps> = ({ password = '' }) => {
  const result = evaluatePassword(password);

  if (!password) {
    return null;
  }

  const getStrengthLabel = () => {
    switch (result.score) {
      case 0:
      case 1:
      case 2:
        return { label: 'Weak', color: 'bg-rose-500', text: 'text-rose-500' };
      case 3:
        return { label: 'Fair', color: 'bg-amber-500', text: 'text-amber-500' };
      case 4:
        return { label: 'Good', color: 'bg-blue-500', text: 'text-blue-500' };
      case 5:
        return { label: 'Strong', color: 'bg-emerald-500', text: 'text-emerald-500' };
      default:
        return { label: 'Weak', color: 'bg-rose-500', text: 'text-rose-500' };
    }
  };

  const strength = getStrengthLabel();

  return (
    <div className="mt-2.5 p-3 rounded-lg bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/60 text-xs space-y-2">
      <div className="flex items-center justify-between">
        <span className="font-medium text-slate-600 dark:text-slate-300">Password Strength:</span>
        <span className={`font-bold ${strength.text}`}>{strength.label}</span>
      </div>

      {/* Progress Bars */}
      <div className="grid grid-cols-5 gap-1.5 h-1.5 w-full">
        {[1, 2, 3, 4, 5].map((level) => (
          <div
            key={level}
            className={`h-full rounded-full transition-colors duration-300 ${
              level <= result.score ? strength.color : 'bg-slate-200 dark:bg-slate-700'
            }`}
          />
        ))}
      </div>

      {/* Checklist */}
      <div className="grid grid-cols-2 gap-x-2 gap-y-1 pt-1 text-[11px]">
        <div className={`flex items-center gap-1.5 ${result.minLength ? 'text-emerald-600 dark:text-emerald-400 font-medium' : 'text-slate-400'}`}>
          {result.minLength ? <Check className="w-3 h-3 text-emerald-500 shrink-0" /> : <X className="w-3 h-3 text-slate-400 shrink-0" />}
          <span>8+ Characters</span>
        </div>

        <div className={`flex items-center gap-1.5 ${result.hasUppercase ? 'text-emerald-600 dark:text-emerald-400 font-medium' : 'text-slate-400'}`}>
          {result.hasUppercase ? <Check className="w-3 h-3 text-emerald-500 shrink-0" /> : <X className="w-3 h-3 text-slate-400 shrink-0" />}
          <span>Uppercase (A-Z)</span>
        </div>

        <div className={`flex items-center gap-1.5 ${result.hasLowercase ? 'text-emerald-600 dark:text-emerald-400 font-medium' : 'text-slate-400'}`}>
          {result.hasLowercase ? <Check className="w-3 h-3 text-emerald-500 shrink-0" /> : <X className="w-3 h-3 text-slate-400 shrink-0" />}
          <span>Lowercase (a-z)</span>
        </div>

        <div className={`flex items-center gap-1.5 ${result.hasNumber ? 'text-emerald-600 dark:text-emerald-400 font-medium' : 'text-slate-400'}`}>
          {result.hasNumber ? <Check className="w-3 h-3 text-emerald-500 shrink-0" /> : <X className="w-3 h-3 text-slate-400 shrink-0" />}
          <span>Number (0-9)</span>
        </div>

        <div className={`flex items-center gap-1.5 col-span-2 ${result.hasSpecialChar ? 'text-emerald-600 dark:text-emerald-400 font-medium' : 'text-slate-400'}`}>
          {result.hasSpecialChar ? <Check className="w-3 h-3 text-emerald-500 shrink-0" /> : <X className="w-3 h-3 text-slate-400 shrink-0" />}
          <span>Special Symbol (!@#$%...)</span>
        </div>
      </div>
    </div>
  );
};
