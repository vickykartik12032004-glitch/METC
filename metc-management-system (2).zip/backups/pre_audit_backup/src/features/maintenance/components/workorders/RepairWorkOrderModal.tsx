import React, { useRef } from 'react';
import { RepairRecord } from '../../../../types';
import { Modal } from '../../../../components/ui/Modal';
import { Button } from '../../../../components/ui/Button';
import { formatDateTime } from '../../../../lib/utils';
import { Printer, QrCode } from 'lucide-react';
import { DEFAULT_COMPANY } from '../../../../constants';

interface Props {
  repairRecord: RepairRecord;
  isOpen: boolean;
  onClose: () => void;
}

export const RepairWorkOrderModal: React.FC<Props> = ({ repairRecord, isOpen, onClose }) => {
  const printRef = useRef<HTMLDivElement>(null);

  if (!repairRecord) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Maintenance Work Order" size="xl">
      <div className="space-y-6">
        <div className="flex justify-end gap-2 print:hidden mb-4">
          <Button variant="primary" size="sm" icon={<Printer className="w-4 h-4" />} onClick={handlePrint}>
            Print Work Order
          </Button>
        </div>

        <div 
          ref={printRef}
          className="bg-white p-8 border border-slate-200 rounded-xl shadow-sm text-slate-900 max-w-3xl mx-auto print:border-none print:shadow-none print:p-0"
        >
          {/* Header */}
          <div className="flex justify-between items-start border-b-2 border-slate-900 pb-6 mb-6">
            <div>
              <h1 className="text-2xl font-black tracking-tight uppercase">{DEFAULT_COMPANY.name}</h1>
              <p className="text-sm font-medium text-slate-500 mt-1">Maintenance & Repair Work Order</p>
            </div>
            <div className="text-right flex flex-col items-end">
              <QrCode className="w-16 h-16 mb-2 text-slate-800" />
              <p className="text-xs font-mono font-bold">{repairRecord.repairCode}</p>
            </div>
          </div>

          {/* Details */}
          <div className="grid grid-cols-2 gap-8 mb-8">
            <div className="space-y-4">
              <div>
                <p className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">Item Details</p>
                <p className="text-base font-bold">{repairRecord.itemName}</p>
                <p className="text-xs text-slate-500 font-mono mt-0.5">{repairRecord.assetId || repairRecord.itemId}</p>
              </div>
              <div>
                <p className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">Repair Vendor</p>
                <p className="text-base font-bold">{repairRecord.repairVendor || 'Internal Maintenance Team'}</p>
              </div>
            </div>
            
            <div className="space-y-4">
              <div>
                <p className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">Date Sent</p>
                <p className="text-sm font-semibold">{formatDateTime(repairRecord.sentDate)}</p>
              </div>
              <div>
                <p className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">Expected Completion</p>
                <p className="text-sm font-semibold">{repairRecord.expectedCompletionDate ? new Date(repairRecord.expectedCompletionDate).toLocaleDateString() : 'N/A'}</p>
              </div>
            </div>
          </div>

          {/* Issue Description */}
          <div className="mb-8">
            <p className="text-[10px] font-bold uppercase text-slate-400 tracking-wider mb-2">Problem Description / Scope of Work</p>
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg text-sm min-h-[100px]">
              {repairRecord.issueDescription}
            </div>
          </div>
          
          <div className="mb-12">
            <p className="text-[10px] font-bold uppercase text-slate-400 tracking-wider mb-2">Remarks</p>
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg text-sm min-h-[60px]">
              {repairRecord.remarks || 'None'}
            </div>
          </div>

          {/* Signatures */}
          <div className="grid grid-cols-3 gap-8 pt-16 border-t border-slate-200">
            <div className="text-center">
              <div className="border-b-2 border-slate-900 w-full mb-2"></div>
              <p className="text-xs font-bold">Authorized By</p>
              <p className="text-[10px] text-slate-500">{repairRecord.handledBy || 'Admin'}</p>
            </div>
            <div className="text-center">
              <div className="border-b-2 border-slate-900 w-full mb-2"></div>
              <p className="text-xs font-bold">Vendor / Technician</p>
              <p className="text-[10px] text-slate-500">Signature & Date</p>
            </div>
            <div className="text-center">
              <div className="border-b-2 border-slate-900 w-full mb-2"></div>
              <p className="text-xs font-bold">QA / Inspected By</p>
              <p className="text-[10px] text-slate-500">Signature & Date</p>
            </div>
          </div>

          {/* Footer */}
          <div className="text-center mt-12 pt-6 border-t border-slate-100">
            <p className="text-[10px] text-slate-500 font-medium">Generated by {DEFAULT_COMPANY.tagline}</p>
          </div>
        </div>
      </div>
    </Modal>
  );
};
