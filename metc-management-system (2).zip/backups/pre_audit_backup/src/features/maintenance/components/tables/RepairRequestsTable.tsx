import React, { useState } from 'react';
import { useTransactionStore } from '../../../../store/useTransactionStore';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '../../../../components/ui/Table';
import { StatusBadge } from '../../../../components/common/StatusBadge';
import { Button } from '../../../../components/ui/Button';
import { approveRepair, completeRepair } from '../../services/maintenance.service';
import { formatDateTime } from '../../../../lib/utils';
import { Eye, CheckCircle, Printer } from 'lucide-react';
import { RepairWorkOrderModal } from '../workorders/RepairWorkOrderModal';
import { RepairRecord } from '../../../../types';

export const RepairRequestsTable: React.FC = () => {
  const { repairs } = useTransactionStore();
  const [selectedRepair, setSelectedRepair] = useState<RepairRecord | null>(null);

  return (
    <>
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Repair Code</TableHead>
              <TableHead>Item Name</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Priority</TableHead>
              <TableHead>Date Sent</TableHead>
              <TableHead>Vendor</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {repairs.length === 0 && (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-8 text-slate-500">No repairs found.</TableCell>
              </TableRow>
            )}
            {repairs.map((r) => (
              <TableRow key={r.id}>
                <TableCell className="font-bold text-slate-900 dark:text-slate-100">{r.repairCode}</TableCell>
                <TableCell className="font-semibold text-slate-800 dark:text-slate-200">{r.itemName}</TableCell>
                <TableCell>{r.repairType || 'Corrective'}</TableCell>
                <TableCell>
                   <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                     r.repairPriority === 'Critical' ? 'bg-rose-100 text-rose-700' :
                     r.repairPriority === 'High' ? 'bg-orange-100 text-orange-700' :
                     r.repairPriority === 'Medium' ? 'bg-blue-100 text-blue-700' :
                     'bg-slate-100 text-slate-700'
                   }`}>
                     {r.repairPriority || 'Medium'}
                   </span>
                </TableCell>
                <TableCell>{formatDateTime(r.sentDate)}</TableCell>
                <TableCell>{r.repairVendor || 'Internal'}</TableCell>
                <TableCell><StatusBadge status={r.status} /></TableCell>
                <TableCell className="text-right space-x-1">
                  {r.status === 'Pending' && (
                    <Button variant="outline" size="xs" onClick={() => approveRepair(r.id)}>Approve</Button>
                  )}
                  {(r.status === 'In Progress' || r.status === 'In Repair' || r.status === 'Waiting Parts') && (
                    <Button variant="primary" size="xs" onClick={() => completeRepair(r.id, r.estimatedCost || 0, 'Completed')} icon={<CheckCircle className="w-3.5 h-3.5" />}>Complete</Button>
                  )}
                  <Button variant="outline" size="xs" icon={<Printer className="w-3.5 h-3.5" />} onClick={() => setSelectedRepair(r)}>Print</Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {selectedRepair && (
        <RepairWorkOrderModal 
          isOpen={true} 
          onClose={() => setSelectedRepair(null)} 
          repairRecord={selectedRepair} 
        />
      )}
    </>
  );
};
