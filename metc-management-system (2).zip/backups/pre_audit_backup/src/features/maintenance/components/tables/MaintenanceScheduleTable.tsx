import React from 'react';
import { useMaintenanceStore } from '../../../../store/useMaintenanceStore';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '../../../../components/ui/Table';
import { StatusBadge } from '../../../../components/common/StatusBadge';
import { Button } from '../../../../components/ui/Button';
import { Eye, CheckCircle } from 'lucide-react';

export const MaintenanceScheduleTable: React.FC = () => {
  const { maintenances, updateMaintenanceStatus } = useMaintenanceStore();

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>PM Code</TableHead>
            <TableHead>Item Name</TableHead>
            <TableHead>Frequency</TableHead>
            <TableHead>Next Maintenance</TableHead>
            <TableHead>Responsible</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {maintenances.length === 0 && (
            <TableRow>
              <TableCell colSpan={7} className="text-center py-8 text-slate-500">No maintenance schedules found.</TableCell>
            </TableRow>
          )}
          {maintenances.map((m) => (
            <TableRow key={m.id}>
              <TableCell className="font-bold text-slate-900 dark:text-slate-100">{m.maintenanceCode}</TableCell>
              <TableCell className="font-semibold text-slate-800 dark:text-slate-200">{m.itemName}</TableCell>
              <TableCell>{m.frequency}</TableCell>
              <TableCell className="font-medium text-slate-700">{new Date(m.nextMaintenance).toLocaleDateString()}</TableCell>
              <TableCell>{m.responsiblePerson}</TableCell>
              <TableCell><StatusBadge status={m.status} /></TableCell>
              <TableCell className="text-right space-x-1">
                {m.status !== 'Completed' && (
                  <Button variant="outline" size="xs" onClick={() => updateMaintenanceStatus(m.id, 'Completed')} icon={<CheckCircle className="w-3.5 h-3.5 text-emerald-500" />}>Mark Done</Button>
                )}
                <Button variant="outline" size="xs" icon={<Eye className="w-3.5 h-3.5" />}>View</Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};
