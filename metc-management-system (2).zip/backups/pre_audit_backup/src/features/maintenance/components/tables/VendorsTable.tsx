import React from 'react';
import { useMaintenanceStore } from '../../../../store/useMaintenanceStore';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '../../../../components/ui/Table';
import { StatusBadge } from '../../../../components/common/StatusBadge';
import { Button } from '../../../../components/ui/Button';
import { Eye, Edit2 } from 'lucide-react';

export const VendorsTable: React.FC = () => {
  const { vendors } = useMaintenanceStore();

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden">
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center">
        <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">Registered Vendors</h3>
        <Button variant="primary" size="sm">Add Vendor</Button>
      </div>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Vendor Name</TableHead>
            <TableHead>Contact</TableHead>
            <TableHead>Email</TableHead>
            <TableHead>Rating</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {vendors.length === 0 && (
            <TableRow>
              <TableCell colSpan={6} className="text-center py-8 text-slate-500">No vendors found.</TableCell>
            </TableRow>
          )}
          {vendors.map((v) => (
            <TableRow key={v.id}>
              <TableCell className="font-bold text-slate-900 dark:text-slate-100">{v.vendorName}</TableCell>
              <TableCell className="text-slate-700">{v.phone}</TableCell>
              <TableCell className="text-slate-700">{v.email}</TableCell>
              <TableCell>
                 <span className="bg-amber-100 text-amber-700 font-bold px-2 py-0.5 rounded-full text-xs">★ {v.rating || 'N/A'}</span>
              </TableCell>
              <TableCell><StatusBadge status={v.status} /></TableCell>
              <TableCell className="text-right space-x-1">
                <Button variant="outline" size="xs" icon={<Edit2 className="w-3.5 h-3.5" />}>Edit</Button>
                <Button variant="outline" size="xs" icon={<Eye className="w-3.5 h-3.5" />}>View</Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};
