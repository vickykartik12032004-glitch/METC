import React from 'react';
import { useMaintenanceStore } from '../../../../store/useMaintenanceStore';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '../../../../components/ui/Table';
import { StatusBadge } from '../../../../components/common/StatusBadge';
import { Button } from '../../../../components/ui/Button';
import { formatDateTime } from '../../../../lib/utils';
import { Eye, CheckCircle } from 'lucide-react';

export const DisposalTable: React.FC = () => {
  const { disposals, updateDisposalStatus } = useMaintenanceStore();

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Disposal Code</TableHead>
            <TableHead>Item</TableHead>
            <TableHead>Reason</TableHead>
            <TableHead>Value</TableHead>
            <TableHead>Date</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {disposals.length === 0 && (
            <TableRow>
              <TableCell colSpan={7} className="text-center py-8 text-slate-500">No disposal records found.</TableCell>
            </TableRow>
          )}
          {disposals.map((d) => (
            <TableRow key={d.id}>
              <TableCell className="font-bold text-slate-900 dark:text-slate-100">{d.disposalCode}</TableCell>
              <TableCell className="font-semibold text-slate-800 dark:text-slate-200">{d.itemName}</TableCell>
              <TableCell className="max-w-[150px] truncate">{d.reason}</TableCell>
              <TableCell>{d.disposalValue ? `$${d.disposalValue.toFixed(2)}` : '-'}</TableCell>
              <TableCell>{formatDateTime(d.disposalDate)}</TableCell>
              <TableCell><StatusBadge status={d.status} /></TableCell>
              <TableCell className="text-right space-x-1">
                {d.status === 'Pending' && (
                  <Button variant="outline" size="xs" onClick={() => updateDisposalStatus(d.id, 'Approved')}>Approve</Button>
                )}
                {d.status === 'Approved' && (
                  <Button variant="primary" size="xs" onClick={() => updateDisposalStatus(d.id, 'Disposed')} icon={<CheckCircle className="w-3.5 h-3.5" />}>Dispose</Button>
                )}
                <Button variant="outline" size="xs" icon={<Eye className="w-3.5 h-3.5" />}>View</Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};
