import React from 'react';
import { useTransactionStore } from '../../../../store/useTransactionStore';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '../../../../components/ui/Table';
import { StatusBadge } from '../../../../components/common/StatusBadge';
import { Button } from '../../../../components/ui/Button';
import { formatDateTime } from '../../../../lib/utils';
import { Eye, ShieldAlert } from 'lucide-react';

export const LostItemsTable: React.FC = () => {
  const { lostItems, updateLostItemStatus } = useTransactionStore();

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Lost Code</TableHead>
            <TableHead>Item</TableHead>
            <TableHead>Worker</TableHead>
            <TableHead>Location</TableHead>
            <TableHead>Date Reported</TableHead>
            <TableHead>Action Taken</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {lostItems.length === 0 && (
            <TableRow>
              <TableCell colSpan={8} className="text-center py-8 text-slate-500">No lost items reported.</TableCell>
            </TableRow>
          )}
          {lostItems.map((l) => (
            <TableRow key={l.id}>
              <TableCell className="font-bold text-slate-900 dark:text-slate-100">{l.lostCode}</TableCell>
              <TableCell className="font-semibold text-slate-800 dark:text-slate-200">{l.itemName}</TableCell>
              <TableCell>{l.workerName || 'N/A'}</TableCell>
              <TableCell>{l.location}</TableCell>
              <TableCell>{formatDateTime(l.reportedDate)}</TableCell>
              <TableCell>{l.actionTaken}</TableCell>
              <TableCell><StatusBadge status={l.status} /></TableCell>
              <TableCell className="text-right space-x-1">
                {l.status !== 'Closed' && (
                  <Button variant="outline" size="xs" onClick={() => updateLostItemStatus(l.id, 'Closed')} icon={<ShieldAlert className="w-3.5 h-3.5" />}>Close</Button>
                )}
                <Button variant="outline" size="xs" icon={<Eye className="w-3.5 h-3.5" />}>View</Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};
