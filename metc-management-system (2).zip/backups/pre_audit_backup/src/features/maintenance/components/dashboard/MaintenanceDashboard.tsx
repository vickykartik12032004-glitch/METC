import React, { useMemo } from 'react';
import { useTransactionStore } from '../../../../store/useTransactionStore';
import { useMaintenanceStore } from '../../../../store/useMaintenanceStore';
import { 
  BarChart2, 
  Wrench, 
  Settings, 
  CalendarDays, 
  AlertTriangle, 
  Trash2, 
  Users, 
  CheckCircle, 
  Clock, 
  DollarSign 
} from 'lucide-react';
import type { MaintenanceTabType } from '../../MaintenanceMasterModule';

interface Props {
  onNavigate: (tab: MaintenanceTabType) => void;
}

export const MaintenanceDashboard: React.FC<Props> = ({ onNavigate }) => {
  const { repairs, lostItems } = useTransactionStore();
  const { maintenances, disposals, vendors } = useMaintenanceStore();

  const kpis = useMemo(() => {
    return {
      underRepair: repairs.filter(r => r.status === 'In Progress' || r.status === 'Waiting Parts' || r.status === 'In Repair').length,
      repairCompleted: repairs.filter(r => r.status === 'Completed' || r.status === 'Repaired').length,
      pmDue: maintenances.filter(m => m.status === 'Scheduled').length,
      pmOverdue: maintenances.filter(m => m.status === 'Overdue').length,
      lost: lostItems.filter(l => l.status === 'Reported' || l.status === 'Pending Review').length,
      disposed: disposals.filter(d => d.status === 'Disposed').length,
      costThisMonth: repairs.reduce((sum, r) => sum + (r.repairCost || 0), 0),
    };
  }, [repairs, lostItems, maintenances, disposals]);

  const cards = [
    { title: 'Items Under Repair', value: kpis.underRepair, icon: Wrench, color: 'text-amber-500', bg: 'bg-amber-50 dark:bg-amber-900/20' },
    { title: 'Repairs Completed', value: kpis.repairCompleted, icon: CheckCircle, color: 'text-emerald-500', bg: 'bg-emerald-50 dark:bg-emerald-900/20' },
    { title: 'PM Due Soon', value: kpis.pmDue, icon: CalendarDays, color: 'text-blue-500', bg: 'bg-blue-50 dark:bg-blue-900/20' },
    { title: 'PM Overdue', value: kpis.pmOverdue, icon: Clock, color: 'text-rose-500', bg: 'bg-rose-50 dark:bg-rose-900/20' },
    { title: 'Active Lost Items', value: kpis.lost, icon: AlertTriangle, color: 'text-orange-500', bg: 'bg-orange-50 dark:bg-orange-900/20' },
    { title: 'Total Disposed', value: kpis.disposed, icon: Trash2, color: 'text-slate-500', bg: 'bg-slate-50 dark:bg-slate-900/20' },
    { title: 'Total Repair Cost', value: `$$${kpis.costThisMonth.toFixed(2)}`, icon: DollarSign, color: 'text-purple-500', bg: 'bg-purple-50 dark:bg-purple-900/20' },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {cards.map((c, i) => (
          <div key={i} className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center justify-between shadow-sm">
            <div>
              <p className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">{c.title}</p>
              <p className={`text-2xl font-black mt-1 ${c.color}`}>{c.value}</p>
            </div>
            <div className={`p-3 rounded-xl ${c.bg}`}>
              <c.icon className={`w-5 h-5 ${c.color}`} />
            </div>
          </div>
        ))}
      </div>
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <button onClick={() => onNavigate('new_repair')} className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800/80 transition flex flex-col items-center gap-2 text-center shadow-xs">
           <Wrench className="w-5 h-5 text-blue-500" />
           <span className="text-xs font-bold text-slate-700 dark:text-slate-300">Create Repair</span>
        </button>
        <button onClick={() => onNavigate('new_maintenance')} className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800/80 transition flex flex-col items-center gap-2 text-center shadow-xs">
           <CalendarDays className="w-5 h-5 text-emerald-500" />
           <span className="text-xs font-bold text-slate-700 dark:text-slate-300">Schedule PM</span>
        </button>
        <button onClick={() => onNavigate('new_lost')} className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800/80 transition flex flex-col items-center gap-2 text-center shadow-xs">
           <AlertTriangle className="w-5 h-5 text-orange-500" />
           <span className="text-xs font-bold text-slate-700 dark:text-slate-300">Report Lost</span>
        </button>
        <button onClick={() => onNavigate('new_disposal')} className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800/80 transition flex flex-col items-center gap-2 text-center shadow-xs">
           <Trash2 className="w-5 h-5 text-rose-500" />
           <span className="text-xs font-bold text-slate-700 dark:text-slate-300">Register Disposal</span>
        </button>
        <button onClick={() => onNavigate('reports')} className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800/80 transition flex flex-col items-center gap-2 text-center shadow-xs">
           <BarChart2 className="w-5 h-5 text-slate-500" />
           <span className="text-xs font-bold text-slate-700 dark:text-slate-300">View Reports</span>
        </button>
      </div>
    </div>
  );
};
