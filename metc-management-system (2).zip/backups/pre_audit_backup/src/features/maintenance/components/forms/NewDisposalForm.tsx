import React from 'react';
import { Button } from '../../../../components/ui/Button';

interface Props {
  onSubmit: () => void;
  onCancel: () => void;
}

export const NewDisposalForm: React.FC<Props> = ({ onSubmit, onCancel }) => {
  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm max-w-4xl mx-auto text-center">
      <h2 className="text-lg font-bold mb-4">Register Asset Disposal</h2>
      <p className="text-slate-500 mb-6">Form to register asset disposal. Fields include item, reason, disposal date, and value.</p>
      <div className="flex justify-center gap-3">
        <Button variant="outline" onClick={onCancel}>Cancel</Button>
        <Button variant="primary" onClick={onSubmit}>Register Disposal</Button>
      </div>
    </div>
  );
};
