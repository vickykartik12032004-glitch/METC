import React from 'react';
import { Button } from '../../../../components/ui/Button';

interface Props {
  onSubmit: () => void;
  onCancel: () => void;
}

export const NewLostItemForm: React.FC<Props> = ({ onSubmit, onCancel }) => {
  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm max-w-4xl mx-auto text-center">
      <h2 className="text-lg font-bold mb-4">Report Lost Item</h2>
      <p className="text-slate-500 mb-6">Form to report a lost item. Fields include item, worker, site, lost date, reason, investigation notes.</p>
      <div className="flex justify-center gap-3">
        <Button variant="outline" onClick={onCancel}>Cancel</Button>
        <Button variant="primary" onClick={onSubmit}>Submit Report</Button>
      </div>
    </div>
  );
};
