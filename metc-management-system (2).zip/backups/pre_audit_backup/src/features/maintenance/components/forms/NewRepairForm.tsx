import React, { useState } from 'react';
import { useAssetStore } from '../../../../store/useAssetStore';
import { useAuthStore } from '../../../../store/useAuthStore';
import { useMaintenanceStore } from '../../../../store/useMaintenanceStore';
import { createRepair } from '../../services/maintenance.service';
import { Button } from '../../../../components/ui/Button';
import { toast } from 'sonner';

interface Props {
  onSubmit: () => void;
  onCancel: () => void;
}

export const NewRepairForm: React.FC<Props> = ({ onSubmit, onCancel }) => {
  const { user } = useAuthStore();
  const { getAllAssets } = useAssetStore();
  const { vendors } = useMaintenanceStore();
  
  const allAssets = getAllAssets();

  const [selectedItemId, setSelectedItemId] = useState('');
  const [repairType, setRepairType] = useState('Corrective');
  const [repairPriority, setRepairPriority] = useState('Medium');
  const [issueDescription, setIssueDescription] = useState('');
  const [estimatedCost, setEstimatedCost] = useState('');
  const [repairVendor, setRepairVendor] = useState('');
  const [expectedCompletionDate, setExpectedCompletionDate] = useState('');
  const [remarks, setRemarks] = useState('');

  const selectedItem = allAssets.find(a => a.id === selectedItemId);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedItem) return toast.error('Please select an item');
    if (!issueDescription) return toast.error('Issue description is required');

    try {
      await createRepair({
        itemId: selectedItem.id,
        itemName: selectedItem.name,
        assetId: selectedItem.code,
        repairType: repairType as any,
        repairPriority: repairPriority as any,
        issueDescription,
        estimatedCost: estimatedCost ? parseFloat(estimatedCost) : undefined,
        repairVendor,
        expectedCompletionDate,
        remarks,
        createdBy: user?.name,
        handledBy: user?.name || 'Admin',
      });
      toast.success('Repair request created successfully');
      onSubmit();
    } catch (err: any) {
      toast.error(err.message || 'Failed to create repair request');
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm max-w-4xl mx-auto">
      <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100 mb-4">Create Repair Request</h2>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Select Item *</label>
            <select
              value={selectedItemId}
              onChange={(e) => setSelectedItemId(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              required
            >
              <option value="">-- Search & Select Asset --</option>
              {allAssets.map(a => (
                <option key={a.id} value={a.id}>
                  {a.code} - {a.name}
                </option>
              ))}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Repair Type</label>
              <select
                value={repairType}
                onChange={(e) => setRepairType(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
              >
                <option value="Corrective">Corrective</option>
                <option value="Preventive">Preventive</option>
                <option value="Calibration">Calibration</option>
                <option value="Inspection">Inspection</option>
                <option value="Warranty Repair">Warranty Repair</option>
                <option value="Emergency Repair">Emergency Repair</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Priority</label>
              <select
                value={repairPriority}
                onChange={(e) => setRepairPriority(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
              >
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
                <option value="High">High</option>
                <option value="Critical">Critical</option>
              </select>
            </div>
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Problem Description *</label>
          <textarea
            rows={3}
            value={issueDescription}
            onChange={(e) => setIssueDescription(e.target.value)}
            className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl resize-none font-medium"
            placeholder="Describe the issue or reason for repair..."
            required
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Repair Vendor</label>
            <select
              value={repairVendor}
              onChange={(e) => setRepairVendor(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
            >
              <option value="">-- Internal / Undecided --</option>
              {vendors.map(v => (
                <option key={v.id} value={v.vendorName}>{v.vendorName}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Estimated Cost</label>
            <input
              type="number"
              min="0"
              step="0.01"
              value={estimatedCost}
              onChange={(e) => setEstimatedCost(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
              placeholder="0.00"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Expected Completion</label>
            <input
              type="date"
              value={expectedCompletionDate}
              onChange={(e) => setExpectedCompletionDate(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Remarks</label>
          <input
            type="text"
            value={remarks}
            onChange={(e) => setRemarks(e.target.value)}
            className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
            placeholder="Additional notes..."
          />
        </div>

        <div className="flex justify-end gap-3 pt-4 border-t border-slate-100 dark:border-slate-800">
          <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
          <Button type="submit" variant="primary">Create Repair Request</Button>
        </div>
      </form>
    </div>
  );
};
