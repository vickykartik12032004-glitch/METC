import React from 'react';
import { useTransactionStore } from '../../../../store/useTransactionStore';
import { useMaintenanceStore } from '../../../../store/useMaintenanceStore';
import { Button } from '../../../../components/ui/Button';
import { FileBarChart2, FileText, FileSpreadsheet } from 'lucide-react';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import * as XLSX from 'xlsx';
import { formatDateTime } from '../../../../lib/utils';
import { DEFAULT_COMPANY } from '../../../../constants';

export const MaintenanceReports: React.FC = () => {
  const { repairs, lostItems } = useTransactionStore();
  const { maintenances, disposals } = useMaintenanceStore();

  const handleExportPDF = () => {
    const doc = new jsPDF();
    
    // Header
    doc.setFontSize(18);
    doc.text(`${DEFAULT_COMPANY.name} - Maintenance Report`, 14, 22);
    doc.setFontSize(11);
    doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 14, 30);
    
    // Repairs
    doc.setFontSize(14);
    doc.text('Repairs', 14, 45);
    (doc as any).autoTable({
      startY: 50,
      head: [['Code', 'Item', 'Status', 'Cost', 'Date Sent']],
      body: repairs.map(r => [
        r.repairCode, 
        r.itemName, 
        r.status, 
        r.repairCost ? `$${r.repairCost.toFixed(2)}` : '-', 
        new Date(r.sentDate).toLocaleDateString()
      ]),
      theme: 'grid',
      headStyles: { fillColor: [41, 128, 185] },
    });

    // Maintenance
    let finalY = (doc as any).lastAutoTable.finalY || 50;
    doc.text('Preventive Maintenance', 14, finalY + 15);
    (doc as any).autoTable({
      startY: finalY + 20,
      head: [['Code', 'Item', 'Freq', 'Status', 'Next Date']],
      body: maintenances.map(m => [
        m.maintenanceCode, 
        m.itemName, 
        m.frequency, 
        m.status, 
        new Date(m.nextMaintenance).toLocaleDateString()
      ]),
      theme: 'grid',
      headStyles: { fillColor: [39, 174, 96] },
    });

    // Lost & Disposed summary can be added similarly
    
    doc.save('Maintenance_Report.pdf');
  };

  const handleExportExcel = () => {
    const wb = XLSX.utils.book_new();

    const repairsData = repairs.map(r => ({
      Code: r.repairCode,
      Item: r.itemName,
      Type: r.repairType || 'Corrective',
      Status: r.status,
      Cost: r.repairCost || 0,
      SentDate: formatDateTime(r.sentDate),
    }));
    const wsRepairs = XLSX.utils.json_to_sheet(repairsData);
    XLSX.utils.book_append_sheet(wb, wsRepairs, "Repairs");

    const pmData = maintenances.map(m => ({
      Code: m.maintenanceCode,
      Item: m.itemName,
      Frequency: m.frequency,
      Status: m.status,
      NextMaintenance: new Date(m.nextMaintenance).toLocaleDateString(),
    }));
    const wsPM = XLSX.utils.json_to_sheet(pmData);
    XLSX.utils.book_append_sheet(wb, wsPM, "Preventive Maintenance");

    XLSX.writeFile(wb, "Maintenance_Report.xlsx");
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-8 text-center">
      <div className="w-16 h-16 bg-blue-50 text-blue-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
        <FileBarChart2 className="w-8 h-8" />
      </div>
      <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100">Enterprise Maintenance Reports</h2>
      <p className="text-slate-500 max-w-md mx-auto mt-2 mb-8">
        Generate comprehensive PDF and Excel reports for all repair activities, preventive maintenance schedules, lost assets, and disposals.
      </p>

      <div className="flex items-center justify-center gap-4">
        <Button variant="primary" icon={<FileText className="w-4 h-4" />} onClick={handleExportPDF}>
          Export PDF Report
        </Button>
        <Button variant="outline" icon={<FileSpreadsheet className="w-4 h-4 text-emerald-600" />} onClick={handleExportExcel}>
          Export Excel (.xlsx)
        </Button>
      </div>
    </div>
  );
};
