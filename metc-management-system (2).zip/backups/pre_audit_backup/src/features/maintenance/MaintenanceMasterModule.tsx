import React, { useState } from 'react';
import { MaintenanceDashboard } from './components/dashboard/MaintenanceDashboard';
import { RepairRequestsTable } from './components/tables/RepairRequestsTable';
import { MaintenanceScheduleTable } from './components/tables/MaintenanceScheduleTable';
import { LostItemsTable } from './components/tables/LostItemsTable';
import { DisposalTable } from './components/tables/DisposalTable';
import { VendorsTable } from './components/tables/VendorsTable';
import { NewRepairForm } from './components/forms/NewRepairForm';
import { NewMaintenanceForm } from './components/forms/NewMaintenanceForm';
import { NewLostItemForm } from './components/forms/NewLostItemForm';
import { NewDisposalForm } from './components/forms/NewDisposalForm';
import { MaintenanceReports } from './components/reports/MaintenanceReports';

import { 
  Wrench, 
  Settings, 
  CalendarDays, 
  AlertTriangle, 
  Trash2, 
  Users, 
  FileBarChart2, 
  Plus
} from 'lucide-react';
import { Button } from '../../components/ui/Button';

export type MaintenanceTabType =
  | 'dashboard'
  | 'repairs'
  | 'maintenance'
  | 'lost'
  | 'disposal'
  | 'vendors'
  | 'reports'
  | 'new_repair'
  | 'new_maintenance'
  | 'new_lost'
  | 'new_disposal';

export const MaintenanceMasterModule: React.FC = () => {
  const [activeTab, setActiveTab] = useState<MaintenanceTabType>('dashboard');

  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: Settings },
    { id: 'repairs', label: 'Repairs', icon: Wrench },
    { id: 'maintenance', label: 'PM Schedule', icon: CalendarDays },
    { id: 'lost', label: 'Lost Items', icon: AlertTriangle },
    { id: 'disposal', label: 'Disposals', icon: Trash2 },
    { id: 'vendors', label: 'Vendors', icon: Users },
    { id: 'reports', label: 'Reports', icon: FileBarChart2 },
  ];

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-4">
          <div>
            <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100 tracking-tight">Enterprise Maintenance & Repair</h1>
            <p className="text-xs text-slate-500 mt-1">Manage repairs, preventive maintenance, lost assets, and disposals</p>
          </div>
        </div>

        <div className="flex items-center gap-1 overflow-x-auto pb-1 scrollbar-hide">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id as MaintenanceTabType)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                activeTab === t.id
                  ? 'bg-blue-50 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              <t.icon className="w-4 h-4" />
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {activeTab === 'dashboard' && (
        <MaintenanceDashboard onNavigate={(tab) => setActiveTab(tab)} />
      )}

      {activeTab === 'repairs' && (
        <div className="space-y-4">
          <div className="flex justify-end">
             <Button variant="primary" icon={<Plus className="w-4 h-4" />} onClick={() => setActiveTab('new_repair')}>Create Repair Request</Button>
          </div>
          <RepairRequestsTable />
        </div>
      )}

      {activeTab === 'maintenance' && (
        <div className="space-y-4">
          <div className="flex justify-end">
             <Button variant="primary" icon={<Plus className="w-4 h-4" />} onClick={() => setActiveTab('new_maintenance')}>Schedule Maintenance</Button>
          </div>
          <MaintenanceScheduleTable />
        </div>
      )}

      {activeTab === 'lost' && (
        <div className="space-y-4">
          <div className="flex justify-end">
             <Button variant="primary" icon={<Plus className="w-4 h-4" />} onClick={() => setActiveTab('new_lost')}>Report Lost Item</Button>
          </div>
          <LostItemsTable />
        </div>
      )}

      {activeTab === 'disposal' && (
        <div className="space-y-4">
          <div className="flex justify-end">
             <Button variant="primary" icon={<Plus className="w-4 h-4" />} onClick={() => setActiveTab('new_disposal')}>Register Disposal</Button>
          </div>
          <DisposalTable />
        </div>
      )}

      {activeTab === 'vendors' && (
        <VendorsTable />
      )}

      {activeTab === 'reports' && (
        <MaintenanceReports />
      )}

      {activeTab === 'new_repair' && <NewRepairForm onCancel={() => setActiveTab('repairs')} onSubmit={() => setActiveTab('repairs')} />}
      {activeTab === 'new_maintenance' && <NewMaintenanceForm onCancel={() => setActiveTab('maintenance')} onSubmit={() => setActiveTab('maintenance')} />}
      {activeTab === 'new_lost' && <NewLostItemForm onCancel={() => setActiveTab('lost')} onSubmit={() => setActiveTab('lost')} />}
      {activeTab === 'new_disposal' && <NewDisposalForm onCancel={() => setActiveTab('disposal')} onSubmit={() => setActiveTab('disposal')} />}
    </div>
  );
};
