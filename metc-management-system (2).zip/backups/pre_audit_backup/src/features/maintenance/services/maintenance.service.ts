import { useTransactionStore } from '../../../store/useTransactionStore';
import { useAssetStore } from '../../../store/useAssetStore';
import { useMaintenanceStore } from '../../../store/useMaintenanceStore';
import { RepairRecord, LostItemRecord, MaintenanceRecord, DisposalRecord } from '../../../types';
import { useNotificationStore } from '../../../store/useNotificationStore';
import { logActivity } from '../../../services/activityLogService';

export async function createRepair(payload: Partial<RepairRecord>) {
  const transactionStore = useTransactionStore.getState();
  const assetStore = useAssetStore.getState();

  const newRepair = {
    ...payload,
    status: 'Pending',
    sentDate: new Date().toISOString(),
  } as Omit<RepairRecord, 'id' | 'repairCode'>;

  transactionStore.addRepair(newRepair);

  // Note: We might update asset status here depending on exact requirements.
  // For now we'll do it on "approve" or when it goes to "In Progress".
  
  const created = transactionStore.repairs[0]; // Assuming addRepair unshifts

  useNotificationStore.getState().addNotification({
    title: `Repair Request Created`,
    message: `Repair requested for ${payload.itemName}`,
    type: 'info',
  });
  
  await logActivity('Created', 'Repair', 'new_repair', { itemName: payload.itemName }, payload.createdBy || 'System');
  
  return created;
}

export async function approveRepair(id: string) {
  const transactionStore = useTransactionStore.getState();
  const assetStore = useAssetStore.getState();
  
  const repair = transactionStore.repairs.find(r => r.id === id);
  if (!repair) throw new Error("Repair not found");

  transactionStore.updateRepairStatus(id, 'In Progress');

  // Remove from Available Stock / Update item status
  const allAssets = assetStore.getAllAssets();
  const asset = allAssets.find(a => a.id === repair.itemId);
  if (asset) {
    if (asset.category === 'Equipment') assetStore.updateEquipment(asset.id, { status: 'Under Repair' });
    else if (asset.category === 'Tool') assetStore.updateTool(asset.id, { status: 'Under Repair' });
  }

  useNotificationStore.getState().addNotification({
    title: `Repair Approved`,
    message: `${repair.itemName} repair is now In Progress.`,
    type: 'success',
  });
  
  await logActivity('Updated', 'Repair', id, { status: 'In Progress' }, 'System');
}

export async function completeRepair(id: string, cost: number, notes: string) {
  const transactionStore = useTransactionStore.getState();
  const assetStore = useAssetStore.getState();
  
  const repair = transactionStore.repairs.find(r => r.id === id);
  if (!repair) throw new Error("Repair not found");

  // Since repairCost and actualReturnDate might not be updateable directly via updateRepairStatus,
  // we may need to update the whole record, but we only have updateRepairStatus in the store.
  // We'll update the status via the store method.
  transactionStore.updateRepairStatus(id, 'Completed');

  // Update item status back to Available
  const allAssets = assetStore.getAllAssets();
  const asset = allAssets.find(a => a.id === repair.itemId);
  if (asset) {
    if (asset.category === 'Equipment') assetStore.updateEquipment(asset.id, { status: 'Available' });
    else if (asset.category === 'Tool') assetStore.updateTool(asset.id, { status: 'Available' });
  }

  useNotificationStore.getState().addNotification({
    title: `Repair Completed`,
    message: `${repair.itemName} repair has been completed.`,
    type: 'success',
  });

  await logActivity('Updated', 'Repair', id, { status: 'Completed', cost }, 'System');
}

export async function createMaintenance(payload: Partial<MaintenanceRecord>) {
  const maintenanceStore = useMaintenanceStore.getState();
  maintenanceStore.addMaintenance(payload as any);

  useNotificationStore.getState().addNotification({
    title: `Maintenance Scheduled`,
    message: `Preventive maintenance scheduled for ${payload.itemName}`,
    type: 'info',
  });

  await logActivity('Created', 'Maintenance', 'new_mtn', { itemName: payload.itemName }, payload.responsiblePerson || 'System');
}

export async function registerLostItem(payload: Partial<LostItemRecord>) {
  const transactionStore = useTransactionStore.getState();
  
  const newLost = {
    ...payload,
    status: 'Reported',
    reportedDate: new Date().toISOString(),
  } as Omit<LostItemRecord, 'id' | 'lostCode'>;

  transactionStore.addLostItem(newLost);

  useNotificationStore.getState().addNotification({
    title: `Lost Item Reported`,
    message: `${payload.itemName} was reported lost.`,
    type: 'error',
  });

  await logActivity('Created', 'LostItem', 'new_lost', { itemName: payload.itemName }, payload.reportedBy || 'System');
}

export async function registerDisposal(payload: Partial<DisposalRecord>) {
  const maintenanceStore = useMaintenanceStore.getState();
  
  const newDisposal = {
    ...payload,
    status: 'Pending',
    disposalDate: new Date().toISOString(),
  } as Omit<DisposalRecord, 'id' | 'disposalCode'>;

  maintenanceStore.addDisposal(newDisposal);

  useNotificationStore.getState().addNotification({
    title: `Disposal Registered`,
    message: `Disposal requested for ${payload.itemName}.`,
    type: 'warning',
  });

  await logActivity('Created', 'Disposal', 'new_dsp', { itemName: payload.itemName }, payload.approvedBy || 'System');
}
