import React from 'react';
import { METCItem, AssetCategory } from '../../../types';
import { DuplicateMatch, DuplicateResolution } from '../utils/duplicateDetector';
import { Modal } from '../../../components/ui/Modal';
import { Button } from '../../../components/ui/Button';
import { AlertTriangle, Plus, ArrowUpRight, SkipForward, CheckCircle2, MapPin, Tag, Layers } from 'lucide-react';

interface DuplicateWarningModalProps {
  isOpen: boolean;
  onClose: () => void;
  duplicateMatch: DuplicateMatch | null;
  draftItem: {
    name: string;
    code?: string;
    category: AssetCategory;
    quantity: number;
    unit?: string;
    location?: string;
  } | null;
  onResolve: (resolution: DuplicateResolution) => void;
}

export const DuplicateWarningModal: React.FC<DuplicateWarningModalProps> = ({
  isOpen,
  onClose,
  duplicateMatch,
  draftItem,
  onResolve,
}) => {
  if (!duplicateMatch || !draftItem) return null;

  const { existingItem, reason, matchType } = duplicateMatch;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Duplicate Inventory Warning"
      maxWidth="max-w-2xl"
    >
      <div className="space-y-5">
        {/* Warning Banner */}
        <div className="p-3.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
          <div className="text-xs space-y-1">
            <div className="font-bold text-amber-900 dark:text-amber-200">
              Potential Duplicate Item Detected ({matchType.replace(/_/g, ' ')})
            </div>
            <p className="text-amber-700 dark:text-amber-300 leading-relaxed">
              {reason}
            </p>
          </div>
        </div>

        {/* Comparison Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          {/* Existing Item Card */}
          <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/80 space-y-2">
            <div className="flex items-center justify-between pb-1.5 border-b border-slate-200 dark:border-slate-800">
              <span className="font-bold text-slate-500 uppercase tracking-wider text-[10px]">
                Already In Inventory
              </span>
              <span className="px-2 py-0.5 rounded-full font-mono text-[10px] font-bold bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200">
                {existingItem.code}
              </span>
            </div>
            <div>
              <div className="font-black text-sm text-slate-900 dark:text-slate-100">{existingItem.name}</div>
              <div className="text-slate-500 flex items-center gap-2 mt-1">
                <span className="inline-flex items-center gap-1">
                  <Tag className="w-3 h-3 text-blue-500" />
                  {existingItem.category}
                </span>
                <span>•</span>
                <span className="inline-flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-slate-400" />
                  {existingItem.location || 'Store Rack'}
                </span>
              </div>
            </div>
            <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <span className="text-slate-500">Current Available Stock:</span>
              <span className="font-black text-emerald-600 dark:text-emerald-400 text-sm">
                {existingItem.availableQuantity} {existingItem.unit}
              </span>
            </div>
          </div>

          {/* New Proposed Item Card */}
          <div className="p-3.5 rounded-xl border border-blue-200 dark:border-blue-900/70 bg-blue-50/50 dark:bg-blue-950/20 space-y-2">
            <div className="flex items-center justify-between pb-1.5 border-b border-blue-200 dark:border-blue-900/60">
              <span className="font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider text-[10px]">
                Item Being Added
              </span>
              <span className="px-2 py-0.5 rounded-full font-mono text-[10px] font-bold bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200">
                {draftItem.code || 'Auto-generated'}
              </span>
            </div>
            <div>
              <div className="font-black text-sm text-slate-900 dark:text-slate-100">{draftItem.name}</div>
              <div className="text-slate-500 flex items-center gap-2 mt-1">
                <span className="inline-flex items-center gap-1">
                  <Tag className="w-3 h-3 text-blue-500" />
                  {draftItem.category}
                </span>
                <span>•</span>
                <span className="inline-flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-slate-400" />
                  {draftItem.location || 'Main Store'}
                </span>
              </div>
            </div>
            <div className="pt-2 border-t border-blue-200 dark:border-blue-900/60 flex items-center justify-between">
              <span className="text-slate-500">Incoming Batch Quantity:</span>
              <span className="font-black text-blue-600 dark:text-blue-400 text-sm">
                +{draftItem.quantity} {draftItem.unit || existingItem.unit}
              </span>
            </div>
          </div>
        </div>

        {/* 3-Way Choice Decision Controls */}
        <div className="space-y-2.5 pt-2">
          <div className="text-xs font-bold text-slate-700 dark:text-slate-300">
            Please choose how to handle this item:
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            {/* Option 1: Stock Adjustment */}
            <button
              type="button"
              onClick={() => {
                onResolve({
                  action: 'UPDATE_STOCK',
                  quantityToAdd: draftItem.quantity,
                  reason: `Authorized stock increase from duplicate entry batch (${draftItem.name})`,
                });
                onClose();
              }}
              className="p-3 rounded-xl border border-emerald-300 dark:border-emerald-800 bg-white dark:bg-slate-900 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 text-left transition-all group cursor-pointer"
            >
              <div className="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400 font-bold text-xs mb-1">
                <ArrowUpRight className="w-4 h-4 shrink-0" />
                <span>1. Update Stock</span>
              </div>
              <p className="text-[11px] text-slate-500 leading-tight">
                Add <strong>+{draftItem.quantity} {draftItem.unit}</strong> to existing stock ({existingItem.availableQuantity} &rarr; {existingItem.availableQuantity + draftItem.quantity}).
              </p>
            </button>

            {/* Option 2: Add As Genuine New Item */}
            <button
              type="button"
              onClick={() => {
                onResolve({ action: 'ADD_NEW' });
                onClose();
              }}
              className="p-3 rounded-xl border border-blue-300 dark:border-blue-800 bg-white dark:bg-slate-900 hover:bg-blue-50 dark:hover:bg-blue-950/40 text-left transition-all group cursor-pointer"
            >
              <div className="flex items-center gap-1.5 text-blue-600 dark:text-blue-400 font-bold text-xs mb-1">
                <Plus className="w-4 h-4 shrink-0" />
                <span>2. Create As New</span>
              </div>
              <p className="text-[11px] text-slate-500 leading-tight">
                Keep as a distinct inventory record with its own unique asset ID.
              </p>
            </button>

            {/* Option 3: Skip Duplicate */}
            <button
              type="button"
              onClick={() => {
                onResolve({ action: 'SKIP' });
                onClose();
              }}
              className="p-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 text-left transition-all group cursor-pointer"
            >
              <div className="flex items-center gap-1.5 text-slate-700 dark:text-slate-300 font-bold text-xs mb-1">
                <SkipForward className="w-4 h-4 shrink-0" />
                <span>3. Skip Item</span>
              </div>
              <p className="text-[11px] text-slate-500 leading-tight">
                Omit this row from import. Do not modify existing inventory.
              </p>
            </button>
          </div>
        </div>
      </div>
    </Modal>
  );
};
