import React, { useState, useMemo, useEffect } from 'react';
import {
  METCItem,
  AssetCategory,
  SiteIssueTransaction,
  SiteIssueItem,
  SiteReturnRecord,
  SiteReturnItem,
} from '../../../types';
import { useAssetStore } from '../../../store/useAssetStore';
import { useAuthStore } from '../../../store/useAuthStore';
import { useAdminStore } from '../../../store/useAdminStore';
import { useWorkerStore } from '../../../store/useWorkerStore';
import { cloudApi } from '../../../services/apiClient';
import { Button } from '../../../components/ui/Button';
import { Modal } from '../../../components/ui/Modal';
import {
  ArrowUpRight,
  ArrowDownLeft,
  Search,
  Plus,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  Building,
  User,
  Calendar,
  Layers,
  Printer,
  Eye,
  FileText,
  Clock,
  RotateCcw,
  Sparkles,
  Check,
  X
} from 'lucide-react';
import { toast } from 'sonner';

interface IssueLineDraft {
  id: string;
  itemId: string;
  item?: METCItem;
  requestedQuantity: number;
  isReusable: boolean;
  remarks: string;
}

interface ReturnLineDraft {
  itemId: string;
  itemCode: string;
  itemName: string;
  category: AssetCategory;
  issuedQuantity: number;
  previouslyReturned: number;
  outstandingQuantity: number;
  returnQty: number;
  workingQty: number;
  damagedQty: number;
  missingQty: number;
  condition: string;
  remarks: string;
}

interface SiteIssueReturnTabProps {
  items: METCItem[];
  onTransactionComplete?: () => void;
}

export const SiteIssueReturnTab: React.FC<SiteIssueReturnTabProps> = ({
  items,
  onTransactionComplete,
}) => {
  const { user } = useAuthStore();
  const { applyRemoteStockUpdated, applyRemoteAssetUpsert } = useAssetStore();
  const { sites, users } = useAdminStore();
  const { workers } = useWorkerStore();

  const [activeSubTab, setActiveSubTab] = useState<'new_issue' | 'active_issues'>('new_issue');

  // Issue Form State
  const [selectedSite, setSelectedSite] = useState<string>('Tuas Mega Logistics Depot');
  const [supervisorName, setSupervisorName] = useState<string>('David Tan');
  const [expectedReturnDate, setExpectedReturnDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() + 14);
    return d.toISOString().split('T')[0];
  });
  const [issueRemarks, setIssueRemarks] = useState<string>('');
  const [issueLines, setIssueLines] = useState<IssueLineDraft[]>([]);
  const [isSubmittingIssue, setIsSubmittingIssue] = useState<boolean>(false);
  const [isIssueConfirmOpen, setIsIssueConfirmOpen] = useState<boolean>(false);

  // Issues and Returns List state
  const [siteIssues, setSiteIssues] = useState<SiteIssueTransaction[]>([]);
  const [isLoadingIssues, setIsLoadingIssues] = useState<boolean>(false);
  const [searchFilter, setSearchFilter] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('All');

  // Return Modal State
  const [activeIssueForReturn, setActiveIssueForReturn] = useState<SiteIssueTransaction | null>(null);
  const [returnLines, setReturnLines] = useState<ReturnLineDraft[]>([]);
  const [returnRemarks, setReturnRemarks] = useState<string>('');
  const [isSubmittingReturn, setIsSubmittingReturn] = useState<boolean>(false);

  // View Receipt Modal State
  const [receiptTransaction, setReceiptTransaction] = useState<SiteIssueTransaction | null>(null);

  // Load existing company site options
  const siteOptions = useMemo(() => {
    const list = sites && sites.length > 0 ? sites.map((s) => s.siteName) : [];
    if (list.length === 0) {
      return [
        'Tuas Mega Logistics Depot',
        'Changi Airport Terminal 5 Expansion',
        'Corporate HQ - Marina Bay',
        'Jurong Innovation District Hub',
      ];
    }
    return list;
  }, [sites]);

  // Load supervisor options from users and workers
  const supervisorOptions = useMemo(() => {
    const names = new Set<string>();
    if (users && users.length > 0) {
      users.forEach((u) => {
        if (['Super Admin', 'Admin', 'Supervisor', 'Site Supervisor'].includes(u.role)) {
          names.add(u.fullName);
        }
      });
    }
    if (workers && workers.length > 0) {
      workers.forEach((w) => names.add(w.name));
    }
    if (names.size === 0) {
      return ['David Tan', 'Rajesh Kumar', 'Super Admin', 'Store Keeper'];
    }
    return Array.from(names);
  }, [users, workers]);

  // Load transactions from cloud
  const loadSiteIssues = async () => {
    setIsLoadingIssues(true);
    try {
      const res = await cloudApi.getSiteIssues();
      if (res && res.data) {
        setSiteIssues(res.data);
      }
    } catch (err) {
      console.warn('Failed to load site issues:', err);
    } finally {
      setIsLoadingIssues(false);
    }
  };

  useEffect(() => {
    loadSiteIssues();
  }, []);

  // Add Item Line to current Issue draft
  const handleAddIssueLine = (item: METCItem) => {
    if (item.availableQuantity <= 0) {
      toast.error(`"${item.name}" has zero available stock in store.`);
      return;
    }
    if (issueLines.some((l) => l.itemId === item.id)) {
      toast.warning(`"${item.name}" is already in this issue list.`);
      return;
    }

    const isReusable = item.category === 'Tool' || item.category === 'Equipment';
    const newLine: IssueLineDraft = {
      id: `line-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      itemId: item.id,
      item,
      requestedQuantity: 1,
      isReusable,
      remarks: '',
    };
    setIssueLines((prev) => [...prev, newLine]);
    toast.success(`Added "${item.name}" to dispatch lines.`);
  };

  const handleUpdateLineQty = (lineId: string, qty: number) => {
    setIssueLines((prev) =>
      prev.map((l) => {
        if (l.id !== lineId) return l;
        const maxAvail = l.item?.availableQuantity || 999;
        const validQty = Math.min(Math.max(1, qty), maxAvail);
        return { ...l, requestedQuantity: validQty };
      })
    );
  };

  const handleRemoveLine = (lineId: string) => {
    setIssueLines((prev) => prev.filter((l) => l.id !== lineId));
  };

  // Submit Issue Transaction
  const handlePostIssueTransaction = async () => {
    if (!selectedSite) {
      toast.error('Please select target Project Site');
      return;
    }
    if (!supervisorName) {
      toast.error('Please select responsible Site Supervisor');
      return;
    }
    if (issueLines.length === 0) {
      toast.error('Please add at least one inventory item to issue');
      return;
    }

    // Double check stock guards
    for (const line of issueLines) {
      const currentItem = items.find((i) => i.id === line.itemId);
      if (!currentItem || line.requestedQuantity > currentItem.availableQuantity) {
        toast.error(
          `Requested quantity (${line.requestedQuantity}) exceeds available stock (${currentItem?.availableQuantity || 0}) for "${line.item?.name}".`
        );
        return;
      }
    }

    setIsSubmittingIssue(true);
    const authorName = user?.name || 'Store Keeper';

    try {
      const payload = {
        site: selectedSite,
        supervisorId: '',
        supervisorName,
        issuer: authorName,
        expectedReturnDate,
        remarks: issueRemarks,
        items: issueLines.map((l) => ({
          itemId: l.itemId,
          requestedQuantity: l.requestedQuantity,
          isReusable: l.isReusable,
        })),
      };

      const res = await cloudApi.createSiteIssue(payload);
      if (res && res.data) {
        // Optimistically update stock in local store
        if (Array.isArray(res.updatedAssets)) {
          res.updatedAssets.forEach((upAsset) => {
            applyRemoteStockUpdated(upAsset.id, upAsset.availableQuantity, upAsset.status);
          });
        }

        toast.success(
          `Site Issue transaction "${res.data.reference}" posted successfully! Stock deducted.`
        );

        // Reset issue form
        setIssueLines([]);
        setIssueRemarks('');
        setIsIssueConfirmOpen(false);

        // Reload transactions and show active list
        await loadSiteIssues();
        setActiveSubTab('active_issues');
        setReceiptTransaction(res.data);

        if (onTransactionComplete) {
          onTransactionComplete();
        }
      }
    } catch (err: any) {
      toast.error(`Failed to post site issue: ${err.message || 'Server error'}`);
    } finally {
      setIsSubmittingIssue(false);
    }
  };

  // Open Return Modal for an existing issue transaction
  const handleOpenReturnModal = (tx: SiteIssueTransaction) => {
    setActiveIssueForReturn(tx);
    setReturnRemarks('');

    const lines: ReturnLineDraft[] = tx.items
      .filter((it) => it.isReusable) // Only returnable items
      .map((it) => {
        const outstanding = it.issuedQuantity - it.returnedQuantity;
        return {
          itemId: it.itemId,
          itemCode: it.itemCode,
          itemName: it.itemName,
          category: it.category,
          issuedQuantity: it.issuedQuantity,
          previouslyReturned: it.returnedQuantity,
          outstandingQuantity: Math.max(0, outstanding),
          returnQty: Math.max(0, outstanding),
          workingQty: Math.max(0, outstanding),
          damagedQty: 0,
          missingQty: 0,
          condition: 'Good Working Condition',
          remarks: '',
        };
      });

    setReturnLines(lines);
  };

  // Adjust return line quantities
  const handleReturnLineChange = (
    itemId: string,
    field: keyof ReturnLineDraft,
    val: any
  ) => {
    setReturnLines((prev) =>
      prev.map((l) => {
        if (l.itemId !== itemId) return l;
        const updated = { ...l, [field]: val };

        // Synchronize workingQty when returnQty changes
        if (field === 'returnQty') {
          const rQty = Math.min(Math.max(0, Number(val)), l.outstandingQuantity);
          updated.returnQty = rQty;
          updated.workingQty = Math.max(0, rQty - updated.damagedQty - updated.missingQty);
        }
        if (field === 'damagedQty' || field === 'missingQty') {
          const dmg = field === 'damagedQty' ? Number(val) : l.damagedQty;
          const mis = field === 'missingQty' ? Number(val) : l.missingQty;
          updated.workingQty = Math.max(0, updated.returnQty - dmg - mis);
        }
        return updated;
      })
    );
  };

  // Submit Return transaction
  const handleProcessReturn = async () => {
    if (!activeIssueForReturn) return;

    // Validate returns
    const activeReturns = returnLines.filter((l) => l.returnQty > 0);
    if (activeReturns.length === 0) {
      toast.error('Please specify a return quantity greater than zero for at least one item.');
      return;
    }

    for (const l of activeReturns) {
      if (l.returnQty > l.outstandingQuantity) {
        toast.error(`Return quantity for "${l.itemName}" exceeds outstanding issued quantity (${l.outstandingQuantity}).`);
        return;
      }
      if (l.workingQty + l.damagedQty + l.missingQty !== l.returnQty) {
        toast.error(`For "${l.itemName}", Working + Damaged + Missing quantities must equal Total Returned.`);
        return;
      }
    }

    setIsSubmittingReturn(true);
    const authorName = user?.name || 'Store Keeper';

    try {
      const payload = {
        issueId: activeIssueForReturn.id,
        receivedBy: authorName,
        remarks: returnRemarks,
        items: activeReturns.map((l) => ({
          itemId: l.itemId,
          returnQty: l.returnQty,
          workingQty: l.workingQty,
          damagedQty: l.damagedQty,
          missingQty: l.missingQty,
          condition: l.condition,
          remarks: l.remarks,
        })),
      };

      const res = await cloudApi.processSiteReturn(payload);
      if (res && res.success) {
        // Optimistically update stock in store for restored working items
        if (Array.isArray(res.updatedAssets)) {
          res.updatedAssets.forEach((upAsset) => {
            applyRemoteStockUpdated(upAsset.id, upAsset.availableQuantity, upAsset.status);
          });
        }

        toast.success('Return processed successfully! Working stock restored to available store.');
        setActiveIssueForReturn(null);
        await loadSiteIssues();

        if (onTransactionComplete) {
          onTransactionComplete();
        }
      }
    } catch (err: any) {
      toast.error(`Failed to process return: ${err.message || 'Server error'}`);
    } finally {
      setIsSubmittingReturn(false);
    }
  };

  // Filtered Site Issues List
  const filteredSiteIssues = useMemo(() => {
    return siteIssues.filter((tx) => {
      if (statusFilter !== 'All' && tx.status !== statusFilter) return false;
      if (!searchFilter.trim()) return true;

      const q = searchFilter.toLowerCase();
      return (
        tx.reference.toLowerCase().includes(q) ||
        tx.site.toLowerCase().includes(q) ||
        tx.supervisorName.toLowerCase().includes(q) ||
        tx.items.some((i) => i.itemName.toLowerCase().includes(q) || i.itemCode.toLowerCase().includes(q))
      );
    });
  }, [siteIssues, statusFilter, searchFilter]);

  return (
    <div className="space-y-6">
      {/* Navigation Sub-Tabs */}
      <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-2">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveSubTab('new_issue')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeSubTab === 'new_issue'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <ArrowUpRight className="w-4 h-4" />
            <span>New Site Issue Dispatch</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSubTab('active_issues')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeSubTab === 'active_issues'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <ArrowDownLeft className="w-4 h-4" />
            <span>Active Issues & Return Desk</span>
            <span className="px-1.5 py-0.2 rounded-full text-[10px] font-mono bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200">
              {siteIssues.filter((t) => t.status !== 'Completed').length}
            </span>
          </button>
        </div>

        <Button
          variant="outline"
          size="sm"
          icon={<RotateCcw className="w-3.5 h-3.5" />}
          onClick={loadSiteIssues}
          isLoading={isLoadingIssues}
        >
          Refresh
        </Button>
      </div>

      {/* ========================================================= */}
      {/* SUB-TAB 1: NEW SITE ISSUE FORM */}
      {/* ========================================================= */}
      {activeSubTab === 'new_issue' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Transaction Metadata & Line Entries */}
          <div className="lg:col-span-8 space-y-5">
            {/* Header Card */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="p-1.5 rounded-lg bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300">
                    <ArrowUpRight className="w-4 h-4" />
                  </span>
                  <h3 className="text-base font-black text-slate-900 dark:text-white">
                    Site Issue Dispatch Transaction
                  </h3>
                </div>
                <span className="text-xs font-mono font-bold text-slate-400">
                  MOUNTEC PTE LTD
                </span>
              </div>

              {/* Site, Supervisor, Date Inputs */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div>
                  <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    Target Construction Site *
                  </label>
                  <select
                    value={selectedSite}
                    onChange={(e) => setSelectedSite(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-medium focus:ring-2 focus:ring-blue-500"
                  >
                    {siteOptions.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    Responsible Supervisor *
                  </label>
                  <select
                    value={supervisorName}
                    onChange={(e) => setSupervisorName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-medium focus:ring-2 focus:ring-blue-500"
                  >
                    {supervisorOptions.map((sup) => (
                      <option key={sup} value={sup}>
                        {sup}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    Expected Return Date (Tools/Eqp)
                  </label>
                  <input
                    type="date"
                    value={expectedReturnDate}
                    onChange={(e) => setExpectedReturnDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1 text-xs">
                  Dispatch Remarks / Work Order Reference
                </label>
                <input
                  type="text"
                  value={issueRemarks}
                  onChange={(e) => setIssueRemarks(e.target.value)}
                  placeholder="e.g. Foundation pile cap casting phase 2 - Tower B"
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            {/* Line Items Table */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <h4 className="text-xs font-black text-slate-800 dark:text-slate-200 uppercase tracking-wider flex items-center gap-2">
                  <Layers className="w-4 h-4 text-blue-500" />
                  <span>Selected Dispatch Lines ({issueLines.length} Items)</span>
                </h4>
                {issueLines.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setIssueLines([])}
                    className="text-xs text-rose-600 dark:text-rose-400 font-bold hover:underline"
                  >
                    Clear All Lines
                  </button>
                )}
              </div>

              {issueLines.length === 0 ? (
                <div className="py-12 text-center text-slate-400 space-y-2 border border-dashed border-slate-200 dark:border-slate-800 rounded-xl">
                  <Layers className="w-8 h-8 mx-auto text-slate-300 dark:text-slate-700" />
                  <p className="text-xs font-bold text-slate-600 dark:text-slate-300">
                    No items selected for this transaction yet.
                  </p>
                  <p className="text-[11px] text-slate-400 max-w-sm mx-auto">
                    Pick items from the inventory catalog on the right to add them to this site dispatch.
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead className="bg-slate-50 dark:bg-slate-800/80 text-[11px] font-bold text-slate-600 dark:text-slate-300 border-b border-slate-200 dark:border-slate-700">
                      <tr>
                        <th className="py-2.5 px-3">Item Details</th>
                        <th className="py-2.5 px-3 text-center">Type</th>
                        <th className="py-2.5 px-3 text-right">Available</th>
                        <th className="py-2.5 px-3 text-center w-28">Issue Qty *</th>
                        <th className="py-2.5 px-3 text-right">Balance After</th>
                        <th className="py-2.5 px-3 text-center w-12">Remove</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {issueLines.map((line) => {
                        const available = line.item?.availableQuantity || 0;
                        const balance = available - line.requestedQuantity;
                        const isOver = line.requestedQuantity > available;

                        return (
                          <tr key={line.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                            <td className="py-2.5 px-3">
                              <div className="font-bold text-slate-900 dark:text-slate-100">
                                {line.item?.name}
                              </div>
                              <div className="text-[10px] text-slate-500 font-mono">
                                {line.item?.code} • {line.item?.category}
                              </div>
                            </td>

                            <td className="py-2.5 px-3 text-center">
                              <span
                                className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                  line.isReusable
                                    ? 'bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300'
                                    : 'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-300'
                                }`}
                              >
                                {line.isReusable ? 'Returnable' : 'Consumed'}
                              </span>
                            </td>

                            <td className="py-2.5 px-3 text-right font-mono text-slate-600 dark:text-slate-400">
                              {available} {line.item?.unit}
                            </td>

                            <td className="py-2.5 px-3 text-center">
                              <input
                                type="number"
                                min="1"
                                max={available}
                                value={line.requestedQuantity}
                                onChange={(e) => handleUpdateLineQty(line.id, Number(e.target.value))}
                                className={`w-20 px-2 py-1 text-center font-mono font-bold text-xs rounded-lg border ${
                                  isOver
                                    ? 'border-rose-400 bg-rose-50 text-rose-800'
                                    : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800'
                                } focus:outline-none focus:ring-2 focus:ring-blue-500`}
                              />
                            </td>

                            <td className="py-2.5 px-3 text-right font-mono font-bold">
                              <span className={balance <= 0 ? 'text-amber-600 dark:text-amber-400' : 'text-slate-700 dark:text-slate-300'}>
                                {balance} {line.item?.unit}
                              </span>
                            </td>

                            <td className="py-2.5 px-3 text-center">
                              <button
                                type="button"
                                onClick={() => handleRemoveLine(line.id)}
                                className="p-1 rounded text-slate-400 hover:text-rose-600 transition-colors"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}

              {/* Action Toolbar */}
              {issueLines.length > 0 && (
                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                  <span className="text-xs text-slate-500">
                    Total Lines: <strong>{issueLines.length}</strong> | Items will be atomically deducted from central store stock.
                  </span>
                  <Button
                    variant="primary"
                    size="sm"
                    icon={<CheckCircle2 className="w-4 h-4" />}
                    onClick={() => setIsIssueConfirmOpen(true)}
                  >
                    Review & Confirm Dispatch
                  </Button>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Inventory Quick Picker */}
          <div className="lg:col-span-4 space-y-4">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-black text-slate-800 dark:text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                  <Search className="w-4 h-4 text-blue-500" />
                  <span>Pick Store Inventory</span>
                </h4>
                <span className="text-[10px] text-slate-400 font-mono">
                  {items.filter((i) => i.availableQuantity > 0).length} available
                </span>
              </div>

              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="Quick search item name or code..."
                  onChange={(e) => setSearchFilter(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="max-h-[520px] overflow-y-auto space-y-1.5 pr-1 divide-y divide-slate-100 dark:divide-slate-800">
                {items
                  .filter((item) => {
                    if (item.availableQuantity <= 0) return false;
                    if (!searchFilter.trim()) return true;
                    const q = searchFilter.toLowerCase();
                    return (
                      item.name.toLowerCase().includes(q) ||
                      item.code.toLowerCase().includes(q) ||
                      item.category.toLowerCase().includes(q)
                    );
                  })
                  .slice(0, 40)
                  .map((item) => {
                    const isSelected = issueLines.some((l) => l.itemId === item.id);

                    return (
                      <div
                        key={item.id}
                        className="pt-1.5 first:pt-0 flex items-center justify-between p-2 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors"
                      >
                        <div className="space-y-0.5">
                          <div className="font-bold text-xs text-slate-900 dark:text-slate-100 line-clamp-1">
                            {item.name}
                          </div>
                          <div className="text-[10px] text-slate-500 font-mono flex items-center gap-2">
                            <span>{item.code}</span>
                            <span>•</span>
                            <span>{item.category}</span>
                            <span>•</span>
                            <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                              {item.availableQuantity} {item.unit}
                            </span>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => handleAddIssueLine(item)}
                          disabled={isSelected}
                          className={`px-2.5 py-1 text-[11px] font-bold rounded-lg transition-all ${
                            isSelected
                              ? 'bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
                              : 'bg-blue-50 text-blue-700 hover:bg-blue-600 hover:text-white dark:bg-blue-950/60 dark:text-blue-300 dark:hover:bg-blue-600 dark:hover:text-white cursor-pointer'
                          }`}
                        >
                          {isSelected ? 'Added ✓' : '+ Add'}
                        </button>
                      </div>
                    );
                  })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* SUB-TAB 2: ACTIVE SITE ISSUES & RETURN DESK */}
      {/* ========================================================= */}
      {activeSubTab === 'active_issues' && (
        <div className="space-y-4">
          {/* Search & Filter Controls */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 text-xs">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                placeholder="Search by reference (e.g. ISS-2026-001), site, supervisor, or item..."
                className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-2">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium focus:ring-2 focus:ring-blue-500"
              >
                <option value="All">All Statuses</option>
                <option value="Active">Active Dispatches</option>
                <option value="Partially Returned">Partially Returned</option>
                <option value="Completed">Completed</option>
              </select>
            </div>
          </div>

          {/* Transactions Table */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs overflow-hidden">
            {isLoadingIssues ? (
              <div className="py-16 text-center text-slate-500 text-xs">
                Loading site issues...
              </div>
            ) : filteredSiteIssues.length === 0 ? (
              <div className="py-16 text-center text-slate-400 space-y-2">
                <FileText className="w-8 h-8 mx-auto text-slate-300 dark:text-slate-700" />
                <p className="text-xs font-bold text-slate-600 dark:text-slate-300">
                  No site issue transactions found.
                </p>
                <p className="text-[11px] text-slate-400">
                  Dispatch items to construction sites via the &ldquo;New Site Issue Dispatch&rdquo; tab.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead className="bg-slate-50 dark:bg-slate-800 text-[11px] font-bold text-slate-600 dark:text-slate-300 border-b border-slate-200 dark:border-slate-700">
                    <tr>
                      <th className="py-2.5 px-3">Reference</th>
                      <th className="py-2.5 px-3">Site & Supervisor</th>
                      <th className="py-2.5 px-3">Issue Date</th>
                      <th className="py-2.5 px-3">Items Dispatched</th>
                      <th className="py-2.5 px-3 text-center">Return Status</th>
                      <th className="py-2.5 px-3 text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {filteredSiteIssues.map((tx) => {
                      const totalItemsCount = tx.items.reduce((acc, i) => acc + i.issuedQuantity, 0);
                      const returnableCount = tx.items
                        .filter((i) => i.isReusable)
                        .reduce((acc, i) => acc + (i.issuedQuantity - i.returnedQuantity), 0);

                      return (
                        <tr key={tx.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                          <td className="py-3 px-3">
                            <span className="font-mono font-black text-blue-600 dark:text-blue-400">
                              {tx.reference}
                            </span>
                            <span className="block text-[10px] text-slate-400">Issuer: {tx.issuer}</span>
                          </td>

                          <td className="py-3 px-3">
                            <div className="font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                              <Building className="w-3.5 h-3.5 text-slate-400" />
                              <span>{tx.site}</span>
                            </div>
                            <div className="text-[10px] text-slate-500 flex items-center gap-1 mt-0.5">
                              <User className="w-3 h-3 text-slate-400" />
                              <span>Supervisor: {tx.supervisorName}</span>
                            </div>
                          </td>

                          <td className="py-3 px-3 text-slate-600 dark:text-slate-400 font-mono text-[11px]">
                            {new Date(tx.date).toLocaleDateString()}
                            {tx.expectedReturnDate && (
                              <span className="block text-[10px] text-slate-400">
                                Due: {tx.expectedReturnDate}
                              </span>
                            )}
                          </td>

                          <td className="py-3 px-3">
                            <span className="font-bold text-slate-800 dark:text-slate-200">
                              {tx.items.length} line(s) ({totalItemsCount} units)
                            </span>
                            <div className="text-[10px] text-slate-500 line-clamp-1 mt-0.5">
                              {tx.items.map((i) => `${i.itemName} (x${i.issuedQuantity})`).join(', ')}
                            </div>
                          </td>

                          <td className="py-3 px-3 text-center">
                            <span
                              className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                                tx.status === 'Completed'
                                  ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                  : tx.status === 'Partially Returned'
                                  ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                                  : 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                              }`}
                            >
                              {tx.status}
                            </span>
                            {returnableCount > 0 && (
                              <span className="block text-[10px] text-amber-600 dark:text-amber-400 font-mono font-semibold mt-0.5">
                                {returnableCount} tools outstanding
                              </span>
                            )}
                          </td>

                          <td className="py-3 px-3 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              {returnableCount > 0 && (
                                <button
                                  type="button"
                                  onClick={() => handleOpenReturnModal(tx)}
                                  className="px-2.5 py-1 text-[11px] font-bold rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-600 hover:text-white dark:bg-emerald-950/60 dark:text-emerald-300 transition-all flex items-center gap-1 cursor-pointer"
                                >
                                  <ArrowDownLeft className="w-3 h-3" />
                                  <span>Receive Return</span>
                                </button>
                              )}

                              <button
                                type="button"
                                onClick={() => setReceiptTransaction(tx)}
                                className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 transition-colors cursor-pointer"
                                title="View / Print Receipt"
                              >
                                <Printer className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* CONFIRM ISSUE MODAL */}
      {/* ========================================================= */}
      <Modal
        isOpen={isIssueConfirmOpen}
        onClose={() => setIsIssueConfirmOpen(false)}
        title="Confirm Site Issue Dispatch"
        maxWidth="max-w-xl"
      >
        <div className="space-y-4 text-xs">
          <div className="p-3.5 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900/60 text-blue-900 dark:text-blue-200">
            <p className="font-bold">Post Dispatch Confirmation</p>
            <p className="mt-1 text-slate-600 dark:text-slate-300">
              Dispatched items will be deducted immediately from available store stock.
            </p>
          </div>

          <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl space-y-1.5 border border-slate-200 dark:border-slate-700">
            <div className="flex justify-between">
              <span className="text-slate-500">Site:</span>
              <span className="font-bold text-slate-800 dark:text-slate-100">{selectedSite}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Supervisor:</span>
              <span className="font-bold text-slate-800 dark:text-slate-100">{supervisorName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Total Items:</span>
              <span className="font-bold text-slate-800 dark:text-slate-100">{issueLines.length} line(s)</span>
            </div>
          </div>

          <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-200 dark:border-slate-800">
            <Button variant="outline" size="sm" onClick={() => setIsIssueConfirmOpen(false)}>
              Cancel
            </Button>
            <Button
              variant="primary"
              size="sm"
              isLoading={isSubmittingIssue}
              onClick={handlePostIssueTransaction}
            >
              Post & Deduct Stock
            </Button>
          </div>
        </div>
      </Modal>

      {/* ========================================================= */}
      {/* RECEIVE RETURN MODAL */}
      {/* ========================================================= */}
      {activeIssueForReturn && (
        <Modal
          isOpen={!!activeIssueForReturn}
          onClose={() => setActiveIssueForReturn(null)}
          title={`Process Return — Ref: ${activeIssueForReturn.reference}`}
          maxWidth="max-w-2xl"
        >
          <div className="space-y-4 text-xs">
            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 flex justify-between">
              <div>
                <span className="text-slate-400 block text-[10px]">Site:</span>
                <span className="font-bold text-slate-900 dark:text-slate-100">{activeIssueForReturn.site}</span>
              </div>
              <div className="text-right">
                <span className="text-slate-400 block text-[10px]">Supervisor:</span>
                <span className="font-bold text-slate-900 dark:text-slate-100">{activeIssueForReturn.supervisorName}</span>
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider text-[11px]">
                Return Quantities & Condition:
              </h4>

              <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
                {returnLines.map((line) => (
                  <div
                    key={line.itemId}
                    className="p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 space-y-2.5"
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="font-bold text-slate-900 dark:text-slate-100 text-xs">
                          {line.itemName}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono block">
                          {line.itemCode} • Outstanding: {line.outstandingQuantity} units
                        </span>
                      </div>
                      <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400">
                        Restores working qty to store
                      </span>
                    </div>

                    <div className="grid grid-cols-4 gap-2 text-center text-xs">
                      <div>
                        <span className="text-[10px] text-slate-400 block mb-0.5">Total Return</span>
                        <input
                          type="number"
                          min="0"
                          max={line.outstandingQuantity}
                          value={line.returnQty}
                          onChange={(e) =>
                            handleReturnLineChange(line.itemId, 'returnQty', Number(e.target.value))
                          }
                          className="w-full text-center py-1 font-mono font-bold rounded border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                        />
                      </div>

                      <div>
                        <span className="text-[10px] text-emerald-600 block mb-0.5 font-bold">Working (Restored)</span>
                        <input
                          type="number"
                          min="0"
                          max={line.returnQty}
                          value={line.workingQty}
                          onChange={(e) =>
                            handleReturnLineChange(line.itemId, 'workingQty', Number(e.target.value))
                          }
                          className="w-full text-center py-1 font-mono font-bold rounded border border-emerald-300 dark:border-emerald-800 bg-emerald-50/50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300"
                        />
                      </div>

                      <div>
                        <span className="text-[10px] text-amber-600 block mb-0.5 font-bold">Damaged (Repair)</span>
                        <input
                          type="number"
                          min="0"
                          max={line.returnQty}
                          value={line.damagedQty}
                          onChange={(e) =>
                            handleReturnLineChange(line.itemId, 'damagedQty', Number(e.target.value))
                          }
                          className="w-full text-center py-1 font-mono font-bold rounded border border-amber-300 dark:border-amber-800 bg-amber-50/50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300"
                        />
                      </div>

                      <div>
                        <span className="text-[10px] text-rose-600 block mb-0.5 font-bold">Missing (Lost)</span>
                        <input
                          type="number"
                          min="0"
                          max={line.returnQty}
                          value={line.missingQty}
                          onChange={(e) =>
                            handleReturnLineChange(line.itemId, 'missingQty', Number(e.target.value))
                          }
                          className="w-full text-center py-1 font-mono font-bold rounded border border-rose-300 dark:border-rose-800 bg-rose-50/50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Return Inspection Remarks
              </label>
              <input
                type="text"
                value={returnRemarks}
                onChange={(e) => setReturnRemarks(e.target.value)}
                placeholder="e.g. Returned after completing pile foundation works. Grinder motor cleaned."
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
              />
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-200 dark:border-slate-800">
              <Button variant="outline" size="sm" onClick={() => setActiveIssueForReturn(null)}>
                Cancel
              </Button>
              <Button
                variant="primary"
                size="sm"
                isLoading={isSubmittingReturn}
                onClick={handleProcessReturn}
              >
                Post Return & Restore Stock
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* ========================================================= */}
      {/* VIEW / PRINT TRANSACTION RECEIPT MODAL */}
      {/* ========================================================= */}
      {receiptTransaction && (
        <Modal
          isOpen={!!receiptTransaction}
          onClose={() => setReceiptTransaction(null)}
          title="Official Material Dispatch Receipt"
          maxWidth="max-w-2xl"
        >
          <div className="space-y-5 p-2 bg-white text-slate-900 text-xs font-sans">
            {/* Receipt Header with Company Branding */}
            <div className="border-b-2 border-slate-900 pb-3 flex items-start justify-between">
              <div>
                <h2 className="text-base font-black tracking-tight text-slate-900 uppercase">
                  MOUNTEC PTE LTD
                </h2>
                <p className="text-[11px] text-slate-600">
                  Engineering & Construction Store Management
                </p>
                <p className="text-[10px] text-slate-500">
                  10 Anson Road, International Plaza, Singapore
                </p>
              </div>
              <div className="text-right">
                <span className="font-mono font-black text-sm text-blue-700 block">
                  {receiptTransaction.reference}
                </span>
                <span className="text-[10px] text-slate-500 font-mono">
                  {new Date(receiptTransaction.date).toLocaleString()}
                </span>
              </div>
            </div>

            {/* Transaction Metadata Info Grid */}
            <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs">
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Project Site:</span>
                <span className="font-black text-slate-900">{receiptTransaction.site}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Authorized Supervisor:</span>
                <span className="font-black text-slate-900">{receiptTransaction.supervisorName}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Store Issuer:</span>
                <span className="font-bold text-slate-800">{receiptTransaction.issuer}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Expected Return:</span>
                <span className="font-mono text-slate-800">
                  {receiptTransaction.expectedReturnDate || 'N/A (Consumed)'}
                </span>
              </div>
            </div>

            {/* Dispatched Lines Table */}
            <div>
              <table className="w-full text-left border-collapse text-xs">
                <thead className="bg-slate-100 border-y border-slate-300 font-bold text-slate-700">
                  <tr>
                    <th className="py-2 px-2.5">Code</th>
                    <th className="py-2 px-2.5">Description</th>
                    <th className="py-2 px-2.5 text-center">Category</th>
                    <th className="py-2 px-2.5 text-center">Qty</th>
                    <th className="py-2 px-2.5 text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 font-mono">
                  {receiptTransaction.items.map((it) => (
                    <tr key={it.itemId}>
                      <td className="py-2 px-2.5 font-bold text-blue-700">{it.itemCode}</td>
                      <td className="py-2 px-2.5 font-sans font-bold text-slate-900">{it.itemName}</td>
                      <td className="py-2 px-2.5 text-center font-sans text-slate-600">{it.category}</td>
                      <td className="py-2 px-2.5 text-center font-bold text-slate-900">
                        {it.issuedQuantity} {it.unit}
                      </td>
                      <td className="py-2 px-2.5 text-right font-sans text-slate-600">{it.status}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Remarks */}
            {receiptTransaction.remarks && (
              <p className="text-[11px] text-slate-600 italic">
                <strong>Remarks:</strong> {receiptTransaction.remarks}
              </p>
            )}

            {/* Signature Blocks */}
            <div className="grid grid-cols-2 gap-8 pt-8 border-t border-slate-300 text-center text-xs">
              <div>
                <div className="border-b border-slate-400 pb-6 mb-1 font-mono text-[11px] text-slate-600">
                  {receiptTransaction.issuer}
                </div>
                <span className="text-[10px] font-bold text-slate-500 uppercase">
                  Issued By (Store Keeper)
                </span>
              </div>
              <div>
                <div className="border-b border-slate-400 pb-6 mb-1 font-mono text-[11px] text-slate-600">
                  {receiptTransaction.supervisorName}
                </div>
                <span className="text-[10px] font-bold text-slate-500 uppercase">
                  Received By (Site Supervisor)
                </span>
              </div>
            </div>

            {/* Print Action */}
            <div className="flex justify-end gap-2 pt-3 border-t border-slate-200">
              <Button
                variant="outline"
                size="sm"
                icon={<Printer className="w-3.5 h-3.5" />}
                onClick={() => window.print()}
              >
                Print Receipt
              </Button>
              <Button variant="primary" size="sm" onClick={() => setReceiptTransaction(null)}>
                Close
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
