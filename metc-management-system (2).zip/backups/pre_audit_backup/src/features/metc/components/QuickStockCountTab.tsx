import React, { useState, useMemo, useEffect } from 'react';
import { METCItem, AssetCategory, StockAdjustment } from '../../../types';
import { useAssetStore } from '../../../store/useAssetStore';
import { useAuthStore } from '../../../store/useAuthStore';
import { cloudApi } from '../../../services/apiClient';
import { Button } from '../../../components/ui/Button';
import { Modal } from '../../../components/ui/Modal';
import {
  ClipboardCheck,
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  History,
  RotateCcw,
  Save,
  Check,
  Layers,
  ArrowUpDown,
  Tag,
  MapPin,
  Calendar,
  X
} from 'lucide-react';
import { toast } from 'sonner';

interface CountEntry {
  itemId: string;
  countedQuantity: number;
  reason: string;
  notes: string;
  isCounted: boolean;
}

const DISCREPANCY_REASONS = [
  'Physical Count Correction',
  'Found Surplus Item',
  'Damaged / Scrapped on Site',
  'Missing / Unaccounted',
  'Site Usage Not Yet Recorded',
  'Routine Cycle Count Verification',
];

interface QuickStockCountTabProps {
  items: METCItem[];
  onCountApplied?: () => void;
}

export const QuickStockCountTab: React.FC<QuickStockCountTabProps> = ({
  items,
  onCountApplied,
}) => {
  const { user } = useAuthStore();
  const { applyRemoteAssetUpsert } = useAssetStore();

  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<AssetCategory | 'All'>('All');
  const [locationFilter, setLocationFilter] = useState('All');

  // Count session entries: itemId -> CountEntry
  const [countEntries, setCountEntries] = useState<Record<string, CountEntry>>(() => {
    try {
      const saved = localStorage.getItem('mountec_quick_count_draft');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // Save drafts to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('mountec_quick_count_draft', JSON.stringify(countEntries));
    } catch {
      // ignore
    }
  }, [countEntries]);

  // Stock Adjustment History state
  const [historyList, setHistoryList] = useState<StockAdjustment[]>([]);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isLoadingHistory, setIsLoadingHistory] = useState(false);

  // Confirmation Modal
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Distinct locations
  const locationOptions = useMemo(() => {
    const locs = new Set<string>();
    items.forEach((item) => {
      if (item.location) locs.add(item.location);
    });
    return ['All', ...Array.from(locs).sort()];
  }, [items]);

  // Filtered Items for Counting
  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      if (categoryFilter !== 'All' && item.category !== categoryFilter) return false;
      if (locationFilter !== 'All' && item.location !== locationFilter) return false;
      if (!searchQuery.trim()) return true;

      const q = searchQuery.toLowerCase();
      return (
        item.name.toLowerCase().includes(q) ||
        item.code.toLowerCase().includes(q) ||
        (item.location && item.location.toLowerCase().includes(q)) ||
        item.category.toLowerCase().includes(q)
      );
    });
  }, [items, categoryFilter, locationFilter, searchQuery]);

  // Counted items summary
  const sessionSummary = useMemo(() => {
    let completedCount = 0;
    let totalDifference = 0;
    let discrepanciesCount = 0;

    (Object.entries(countEntries) as [string, CountEntry][]).forEach(([itemId, entry]) => {
      if (entry.isCounted) {
        completedCount++;
        const item = items.find((i) => i.id === itemId);
        if (item) {
          const diff = entry.countedQuantity - item.availableQuantity;
          totalDifference += diff;
          if (diff !== 0) {
            discrepanciesCount++;
          }
        }
      }
    });

    const remainingCount = items.length - completedCount;

    return {
      completedCount,
      remainingCount,
      totalDifference,
      discrepanciesCount,
    };
  }, [countEntries, items]);

  // Update physical count input
  const handleSetCount = (itemId: string, countedVal: number) => {
    const safeVal = Math.max(0, countedVal);
    setCountEntries((prev) => {
      const existing = prev[itemId] || {
        itemId,
        countedQuantity: safeVal,
        reason: 'Physical Count Correction',
        notes: '',
        isCounted: true,
      };
      return {
        ...prev,
        [itemId]: {
          ...existing,
          countedQuantity: safeVal,
          isCounted: true,
        },
      };
    });
  };

  // Update reason
  const handleSetReason = (itemId: string, reason: string) => {
    setCountEntries((prev) => {
      const existing = prev[itemId];
      if (!existing) return prev;
      return {
        ...prev,
        [itemId]: { ...existing, reason },
      };
    });
  };

  // Mark item as confirmed matched (Counted = Recorded)
  const handleConfirmMatch = (item: METCItem) => {
    handleSetCount(item.id, item.availableQuantity);
    toast.success(`"${item.name}" verified matching recorded stock (${item.availableQuantity} ${item.unit}).`);
  };

  // Clear single item count
  const handleResetItemCount = (itemId: string) => {
    setCountEntries((prev) => {
      const updated = { ...prev };
      delete updated[itemId];
      return updated;
    });
  };

  // Reset entire session draft
  const handleResetSession = () => {
    if (window.confirm('Reset all counted values in this counting draft session?')) {
      setCountEntries({});
      localStorage.removeItem('mountec_quick_count_draft');
      toast.info('Stock count draft reset');
    }
  };

  // Load History
  const handleOpenHistory = async () => {
    setIsHistoryOpen(true);
    setIsLoadingHistory(true);
    try {
      const res = await cloudApi.getStockAdjustments();
      if (res && res.data) {
        setHistoryList(res.data);
      }
    } catch (err) {
      console.warn('Failed to load stock adjustment history:', err);
    } finally {
      setIsLoadingHistory(false);
    }
  };

  // Submit confirmed count to update stock atomically
  const handleApplyCounts = async () => {
    const countedEntriesList = (Object.values(countEntries) as CountEntry[]).filter((e) => e.isCounted);
    if (countedEntriesList.length === 0) {
      toast.error('No items have been counted yet in this session.');
      return;
    }

    setIsSubmitting(true);
    const authorName = user?.name || 'Store Keeper';

    try {
      let updatedCount = 0;

      for (const entry of countedEntriesList) {
        const item = items.find((i) => i.id === entry.itemId);
        if (!item) continue;

        const prevQty = item.availableQuantity;
        const newQty = entry.countedQuantity;
        const diff = newQty - prevQty;

        // Create authorized stock adjustment record
        await cloudApi.createStockAdjustment({
          itemId: item.id,
          itemName: item.name,
          itemCode: item.code,
          category: item.category,
          previousQuantity: prevQty,
          newQuantity: newQty,
          difference: diff,
          reason: entry.reason || 'Physical Inventory Count',
          countedBy: authorName,
          location: item.location,
          remarks: entry.notes || undefined,
        });

        // Update local asset store state atomically
        applyRemoteAssetUpsert(item.category, {
          ...item,
          quantity: item.quantity + diff,
          availableQuantity: newQty,
          status: newQty > (item.minQuantityThreshold || 5) ? 'Available' : (newQty > 0 ? 'Low Stock' : 'Out of Stock'),
        });

        updatedCount++;
      }

      toast.success(
        `Physical Count Confirmed! ${updatedCount} stock record(s) updated and audit adjustments logged.`
      );

      // Reset count session
      setCountEntries({});
      localStorage.removeItem('mountec_quick_count_draft');
      setIsConfirmModalOpen(false);

      if (onCountApplied) {
        onCountApplied();
      }
    } catch (err: any) {
      toast.error(`Failed to apply count: ${err.message || 'Server error'}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300">
                <ClipboardCheck className="w-4 h-4" />
              </span>
              <h2 className="text-base sm:text-lg font-black text-slate-900 dark:text-white">
                Quick Physical Stock Count
              </h2>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Rapid live physical inventory counting. Enter counted quantities, review variances, and submit authorized stock adjustments with complete immutable history.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              icon={<History className="w-4 h-4 text-slate-600" />}
              onClick={handleOpenHistory}
            >
              Adjustment History
            </Button>

            <Button
              variant="outline"
              size="sm"
              icon={<RotateCcw className="w-4 h-4 text-rose-500" />}
              onClick={handleResetSession}
              disabled={sessionSummary.completedCount === 0}
            >
              Reset Session
            </Button>

            <Button
              variant="primary"
              size="sm"
              icon={<Save className="w-4 h-4" />}
              onClick={() => setIsConfirmModalOpen(true)}
              disabled={sessionSummary.completedCount === 0}
            >
              Confirm & Post Count ({sessionSummary.completedCount} Items)
            </Button>
          </div>
        </div>

        {/* Count Progress Bar & Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 text-xs">
          <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
            <span className="text-slate-400 block text-[10px] uppercase font-bold">Total Expected Items</span>
            <span className="text-base font-black text-slate-800 dark:text-slate-100">{items.length}</span>
          </div>

          <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/60">
            <span className="text-emerald-700 dark:text-emerald-300 block text-[10px] uppercase font-bold flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Counted Items
            </span>
            <span className="text-base font-black text-emerald-700 dark:text-emerald-300">
              {sessionSummary.completedCount} / {items.length}
            </span>
          </div>

          <div className="p-2.5 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900/60">
            <span className="text-blue-700 dark:text-blue-300 block text-[10px] uppercase font-bold">Remaining To Count</span>
            <span className="text-base font-black text-blue-700 dark:text-blue-300">{sessionSummary.remainingCount}</span>
          </div>

          <div className={`p-2.5 rounded-xl border ${sessionSummary.discrepanciesCount > 0 ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-900/60 text-amber-700 dark:text-amber-300' : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-500'}`}>
            <span className="block text-[10px] uppercase font-bold flex items-center gap-1">
              <AlertTriangle className="w-3 h-3" /> Discrepancies
            </span>
            <span className="text-base font-black">
              {sessionSummary.discrepanciesCount} ({sessionSummary.totalDifference > 0 ? `+${sessionSummary.totalDifference}` : sessionSummary.totalDifference} net)
            </span>
          </div>
        </div>
      </div>

      {/* Filter and Live Search Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-3 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 text-xs">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search item name, code (e.g. TOL-2002), or location (e.g. Rack A-1)..."
            className="w-full pl-10 pr-8 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none text-slate-900 dark:text-slate-100"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 p-0.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Category Filter */}
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value as any)}
            className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium focus:ring-2 focus:ring-blue-500"
          >
            <option value="All">All Categories</option>
            <option value="Material">Materials</option>
            <option value="Equipment">Equipment</option>
            <option value="Tool">Tools</option>
            <option value="Consumable">Consumables</option>
            <option value="PPE">PPE Safety</option>
          </select>

          {/* Location Filter */}
          <select
            value={locationFilter}
            onChange={(e) => setLocationFilter(e.target.value)}
            className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium focus:ring-2 focus:ring-blue-500"
          >
            {locationOptions.map((loc) => (
              <option key={loc} value={loc}>
                {loc === 'All' ? 'All Store Locations' : loc}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Stock Count List Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto max-h-[560px] overflow-y-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800 sticky top-0 z-10 border-b border-slate-200 dark:border-slate-700 text-[11px] font-bold text-slate-600 dark:text-slate-300">
              <tr>
                <th className="py-2.5 px-3 w-10 text-center">Status</th>
                <th className="py-2.5 px-3 min-w-[200px]">Item Name & Details</th>
                <th className="py-2.5 px-3 min-w-[100px]">Category</th>
                <th className="py-2.5 px-3 min-w-[130px]">Location / Rack</th>
                <th className="py-2.5 px-3 min-w-[90px] text-right">Recorded Qty</th>
                <th className="py-2.5 px-3 min-w-[120px] text-center">Physical Count</th>
                <th className="py-2.5 px-3 min-w-[90px] text-center">Difference</th>
                <th className="py-2.5 px-3 min-w-[180px]">Discrepancy Reason</th>
                <th className="py-2.5 px-3 w-20 text-center">Quick Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredItems.map((item) => {
                const entry = countEntries[item.id];
                const isCounted = !!entry?.isCounted;
                const countedQty = entry ? entry.countedQuantity : item.availableQuantity;
                const difference = isCounted ? countedQty - item.availableQuantity : 0;
                const hasDiscrepancy = isCounted && difference !== 0;

                return (
                  <tr
                    key={item.id}
                    className={`transition-colors ${
                      isCounted
                        ? hasDiscrepancy
                          ? 'bg-amber-50/40 dark:bg-amber-950/20'
                          : 'bg-emerald-50/30 dark:bg-emerald-950/20'
                        : 'hover:bg-slate-50/60 dark:hover:bg-slate-800/40'
                    }`}
                  >
                    {/* Status Badge */}
                    <td className="py-2.5 px-3 text-center">
                      {isCounted ? (
                        hasDiscrepancy ? (
                          <span className="p-1 rounded-full bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 inline-block" title="Counted with Variance">
                            <AlertTriangle className="w-3.5 h-3.5" />
                          </span>
                        ) : (
                          <span className="p-1 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 inline-block" title="Counted & Matches">
                            <Check className="w-3.5 h-3.5" />
                          </span>
                        )
                      ) : (
                        <span className="w-2.5 h-2.5 rounded-full bg-slate-300 dark:bg-slate-600 inline-block" title="Uncounted" />
                      )}
                    </td>

                    {/* Item Name */}
                    <td className="py-2.5 px-3">
                      <div className="font-bold text-slate-900 dark:text-slate-100">{item.name}</div>
                      <div className="text-[10px] text-slate-500 font-mono flex items-center gap-2 mt-0.5">
                        <span className="font-bold text-blue-600 dark:text-blue-400">{item.code}</span>
                        <span>•</span>
                        <span>Unit: {item.unit}</span>
                      </div>
                    </td>

                    {/* Category */}
                    <td className="py-2.5 px-3">
                      <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-slate-700 dark:text-slate-300">
                        <Tag className="w-3 h-3 text-blue-500" />
                        {item.category}
                      </span>
                    </td>

                    {/* Location */}
                    <td className="py-2.5 px-3 text-slate-600 dark:text-slate-400">
                      <span className="inline-flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-slate-400" />
                        {item.location || 'Store Rack'}
                      </span>
                    </td>

                    {/* Recorded Quantity */}
                    <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-700 dark:text-slate-300">
                      {item.availableQuantity} {item.unit}
                    </td>

                    {/* Physical Count Input */}
                    <td className="py-2.5 px-3 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <input
                          type="number"
                          min="0"
                          value={isCounted ? entry.countedQuantity : ''}
                          onChange={(e) => handleSetCount(item.id, Number(e.target.value))}
                          placeholder={String(item.availableQuantity)}
                          className={`w-20 px-2.5 py-1 text-center font-mono font-bold text-xs rounded-lg border ${
                            isCounted
                              ? hasDiscrepancy
                                ? 'border-amber-400 bg-amber-50 dark:bg-amber-950/60 dark:border-amber-700'
                                : 'border-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 dark:border-emerald-700 text-emerald-800 dark:text-emerald-300'
                              : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800'
                          } focus:outline-none focus:ring-2 focus:ring-blue-500`}
                        />
                        <span className="text-[10px] text-slate-400 font-mono">{item.unit}</span>
                      </div>
                    </td>

                    {/* Difference */}
                    <td className="py-2.5 px-3 text-center font-mono">
                      {isCounted ? (
                        <span
                          className={`px-2 py-0.5 rounded-full font-bold text-[11px] ${
                            difference === 0
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300'
                              : difference > 0
                              ? 'bg-blue-100 text-blue-800 dark:bg-blue-950/80 dark:text-blue-300'
                              : 'bg-rose-100 text-rose-800 dark:bg-rose-950/80 dark:text-rose-300'
                          }`}
                        >
                          {difference > 0 ? `+${difference}` : difference}
                        </span>
                      ) : (
                        <span className="text-slate-400 text-[11px]">—</span>
                      )}
                    </td>

                    {/* Discrepancy Reason */}
                    <td className="py-2.5 px-3">
                      {hasDiscrepancy ? (
                        <select
                          value={entry?.reason || DISCREPANCY_REASONS[0]}
                          onChange={(e) => handleSetReason(item.id, e.target.value)}
                          className="w-full text-xs px-2 py-1 rounded-lg border border-amber-300 dark:border-amber-800 bg-white dark:bg-slate-800 focus:outline-none focus:ring-1 focus:ring-amber-500"
                        >
                          {DISCREPANCY_REASONS.map((r) => (
                            <option key={r} value={r}>
                              {r}
                            </option>
                          ))}
                        </select>
                      ) : isCounted ? (
                        <span className="text-[11px] text-emerald-600 dark:text-emerald-400 flex items-center gap-1 font-medium">
                          <Check className="w-3.5 h-3.5" /> Stock Matches
                        </span>
                      ) : (
                        <span className="text-slate-400 text-[11px]">Not counted</span>
                      )}
                    </td>

                    {/* Quick Action */}
                    <td className="py-2.5 px-3 text-center">
                      {!isCounted ? (
                        <button
                          type="button"
                          onClick={() => handleConfirmMatch(item)}
                          className="px-2 py-1 rounded-lg text-[10px] font-bold bg-slate-100 hover:bg-emerald-50 text-slate-700 hover:text-emerald-700 dark:bg-slate-800 dark:hover:bg-emerald-950 transition-colors"
                          title="Verify as exact match"
                        >
                          Match ✓
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => handleResetItemCount(item.id)}
                          className="p-1 rounded text-slate-400 hover:text-rose-600 transition-colors"
                          title="Clear counted value"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Confirmation Modal */}
      <Modal
        isOpen={isConfirmModalOpen}
        onClose={() => setIsConfirmModalOpen(false)}
        title="Confirm Stock Count Adjustment"
        maxWidth="max-w-xl"
      >
        <div className="space-y-4 text-xs">
          <div className="p-3.5 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900/60 text-blue-900 dark:text-blue-200">
            <p className="font-bold">Authorized Stock Update Review</p>
            <p className="mt-1 text-slate-600 dark:text-slate-300">
              You are about to confirm and post <strong>{sessionSummary.completedCount} counted item(s)</strong>.
              This will update available store inventory and create immutable audit logs under your name (<strong>{user?.name || 'Store Keeper'}</strong>).
            </p>
          </div>

          <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl space-y-2 border border-slate-200 dark:border-slate-700">
            <div className="flex justify-between">
              <span className="text-slate-500">Items with Variances:</span>
              <span className="font-bold text-slate-800 dark:text-slate-100">{sessionSummary.discrepanciesCount}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Net Stock Adjustment:</span>
              <span className={`font-black ${sessionSummary.totalDifference >= 0 ? 'text-blue-600' : 'text-rose-600'}`}>
                {sessionSummary.totalDifference > 0 ? `+${sessionSummary.totalDifference}` : sessionSummary.totalDifference} Units
              </span>
            </div>
          </div>

          <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-200 dark:border-slate-800">
            <Button variant="outline" size="sm" onClick={() => setIsConfirmModalOpen(false)}>
              Cancel
            </Button>
            <Button
              variant="primary"
              size="sm"
              isLoading={isSubmitting}
              onClick={handleApplyCounts}
            >
              Confirm & Post Adjustments
            </Button>
          </div>
        </div>
      </Modal>

      {/* Stock Adjustment History Drawer / Modal */}
      <Modal
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        title="Stock Adjustment Audit History"
        maxWidth="max-w-3xl"
      >
        <div className="space-y-4">
          <p className="text-xs text-slate-500">
            Immutable log of all physical inventory counts, variance corrections, and authorized adjustments.
          </p>

          {isLoadingHistory ? (
            <div className="py-12 text-center text-slate-500 text-xs">
              Loading audit logs...
            </div>
          ) : historyList.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-xs">
              No stock adjustments recorded yet.
            </div>
          ) : (
            <div className="max-h-[460px] overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-xl">
              {historyList.map((log) => (
                <div key={log.id} className="p-3 text-xs space-y-1 hover:bg-slate-50/60 dark:hover:bg-slate-800/40">
                  <div className="flex items-center justify-between">
                    <div className="font-black text-slate-900 dark:text-slate-100">
                      {log.itemName} <span className="text-slate-400 font-normal font-mono">({log.itemCode})</span>
                    </div>
                    <span
                      className={`px-2 py-0.5 rounded-full font-mono font-bold text-[10px] ${
                        log.difference > 0
                          ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                          : log.difference < 0
                          ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                          : 'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-300'
                      }`}
                    >
                      {log.difference > 0 ? `+${log.difference}` : log.difference}
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-500">
                    <span>
                      Qty: <strong>{log.previousQuantity}</strong> &rarr; <strong>{log.newQuantity}</strong>
                    </span>
                    <span>•</span>
                    <span>Reason: <em>{log.reason}</em></span>
                    <span>•</span>
                    <span>By: {log.user}</span>
                    <span>•</span>
                    <span className="font-mono text-[10px] text-slate-400">
                      {new Date(log.timestamp).toLocaleString()}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </Modal>
    </div>
  );
};
