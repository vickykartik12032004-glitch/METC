import React, { useState, useMemo } from 'react';
import { METCItem, AssetCategory } from '../../../types';
import { useAssetStore } from '../../../store/useAssetStore';
import { useAuthStore } from '../../../store/useAuthStore';
import { cloudApi } from '../../../services/apiClient';
import { checkDuplicate, DuplicateMatch, DuplicateResolution } from '../utils/duplicateDetector';
import { DuplicateWarningModal } from './DuplicateWarningModal';
import { Button } from '../../../components/ui/Button';
import { 
  Plus, 
  Trash2, 
  Copy, 
  AlertTriangle, 
  CheckCircle2, 
  RotateCcw, 
  Save, 
  FileSpreadsheet, 
  Sparkles, 
  Info,
  Layers,
  ArrowUpRight
} from 'lucide-react';
import { toast } from 'sonner';
import { getNextMetNumber, getSequentialMetNumbers, isMetNumberRecommended } from '../../../utils/metAssetNumber';

export interface BulkDraftRow {
  id: string;
  name: string;
  code: string;
  category: AssetCategory;
  unit: string;
  openingQuantity: number;
  workingQuantity: number;
  damagedQuantity: number;
  location: string;
  minStockLevel: number;
  remarks: string;
  // Duplicate handling resolution
  duplicateResolution?: DuplicateResolution;
}

const CATEGORIES: AssetCategory[] = ['Material', 'Equipment', 'Tool', 'Consumable', 'PPE'];

const COMMON_UNITS = [
  'PCS',
  'NOS',
  'SET',
  'MTR',
  'KG',
  'BOX',
  'ROLL',
  'PAIR',
  'PKT',
  'BDL',
  'LTR',
  'BAG',
  'DRUM',
  'SHEET'
];

function createBlankRow(category: AssetCategory = 'Material', codeVal: string = ''): BulkDraftRow {
  return {
    id: `draft-${Date.now()}-${Math.floor(Math.random() * 100000)}`,
    name: '',
    code: codeVal,
    category,
    unit: 'NOS',
    openingQuantity: 10,
    workingQuantity: 10,
    damagedQuantity: 0,
    location: 'Main Warehouse',
    minStockLevel: 5,
    remarks: '',
  };
}

interface BulkAddTabProps {
  existingItems: METCItem[];
  onSuccess?: () => void;
  onSwitchToPaste?: () => void;
}

export const BulkAddTab: React.FC<BulkAddTabProps> = ({
  existingItems,
  onSuccess,
  onSwitchToPaste,
}) => {
  const { user } = useAuthStore();
  const { bulkAddAssets, applyRemoteAssetUpsert } = useAssetStore();

  // Initialize with rows: Equipment & Tools get MET numbers starting from MET - 1; Consumables & Materials have empty optional codes
  const [rows, setRows] = useState<BulkDraftRow[]>(() => {
    return [
      createBlankRow('Material', ''),
      createBlankRow('Equipment', 'MET - 1'),
      createBlankRow('Tool', 'MET - 2'),
      createBlankRow('Consumable', ''),
      createBlankRow('PPE', ''),
    ];
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [duplicateModalRow, setDuplicateModalRow] = useState<{
    row: BulkDraftRow;
    match: DuplicateMatch;
  } | null>(null);

  // Validation function for a single row
  const getRowErrors = (row: BulkDraftRow): string[] => {
    const errors: string[] = [];
    if (!row.name.trim()) {
      errors.push('Item Name is required');
    }
    if (row.openingQuantity < 0) {
      errors.push('Opening Qty cannot be negative');
    }
    if (row.workingQuantity < 0) {
      errors.push('Working Qty cannot be negative');
    }
    if (row.damagedQuantity < 0) {
      errors.push('Damaged Qty cannot be negative');
    }
    if (row.workingQuantity + row.damagedQuantity > row.openingQuantity) {
      errors.push('Working + Damaged exceeds Opening Qty');
    }
    if (!row.location.trim()) {
      errors.push('Store Location or Rack is required');
    }
    return errors;
  };

  // Row duplicates against existing items
  const duplicateCandidateMap = useMemo(() => {
    const map = new Map<string, DuplicateMatch>();
    rows.forEach((row) => {
      if (row.name.trim()) {
        const match = checkDuplicate(
          {
            name: row.name,
            code: row.code,
            category: row.category,
            unit: row.unit,
          },
          existingItems
        );
        if (match) {
          map.set(row.id, match);
        }
      }
    });
    return map;
  }, [rows, existingItems]);

  // Validation Summary
  const { validRowsCount, invalidRowsCount, duplicatesCount } = useMemo(() => {
    let valid = 0;
    let invalid = 0;
    let dups = 0;

    rows.forEach((row) => {
      const errs = getRowErrors(row);
      if (errs.length === 0) {
        valid++;
      } else {
        invalid++;
      }
      if (duplicateCandidateMap.has(row.id) && !row.duplicateResolution) {
        dups++;
      }
    });

    return {
      validRowsCount: valid,
      invalidRowsCount: invalid,
      duplicatesCount: dups,
    };
  }, [rows, duplicateCandidateMap]);

  // Add Rows
  const handleAddRow = (count: number = 1, category: AssetCategory = 'Material') => {
    const isSerialized = isMetNumberRecommended(category);
    const metSeq = isSerialized ? getSequentialMetNumbers(existingItems, count, false) : [];
    const newRows: BulkDraftRow[] = [];
    for (let i = 0; i < count; i++) {
      newRows.push(createBlankRow(category, metSeq[i] || ''));
    }
    setRows((prev) => [...prev, ...newRows]);
    toast.info(`Added ${count} blank row${count > 1 ? 's' : ''}`);
  };

  // MET Numbering Sequencing Helpers (Supports starting from MET - 1 or clearing for optional consumables)
  const handleSequenceMetNumbers = (startFromOne: boolean = true) => {
    const metSeq = getSequentialMetNumbers(existingItems, rows.length, startFromOne, true);
    setRows((prev) =>
      prev.map((r, idx) => ({
        ...r,
        code: metSeq[idx] || `MET - ${idx + 1}`,
      }))
    );
    toast.success(
      startFromOne
        ? 'Assigned MET numbers starting from MET - 1 (MET - 1, MET - 2...)!'
        : 'Assigned sequential MET numbers across all draft rows!'
    );
  };

  const handleClearConsumableMetNumbers = () => {
    let clearedCount = 0;
    setRows((prev) =>
      prev.map((r) => {
        if (r.category === 'Consumable' || r.category === 'Material') {
          clearedCount++;
          return { ...r, code: '' };
        }
        return r;
      })
    );
    toast.info(`Cleared MET numbers from ${clearedCount} Consumable/Material rows (MET number is optional).`);
  };

  // Update Field
  const handleFieldChange = (
    id: string,
    field: keyof BulkDraftRow,
    value: any
  ) => {
    setRows((prev) =>
      prev.map((r) => {
        if (r.id !== id) return r;
        const updated = { ...r, [field]: value };
        // If category changed to Equipment/Tool and code was blank, suggest next MET#
        if (field === 'category') {
          if (isMetNumberRecommended(value as AssetCategory) && !r.code.trim()) {
            updated.code = getNextMetNumber(existingItems);
          }
        }
        // If opening quantity changed, sync working quantity if working qty matched old opening
        if (field === 'openingQuantity' && r.workingQuantity === r.openingQuantity) {
          updated.workingQuantity = Math.max(0, Number(value) - r.damagedQuantity);
        }
        // Clear duplicate resolution if user changed name or code
        if (field === 'name' || field === 'code' || field === 'category') {
          updated.duplicateResolution = undefined;
        }
        return updated;
      })
    );
  };

  // Duplicate a draft row
  const handleDuplicateRow = (id: string) => {
    const target = rows.find((r) => r.id === id);
    if (!target) return;
    const isSerialized = isMetNumberRecommended(target.category);
    const newCode = isSerialized ? getNextMetNumber(existingItems) : '';
    const duplicated: BulkDraftRow = {
      ...target,
      id: `draft-${Date.now()}-${Math.floor(Math.random() * 10000)}`,
      code: newCode,
      name: `${target.name} (Copy)`,
      duplicateResolution: undefined,
    };
    const index = rows.findIndex((r) => r.id === id);
    const updated = [...rows];
    updated.splice(index + 1, 0, duplicated);
    setRows(updated);
    toast.success('Row duplicated');
  };

  // Delete a draft row
  const handleDeleteRow = (id: string) => {
    if (rows.length <= 1) {
      toast.error('Must keep at least one row');
      return;
    }
    setRows((prev) => prev.filter((r) => r.id !== id));
  };

  // Clear all drafts
  const handleClearDrafts = () => {
    if (window.confirm('Reset all draft rows to default 5 blank entries?')) {
      const metSeq = getSequentialMetNumbers(existingItems, 3, false);
      setRows([
        createBlankRow('Material', ''),
        createBlankRow('Equipment', metSeq[0] || 'MET-1'),
        createBlankRow('Tool', metSeq[1] || 'MET-2'),
        createBlankRow('Consumable', ''),
        createBlankRow('PPE', ''),
      ]);
      toast.info('Draft rows reset');
    }
  };

  // Save batch
  const handleSaveBatch = async () => {
    // Check row errors
    const invalidItems = rows.filter((r) => getRowErrors(r).length > 0);
    if (invalidItems.length > 0) {
      toast.error(`Please fix errors in ${invalidItems.length} invalid row(s) before saving.`);
      return;
    }

    // Check unresolved duplicates
    const unresolvedDups = rows.filter(
      (r) => duplicateCandidateMap.has(r.id) && !r.duplicateResolution
    );
    if (unresolvedDups.length > 0) {
      const firstDup = unresolvedDups[0];
      const match = duplicateCandidateMap.get(firstDup.id)!;
      setDuplicateModalRow({ row: firstDup, match });
      toast.warning(
        `There are ${unresolvedDups.length} duplicate warning(s). Please choose how to handle them.`
      );
      return;
    }

    setIsSubmitting(true);
    const authorName = user?.name || 'Store Keeper';

    try {
      const itemsToCreate: any[] = [];
      const stockAdjustmentsToMake: Array<{
        itemId: string;
        qtyToAdd: number;
        reason: string;
      }> = [];

      for (const row of rows) {
        if (row.duplicateResolution?.action === 'SKIP') {
          continue; // User explicitly skipped this duplicate row
        }

        if (row.duplicateResolution?.action === 'UPDATE_STOCK') {
          const match = duplicateCandidateMap.get(row.id);
          if (match) {
            stockAdjustmentsToMake.push({
              itemId: match.existingItem.id,
              qtyToAdd: row.openingQuantity,
              reason: row.duplicateResolution.reason || `Stock batch addition for ${row.name}`,
            });
            continue;
          }
        }

        // Standard new item creation
        itemsToCreate.push({
          name: row.name.trim(),
          code: row.code.trim(),
          category: row.category,
          unit: row.unit.trim().toUpperCase(),
          quantity: row.openingQuantity,
          availableQuantity: row.workingQuantity,
          damagedQuantity: row.damagedQuantity,
          location: row.location.trim(),
          minQuantityThreshold: row.minStockLevel,
          remarks: row.remarks.trim(),
          status: row.workingQuantity > 0 ? 'Available' : 'Out of Stock',
        });
      }

      let createdCount = 0;
      let adjustedCount = 0;

      // 1. Process batch new assets
      if (itemsToCreate.length > 0) {
        const res = await bulkAddAssets(itemsToCreate, authorName);
        createdCount = res?.length || itemsToCreate.length;
      }

      // 2. Process stock adjustments for duplicate items user selected to update
      for (const adj of stockAdjustmentsToMake) {
        const item = existingItems.find((i) => i.id === adj.itemId);
        if (item) {
          const newQty = item.quantity + adj.qtyToAdd;
          const newAvail = item.availableQuantity + adj.qtyToAdd;
          await cloudApi.createStockAdjustment({
            itemId: item.id,
            itemName: item.name,
            itemCode: item.code,
            category: item.category,
            previousQuantity: item.quantity,
            newQuantity: newQty,
            difference: adj.qtyToAdd,
            reason: adj.reason,
            countedBy: authorName,
            location: item.location,
          });
          applyRemoteAssetUpsert(item.category, {
            ...item,
            quantity: newQty,
            availableQuantity: newAvail,
          });
          adjustedCount++;
        }
      }

      toast.success(
        `Batch successfully processed! ${createdCount} new item(s) created, ${adjustedCount} stock adjustment(s) applied.`
      );

      // Reset rows to fresh clean state
      setRows([
        createBlankRow('Material'),
        createBlankRow('Tool'),
        createBlankRow('Equipment'),
      ]);

      if (onSuccess) {
        onSuccess();
      }
    } catch (err: any) {
      toast.error(`Failed to save batch: ${err.message || 'Server error'}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Fast Action Toolbar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300">
                <Layers className="w-4 h-4" />
              </span>
              <h2 className="text-base sm:text-lg font-black text-slate-900 dark:text-white">
                Bulk Add Inventory Items
              </h2>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Add 30–50+ inventory rows at once with row-level validation, live duplicate prevention, and batch persistence.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {onSwitchToPaste && (
              <Button
                variant="outline"
                size="sm"
                icon={<FileSpreadsheet className="w-4 h-4 text-emerald-600" />}
                onClick={onSwitchToPaste}
              >
                Paste from Excel
              </Button>
            )}

            <Button
              variant="outline"
              size="sm"
              icon={<RotateCcw className="w-4 h-4 text-rose-500" />}
              onClick={handleClearDrafts}
            >
              Reset Drafts
            </Button>

            <Button
              variant="primary"
              size="sm"
              icon={<Save className="w-4 h-4" />}
              isLoading={isSubmitting}
              onClick={handleSaveBatch}
              disabled={rows.length === 0}
            >
              Save Batch ({rows.length} Rows)
            </Button>
          </div>
        </div>

        {/* MET Numbering Options Toolbar */}
        <div className="flex flex-wrap items-center justify-between gap-2.5 mt-3 pt-3 border-t border-slate-100 dark:border-slate-800">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-blue-500" /> MET Numbering:
            </span>
            <button
              type="button"
              onClick={() => handleSequenceMetNumbers(true)}
              className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-900 text-blue-700 dark:text-blue-300 hover:bg-blue-100 dark:hover:bg-blue-900 transition-colors shadow-2xs cursor-pointer"
              title="Assign MET numbers starting from MET - 1"
            >
              Start Sequence from MET - 1 (MET - 1, MET - 2...)
            </button>
            <button
              type="button"
              onClick={() => handleSequenceMetNumbers(false)}
              className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer"
              title="Continue sequence from next available MET number"
            >
              Continue Next MET#
            </button>
            <button
              type="button"
              onClick={handleClearConsumableMetNumbers}
              className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-900 text-amber-800 dark:text-amber-300 hover:bg-amber-100 dark:hover:bg-amber-900 transition-colors cursor-pointer"
              title="Clear MET numbers for consumables and materials (optional)"
            >
              Clear Consumables MET# (Optional)
            </button>
          </div>
          <span className="text-[11px] text-slate-400 italic">
            * MET number option me hai (optional for bulk materials and consumables).
          </span>
        </div>

        {/* Validation & Draft Metrics Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 text-xs">
          <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
            <span className="text-slate-400 block text-[10px] uppercase font-bold">Total Draft Rows</span>
            <span className="text-base font-black text-slate-800 dark:text-slate-100">{rows.length}</span>
          </div>

          <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/60">
            <span className="text-emerald-700 dark:text-emerald-300 block text-[10px] uppercase font-bold flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Valid Rows
            </span>
            <span className="text-base font-black text-emerald-700 dark:text-emerald-300">{validRowsCount}</span>
          </div>

          <div className={`p-2.5 rounded-xl border ${invalidRowsCount > 0 ? 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-900/60 text-rose-700 dark:text-rose-300' : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-500'}`}>
            <span className="block text-[10px] uppercase font-bold flex items-center gap-1">
              <AlertTriangle className="w-3 h-3" /> Errors
            </span>
            <span className="text-base font-black">{invalidRowsCount}</span>
          </div>

          <div className={`p-2.5 rounded-xl border ${duplicatesCount > 0 ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-900/60 text-amber-700 dark:text-amber-300' : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-500'}`}>
            <span className="block text-[10px] uppercase font-bold flex items-center gap-1">
              <Info className="w-3 h-3" /> Duplicate Alerts
            </span>
            <span className="text-base font-black">{duplicatesCount}</span>
          </div>
        </div>
      </div>

      {/* Draft Grid Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto max-h-[580px] overflow-y-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/80 sticky top-0 z-10 border-b border-slate-200 dark:border-slate-700 text-[11px] font-bold text-slate-600 dark:text-slate-300">
              <tr>
                <th className="py-2.5 px-3 w-10 text-center">#</th>
                <th className="py-2.5 px-3 min-w-[180px]">Item Name *</th>
                <th className="py-2.5 px-3 min-w-[130px]">MET Number <span className="text-[10px] font-normal text-slate-400">(Optional)</span></th>
                <th className="py-2.5 px-3 min-w-[120px]">Category *</th>
                <th className="py-2.5 px-3 min-w-[90px]">Unit *</th>
                <th className="py-2.5 px-3 min-w-[90px]">Opening Qty *</th>
                <th className="py-2.5 px-3 min-w-[90px]">Working Qty</th>
                <th className="py-2.5 px-3 min-w-[90px]">Damaged Qty</th>
                <th className="py-2.5 px-3 min-w-[130px]">Store Rack / Loc *</th>
                <th className="py-2.5 px-3 min-w-[80px]">Min Stock</th>
                <th className="py-2.5 px-3 min-w-[140px]">Remarks</th>
                <th className="py-2.5 px-3 w-20 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {rows.map((row, index) => {
                const errors = getRowErrors(row);
                const hasErrors = errors.length > 0;
                const dupMatch = duplicateCandidateMap.get(row.id);
                const isDup = !!dupMatch && !row.duplicateResolution;

                return (
                  <tr
                    key={row.id}
                    className={`transition-colors ${
                      hasErrors
                        ? 'bg-rose-50/30 dark:bg-rose-950/20'
                        : isDup
                        ? 'bg-amber-50/30 dark:bg-amber-950/20'
                        : row.duplicateResolution?.action === 'SKIP'
                        ? 'opacity-40 bg-slate-100 dark:bg-slate-800'
                        : 'hover:bg-slate-50/60 dark:hover:bg-slate-800/40'
                    }`}
                  >
                    {/* Index */}
                    <td className="py-2 px-3 text-center text-slate-400 font-mono text-[11px]">
                      {index + 1}
                    </td>

                    {/* Item Name */}
                    <td className="py-2 px-3">
                      <input
                        type="text"
                        value={row.name}
                        onChange={(e) => handleFieldChange(row.id, 'name', e.target.value)}
                        placeholder="e.g. Angle Grinder 4-inch"
                        className={`w-full px-2.5 py-1.5 rounded-lg text-xs bg-white dark:bg-slate-800 border ${
                          !row.name.trim()
                            ? 'border-rose-400 dark:border-rose-600 focus:ring-rose-500'
                            : 'border-slate-200 dark:border-slate-700 focus:ring-blue-500'
                        } focus:outline-none focus:ring-1`}
                      />
                      {dupMatch && (
                        <div className="mt-1 flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => setDuplicateModalRow({ row, match: dupMatch })}
                            className={`text-[10px] font-bold px-1.5 py-0.5 rounded flex items-center gap-1 cursor-pointer ${
                              row.duplicateResolution?.action === 'UPDATE_STOCK'
                                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                : row.duplicateResolution?.action === 'SKIP'
                                ? 'bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300 line-through'
                                : row.duplicateResolution?.action === 'ADD_NEW'
                                ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                                : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 animate-pulse'
                            }`}
                          >
                            <AlertTriangle className="w-3 h-3" />
                            <span>
                              {row.duplicateResolution
                                ? `Resolved: ${row.duplicateResolution.action.replace('_', ' ')}`
                                : 'Duplicate Warning (Click to resolve)'}
                            </span>
                          </button>
                        </div>
                      )}
                    </td>

                    {/* Item Code / MET Number */}
                    <td className="py-2 px-3">
                      <input
                        type="text"
                        value={row.code}
                        onChange={(e) => handleFieldChange(row.id, 'code', e.target.value)}
                        placeholder="e.g. MET-1 (Optional)"
                        className="w-full px-2 py-1.5 rounded-lg text-xs font-mono bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-1 focus:ring-blue-500 placeholder:text-slate-400"
                      />
                    </td>

                    {/* Category */}
                    <td className="py-2 px-3">
                      <select
                        value={row.category}
                        onChange={(e) => handleFieldChange(row.id, 'category', e.target.value as AssetCategory)}
                        className="w-full px-2 py-1.5 rounded-lg text-xs bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-1 focus:ring-blue-500"
                      >
                        {CATEGORIES.map((cat) => (
                          <option key={cat} value={cat}>
                            {cat}
                          </option>
                        ))}
                      </select>
                    </td>

                    {/* Unit */}
                    <td className="py-2 px-3">
                      <select
                        value={row.unit}
                        onChange={(e) => handleFieldChange(row.id, 'unit', e.target.value)}
                        className="w-full px-2 py-1.5 rounded-lg text-xs bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-1 focus:ring-blue-500"
                      >
                        {COMMON_UNITS.map((u) => (
                          <option key={u} value={u}>
                            {u}
                          </option>
                        ))}
                      </select>
                    </td>

                    {/* Opening Quantity */}
                    <td className="py-2 px-3">
                      <input
                        type="number"
                        min="0"
                        value={row.openingQuantity}
                        onChange={(e) => handleFieldChange(row.id, 'openingQuantity', Number(e.target.value))}
                        className={`w-full px-2 py-1.5 rounded-lg text-xs font-mono font-bold text-center bg-white dark:bg-slate-800 border ${
                          row.openingQuantity < 0
                            ? 'border-rose-400'
                            : 'border-slate-200 dark:border-slate-700'
                        } focus:outline-none focus:ring-1 focus:ring-blue-500`}
                      />
                    </td>

                    {/* Working Quantity */}
                    <td className="py-2 px-3">
                      <input
                        type="number"
                        min="0"
                        value={row.workingQuantity}
                        onChange={(e) => handleFieldChange(row.id, 'workingQuantity', Number(e.target.value))}
                        className="w-full px-2 py-1.5 rounded-lg text-xs font-mono text-center bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-1 focus:ring-blue-500"
                      />
                    </td>

                    {/* Damaged Quantity */}
                    <td className="py-2 px-3">
                      <input
                        type="number"
                        min="0"
                        value={row.damagedQuantity}
                        onChange={(e) => handleFieldChange(row.id, 'damagedQuantity', Number(e.target.value))}
                        className="w-full px-2 py-1.5 rounded-lg text-xs font-mono text-center text-rose-600 dark:text-rose-400 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-1 focus:ring-rose-500"
                      />
                    </td>

                    {/* Store Location */}
                    <td className="py-2 px-3">
                      <input
                        type="text"
                        value={row.location}
                        onChange={(e) => handleFieldChange(row.id, 'location', e.target.value)}
                        placeholder="Rack A-1"
                        className={`w-full px-2 py-1.5 rounded-lg text-xs bg-white dark:bg-slate-800 border ${
                          !row.location.trim()
                            ? 'border-rose-400'
                            : 'border-slate-200 dark:border-slate-700'
                        } focus:outline-none focus:ring-1 focus:ring-blue-500`}
                      />
                    </td>

                    {/* Min Stock */}
                    <td className="py-2 px-3">
                      <input
                        type="number"
                        min="0"
                        value={row.minStockLevel}
                        onChange={(e) => handleFieldChange(row.id, 'minStockLevel', Number(e.target.value))}
                        className="w-full px-2 py-1.5 rounded-lg text-xs font-mono text-center bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-1 focus:ring-blue-500"
                      />
                    </td>

                    {/* Remarks */}
                    <td className="py-2 px-3">
                      <input
                        type="text"
                        value={row.remarks}
                        onChange={(e) => handleFieldChange(row.id, 'remarks', e.target.value)}
                        placeholder="Optional notes"
                        className="w-full px-2 py-1.5 rounded-lg text-xs bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-1 focus:ring-blue-500"
                      />
                    </td>

                    {/* Action buttons */}
                    <td className="py-2 px-3 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          type="button"
                          onClick={() => handleDuplicateRow(row.id)}
                          className="p-1 rounded hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500 hover:text-blue-600 transition-colors"
                          title="Duplicate row"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteRow(row.id)}
                          className="p-1 rounded hover:bg-rose-100 dark:hover:bg-rose-950 text-slate-400 hover:text-rose-600 transition-colors"
                          title="Delete row"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Table Bottom Fast-Add Toolbar */}
        <div className="p-3 bg-slate-50 dark:bg-slate-800/60 border-t border-slate-200 dark:border-slate-700 flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => handleAddRow(1)}
              className="px-3 py-1.5 text-xs font-bold text-blue-600 dark:text-blue-400 bg-white dark:bg-slate-800 border border-blue-200 dark:border-blue-900 rounded-xl hover:bg-blue-50 transition-all shadow-2xs flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add 1 Row</span>
            </button>

            <button
              type="button"
              onClick={() => handleAddRow(10)}
              className="px-2.5 py-1.5 text-xs font-bold text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl hover:bg-slate-100 transition-all shadow-2xs cursor-pointer"
            >
              +10 Rows
            </button>

            <button
              type="button"
              onClick={() => handleAddRow(25)}
              className="px-2.5 py-1.5 text-xs font-bold text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl hover:bg-slate-100 transition-all shadow-2xs cursor-pointer"
            >
              +25 Rows
            </button>

            <button
              type="button"
              onClick={() => handleAddRow(50)}
              className="px-2.5 py-1.5 text-xs font-bold text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl hover:bg-slate-100 transition-all shadow-2xs cursor-pointer"
            >
              +50 Rows
            </button>
          </div>

          <div className="text-xs text-slate-500 flex items-center gap-3">
            <span>
              Rows: <strong>{rows.length}</strong>
            </span>
            <span>•</span>
            <span className="text-emerald-600 dark:text-emerald-400 font-bold">
              {validRowsCount} ready to save
            </span>
          </div>
        </div>
      </div>

      {/* Duplicate Warning Modal Handler */}
      {duplicateModalRow && (
        <DuplicateWarningModal
          isOpen={!!duplicateModalRow}
          onClose={() => setDuplicateModalRow(null)}
          duplicateMatch={duplicateModalRow.match}
          draftItem={{
            name: duplicateModalRow.row.name,
            code: duplicateModalRow.row.code,
            category: duplicateModalRow.row.category,
            quantity: duplicateModalRow.row.openingQuantity,
            unit: duplicateModalRow.row.unit,
            location: duplicateModalRow.row.location,
          }}
          onResolve={(res) => {
            setRows((prev) =>
              prev.map((r) =>
                r.id === duplicateModalRow.row.id
                  ? { ...r, duplicateResolution: res }
                  : r
              )
            );
            toast.success(`Duplicate action set to: ${res.action.replace('_', ' ')}`);
          }}
        />
      )}
    </div>
  );
};
