import React, { useState, useMemo, useEffect } from 'react';
import {
  METCItem,
  AssetCategory,
  StocktakingSession,
  StocktakingItem,
  StocktakingItemStatus,
} from '../../../types';
import { useAssetStore } from '../../../store/useAssetStore';
import { useAuthStore } from '../../../store/useAuthStore';
import { cloudApi } from '../../../services/apiClient';
import { Button } from '../../../components/ui/Button';
import { Modal } from '../../../components/ui/Modal';
import {
  PieChart,
  CheckCircle2,
  Clock,
  Play,
  RotateCcw,
  Plus,
  Search,
  Filter,
  Check,
  AlertTriangle,
  Layers,
  ArrowRight,
  Sparkles,
  Calendar,
  User,
  MapPin,
  Tag,
  X
} from 'lucide-react';
import { toast } from 'sonner';

const ALL_CATEGORIES: AssetCategory[] = [
  'Material',
  'Equipment',
  'Tool',
  'Consumable',
  'PPE',
];

interface PendingCountTrackerTabProps {
  items: METCItem[];
  onOpenQuickCount?: () => void;
}

export const PendingCountTrackerTab: React.FC<PendingCountTrackerTabProps> = ({
  items,
  onOpenQuickCount,
}) => {
  const { user } = useAuthStore();
  const { applyRemoteAssetUpsert } = useAssetStore();

  const [sessions, setSessions] = useState<StocktakingSession[]>([]);
  const [activeSession, setActiveSession] = useState<StocktakingSession | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // New Session Creation Modal state
  const [isNewSessionModalOpen, setIsNewSessionModalOpen] = useState<boolean>(false);
  const [sessionTitle, setSessionTitle] = useState<string>('Q4 Full Construction Store Physical Count');
  const [selectedCategories, setSelectedCategories] = useState<AssetCategory[]>([
    'Material',
    'Equipment',
    'Tool',
    'Consumable',
    'PPE',
  ]);
  const [selectedLocations, setSelectedLocations] = useState<string[]>(['All']);
  const [sessionNotes, setSessionNotes] = useState<string>('');

  // Item Checklist Filtering within Active Session
  const [itemSearch, setItemSearch] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<StocktakingItemStatus | 'All'>('All');
  const [categoryFilter, setCategoryFilter] = useState<AssetCategory | 'All'>('All');

  // Load existing sessions from cloud
  const loadSessions = async () => {
    setIsLoading(true);
    try {
      const res = await cloudApi.getStocktakingSessions();
      if (res && res.data) {
        setSessions(res.data);
        // If an active session is in progress, select it
        const inProgress = res.data.find((s) => s.status === 'In Progress');
        if (inProgress && !activeSession) {
          setActiveSession(inProgress);
        }
      }
    } catch (err) {
      console.warn('Failed to load stocktaking sessions:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadSessions();
  }, []);

  // Distinct locations from inventory items
  const locationOptions = useMemo(() => {
    const locs = new Set<string>();
    items.forEach((it) => {
      if (it.location) locs.add(it.location);
    });
    return ['All', ...Array.from(locs).sort()];
  }, [items]);

  // Overall category metrics across current inventory
  const categoryMetrics = useMemo(() => {
    return ALL_CATEGORIES.map((cat) => {
      const catItems = items.filter((it) => it.category === cat);
      const totalExpected = catItems.length;

      // Check how many items in active session are counted for this category
      let counted = 0;
      let inProgressCount = 0;
      let needsReviewCount = 0;

      if (activeSession) {
        const sessionCatItems = activeSession.items.filter((it) => it.category === cat);
        counted = sessionCatItems.filter((it) => it.status === 'Counted').length;
        inProgressCount = sessionCatItems.filter((it) => it.status === 'In Progress').length;
        needsReviewCount = sessionCatItems.filter((it) => it.status === 'Needs Review').length;
      }

      const percent = totalExpected > 0 ? Math.round((counted / totalExpected) * 100) : 100;
      const isComplete = totalExpected > 0 && counted === totalExpected && needsReviewCount === 0;

      return {
        category: cat,
        totalExpected,
        counted,
        inProgressCount,
        needsReviewCount,
        remaining: Math.max(0, totalExpected - counted),
        percent,
        isComplete,
      };
    });
  }, [items, activeSession]);

  // Check if new items were added since active session started
  const newlyAddedItemsCount = useMemo(() => {
    if (!activeSession) return 0;
    const sessionItemIds = new Set(activeSession.items.map((i) => i.itemId));
    const unlisted = items.filter(
      (it) =>
        activeSession.categories.includes(it.category) &&
        !sessionItemIds.has(it.id)
    );
    return unlisted.length;
  }, [items, activeSession]);

  // Start New Stocktaking Session
  const handleStartSession = async () => {
    if (!sessionTitle.trim()) {
      toast.error('Please enter a session title');
      return;
    }
    if (selectedCategories.length === 0) {
      toast.error('Select at least one category for the count scope');
      return;
    }

    // Filter items matching scope
    const targetItems = items.filter((it) => {
      if (!selectedCategories.includes(it.category)) return false;
      if (!selectedLocations.includes('All') && !selectedLocations.includes(it.location)) {
        return false;
      }
      return true;
    });

    if (targetItems.length === 0) {
      toast.error('No inventory items match the selected categories and locations.');
      return;
    }

    const checklistItems: StocktakingItem[] = targetItems.map((it) => ({
      itemId: it.id,
      itemCode: it.code,
      itemName: it.name,
      category: it.category,
      location: it.location || 'Main Warehouse',
      expectedQuantity: it.availableQuantity,
      countedQuantity: undefined,
      difference: 0,
      status: 'Not Counted',
      reason: '',
      remarks: '',
    }));

    const authorName = user?.name || 'Store Keeper';
    const newSessionPayload = {
      title: sessionTitle.trim(),
      categories: selectedCategories,
      locations: selectedLocations,
      status: 'In Progress',
      startedAt: new Date().toISOString(),
      createdBy: authorName,
      items: checklistItems,
      totalExpected: checklistItems.length,
      totalCounted: 0,
      totalDiscrepancies: 0,
      notes: sessionNotes,
    };

    try {
      const res = await cloudApi.saveStocktakingSession(newSessionPayload);
      if (res && res.data) {
        toast.success(`Stocktaking session "${res.data.title}" started with ${checklistItems.length} items to count!`);
        setActiveSession(res.data);
        setIsNewSessionModalOpen(false);
        await loadSessions();
      }
    } catch (err: any) {
      toast.error(`Failed to start session: ${err.message || 'Server error'}`);
    }
  };

  // Include new inventory items into active session
  const handleIncludeNewItems = async () => {
    if (!activeSession) return;
    const sessionItemIds = new Set(activeSession.items.map((i) => i.itemId));
    const newItems = items
      .filter(
        (it) =>
          activeSession.categories.includes(it.category) &&
          !sessionItemIds.has(it.id)
      )
      .map((it) => ({
        itemId: it.id,
        itemCode: it.code,
        itemName: it.name,
        category: it.category,
        location: it.location || 'Main Warehouse',
        expectedQuantity: it.availableQuantity,
        countedQuantity: undefined,
        difference: 0,
        status: 'Not Counted' as StocktakingItemStatus,
      }));

    const updatedSession = {
      ...activeSession,
      items: [...activeSession.items, ...newItems],
      totalExpected: activeSession.items.length + newItems.length,
    };

    try {
      const res = await cloudApi.saveStocktakingSession(updatedSession);
      if (res && res.data) {
        setActiveSession(res.data);
        toast.success(`Included ${newItems.length} newly added inventory item(s) into this stocktaking session.`);
        await loadSessions();
      }
    } catch (err: any) {
      toast.error('Failed to include new items');
    }
  };

  // Update item counting status within active session
  const handleUpdateItemCount = async (
    itemId: string,
    countedVal: number,
    status: StocktakingItemStatus,
    reason?: string
  ) => {
    if (!activeSession) return;

    const updatedItems = activeSession.items.map((it) => {
      if (it.itemId !== itemId) return it;
      const diff = countedVal - it.expectedQuantity;
      return {
        ...it,
        countedQuantity: countedVal,
        difference: diff,
        status: status,
        reason: reason || it.reason,
        countedAt: new Date().toISOString(),
        countedBy: user?.name || 'Store Keeper',
      };
    });

    const countedCount = updatedItems.filter((i) => i.status === 'Counted').length;
    const discCount = updatedItems.filter(
      (i) => i.status === 'Counted' && (i.difference || 0) !== 0
    ).length;

    // Check if entire scope is complete
    const allCounted = updatedItems.every((i) => i.status === 'Counted');
    const sessionStatus = allCounted ? 'Completed' : 'In Progress';

    const updatedSession: StocktakingSession = {
      ...activeSession,
      items: updatedItems,
      totalCounted: countedCount,
      totalDiscrepancies: discCount,
      status: sessionStatus as any,
      completedAt: allCounted ? new Date().toISOString() : undefined,
    };

    setActiveSession(updatedSession);

    // Save progress to cloud
    try {
      await cloudApi.saveStocktakingSession(updatedSession);
    } catch (err) {
      console.warn('Failed to auto-save stocktaking session progress:', err);
    }
  };

  // "Continue Counting": Jump to and focus next uncounted item
  const handleContinueCountingNext = () => {
    if (!activeSession) return;
    const nextUncounted = activeSession.items.find(
      (it) => it.status === 'Not Counted' || it.status === 'In Progress'
    );
    if (nextUncounted) {
      setItemSearch(nextUncounted.itemCode);
      setStatusFilter('All');
      toast.info(`Jumped to next item: ${nextUncounted.itemName} (${nextUncounted.itemCode})`);
    } else {
      toast.success('All items in this stocktaking scope have been counted!');
    }
  };

  // Filtered Checklist items for active session
  const filteredChecklist = useMemo(() => {
    if (!activeSession) return [];
    return activeSession.items.filter((it) => {
      if (categoryFilter !== 'All' && it.category !== categoryFilter) return false;
      if (statusFilter !== 'All' && it.status !== statusFilter) return false;
      if (!itemSearch.trim()) return true;

      const q = itemSearch.toLowerCase();
      return (
        it.itemName.toLowerCase().includes(q) ||
        it.itemCode.toLowerCase().includes(q) ||
        it.location.toLowerCase().includes(q)
      );
    });
  }, [activeSession, categoryFilter, statusFilter, itemSearch]);

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xs space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300">
                <PieChart className="w-4 h-4" />
              </span>
              <h2 className="text-base sm:text-lg font-black text-slate-900 dark:text-white">
                Pending Count Tracker & Stocktaking Progress
              </h2>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Real-time physical counting progress across all 5 categories. Track Not Counted, In Progress, and Counted checklist statuses with automatic session resumption.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {activeSession && (
              <Button
                variant="primary"
                size="sm"
                icon={<Play className="w-4 h-4" />}
                onClick={handleContinueCountingNext}
              >
                Continue Counting Next Item &rarr;
              </Button>
            )}

            <Button
              variant="outline"
              size="sm"
              icon={<Plus className="w-4 h-4 text-emerald-600" />}
              onClick={() => setIsNewSessionModalOpen(true)}
            >
              Start New Stocktaking Session
            </Button>
          </div>
        </div>

        {/* Category Progress Dashboards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 pt-4 border-t border-slate-100 dark:border-slate-800 text-xs">
          {categoryMetrics.map((cat) => (
            <div
              key={cat.category}
              className={`p-3 rounded-xl border transition-all ${
                cat.isComplete
                  ? 'bg-emerald-50/60 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-800'
                  : cat.counted > 0
                  ? 'bg-blue-50/40 dark:bg-blue-950/30 border-blue-200 dark:border-blue-900'
                  : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-black text-slate-800 dark:text-slate-200 uppercase tracking-wider text-[11px]">
                  {cat.category}
                </span>
                <span
                  className={`px-1.5 py-0.5 rounded-full text-[10px] font-bold ${
                    cat.isComplete
                      ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200'
                      : cat.counted > 0
                      ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200'
                      : 'bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-300'
                  }`}
                >
                  {cat.isComplete ? 'Complete ✓' : cat.counted > 0 ? 'In Progress' : 'Pending'}
                </span>
              </div>

              {/* Progress Count */}
              <div className="flex items-baseline justify-between mb-1.5 font-mono text-[11px]">
                <span className="font-bold text-slate-900 dark:text-slate-100">
                  {cat.counted} of {cat.totalExpected} counted
                </span>
                <span className="text-slate-400 font-normal">
                  {cat.remaining} remaining
                </span>
              </div>

              {/* Progress Bar */}
              <div className="w-full bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
                <div
                  className={`h-full transition-all duration-300 ${
                    cat.isComplete
                      ? 'bg-emerald-500'
                      : cat.counted > 0
                      ? 'bg-blue-500'
                      : 'bg-slate-300 dark:bg-slate-600'
                  }`}
                  style={{ width: `${cat.percent}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Active Session Notice & Resume Bar */}
      {activeSession ? (
        <div className="p-4 rounded-2xl bg-blue-50/70 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900/60 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-black text-blue-900 dark:text-blue-200 text-sm">
                Active Session: {activeSession.title}
              </span>
              <span className="px-2 py-0.5 rounded-full font-mono text-[10px] font-bold bg-blue-200 dark:bg-blue-900 text-blue-800 dark:text-blue-200">
                {activeSession.sessionCode}
              </span>
            </div>
            <p className="text-blue-700 dark:text-blue-300 text-[11px] mt-0.5">
              Started by <strong>{activeSession.createdBy}</strong> on{' '}
              {new Date(activeSession.startedAt).toLocaleString()} • Scope: {activeSession.categories.join(', ')}
            </p>
          </div>

          <div className="flex items-center gap-2">
            {newlyAddedItemsCount > 0 && (
              <button
                type="button"
                onClick={handleIncludeNewItems}
                className="px-2.5 py-1 text-[11px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-200 border border-amber-300 dark:border-amber-800 rounded-xl hover:bg-amber-200 flex items-center gap-1 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                <span>Include {newlyAddedItemsCount} New Store Items</span>
              </button>
            )}

            <Button
              variant="outline"
              size="sm"
              icon={<RotateCcw className="w-3.5 h-3.5" />}
              onClick={loadSessions}
            >
              Refresh
            </Button>
          </div>
        </div>
      ) : (
        <div className="p-8 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-dashed border-slate-200 dark:border-slate-700 text-center space-y-2">
          <Clock className="w-8 h-8 mx-auto text-slate-400" />
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">
            No Active Stocktaking Session
          </h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Click &ldquo;Start New Stocktaking Session&rdquo; above to select categories and generate an inventory physical count checklist.
          </p>
        </div>
      )}

      {/* Active Session Checklist Table */}
      {activeSession && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs overflow-hidden space-y-3 p-4">
          <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 text-xs">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={itemSearch}
                onChange={(e) => setItemSearch(e.target.value)}
                placeholder="Search expected item name, asset code, or location rack..."
                className="w-full pl-10 pr-8 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-500 text-xs"
              />
              {itemSearch && (
                <button
                  type="button"
                  onClick={() => setItemSearch('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 p-0.5 text-slate-400"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value as any)}
                className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
              >
                <option value="All">All Categories</option>
                {ALL_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>

              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as any)}
                className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
              >
                <option value="All">All Counting Statuses</option>
                <option value="Not Counted">Not Counted</option>
                <option value="In Progress">In Progress</option>
                <option value="Counted">Counted</option>
                <option value="Needs Review">Needs Review</option>
              </select>
            </div>
          </div>

          {/* Checklist Table */}
          <div className="overflow-x-auto max-h-[500px] overflow-y-auto border border-slate-200 dark:border-slate-800 rounded-xl">
            <table className="w-full text-left border-collapse text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800 sticky top-0 z-10 border-b border-slate-200 dark:border-slate-700 text-[11px] font-bold text-slate-600 dark:text-slate-300">
                <tr>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3 min-w-[200px]">Item Description</th>
                  <th className="py-2.5 px-3">Category</th>
                  <th className="py-2.5 px-3">Location</th>
                  <th className="py-2.5 px-3 text-right">Expected Qty</th>
                  <th className="py-2.5 px-3 text-center w-28">Physical Count</th>
                  <th className="py-2.5 px-3 text-center">Variance</th>
                  <th className="py-2.5 px-3 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredChecklist.map((it) => {
                  const isCounted = it.status === 'Counted';
                  const countedVal = it.countedQuantity !== undefined ? it.countedQuantity : it.expectedQuantity;
                  const diff = isCounted ? (it.difference || 0) : 0;

                  return (
                    <tr
                      key={it.itemId}
                      className={`hover:bg-slate-50/50 dark:hover:bg-slate-800/30 ${
                        isCounted
                          ? diff !== 0
                            ? 'bg-amber-50/30 dark:bg-amber-950/20'
                            : 'bg-emerald-50/20 dark:bg-emerald-950/10'
                          : ''
                      }`}
                    >
                      <td className="py-2.5 px-3">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            it.status === 'Counted'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                              : it.status === 'In Progress'
                              ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                              : it.status === 'Needs Review'
                              ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                              : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                          }`}
                        >
                          {it.status}
                        </span>
                      </td>

                      <td className="py-2.5 px-3">
                        <div className="font-bold text-slate-900 dark:text-slate-100">{it.itemName}</div>
                        <div className="text-[10px] text-slate-500 font-mono">{it.itemCode}</div>
                      </td>

                      <td className="py-2.5 px-3 text-slate-600 dark:text-slate-400">{it.category}</td>
                      <td className="py-2.5 px-3 text-slate-600 dark:text-slate-400">{it.location}</td>

                      <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-700 dark:text-slate-300">
                        {it.expectedQuantity}
                      </td>

                      <td className="py-2.5 px-3 text-center">
                        <input
                          type="number"
                          min="0"
                          value={it.countedQuantity !== undefined ? it.countedQuantity : ''}
                          placeholder={String(it.expectedQuantity)}
                          onChange={(e) =>
                            handleUpdateItemCount(
                              it.itemId,
                              Number(e.target.value),
                              'Counted'
                            )
                          }
                          className="w-20 px-2 py-1 text-center font-mono font-bold text-xs rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 focus:ring-1 focus:ring-blue-500"
                        />
                      </td>

                      <td className="py-2.5 px-3 text-center font-mono">
                        {isCounted ? (
                          <span
                            className={`font-bold ${
                              diff === 0
                                ? 'text-emerald-600'
                                : diff > 0
                                ? 'text-blue-600'
                                : 'text-rose-600'
                            }`}
                          >
                            {diff > 0 ? `+${diff}` : diff}
                          </span>
                        ) : (
                          <span className="text-slate-400">—</span>
                        )}
                      </td>

                      <td className="py-2.5 px-3 text-center">
                        {!isCounted ? (
                          <button
                            type="button"
                            onClick={() =>
                              handleUpdateItemCount(
                                it.itemId,
                                it.expectedQuantity,
                                'Counted'
                              )
                            }
                            className="px-2 py-1 text-[10px] font-bold rounded bg-emerald-50 text-emerald-700 hover:bg-emerald-600 hover:text-white dark:bg-emerald-950 dark:text-emerald-300 transition-colors"
                          >
                            Confirm Match ✓
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() =>
                              handleUpdateItemCount(
                                it.itemId,
                                it.expectedQuantity,
                                'Not Counted'
                              )
                            }
                            className="text-[10px] text-slate-400 hover:text-rose-600 font-bold"
                          >
                            Reset
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Start New Session Modal */}
      <Modal
        isOpen={isNewSessionModalOpen}
        onClose={() => setIsNewSessionModalOpen(false)}
        title="Start Physical Stocktaking Session"
        maxWidth="max-w-xl"
      >
        <div className="space-y-4 text-xs">
          <div>
            <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
              Stocktaking Session Title *
            </label>
            <input
              type="text"
              value={sessionTitle}
              onChange={(e) => setSessionTitle(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold text-xs"
            />
          </div>

          <div>
            <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
              Categories In Scope *
            </label>
            <div className="flex flex-wrap gap-2">
              {ALL_CATEGORIES.map((cat) => {
                const isChecked = selectedCategories.includes(cat);
                return (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => {
                      if (isChecked) {
                        if (selectedCategories.length > 1) {
                          setSelectedCategories(selectedCategories.filter((c) => c !== cat));
                        }
                      } else {
                        setSelectedCategories([...selectedCategories, cat]);
                      }
                    }}
                    className={`px-3 py-1.5 rounded-xl font-bold border transition-all cursor-pointer ${
                      isChecked
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'bg-white dark:bg-slate-800 text-slate-600 border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    {cat}
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
              Store Locations
            </label>
            <select
              value={selectedLocations[0] || 'All'}
              onChange={(e) => setSelectedLocations([e.target.value])}
              className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
            >
              {locationOptions.map((loc) => (
                <option key={loc} value={loc}>
                  {loc === 'All' ? 'All Store Locations' : loc}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
              Audit Notes
            </label>
            <textarea
              value={sessionNotes}
              onChange={(e) => setSessionNotes(e.target.value)}
              placeholder="e.g. Mandatory monthly store audit by Storekeeper & Safety Lead"
              rows={2}
              className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
            />
          </div>

          <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-200 dark:border-slate-800">
            <Button variant="outline" size="sm" onClick={() => setIsNewSessionModalOpen(false)}>
              Cancel
            </Button>
            <Button variant="primary" size="sm" onClick={handleStartSession}>
              Initialize Session
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
