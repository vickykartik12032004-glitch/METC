import React, { useState, useEffect, useMemo } from 'react';
import { 
  FileSpreadsheet, 
  Search, 
  Filter, 
  Sparkles, 
  Eye, 
  FileText, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  Ban, 
  Download, 
  Trash2, 
  Building, 
  Calendar, 
  DollarSign, 
  Layers, 
  ExternalLink,
  ShieldCheck,
  RefreshCw
} from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '../../../../components/ui/Button';
import { Modal } from '../../../../components/ui/Modal';
import { PurchaseRecord } from '../../../../types/purchase.types';
import { purchaseService } from '../../../../services/purchaseService';
import { useAuthStore } from '../../../../store/useAuthStore';
import { usePermissions } from '../../../../hooks/usePermissions';
import { useAssetStore } from '../../../../store/useAssetStore';
import { exportToCSV } from '../../../../utils/exportUtils';

interface PurchaseRecordsTabProps {
  onOpenScanner: () => void;
  onRefreshInventory?: () => void;
}

export const PurchaseRecordsTab: React.FC<PurchaseRecordsTabProps> = ({
  onOpenScanner,
  onRefreshInventory,
}) => {
  const { user } = useAuthStore();
  const { canEdit } = usePermissions();
  const { fetchAssets } = useAssetStore();

  const [purchases, setPurchases] = useState<PurchaseRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'Draft' | 'Confirmed' | 'Voided'>('ALL');

  // Detail Modal & Preview
  const [activePurchase, setActivePurchase] = useState<PurchaseRecord | null>(null);
  const [previewAttachment, setPreviewAttachment] = useState<{ fileName: string; fileType: string; dataUrl?: string } | null>(null);
  const [isConfirmingId, setIsConfirmingId] = useState<string | null>(null);
  const [voidModalPurchase, setVoidModalPurchase] = useState<PurchaseRecord | null>(null);
  const [voidReason, setVoidReason] = useState('');

  const loadPurchases = async () => {
    setIsLoading(true);
    try {
      const data = await purchaseService.getPurchases();
      setPurchases(data);
    } catch (err: any) {
      toast.error('Failed to load purchase records.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadPurchases();
  }, []);

  // Filtered List
  const filteredPurchases = useMemo(() => {
    return purchases.filter((p) => {
      if (statusFilter !== 'ALL' && p.status !== statusFilter) return false;
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase();
      return (
        p.invoiceNumber.toLowerCase().includes(q) ||
        p.supplierName.toLowerCase().includes(q) ||
        (p.purchaseOrderNumber && p.purchaseOrderNumber.toLowerCase().includes(q)) ||
        p.lineItems.some((l) => l.name.toLowerCase().includes(q) || l.rawDescription.toLowerCase().includes(q))
      );
    });
  }, [purchases, searchQuery, statusFilter]);

  // Financial Metrics
  const metrics = useMemo(() => {
    const totalCount = purchases.length;
    const confirmedList = purchases.filter((p) => p.status === 'Confirmed');
    const draftList = purchases.filter((p) => p.status === 'Draft');
    const totalSpend = confirmedList.reduce((acc, p) => acc + (Number(p.grandTotal) || 0), 0);

    return {
      totalCount,
      confirmedCount: confirmedList.length,
      draftCount: draftList.length,
      totalSpend,
    };
  }, [purchases]);

  // Confirm and apply stock
  const handleConfirmPurchase = async (purchase: PurchaseRecord) => {
    if (!canEdit) {
      toast.error('Restricted: Only Admin and Super Admin can confirm purchase invoices.');
      return;
    }

    setIsConfirmingId(purchase.id);
    try {
      const res = await purchaseService.confirmPurchase(
        purchase.id,
        purchase.idempotencyKey,
        user?.name || 'Store Keeper'
      );
      toast.success(`Invoice #${purchase.invoiceNumber} confirmed! Stock updated for ${res.stockUpdates.length} items.`);
      if (fetchAssets) await fetchAssets();
      if (onRefreshInventory) onRefreshInventory();
      await loadPurchases();
    } catch (err: any) {
      toast.error(`Confirmation failed: ${err.message}`);
    } finally {
      setIsConfirmingId(null);
    }
  };

  // Void Purchase
  const handleVoidPurchase = async () => {
    if (!voidModalPurchase) return;
    try {
      await purchaseService.voidPurchase(
        voidModalPurchase.id,
        voidReason,
        user?.name || 'Store Keeper'
      );
      toast.info(`Invoice #${voidModalPurchase.invoiceNumber} has been voided.`);
      setVoidModalPurchase(null);
      setVoidReason('');
      await loadPurchases();
    } catch (err: any) {
      toast.error(`Void failed: ${err.message}`);
    }
  };

  // Delete Draft
  const handleDeleteDraft = async (purchase: PurchaseRecord) => {
    if (purchase.status === 'Confirmed') {
      toast.error('Confirmed invoices cannot be deleted. Use Void instead.');
      return;
    }
    if (!window.confirm(`Delete draft invoice #${purchase.invoiceNumber}?`)) return;

    try {
      await purchaseService.deletePurchase(purchase.id, user?.name || 'Store Keeper');
      toast.success('Draft purchase deleted.');
      await loadPurchases();
    } catch (err: any) {
      toast.error(`Delete failed: ${err.message}`);
    }
  };

  // Export CSV
  const handleExportCSV = () => {
    if (filteredPurchases.length === 0) {
      toast.error('No purchases to export');
      return;
    }
    const exportData = filteredPurchases.map((p) => ({
      'Invoice Number': p.invoiceNumber,
      'Invoice Date': p.invoiceDate,
      'Supplier Name': p.supplierName,
      'Supplier Contact': p.supplierContact || '',
      'PO Number': p.purchaseOrderNumber || '',
      'Line Items Count': p.lineItemsCount,
      'Subtotal ($)': p.subtotal,
      'Tax Amount ($)': p.taxAmount,
      'Grand Total ($)': p.grandTotal,
      'Currency': p.currency,
      'Status': p.status,
      'Stock Updated': p.stockUpdated ? 'Yes' : 'No',
      'Created By': p.createdByUser,
      'Created Date': p.createdAt,
    }));
    exportToCSV(exportData, `MOUNTEC_Purchase_Invoices_${new Date().toISOString().slice(0, 10)}.csv`);
    toast.success(`Exported ${filteredPurchases.length} invoices to CSV`);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner Toolbar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300">
                <FileSpreadsheet className="w-4 h-4" />
              </span>
              <h2 className="text-base sm:text-lg font-black text-slate-900 dark:text-white">
                Purchase Records & Vendor Invoices
              </h2>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Automated invoice capture, document archive, Singapore GST compliance, and direct stock increments for MOUNTEC inventory.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              icon={<RefreshCw className="w-3.5 h-3.5" />}
              onClick={loadPurchases}
            >
              Refresh
            </Button>

            <Button
              variant="outline"
              size="sm"
              icon={<Download className="w-3.5 h-3.5 text-blue-600" />}
              onClick={handleExportCSV}
            >
              Export CSV
            </Button>

            {canEdit && (
              <Button
                variant="primary"
                size="sm"
                icon={<Sparkles className="w-4 h-4 text-amber-300" />}
                onClick={onOpenScanner}
              >
                AI Invoice Scanner
              </Button>
            )}
          </div>
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 text-xs">
          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
            <span className="text-slate-400 block text-[10px] uppercase font-bold">Total Invoices</span>
            <span className="text-base font-black text-slate-900 dark:text-white">{metrics.totalCount}</span>
          </div>

          <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/60">
            <span className="text-emerald-700 dark:text-emerald-300 block text-[10px] uppercase font-bold flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Confirmed & Stocked
            </span>
            <span className="text-base font-black text-emerald-700 dark:text-emerald-300">{metrics.confirmedCount}</span>
          </div>

          <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60">
            <span className="text-amber-800 dark:text-amber-300 block text-[10px] uppercase font-bold flex items-center gap-1">
              <Clock className="w-3 h-3 text-amber-600" /> Pending Review
            </span>
            <span className="text-base font-black text-amber-800 dark:text-amber-300">{metrics.draftCount}</span>
          </div>

          <div className="p-3 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900/60">
            <span className="text-blue-700 dark:text-blue-300 block text-[10px] uppercase font-bold flex items-center gap-1">
              <DollarSign className="w-3 h-3 text-blue-600" /> Total Spend (Confirmed)
            </span>
            <span className="text-base font-black text-blue-700 dark:text-blue-300">
              ${metrics.totalSpend.toLocaleString('en-SG', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-3">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="relative w-full sm:w-96 flex items-center">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 pointer-events-none" />
            <input
              type="text"
              placeholder="Search by invoice #, supplier name, PO #, item..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto">
            {(['ALL', 'Confirmed', 'Draft', 'Voided'] as const).map((st) => (
              <button
                key={st}
                type="button"
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-colors shrink-0 ${
                  statusFilter === st
                    ? 'bg-blue-600 text-white border-blue-600 shadow-2xs'
                    : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100'
                }`}
              >
                {st === 'ALL' ? 'All Invoices' : st}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Purchases Data Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-2xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-100/80 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 uppercase tracking-wider text-[10px] font-bold border-b border-slate-200 dark:border-slate-700">
              <tr>
                <th className="py-3 px-3">Invoice #</th>
                <th className="py-3 px-3">Date</th>
                <th className="py-3 px-3">Supplier Name</th>
                <th className="py-3 px-3 text-center">Items</th>
                <th className="py-3 px-3 text-right">Grand Total</th>
                <th className="py-3 px-3 text-center">Status</th>
                <th className="py-3 px-3 text-center">Stock Updated</th>
                <th className="py-3 px-3 text-center">Attachment</th>
                <th className="py-3 px-3 text-right pr-4">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {isLoading ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-slate-400">
                    <div className="flex items-center justify-center gap-2">
                      <RefreshCw className="w-4 h-4 animate-spin text-blue-600" />
                      <span>Loading purchase invoices...</span>
                    </div>
                  </td>
                </tr>
              ) : filteredPurchases.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-400">
                    <FileText className="w-10 h-10 mx-auto text-slate-300 dark:text-slate-700 mb-2" />
                    <p className="font-bold text-sm text-slate-700 dark:text-slate-300">No purchase records found</p>
                    <p className="text-xs text-slate-400 mt-1">
                      Click "AI Invoice Scanner" above to scan your first vendor invoice photo or PDF.
                    </p>
                  </td>
                </tr>
              ) : (
                filteredPurchases.map((purchase) => {
                  const isConfirmed = purchase.status === 'Confirmed';
                  const isVoided = purchase.status === 'Voided';
                  const isDraft = purchase.status === 'Draft';

                  return (
                    <tr
                      key={purchase.id}
                      className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors"
                    >
                      {/* Invoice # */}
                      <td className="py-3 px-3 font-mono font-bold text-blue-600 dark:text-blue-400">
                        <button
                          type="button"
                          onClick={() => setActivePurchase(purchase)}
                          className="hover:underline text-left"
                        >
                          {purchase.invoiceNumber}
                        </button>
                        {purchase.purchaseOrderNumber && (
                          <div className="text-[10px] text-slate-400 font-normal">
                            PO: {purchase.purchaseOrderNumber}
                          </div>
                        )}
                      </td>

                      {/* Date */}
                      <td className="py-3 px-3 text-slate-600 dark:text-slate-400 font-medium">
                        {purchase.invoiceDate}
                      </td>

                      {/* Supplier */}
                      <td className="py-3 px-3">
                        <span className="font-bold text-slate-900 dark:text-white block">
                          {purchase.supplierName}
                        </span>
                        {purchase.supplierContact && (
                          <span className="text-[10px] text-slate-400 block truncate max-w-[180px]">
                            {purchase.supplierContact}
                          </span>
                        )}
                      </td>

                      {/* Line Items Count */}
                      <td className="py-3 px-3 text-center">
                        <span className="px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-[10px] font-bold text-slate-700 dark:text-slate-300">
                          {purchase.lineItemsCount || purchase.lineItems.length} lines
                        </span>
                      </td>

                      {/* Grand Total */}
                      <td className="py-3 px-3 text-right font-mono font-bold text-slate-900 dark:text-white">
                        ${Number(purchase.grandTotal || 0).toLocaleString('en-SG', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        <span className="text-[10px] text-slate-400 ml-1 font-normal">{purchase.currency}</span>
                      </td>

                      {/* Status */}
                      <td className="py-3 px-3 text-center">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                          isConfirmed
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300'
                            : isDraft
                            ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300'
                            : 'bg-rose-100 text-rose-800 dark:bg-rose-950/80 dark:text-rose-300'
                        }`}>
                          {isConfirmed && <CheckCircle2 className="w-3 h-3" />}
                          {isDraft && <Clock className="w-3 h-3" />}
                          {isVoided && <Ban className="w-3 h-3" />}
                          <span>{purchase.status}</span>
                        </span>
                      </td>

                      {/* Stock Updated */}
                      <td className="py-3 px-3 text-center">
                        {purchase.stockUpdated ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-600 dark:text-emerald-400">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Stock Received
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-400">
                            <Clock className="w-3 h-3" /> Not Stocked
                          </span>
                        )}
                      </td>

                      {/* Attachment */}
                      <td className="py-3 px-3 text-center">
                        {purchase.invoiceFile?.dataUrl ? (
                          <button
                            type="button"
                            onClick={() => setPreviewAttachment(purchase.invoiceFile!)}
                            className="p-1 rounded text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-slate-800 transition-colors inline-flex items-center gap-1 text-[11px] font-medium"
                            title="View attached invoice photo/PDF"
                          >
                            <FileText className="w-4 h-4" />
                            <span>View</span>
                          </button>
                        ) : (
                          <span className="text-slate-300 text-[10px]">—</span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-3 text-right pr-4">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={() => setActivePurchase(purchase)}
                            className="p-1 rounded hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500 hover:text-blue-600 transition-colors"
                            title="View Invoice Details"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          {isDraft && canEdit && (
                            <button
                              type="button"
                              onClick={() => handleConfirmPurchase(purchase)}
                              disabled={isConfirmingId === purchase.id}
                              className="px-2 py-0.5 rounded bg-emerald-600 text-white hover:bg-emerald-700 transition-colors text-[10px] font-bold shadow-2xs"
                              title="Confirm purchase and increment inventory stock"
                            >
                              {isConfirmingId === purchase.id ? 'Stocking...' : 'Confirm Stock'}
                            </button>
                          )}

                          {isDraft && canEdit && (
                            <button
                              type="button"
                              onClick={() => handleDeleteDraft(purchase)}
                              className="p-1 rounded hover:bg-rose-100 dark:hover:bg-rose-950 text-slate-400 hover:text-rose-600 transition-colors"
                              title="Delete Draft"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {!isVoided && canEdit && (
                            <button
                              type="button"
                              onClick={() => setVoidModalPurchase(purchase)}
                              className="p-1 rounded hover:bg-amber-100 dark:hover:bg-amber-950 text-slate-400 hover:text-amber-600 transition-colors"
                              title="Void Invoice"
                            >
                              <Ban className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Purchase Details Modal */}
      {activePurchase && (
        <Modal
          isOpen={!!activePurchase}
          onClose={() => setActivePurchase(null)}
          title={`Purchase Invoice Details - #${activePurchase.invoiceNumber}`}
          size="lg"
        >
          <div className="space-y-5 text-xs text-slate-900 dark:text-slate-100 max-h-[80vh] overflow-y-auto pr-1">
            {/* Header Specs */}
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase block">Supplier</span>
                <span className="font-bold text-sm text-slate-900 dark:text-white">{activePurchase.supplierName}</span>
                {activePurchase.supplierContact && (
                  <span className="text-[10px] text-slate-400 block mt-0.5">{activePurchase.supplierContact}</span>
                )}
              </div>

              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase block">Invoice Date</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">{activePurchase.invoiceDate}</span>
                {activePurchase.purchaseOrderNumber && (
                  <span className="text-[10px] text-slate-400 block mt-0.5">PO: {activePurchase.purchaseOrderNumber}</span>
                )}
              </div>

              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase block">Status</span>
                <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase mt-0.5 ${
                  activePurchase.status === 'Confirmed'
                    ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                    : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                }`}>
                  {activePurchase.status}
                </span>
                <span className="text-[10px] text-slate-400 block mt-0.5">
                  {activePurchase.stockUpdated ? 'Stock Applied' : 'Stock Not Applied'}
                </span>
              </div>

              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase block">Grand Total</span>
                <span className="font-bold text-base text-blue-600 dark:text-blue-400 font-mono">
                  ${Number(activePurchase.grandTotal).toFixed(2)} {activePurchase.currency}
                </span>
                <span className="text-[10px] text-slate-400 block mt-0.5">
                  Subtotal: ${Number(activePurchase.subtotal).toFixed(2)} | GST: ${Number(activePurchase.taxAmount).toFixed(2)}
                </span>
              </div>
            </div>

            {/* Line Items Table */}
            <div className="space-y-2">
              <h4 className="font-bold text-xs uppercase tracking-wider text-slate-500">
                Purchased Line Items ({activePurchase.lineItems.length})
              </h4>
              <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-[10px] font-bold uppercase">
                    <tr>
                      <th className="py-2 px-3">#</th>
                      <th className="py-2 px-3">Item Name</th>
                      <th className="py-2 px-3">Category</th>
                      <th className="py-2 px-3 text-right">Qty</th>
                      <th className="py-2 px-3">UOM</th>
                      <th className="py-2 px-3 text-right">Unit Price</th>
                      <th className="py-2 px-3 text-right">Total</th>
                      <th className="py-2 px-3">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {activePurchase.lineItems.map((item, idx) => (
                      <tr key={item.id}>
                        <td className="py-2 px-3 text-slate-400 font-mono text-[11px]">{idx + 1}</td>
                        <td className="py-2 px-3 font-semibold text-slate-900 dark:text-slate-100">
                          {item.name}
                          {item.code && (
                            <span className="ml-1.5 font-mono text-[10px] text-blue-600 dark:text-blue-400">
                              [{item.code}]
                            </span>
                          )}
                        </td>
                        <td className="py-2 px-3 text-slate-500">{item.category}</td>
                        <td className="py-2 px-3 text-right font-mono font-bold">{item.quantity}</td>
                        <td className="py-2 px-3 text-slate-500 uppercase text-[10px]">{item.unit}</td>
                        <td className="py-2 px-3 text-right font-mono">${Number(item.unitPrice).toFixed(2)}</td>
                        <td className="py-2 px-3 text-right font-mono font-bold">${Number(item.totalPrice).toFixed(2)}</td>
                        <td className="py-2 px-3">
                          <span className={`px-1.5 py-0.5 rounded text-[10px] font-semibold ${
                            item.action === 'UPDATE_EXISTING'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                              : item.action === 'CREATE_NEW'
                              ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                              : 'bg-slate-200 text-slate-600'
                          }`}>
                            {item.action === 'UPDATE_EXISTING' ? 'Updated Stock' : item.action === 'CREATE_NEW' ? 'Created Item' : 'Ignored'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Audit Trail */}
            {activePurchase.auditTrail && activePurchase.auditTrail.length > 0 && (
              <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <h4 className="font-bold text-xs uppercase tracking-wider text-slate-500">
                  Audit Trail
                </h4>
                <div className="space-y-1.5 bg-slate-50 dark:bg-slate-800/40 p-3 rounded-xl border border-slate-200 dark:border-slate-800">
                  {activePurchase.auditTrail.map((entry, idx) => (
                    <div key={idx} className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
                      <span>• {entry.note || entry.action} (User: <strong className="text-slate-700 dark:text-slate-300">{entry.user}</strong>)</span>
                      <span className="font-mono text-[10px] text-slate-400">{new Date(entry.timestamp).toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Attached Invoice File */}
            {activePurchase.invoiceFile?.dataUrl && (
              <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-blue-600" />
                  <span className="font-semibold text-slate-700 dark:text-slate-300">{activePurchase.invoiceFile.fileName}</span>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  icon={<Eye className="w-3.5 h-3.5" />}
                  onClick={() => setPreviewAttachment(activePurchase.invoiceFile!)}
                >
                  View Attached Document
                </Button>
              </div>
            )}
          </div>
        </Modal>
      )}

      {/* Attachment Preview Modal */}
      {previewAttachment && (
        <Modal
          isOpen={!!previewAttachment}
          onClose={() => setPreviewAttachment(null)}
          title={`Invoice Document - ${previewAttachment.fileName}`}
          size="lg"
        >
          <div className="max-h-[80vh] overflow-y-auto p-2">
            {previewAttachment.fileType.includes('image') ? (
              <img src={previewAttachment.dataUrl} alt="Attached Invoice" className="w-full object-contain rounded-xl" />
            ) : (
              <div className="p-8 text-center space-y-4">
                <FileText className="w-16 h-16 mx-auto text-red-500" />
                <p className="font-bold text-sm">{previewAttachment.fileName}</p>
                <a
                  href={previewAttachment.dataUrl}
                  download={previewAttachment.fileName}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 text-white font-semibold text-xs shadow-sm hover:bg-blue-700"
                >
                  <Download className="w-4 h-4" />
                  Download PDF Invoice
                </a>
              </div>
            )}
          </div>
        </Modal>
      )}

      {/* Void Invoice Reason Modal */}
      {voidModalPurchase && (
        <Modal
          isOpen={!!voidModalPurchase}
          onClose={() => setVoidModalPurchase(null)}
          title={`Void Invoice #${voidModalPurchase.invoiceNumber}`}
          size="sm"
        >
          <div className="space-y-4 text-xs">
            <p className="text-slate-600 dark:text-slate-400">
              Voiding an invoice marks it as cancelled in accounting history while preserving the audit trail and original attachment.
            </p>
            <div>
              <label className="block font-bold text-slate-500 uppercase text-[10px] mb-1">Reason for Voiding</label>
              <textarea
                value={voidReason}
                onChange={(e) => setVoidReason(e.target.value)}
                rows={3}
                placeholder="e.g. Supplier issued revised credit note or duplicate scan"
                className="w-full p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
              <Button variant="outline" size="sm" onClick={() => setVoidModalPurchase(null)}>
                Cancel
              </Button>
              <Button variant="danger" size="sm" onClick={handleVoidPurchase}>
                Confirm Void
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
