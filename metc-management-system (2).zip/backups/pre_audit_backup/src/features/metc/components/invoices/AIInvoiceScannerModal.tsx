import React, { useState, useRef, useMemo } from 'react';
import { 
  Camera, 
  Upload, 
  FileText, 
  Image as ImageIcon, 
  X, 
  Sparkles, 
  AlertTriangle, 
  CheckCircle2, 
  Plus, 
  Trash2, 
  Copy, 
  RefreshCw, 
  FileCheck, 
  ExternalLink, 
  Layers, 
  ArrowRight,
  Info,
  DollarSign,
  Building,
  Calendar,
  Search,
  Eye,
  ShieldCheck,
  ChevronDown
} from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '../../../../components/ui/Button';
import { Modal } from '../../../../components/ui/Modal';
import { METCItem, AssetCategory } from '../../../../types';
import { 
  PurchaseRecord, 
  PurchaseLineItem, 
  InvoiceAttachment, 
  ExtractedInvoiceData, 
  InvoiceDiscrepancyCheck,
  LineItemAction
} from '../../../../types/purchase.types';
import { purchaseService } from '../../../../services/purchaseService';
import { useAuthStore } from '../../../../store/useAuthStore';
import { useAssetStore } from '../../../../store/useAssetStore';
import { getNextMetNumber, isMetNumberRecommended } from '../../../../utils/metAssetNumber';
import { matchInvoiceItemWithInventory } from '../../../../utils/inventoryMatcher';

interface AIInvoiceScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPurchaseConfirmed?: (purchase: PurchaseRecord) => void;
  existingItems: METCItem[];
}

type ScanStep = 'UPLOAD' | 'SCANNING' | 'REVIEW';

export const AIInvoiceScannerModal: React.FC<AIInvoiceScannerModalProps> = ({
  isOpen,
  onClose,
  onPurchaseConfirmed,
  existingItems,
}) => {
  const { user } = useAuthStore();
  const { applyRemoteAssetUpsert, fetchAssets } = useAssetStore();

  const [step, setStep] = useState<ScanStep>('UPLOAD');
  const [selectedFiles, setSelectedFiles] = useState<Array<{ name: string; type: string; size: number; dataUrl: string }>>([]);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);

  // Scan progress state
  const [scanProgressMessage, setScanProgressMessage] = useState('Initializing Gemini Document AI...');
  const [scanError, setScanError] = useState<string | null>(null);

  // Extracted and Editable State
  const [purchaseId, setPurchaseId] = useState<string>('');
  const [idempotencyKey, setIdempotencyKey] = useState<string>(() => `idem-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`);
  const [supplierName, setSupplierName] = useState('');
  const [supplierContact, setSupplierContact] = useState('');
  const [invoiceNumber, setInvoiceNumber] = useState('');
  const [invoiceDate, setInvoiceDate] = useState(new Date().toISOString().split('T')[0]);
  const [purchaseOrderNumber, setPurchaseOrderNumber] = useState('');
  const [paymentTerms, setPaymentTerms] = useState('Net 30 Days');
  const [currency, setCurrency] = useState('SGD');

  const [subtotal, setSubtotal] = useState<number>(0);
  const [taxRate, setTaxRate] = useState<number>(9); // 9% GST in Singapore
  const [taxAmount, setTaxAmount] = useState<number>(0);
  const [discountAmount, setDiscountAmount] = useState<number>(0);
  const [freightAmount, setFreightAmount] = useState<number>(0);
  const [grandTotal, setGrandTotal] = useState<number>(0);

  const [lineItems, setLineItems] = useState<PurchaseLineItem[]>([]);
  const [discrepancyCheck, setDiscrepancyCheck] = useState<InvoiceDiscrepancyCheck | null>(null);
  const [activeItemMatchPicker, setActiveItemMatchPicker] = useState<string | null>(null);
  const [matchSearchQuery, setMatchSearchQuery] = useState('');
  const [showOriginalDoc, setShowOriginalDoc] = useState(false);
  const [isSavingDraft, setIsSavingDraft] = useState(false);
  const [isConfirmingStock, setIsConfirmingStock] = useState(false);

  // File input change
  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    processUploadedFiles(Array.from(files));
  };

  const processUploadedFiles = (files: File[]) => {
    const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/jpg', 'application/pdf'];
    const newFiles: Array<{ name: string; type: string; size: number; dataUrl: string }> = [];

    let processedCount = 0;
    for (const file of files) {
      if (!validTypes.includes(file.type.toLowerCase()) && !file.name.endsWith('.pdf')) {
        toast.error(`Invalid format for "${file.name}". Please upload JPG, PNG, WEBP, or PDF.`);
        continue;
      }
      if (file.size > 25 * 1024 * 1024) {
        toast.error(`File "${file.name}" exceeds 25MB limit.`);
        continue;
      }

      const reader = new FileReader();
      reader.onload = (event) => {
        const dataUrl = event.target?.result as string;
        newFiles.push({
          name: file.name,
          type: file.type || 'application/pdf',
          size: file.size,
          dataUrl,
        });
        processedCount++;
        if (processedCount === files.length) {
          setSelectedFiles((prev) => [...prev, ...newFiles]);
          toast.success(`Added ${newFiles.length} invoice document(s)/page(s).`);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Camera Capture
  const startCamera = async () => {
    try {
      setIsCameraActive(true);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1920 }, height: { ideal: 1080 } },
      });
      mediaStreamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err: any) {
      toast.error('Could not access camera. Please check browser permissions or use file upload.');
      setIsCameraActive(false);
    }
  };

  const capturePhoto = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth || 1280;
    canvas.height = videoRef.current.videoHeight || 720;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.9);

    setSelectedFiles((prev) => [
      ...prev,
      {
        name: `Camera-Invoice-Page-${prev.length + 1}.jpg`,
        type: 'image/jpeg',
        size: Math.round((dataUrl.length * 3) / 4),
        dataUrl,
      },
    ]);
    toast.success('Invoice photo captured!');
    stopCamera();
  };

  const stopCamera = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
    setIsCameraActive(false);
  };

  // Run AI Invoice Scan
  const handleStartScan = async () => {
    if (selectedFiles.length === 0) {
      toast.error('Please upload or take a photo of an invoice first.');
      return;
    }

    setStep('SCANNING');
    setScanError(null);
    setScanProgressMessage('Uploading document to server-side Gemini Vision OCR...');

    try {
      const filePayload = selectedFiles.map((f) => ({
        mimeType: f.type,
        base64Data: f.dataUrl,
      }));

      const progressTimer = setTimeout(() => {
        setScanProgressMessage('Extracting supplier, invoice number, and tabular line items...');
      }, 2500);

      const secondTimer = setTimeout(() => {
        setScanProgressMessage('Validating GST/tax calculations and matching MOUNTEC inventory...');
      }, 5500);

      const response = await purchaseService.scanInvoice(filePayload, selectedFiles[0].name);

      clearTimeout(progressTimer);
      clearTimeout(secondTimer);

      if (!response.extractedData) {
        throw new Error('No data extracted from document.');
      }

      const ext = response.extractedData;
      setPurchaseId(`pur-${Date.now()}`);
      setIdempotencyKey(`idem-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`);
      setSupplierName(ext.supplier?.name || '');
      setSupplierContact(ext.supplier?.contact || ext.supplier?.uenOrTaxNumber || '');
      setInvoiceNumber(ext.invoice?.invoiceNumber || '');
      setInvoiceDate(ext.invoice?.invoiceDate || new Date().toISOString().split('T')[0]);
      setPurchaseOrderNumber(ext.invoice?.purchaseOrderNumber || '');
      setPaymentTerms(ext.invoice?.paymentTerms || 'Net 30 Days');
      setCurrency(ext.invoice?.currency || 'SGD');

      setSubtotal(ext.financials?.subtotal || 0);
      setTaxRate(ext.financials?.taxRate || 9);
      setTaxAmount(ext.financials?.taxAmount || 0);
      setDiscountAmount(ext.financials?.discountAmount || 0);
      setFreightAmount(ext.financials?.freightAmount || 0);
      setGrandTotal(ext.financials?.grandTotal || 0);

      setLineItems(ext.lineItems as any || []);
      setDiscrepancyCheck(response.discrepancyCheck || null);

      setStep('REVIEW');
      toast.success(`Successfully extracted ${ext.lineItems?.length || 0} line items from invoice!`);
    } catch (err: any) {
      console.error('[InvoiceScanner] Scan failed:', err);
      setScanError(err.message || 'Failed to scan invoice. Please verify GEMINI_API_KEY is configured in Secrets.');
      setStep('UPLOAD');
    }
  };

  // Recalculate Totals
  const calculatedLineSum = useMemo(() => {
    return lineItems.reduce((acc, row) => acc + (Number(row.totalPrice) || 0), 0);
  }, [lineItems]);

  const calculatedExpectedGrandTotal = useMemo(() => {
    return Math.max(0, subtotal - discountAmount + taxAmount + freightAmount);
  }, [subtotal, discountAmount, taxAmount, freightAmount]);

  const hasCalculationDiscrepancy = useMemo(() => {
    const diffSub = Math.abs(calculatedLineSum - subtotal);
    const diffGrand = Math.abs(calculatedExpectedGrandTotal - grandTotal);
    return diffSub > 0.1 || diffGrand > 0.1;
  }, [calculatedLineSum, subtotal, calculatedExpectedGrandTotal, grandTotal]);

  // Line Items Manipulation
  const handleUpdateLine = (id: string, field: keyof PurchaseLineItem, value: any) => {
    setLineItems((prev) =>
      prev.map((row) => {
        if (row.id !== id) return row;
        const updated = { ...row, [field]: value };
        if (field === 'quantity' || field === 'unitPrice') {
          const qty = field === 'quantity' ? Number(value) || 0 : row.quantity;
          const price = field === 'unitPrice' ? Number(value) || 0 : row.unitPrice;
          updated.totalPrice = Number((qty * price).toFixed(2));
        }
        return updated;
      })
    );
  };

  const handleActionChange = (id: string, newAction: LineItemAction) => {
    setLineItems((prev) =>
      prev.map((row) => {
        if (row.id !== id) return row;
        if (newAction === 'CREATE_NEW') {
          // If switching to new, propose MET-1 or sequential code if equipment/tool
          const isSer = isMetNumberRecommended(row.category);
          const nextCode = isSer ? getNextMetNumber(existingItems, true, true) : '';
          return {
            ...row,
            action: newAction,
            matchedAssetId: undefined,
            matchedAssetCode: undefined,
            matchedAssetName: undefined,
            code: nextCode,
            status: 'new_suggestion',
          };
        }
        return { ...row, action: newAction };
      })
    );
  };

  const handleSelectMatchedAsset = (rowId: string, asset: METCItem) => {
    setLineItems((prev) =>
      prev.map((row) => {
        if (row.id !== rowId) return row;
        return {
          ...row,
          matchedAssetId: asset.id,
          matchedAssetCode: asset.code,
          matchedAssetName: asset.name,
          category: asset.category,
          unit: asset.unit || row.unit,
          action: 'UPDATE_EXISTING',
          status: 'matched',
        };
      })
    );
    setActiveItemMatchPicker(null);
    setMatchSearchQuery('');
    toast.success(`Matched with "${asset.name}" (${asset.code || 'No MET tag'})`);
  };

  const handleAddLineRow = () => {
    const nextCode = getNextMetNumber(existingItems, true, true);
    const newRow: PurchaseLineItem = {
      id: `line-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      rawDescription: '',
      productCode: '',
      name: '',
      category: 'Material',
      code: '',
      quantity: 1,
      unit: 'NOS',
      unitPrice: 0,
      totalPrice: 0,
      action: 'CREATE_NEW',
      status: 'new_suggestion',
      confidence: 1.0,
    };
    setLineItems((prev) => [...prev, newRow]);
  };

  const handleDeleteLineRow = (id: string) => {
    setLineItems((prev) => prev.filter((r) => r.id !== id));
  };

  const handleDuplicateLineRow = (id: string) => {
    const target = lineItems.find((r) => r.id === id);
    if (!target) return;
    const duplicated: PurchaseLineItem = {
      ...target,
      id: `line-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      name: `${target.name} (Copy)`,
      action: 'CREATE_NEW',
      matchedAssetId: undefined,
    };
    const idx = lineItems.findIndex((r) => r.id === id);
    const list = [...lineItems];
    list.splice(idx + 1, 0, duplicated);
    setLineItems(list);
  };

  // Save Draft
  const handleSaveDraft = async () => {
    if (!supplierName.trim()) {
      toast.error('Supplier Name is required.');
      return;
    }
    if (!invoiceNumber.trim()) {
      toast.error('Invoice Number is required.');
      return;
    }

    setIsSavingDraft(true);
    try {
      const draftPayload: Partial<PurchaseRecord> = {
        id: purchaseId,
        idempotencyKey,
        supplierName,
        supplierContact,
        invoiceNumber,
        invoiceDate,
        purchaseOrderNumber,
        paymentTerms,
        currency,
        subtotal,
        taxRate,
        taxAmount,
        discountAmount,
        freightAmount,
        grandTotal,
        lineItemsCount: lineItems.length,
        status: 'Draft',
        invoiceFile: selectedFiles[0]
          ? {
              fileName: selectedFiles[0].name,
              fileType: selectedFiles[0].type,
              fileSize: selectedFiles[0].size,
              dataUrl: selectedFiles[0].dataUrl,
            }
          : undefined,
        lineItems,
        stockUpdated: false,
      };

      await purchaseService.createDraft(draftPayload, user?.name || 'Store Keeper');
      toast.success(`Draft purchase invoice "${invoiceNumber}" saved successfully!`);
      onClose();
    } catch (err: any) {
      toast.error(`Failed to save draft: ${err.message}`);
    } finally {
      setIsSavingDraft(false);
    }
  };

  // Confirm Purchase & Update Stock Exactly Once
  const handleConfirmAndStock = async () => {
    if (!supplierName.trim()) {
      toast.error('Supplier Name is required.');
      return;
    }
    if (!invoiceNumber.trim()) {
      toast.error('Invoice Number is required.');
      return;
    }
    if (lineItems.length === 0) {
      toast.error('Invoice must contain at least one line item to update stock.');
      return;
    }

    // Check if any row has missing quantity
    const hasZeroQty = lineItems.some((r) => r.action !== 'IGNORE' && (!r.quantity || r.quantity <= 0));
    if (hasZeroQty) {
      toast.error('Please ensure all items to be stocked have a quantity greater than zero.');
      return;
    }

    setIsConfirmingStock(true);
    try {
      // 1. Create or save draft first
      const draftPayload: Partial<PurchaseRecord> = {
        id: purchaseId,
        idempotencyKey,
        supplierName,
        supplierContact,
        invoiceNumber,
        invoiceDate,
        purchaseOrderNumber,
        paymentTerms,
        currency,
        subtotal,
        taxRate,
        taxAmount,
        discountAmount,
        freightAmount,
        grandTotal,
        lineItemsCount: lineItems.length,
        status: 'Draft',
        invoiceFile: selectedFiles[0]
          ? {
              fileName: selectedFiles[0].name,
              fileType: selectedFiles[0].type,
              fileSize: selectedFiles[0].size,
              dataUrl: selectedFiles[0].dataUrl,
            }
          : undefined,
        lineItems,
        stockUpdated: false,
      };

      const savedDraft = await purchaseService.createDraft(draftPayload, user?.name || 'Store Keeper');

      // 2. Confirm and apply stock updates atomically with idempotency protection
      const confirmResult = await purchaseService.confirmPurchase(
        savedDraft.id,
        idempotencyKey,
        user?.name || 'Store Keeper'
      );

      // Refresh store assets so UI reflects immediate stock updates
      if (fetchAssets) {
        await fetchAssets();
      }

      toast.success(
        `Purchase confirmed! Stock successfully incremented for ${confirmResult.stockUpdates.length} items from Invoice #${invoiceNumber}.`
      );

      if (onPurchaseConfirmed) {
        onPurchaseConfirmed(confirmResult.purchase);
      }
      onClose();
    } catch (err: any) {
      toast.error(`Confirmation failed: ${err.message}`);
    } finally {
      setIsConfirmingStock(false);
    }
  };

  // Filtered Assets for Match Picker Modal
  const filteredAssetsForMatch = useMemo(() => {
    if (!matchSearchQuery.trim()) return existingItems.slice(0, 20);
    const q = matchSearchQuery.toLowerCase();
    return existingItems.filter(
      (a) =>
        a.name.toLowerCase().includes(q) ||
        (a.code && a.code.toLowerCase().includes(q)) ||
        (a.category && a.category.toLowerCase().includes(q))
    ).slice(0, 30);
  }, [existingItems, matchSearchQuery]);

  if (!isOpen) return null;

  return (
    <Modal
      isOpen={isOpen}
      onClose={() => {
        stopCamera();
        onClose();
      }}
      title="AI Invoice Photo Scanner & Automatic Purchase Entry"
      size="xl"
    >
      <div className="space-y-6 text-slate-900 dark:text-slate-100 max-h-[85vh] overflow-y-auto pr-1">
        
        {/* Step 1: Upload or Camera Capture */}
        {step === 'UPLOAD' && (
          <div className="space-y-5">
            <div className="p-4 rounded-xl bg-gradient-to-r from-blue-500/10 via-indigo-500/10 to-transparent border border-blue-200 dark:border-blue-900/60">
              <div className="flex items-start gap-3">
                <span className="p-2 rounded-xl bg-blue-600 text-white shrink-0 mt-0.5">
                  <Sparkles className="w-5 h-5" />
                </span>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    Scan Vendor Invoices with Gemini Vision AI
                  </h3>
                  <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">
                    Upload photos, scans, or PDF purchase invoices (including 30–50+ line items). The AI extracts supplier details, tax invoices, GST totals, and automatically matches items with your existing MOUNTEC METC inventory without duplicating records.
                  </p>
                </div>
              </div>
            </div>

            {scanError && (
              <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 text-rose-800 dark:text-rose-200 text-xs flex items-start gap-2.5">
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <div className="flex-1">
                  <strong className="block font-bold">Extraction Error:</strong>
                  <span>{scanError}</span>
                </div>
              </div>
            )}

            {/* Live Camera Stream View */}
            {isCameraActive ? (
              <div className="space-y-3 p-4 bg-slate-900 rounded-2xl border border-slate-700">
                <div className="relative rounded-xl overflow-hidden bg-black aspect-video flex items-center justify-center">
                  <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
                  <div className="absolute inset-0 pointer-events-none border-2 border-dashed border-blue-400/60 m-6 rounded-xl flex items-center justify-center">
                    <span className="text-[11px] text-white/80 bg-black/60 px-3 py-1 rounded-full">
                      Align invoice inside frame
                    </span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <Button variant="outline" size="sm" onClick={stopCamera}>
                    Cancel Camera
                  </Button>
                  <Button variant="primary" size="sm" icon={<Camera className="w-4 h-4" />} onClick={capturePhoto}>
                    Capture Photo
                  </Button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Drag & Drop Upload Area */}
                <label className="border-2 border-dashed border-blue-300 dark:border-blue-800/80 hover:border-blue-500 rounded-2xl p-6 flex flex-col items-center justify-center text-center cursor-pointer transition-colors bg-blue-50/30 dark:bg-slate-900/40 group">
                  <input
                    type="file"
                    multiple
                    accept="image/jpeg,image/png,image/webp,application/pdf"
                    onChange={handleFileInput}
                    className="hidden"
                  />
                  <div className="p-3 rounded-2xl bg-blue-100 dark:bg-blue-900/60 text-blue-600 dark:text-blue-300 group-hover:scale-110 transition-transform mb-3">
                    <Upload className="w-6 h-6" />
                  </div>
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-100">
                    Upload Invoice Images or PDF
                  </span>
                  <span className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                    Supports JPG, PNG, WEBP, and multi-page PDFs
                  </span>
                  <span className="mt-3 px-3 py-1 text-[10px] font-semibold rounded-full bg-blue-100 dark:bg-blue-900/80 text-blue-700 dark:text-blue-200">
                    Browse Files
                  </span>
                </label>

                {/* Direct Camera Option */}
                <div className="border border-slate-200 dark:border-slate-800 rounded-2xl p-6 flex flex-col items-center justify-center text-center bg-white dark:bg-slate-900">
                  <div className="p-3 rounded-2xl bg-emerald-100 dark:bg-emerald-900/60 text-emerald-600 dark:text-emerald-300 mb-3">
                    <Camera className="w-6 h-6" />
                  </div>
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-100">
                    Capture Photo with Camera
                  </span>
                  <span className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                    Snap physical paper invoices on site or in store
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-3"
                    icon={<Camera className="w-4 h-4 text-emerald-600" />}
                    onClick={startCamera}
                  >
                    Open Device Camera
                  </Button>
                </div>
              </div>
            )}

            {/* Selected Files Preview List */}
            {selectedFiles.length > 0 && (
              <div className="space-y-3 pt-3 border-t border-slate-200 dark:border-slate-800">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-700 dark:text-slate-300">
                    Attached Invoice Pages ({selectedFiles.length})
                  </span>
                  <button
                    type="button"
                    onClick={() => setSelectedFiles([])}
                    className="text-rose-500 hover:underline text-[11px]"
                  >
                    Clear All
                  </button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {selectedFiles.map((file, idx) => (
                    <div
                      key={idx}
                      className="relative p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 group overflow-hidden"
                    >
                      {file.type.includes('image') ? (
                        <div className="w-full h-24 rounded-lg bg-slate-200 dark:bg-slate-700 overflow-hidden mb-2">
                          <img src={file.dataUrl} alt={file.name} className="w-full h-full object-cover" />
                        </div>
                      ) : (
                        <div className="w-full h-24 rounded-lg bg-red-50 dark:bg-red-950/50 flex flex-col items-center justify-center mb-2 text-red-600">
                          <FileText className="w-8 h-8" />
                          <span className="text-[10px] font-bold mt-1">PDF Document</span>
                        </div>
                      )}
                      <p className="text-[11px] font-semibold truncate text-slate-800 dark:text-slate-200">
                        {file.name}
                      </p>
                      <p className="text-[10px] text-slate-400">
                        {(file.size / 1024).toFixed(0)} KB
                      </p>
                      <button
                        type="button"
                        onClick={() => setSelectedFiles((prev) => prev.filter((_, i) => i !== idx))}
                        className="absolute top-3 right-3 p-1 rounded-full bg-slate-900/70 text-white hover:bg-rose-600 transition-colors"
                        title="Remove file"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>

                <div className="pt-3 flex justify-end">
                  <Button
                    variant="primary"
                    size="md"
                    icon={<Sparkles className="w-4 h-4 text-amber-300" />}
                    onClick={handleStartScan}
                  >
                    Start AI Extraction ({selectedFiles.length} Page{selectedFiles.length > 1 ? 's' : ''})
                  </Button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Step 2: Scanning Progress Screen */}
        {step === 'SCANNING' && (
          <div className="py-12 flex flex-col items-center justify-center text-center space-y-4">
            <div className="relative">
              <div className="w-16 h-16 rounded-full border-4 border-blue-200 dark:border-blue-900 border-t-blue-600 animate-spin flex items-center justify-center" />
              <Sparkles className="w-6 h-6 text-blue-600 absolute inset-0 m-auto animate-pulse" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Scanning Invoice Document
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 font-medium animate-pulse">
                {scanProgressMessage}
              </p>
            </div>
            <span className="text-[11px] text-slate-400 max-w-sm">
              Analyzing supplier headers, line items, Singapore 9% GST, and matching with MOUNTEC METC records.
            </span>
          </div>
        )}

        {/* Step 3: Review Table, Inventory Matching & Validation */}
        {step === 'REVIEW' && (
          <div className="space-y-6">
            {/* Top Discrepancy & Validation Banner */}
            {discrepancyCheck && discrepancyCheck.warnings.length > 0 && (
              <div className={`p-4 rounded-xl border ${
                discrepancyCheck.isDuplicateInvoice 
                  ? 'bg-rose-50 dark:bg-rose-950/60 border-rose-300 dark:border-rose-800 text-rose-900 dark:text-rose-100'
                  : 'bg-amber-50 dark:bg-amber-950/50 border-amber-300 dark:border-amber-800 text-amber-900 dark:text-amber-100'
              }`}>
                <div className="flex items-start gap-2.5">
                  <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5 text-amber-600 dark:text-amber-400" />
                  <div className="space-y-1 text-xs">
                    <strong className="block font-bold uppercase tracking-wider text-[11px]">
                      Validation & Discrepancy Notice
                    </strong>
                    {discrepancyCheck.warnings.map((warn, i) => (
                      <p key={i} className="text-xs leading-relaxed">
                        • {warn}
                      </p>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Invoice Header Details Grid */}
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                  <Building className="w-3.5 h-3.5 text-blue-500" /> Supplier & Invoice Information
                </span>
                {selectedFiles[0] && (
                  <button
                    type="button"
                    onClick={() => setShowOriginalDoc(!showOriginalDoc)}
                    className="text-xs font-semibold text-blue-600 dark:text-blue-400 flex items-center gap-1 hover:underline"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>{showOriginalDoc ? 'Hide Original Invoice' : 'View Original Invoice File'}</span>
                  </button>
                )}
              </div>

              {/* Side-by-side or collapsible original invoice preview */}
              {showOriginalDoc && selectedFiles[0] && (
                <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-300 dark:border-slate-700 max-h-64 overflow-y-auto">
                  {selectedFiles[0].type.includes('image') ? (
                    <img src={selectedFiles[0].dataUrl} alt="Original Invoice" className="w-full object-contain rounded-lg" />
                  ) : (
                    <div className="flex items-center justify-between p-4 bg-slate-100 dark:bg-slate-800 rounded-lg">
                      <div className="flex items-center gap-2">
                        <FileText className="w-5 h-5 text-red-500" />
                        <span className="text-xs font-semibold">{selectedFiles[0].name}</span>
                      </div>
                      <a
                        href={selectedFiles[0].dataUrl}
                        download={selectedFiles[0].name}
                        className="text-xs text-blue-600 hover:underline"
                      >
                        Download PDF
                      </a>
                    </div>
                  )}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-4 gap-3 text-xs">
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Supplier Name *</label>
                  <input
                    type="text"
                    value={supplierName}
                    onChange={(e) => setSupplierName(e.target.value)}
                    placeholder="e.g. Bossard Pte Ltd"
                    className="w-full px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 font-bold focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Invoice Number *</label>
                  <input
                    type="text"
                    value={invoiceNumber}
                    onChange={(e) => setInvoiceNumber(e.target.value)}
                    placeholder="e.g. INV-2026-9812"
                    className="w-full px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 font-mono font-bold text-blue-600 dark:text-blue-400 focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Invoice Date *</label>
                  <input
                    type="date"
                    value={invoiceDate}
                    onChange={(e) => setInvoiceDate(e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 font-medium focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Purchase Order (PO)</label>
                  <input
                    type="text"
                    value={purchaseOrderNumber}
                    onChange={(e) => setPurchaseOrderNumber(e.target.value)}
                    placeholder="e.g. PO-MTC-0842"
                    className="w-full px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 font-medium focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Supplier Contact / UEN</label>
                  <input
                    type="text"
                    value={supplierContact}
                    onChange={(e) => setSupplierContact(e.target.value)}
                    placeholder="UEN 201827491G, Tel: 6789 1234"
                    className="w-full px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 font-medium focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Payment Terms</label>
                  <input
                    type="text"
                    value={paymentTerms}
                    onChange={(e) => setPaymentTerms(e.target.value)}
                    placeholder="e.g. 30 Days Net"
                    className="w-full px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 font-medium focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Currency</label>
                  <select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 font-bold focus:ring-1 focus:ring-blue-500"
                  >
                    <option value="SGD">SGD (S$ - Singapore Dollar)</option>
                    <option value="USD">USD ($ - US Dollar)</option>
                    <option value="MYR">MYR (RM - Malaysian Ringgit)</option>
                    <option value="EUR">EUR (€ - Euro)</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Editable Review Table of Line Items */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <span>Line Items Review Table</span>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300 font-semibold">
                      {lineItems.length} Items
                    </span>
                  </h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Review and verify all extracted lines. Match with existing stock or confirm new product suggestions.
                  </p>
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  icon={<Plus className="w-3.5 h-3.5 text-blue-600" />}
                  onClick={handleAddLineRow}
                >
                  Add Row
                </Button>
              </div>

              <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-x-auto shadow-2xs">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="bg-slate-100/80 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 uppercase tracking-wider text-[10px] font-bold border-b border-slate-200 dark:border-slate-700">
                    <tr>
                      <th className="py-2.5 px-2 text-center w-8">#</th>
                      <th className="py-2.5 px-3 min-w-[200px]">Item Description & Product Title</th>
                      <th className="py-2.5 px-3 min-w-[130px]">Category</th>
                      <th className="py-2.5 px-3 min-w-[180px]">Inventory Match Action</th>
                      <th className="py-2.5 px-2 text-right w-20">Qty</th>
                      <th className="py-2.5 px-2 w-16">UOM</th>
                      <th className="py-2.5 px-2 text-right w-24">Unit Price</th>
                      <th className="py-2.5 px-2 text-right w-24">Line Total</th>
                      <th className="py-2.5 px-2 text-center w-16">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {lineItems.map((item, index) => {
                      const isMatched = item.action === 'UPDATE_EXISTING' && !!item.matchedAssetId;
                      const isIgnored = item.action === 'IGNORE';
                      const isLowConfidence = typeof item.confidence === 'number' && item.confidence < 0.65;

                      return (
                        <tr
                          key={item.id}
                          className={`hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors ${
                            isIgnored ? 'opacity-50 bg-slate-100/50 dark:bg-slate-900/50' : ''
                          }`}
                        >
                          {/* Row Index & Confidence */}
                          <td className="py-2 px-2 text-center text-slate-400 font-mono text-[11px]">
                            <div className="flex flex-col items-center">
                              <span>{index + 1}</span>
                              {isLowConfidence && (
                                <span title="Low OCR confidence - please double check values" className="text-amber-500">
                                  <AlertTriangle className="w-3 h-3" />
                                </span>
                              )}
                            </div>
                          </td>

                          {/* Description & Product Title */}
                          <td className="py-2 px-3">
                            <input
                              type="text"
                              value={item.name}
                              onChange={(e) => handleUpdateLine(item.id, 'name', e.target.value)}
                              placeholder="Item Name"
                              className="w-full px-2 py-1 rounded bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 font-bold focus:ring-1 focus:ring-blue-500"
                            />
                            {item.rawDescription && item.rawDescription !== item.name && (
                              <p className="text-[10px] text-slate-400 mt-0.5 truncate" title={item.rawDescription}>
                                Raw: {item.rawDescription}
                              </p>
                            )}
                          </td>

                          {/* Category */}
                          <td className="py-2 px-3">
                            <select
                              value={item.category}
                              onChange={(e) => handleUpdateLine(item.id, 'category', e.target.value as AssetCategory)}
                              className="w-full px-2 py-1 rounded bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 focus:ring-1 focus:ring-blue-500 text-xs"
                            >
                              <option value="Material">Material</option>
                              <option value="Equipment">Equipment</option>
                              <option value="Tool">Tool</option>
                              <option value="Consumable">Consumable</option>
                              <option value="PPE">PPE Safety</option>
                            </select>
                            {/* MET code if relevant */}
                            {item.action === 'CREATE_NEW' && (
                              <input
                                type="text"
                                value={item.code || ''}
                                onChange={(e) => handleUpdateLine(item.id, 'code', e.target.value)}
                                placeholder="e.g. MET - 1 (Optional)"
                                className="w-full mt-1 px-1.5 py-0.5 rounded text-[10px] font-mono bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700"
                              />
                            )}
                          </td>

                          {/* Match Action & Match Details */}
                          <td className="py-2 px-3">
                            <select
                              value={item.action}
                              onChange={(e) => handleActionChange(item.id, e.target.value as LineItemAction)}
                              className={`w-full px-2 py-1 rounded font-semibold text-xs border ${
                                isMatched
                                  ? 'bg-emerald-50 dark:bg-emerald-950/50 border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200'
                                  : item.action === 'CREATE_NEW'
                                  ? 'bg-blue-50 dark:bg-blue-950/50 border-blue-300 dark:border-blue-800 text-blue-800 dark:text-blue-200'
                                  : 'bg-slate-200 dark:bg-slate-700 border-slate-300 text-slate-700 dark:text-slate-300'
                              }`}
                            >
                              <option value="UPDATE_EXISTING">Update Existing Stock</option>
                              <option value="CREATE_NEW">Create as New Item</option>
                              <option value="IGNORE">Ignore (Do Not Stock)</option>
                            </select>

                            {/* Matched Asset display or change button */}
                            {item.action === 'UPDATE_EXISTING' && (
                              <div className="mt-1 flex items-center justify-between text-[11px] bg-white dark:bg-slate-900 px-2 py-1 rounded border border-slate-200 dark:border-slate-700">
                                <span className="truncate max-w-[120px] font-medium" title={item.matchedAssetName || ''}>
                                  {item.matchedAssetCode ? `[${item.matchedAssetCode}] ` : ''}
                                  {item.matchedAssetName || 'Click to select item'}
                                </span>
                                <button
                                  type="button"
                                  onClick={() => setActiveItemMatchPicker(item.id)}
                                  className="text-blue-600 dark:text-blue-400 font-bold hover:underline shrink-0 ml-1 text-[10px]"
                                >
                                  Change
                                </button>
                              </div>
                            )}
                          </td>

                          {/* Qty */}
                          <td className="py-2 px-2 text-right">
                            <input
                              type="number"
                              min="0"
                              step="any"
                              value={item.quantity}
                              onChange={(e) => handleUpdateLine(item.id, 'quantity', e.target.value)}
                              className="w-full text-right px-1.5 py-1 rounded bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 font-mono font-bold focus:ring-1 focus:ring-blue-500"
                            />
                          </td>

                          {/* Unit */}
                          <td className="py-2 px-2">
                            <input
                              type="text"
                              value={item.unit}
                              onChange={(e) => handleUpdateLine(item.id, 'unit', e.target.value)}
                              className="w-full px-1.5 py-1 rounded bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-center font-bold text-[11px] uppercase focus:ring-1 focus:ring-blue-500"
                            />
                          </td>

                          {/* Unit Price */}
                          <td className="py-2 px-2 text-right">
                            <input
                              type="number"
                              min="0"
                              step="0.01"
                              value={item.unitPrice}
                              onChange={(e) => handleUpdateLine(item.id, 'unitPrice', e.target.value)}
                              className="w-full text-right px-1.5 py-1 rounded bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 font-mono focus:ring-1 focus:ring-blue-500"
                            />
                          </td>

                          {/* Line Total */}
                          <td className="py-2 px-2 text-right font-mono font-bold text-slate-800 dark:text-slate-100">
                            ${Number(item.totalPrice || 0).toFixed(2)}
                          </td>

                          {/* Actions */}
                          <td className="py-2 px-2 text-center">
                            <div className="flex items-center justify-center gap-1">
                              <button
                                type="button"
                                onClick={() => handleDuplicateLineRow(item.id)}
                                className="p-1 rounded hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-400 hover:text-blue-600 transition-colors"
                                title="Duplicate row"
                              >
                                <Copy className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleDeleteLineRow(item.id)}
                                className="p-1 rounded hover:bg-rose-100 dark:hover:bg-rose-950 text-slate-400 hover:text-rose-600 transition-colors"
                                title="Delete row"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Financial Summary & Total Reconciliation */}
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-4">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 block">
                Financial Summary & Tax Reconciliation
              </span>

              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Subtotal ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={subtotal}
                    onChange={(e) => setSubtotal(Number(e.target.value) || 0)}
                    className="w-full px-2 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 font-mono font-bold focus:ring-1 focus:ring-blue-500"
                  />
                  <span className="text-[10px] text-slate-400">Sum: ${calculatedLineSum.toFixed(2)}</span>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Discount ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={discountAmount}
                    onChange={(e) => setDiscountAmount(Number(e.target.value) || 0)}
                    className="w-full px-2 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 font-mono focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">GST / Tax Rate (%)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={taxRate}
                    onChange={(e) => {
                      const r = Number(e.target.value) || 0;
                      setTaxRate(r);
                      setTaxAmount(Number(((subtotal - discountAmount) * (r / 100)).toFixed(2)));
                    }}
                    className="w-full px-2 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 font-mono focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">GST Amount ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={taxAmount}
                    onChange={(e) => setTaxAmount(Number(e.target.value) || 0)}
                    className="w-full px-2 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 font-mono font-bold focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Freight / Delivery ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={freightAmount}
                    onChange={(e) => setFreightAmount(Number(e.target.value) || 0)}
                    className="w-full px-2 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 font-mono focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Grand Total ({currency}) *</label>
                  <input
                    type="number"
                    step="0.01"
                    value={grandTotal}
                    onChange={(e) => setGrandTotal(Number(e.target.value) || 0)}
                    className="w-full px-2 py-1.5 rounded-lg bg-white dark:bg-slate-900 border-2 border-blue-500 font-mono font-black text-sm text-blue-600 dark:text-blue-400 focus:ring-1 focus:ring-blue-500"
                  />
                  <span className="text-[10px] text-slate-400">Calc: ${calculatedExpectedGrandTotal.toFixed(2)}</span>
                </div>
              </div>
            </div>

            {/* Bottom Actions Bar */}
            <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
              <Button
                variant="outline"
                size="sm"
                icon={<RefreshCw className="w-3.5 h-3.5" />}
                onClick={() => setStep('UPLOAD')}
              >
                Scan Another Invoice
              </Button>

              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="md"
                  isLoading={isSavingDraft}
                  onClick={handleSaveDraft}
                >
                  Save as Draft Invoice
                </Button>

                <Button
                  variant="primary"
                  size="md"
                  icon={<ShieldCheck className="w-4 h-4" />}
                  isLoading={isConfirmingStock}
                  onClick={handleConfirmAndStock}
                >
                  Confirm Purchase & Update Stock
                </Button>
              </div>
            </div>
          </div>
        )}

      </div>

      {/* Item Matching Selector Modal */}
      {activeItemMatchPicker && (
        <Modal
          isOpen={!!activeItemMatchPicker}
          onClose={() => setActiveItemMatchPicker(null)}
          title="Match with Existing MOUNTEC Inventory Asset"
          size="md"
        >
          <div className="space-y-4 text-xs">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={matchSearchQuery}
                onChange={(e) => setMatchSearchQuery(e.target.value)}
                placeholder="Search by asset name, MET code, category..."
                className="w-full pl-9 pr-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-xs focus:ring-1 focus:ring-blue-500"
                autoFocus
              />
            </div>

            <div className="max-h-60 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl">
              {filteredAssetsForMatch.map((asset) => (
                <div
                  key={asset.id}
                  onClick={() => handleSelectMatchedAsset(activeItemMatchPicker, asset)}
                  className="p-2.5 hover:bg-blue-50 dark:hover:bg-slate-800 cursor-pointer flex items-center justify-between transition-colors"
                >
                  <div>
                    <span className="font-bold text-slate-900 dark:text-white block">
                      {asset.name}
                    </span>
                    <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                      {asset.code && (
                        <span className="font-mono font-bold text-blue-600 dark:text-blue-400">
                          {asset.code}
                        </span>
                      )}
                      <span>•</span>
                      <span>{asset.category}</span>
                      <span>•</span>
                      <span>Stock: {asset.availableQuantity ?? asset.quantity} {asset.unit}</span>
                    </div>
                  </div>
                  <span className="text-[11px] font-semibold text-blue-600 dark:text-blue-400">
                    Select
                  </span>
                </div>
              ))}
            </div>
          </div>
        </Modal>
      )}
    </Modal>
  );
};
