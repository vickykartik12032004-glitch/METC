import React, { useState, useMemo } from 'react';
import { METCItem, AssetCategory } from '../../../types';
import { useAssetStore } from '../../../store/useAssetStore';
import { useAuthStore } from '../../../store/useAuthStore';
import { checkDuplicate, DuplicateMatch, DuplicateResolution } from '../utils/duplicateDetector';
import { DuplicateWarningModal } from './DuplicateWarningModal';
import { Button } from '../../../components/ui/Button';
import { 
  Clipboard, 
  FileSpreadsheet, 
  Download, 
  Copy, 
  CheckCircle2, 
  AlertTriangle, 
  Trash2, 
  Save, 
  ArrowRight,
  Info,
  RefreshCw,
  Table,
  Sparkles
} from 'lucide-react';
import { toast } from 'sonner';

interface ParsedRow {
  id: string;
  name: string;
  code: string;
  category: AssetCategory;
  unit: string;
  quantity: number;
  availableQuantity: number;
  damagedQuantity: number;
  location: string;
  minQuantityThreshold: number;
  remarks: string;
  duplicateResolution?: DuplicateResolution;
}

const CATEGORIES: AssetCategory[] = ['Material', 'Equipment', 'Tool', 'Consumable', 'PPE'];

import { getNextMetNumber, getSequentialMetNumbers, isMetNumberRecommended } from '../../../utils/metAssetNumber';

const TARGET_FIELDS = [
  { key: 'name', label: 'Item Name *', required: true },
  { key: 'code', label: 'MET Number / Code (Optional)', required: false },
  { key: 'category', label: 'Category *', required: true },
  { key: 'quantity', label: 'Quantity *', required: true },
  { key: 'unit', label: 'Unit of Measure', required: false },
  { key: 'location', label: 'Store Location / Rack', required: false },
  { key: 'minQuantityThreshold', label: 'Min Stock Level', required: false },
  { key: 'remarks', label: 'Remarks', required: false },
];

const SAMPLE_TEMPLATE_ROWS = [
  ['Item Name', 'MET Number', 'Category', 'Quantity', 'Unit', 'Location', 'Min Stock', 'Remarks'],
  ['DAWER ALUMINIUM CUTTER MIRER SAW', 'MET-1', 'Equipment', '5', 'NOS', 'Main Warehouse Rack A-01', '2', 'Precision aluminum miter saw'],
  ['MAKITA 4-INCH ANGLE GRINDER 9553NB', 'MET-2', 'Tool', '12', 'PCS', 'Rack B-04', '4', 'Standard 100mm disc angle grinder'],
  ['DEWALT CORDLESS IMPACT DRIVER 18V', 'MET-3', 'Tool', '8', 'SET', 'Rack B-05', '3', 'Brushless motor with 2x 4.0Ah batteries'],
  ['PORTLAND COMPOSITE CEMENT EN 197', '', 'Material', '300', 'BAG', 'Shed 2 - Dry Storage', '50', 'Bulk cement (No MET tag needed)'],
  ['CUTTING DISC 4-INCH METAL (100MM)', '', 'Consumable', '500', 'PCS', 'Consumables Bin C-1', '100', 'Steel discs (No MET tag needed)'],
  ['HEAVY DUTY SAFETY HELMET WHITE', 'MET-4', 'PPE', '50', 'PCS', 'Safety Rack S-1', '15', 'EN 397 certified safety helmets'],
];

interface PasteFromExcelTabProps {
  existingItems: METCItem[];
  onSuccess?: () => void;
}

export const PasteFromExcelTab: React.FC<PasteFromExcelTabProps> = ({
  existingItems,
  onSuccess,
}) => {
  const { user } = useAuthStore();
  const { bulkAddAssets } = useAssetStore();

  const [pastedText, setPastedText] = useState<string>('');
  const [hasHeaders, setHasHeaders] = useState<boolean>(true);
  const [parsedRows, setParsedRows] = useState<ParsedRow[]>([]);
  const [isParsed, setIsParsed] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Column Mapping: columnIndex -> targetField
  const [columnMap, setColumnMap] = useState<Record<number, string>>({});
  const [detectedColumns, setDetectedColumns] = useState<string[]>([]);

  // Duplicate Modal state
  const [duplicateModalRow, setDuplicateModalRow] = useState<{
    row: ParsedRow;
    match: DuplicateMatch;
  } | null>(null);

  // Normalize category name
  const parseCategory = (raw: string): AssetCategory => {
    const val = (raw || '').toLowerCase().trim();
    if (val.includes('equip')) return 'Equipment';
    if (val.includes('tool')) return 'Tool';
    if (val.includes('consum')) return 'Consumable';
    if (val.includes('ppe') || val.includes('safety')) return 'PPE';
    return 'Material';
  };

  // Handle parsing pasted text
  const handleParse = () => {
    const raw = pastedText.trim();
    if (!raw) {
      toast.error('Please paste data copied from Excel or Google Sheets.');
      return;
    }

    const lines = raw.split(/\r?\n/).filter((l) => l.trim().length > 0);
    if (lines.length === 0) {
      toast.error('No readable rows found in pasted text.');
      return;
    }

    const splitRows = lines.map((line) =>
      line.split('\t').map((cell) => cell.trim())
    );

    let headers: string[] = [];
    let dataRows = splitRows;

    if (hasHeaders && splitRows.length > 1) {
      headers = splitRows[0];
      dataRows = splitRows.slice(1);
    } else {
      // Create generic Col 1, Col 2...
      const maxCols = Math.max(...splitRows.map((r) => r.length));
      headers = Array.from({ length: maxCols }, (_, i) => `Column ${i + 1}`);
    }

    setDetectedColumns(headers);

    // Auto-map recognized headers
    const newMap: Record<number, string> = {};
    headers.forEach((h, idx) => {
      const lower = h.toLowerCase();
      if (lower.includes('item name') || lower.includes('description') || lower === 'name') {
        newMap[idx] = 'name';
      } else if (lower.includes('code') || lower.includes('asset id') || lower.includes('sku')) {
        newMap[idx] = 'code';
      } else if (lower.includes('category') || lower.includes('type')) {
        newMap[idx] = 'category';
      } else if (lower.includes('qty') || lower.includes('quantity') || lower.includes('stock')) {
        newMap[idx] = 'quantity';
      } else if (lower.includes('unit') || lower.includes('uom')) {
        newMap[idx] = 'unit';
      } else if (lower.includes('location') || lower.includes('rack') || lower.includes('bin') || lower.includes('store')) {
        newMap[idx] = 'location';
      } else if (lower.includes('min') || lower.includes('threshold') || lower.includes('reorder')) {
        newMap[idx] = 'minQuantityThreshold';
      } else if (lower.includes('remark') || lower.includes('note')) {
        newMap[idx] = 'remarks';
      }
    });

    setColumnMap(newMap);
    buildParsedRows(dataRows, newMap);
    setIsParsed(true);
    toast.success(`Parsed ${dataRows.length} row(s) from spreadsheet.`);
  };

  // Convert raw rows into ParsedRow objects based on columnMap
  const buildParsedRows = (
    dataRows: string[][],
    mapping: Record<number, string>
  ) => {
    const rows: ParsedRow[] = dataRows.map((cells, index) => {
      const rowObj: any = {
        name: '',
        code: '',
        category: 'Material',
        unit: 'NOS',
        quantity: 10,
        availableQuantity: 10,
        damagedQuantity: 0,
        location: 'Main Warehouse',
        minQuantityThreshold: 5,
        remarks: '',
      };

      cells.forEach((val, colIdx) => {
        const field = mapping[colIdx];
        if (!field) return;

        if (field === 'quantity' || field === 'minQuantityThreshold') {
          const num = Number(val);
          rowObj[field] = isNaN(num) ? 0 : Math.max(0, num);
        } else if (field === 'category') {
          rowObj.category = parseCategory(val);
        } else {
          rowObj[field] = val;
        }
      });

      // Sensible defaults
      if (!rowObj.name) rowObj.name = `Imported Asset ${index + 1}`;
      if (!rowObj.code) rowObj.code = ''; // Keep empty if not supplied; MET number is optional for non-serialized items
      if (!rowObj.unit) rowObj.unit = 'NOS';
      if (!rowObj.location) rowObj.location = 'Main Warehouse';
      rowObj.availableQuantity = rowObj.quantity;

      return {
        ...rowObj,
        id: `excel-row-${Date.now()}-${index}-${Math.floor(Math.random() * 1000)}`,
      };
    });

    setParsedRows(rows);
  };

  // Sequence MET numbers across imported rows (starting from MET - 1 or next available)
  const handleSequenceMetNumbers = (startFromOne: boolean = true) => {
    const metSeq = getSequentialMetNumbers(existingItems, parsedRows.length, startFromOne, true);
    setParsedRows((prev) =>
      prev.map((r, idx) => ({
        ...r,
        code: metSeq[idx] || `MET - ${idx + 1}`,
      }))
    );
    toast.success(
      startFromOne
        ? 'Assigned MET numbers starting from MET - 1 (MET - 1, MET - 2...)!'
        : 'Assigned sequential MET numbers across imported rows!'
    );
  };

  const handleClearConsumablesMetNumbers = () => {
    let cleared = 0;
    setParsedRows((prev) =>
      prev.map((r) => {
        if (r.category === 'Consumable' || r.category === 'Material') {
          cleared++;
          return { ...r, code: '' };
        }
        return r;
      })
    );
    toast.info(`Cleared MET numbers from ${cleared} Consumable/Material rows (MET number is optional).`);
  };

  // Re-map when user changes manual column mapping dropdowns
  const handleMappingChange = (colIdx: number, targetField: string) => {
    const updated = { ...columnMap, [colIdx]: targetField };
    setColumnMap(updated);

    // Re-parse with updated mapping
    const raw = pastedText.trim();
    const lines = raw.split(/\r?\n/).filter((l) => l.trim().length > 0);
    const splitRows = lines.map((l) => l.split('\t').map((c) => c.trim()));
    const dataRows = hasHeaders ? splitRows.slice(1) : splitRows;
    buildParsedRows(dataRows, updated);
  };

  // Inline cell editing in preview table
  const handleCellChange = (id: string, field: keyof ParsedRow, val: any) => {
    setParsedRows((prev) =>
      prev.map((r) => (r.id === id ? { ...r, [field]: val } : r))
    );
  };

  // Delete row from preview table
  const handleDeleteRow = (id: string) => {
    setParsedRows((prev) => prev.filter((r) => r.id !== id));
  };

  // Row validation
  const getRowErrors = (row: ParsedRow): string[] => {
    const errors: string[] = [];
    if (!row.name.trim()) errors.push('Item Name is required');
    if (row.quantity < 0) errors.push('Quantity cannot be negative');
    if (!row.location.trim()) errors.push('Location is required');
    return errors;
  };

  // Duplicate Candidate map
  const duplicateCandidateMap = useMemo(() => {
    const map = new Map<string, DuplicateMatch>();
    parsedRows.forEach((row) => {
      if (row.name.trim()) {
        const match = checkDuplicate(
          {
            name: row.name,
            code: row.code,
            category: row.category,
            unit: row.unit,
          },
          existingItems
        );
        if (match) {
          map.set(row.id, match);
        }
      }
    });
    return map;
  }, [parsedRows, existingItems]);

  // Validation metrics
  const { validCount, invalidCount, duplicateCount } = useMemo(() => {
    let valid = 0;
    let invalid = 0;
    let dups = 0;
    parsedRows.forEach((r) => {
      if (getRowErrors(r).length === 0) valid++;
      else invalid++;
      if (duplicateCandidateMap.has(r.id) && !r.duplicateResolution) dups++;
    });
    return { validCount: valid, invalidCount: invalid, duplicateCount: dups };
  }, [parsedRows, duplicateCandidateMap]);

  // Copy sample to clipboard
  const handleCopySample = () => {
    const text = SAMPLE_TEMPLATE_ROWS.map((r) => r.join('\t')).join('\n');
    navigator.clipboard.writeText(text);
    toast.success('Sample Excel data copied to clipboard! Paste it directly below (Ctrl+V / Cmd+V).');
  };

  // Download Sample Template CSV
  const handleDownloadSample = () => {
    const csvContent =
      'data:text/csv;charset=utf-8,' +
      SAMPLE_TEMPLATE_ROWS.map((e) =>
        e.map((x) => `"${x.replace(/"/g, '""')}"`).join(',')
      ).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'MOUNTEC_Inventory_Import_Template.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success('Sample template downloaded');
  };

  // Submit & Save confirmed rows
  const handleConfirmImport = async () => {
    if (parsedRows.length === 0) {
      toast.error('No items to import.');
      return;
    }

    const invalidItems = parsedRows.filter((r) => getRowErrors(r).length > 0);
    if (invalidItems.length > 0) {
      toast.error(`Please fix ${invalidItems.length} invalid row(s) before importing.`);
      return;
    }

    const unresolvedDups = parsedRows.filter(
      (r) => duplicateCandidateMap.has(r.id) && !r.duplicateResolution
    );
    if (unresolvedDups.length > 0) {
      const firstDup = unresolvedDups[0];
      const match = duplicateCandidateMap.get(firstDup.id)!;
      setDuplicateModalRow({ row: firstDup, match });
      toast.warning(
        `There are ${unresolvedDups.length} duplicate items. Please resolve them before proceeding.`
      );
      return;
    }

    setIsSubmitting(true);
    const authorName = user?.name || 'Store Keeper';

    try {
      const itemsToCreate: any[] = [];
      for (const row of parsedRows) {
        if (row.duplicateResolution?.action === 'SKIP') {
          continue;
        }

        itemsToCreate.push({
          name: row.name.trim(),
          code: row.code.trim(),
          category: row.category,
          unit: row.unit.trim().toUpperCase(),
          quantity: row.quantity,
          availableQuantity: row.quantity,
          damagedQuantity: row.damagedQuantity || 0,
          location: row.location.trim(),
          minQuantityThreshold: row.minQuantityThreshold || 5,
          remarks: row.remarks ? `${row.remarks} (Excel Import)` : 'Imported via Excel Paste',
          status: row.quantity > 0 ? 'Available' : 'Out of Stock',
        });
      }

      const res = await bulkAddAssets(itemsToCreate, authorName);
      toast.success(
        `Excel Import Successful! ${res?.length || itemsToCreate.length} records added to inventory.`
      );

      // Clear state
      setPastedText('');
      setParsedRows([]);
      setIsParsed(false);

      if (onSuccess) {
        onSuccess();
      }
    } catch (err: any) {
      toast.error(`Import failed: ${err.message || 'Server error'}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xs space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300">
                <FileSpreadsheet className="w-4 h-4" />
              </span>
              <h2 className="text-base sm:text-lg font-black text-slate-900 dark:text-white">
                Paste Directly from Excel / Google Sheets
              </h2>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Copy tab-separated cells from your spreadsheet (Ctrl+C) and paste below. Headers are auto-mapped, duplicates warned, and values validated before saving.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              icon={<Copy className="w-4 h-4 text-blue-600" />}
              onClick={handleCopySample}
            >
              Copy Sample Table
            </Button>

            <Button
              variant="outline"
              size="sm"
              icon={<Download className="w-4 h-4 text-slate-600" />}
              onClick={handleDownloadSample}
            >
              Download Template CSV
            </Button>
          </div>
        </div>

        {/* Paste Area Form */}
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs">
            <label className="font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <Clipboard className="w-4 h-4 text-emerald-600" />
              <span>Spreadsheet Paste Box (Paste rows here):</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer text-slate-600 dark:text-slate-400 font-medium">
              <input
                type="checkbox"
                checked={hasHeaders}
                onChange={(e) => setHasHeaders(e.target.checked)}
                className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
              />
              <span>First row contains column headers</span>
            </label>
          </div>

          <textarea
            value={pastedText}
            onChange={(e) => setPastedText(e.target.value)}
            placeholder={`Paste your Excel rows here...\n\nExample format:\nItem Name\tCode\tCategory\tQuantity\tUnit\tLocation\nBOSCH HAMMER\tEQP-101\tEquipment\t15\tNOS\tRack A-1`}
            rows={5}
            className="w-full p-3 text-xs font-mono rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-950/60 focus:bg-white dark:focus:bg-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-none transition-all placeholder:text-slate-400"
          />

          <div className="flex items-center justify-between">
            <span className="text-[11px] text-slate-500">
              {pastedText.trim()
                ? `${pastedText.trim().split(/\r?\n/).length} line(s) detected in clipboard text`
                : 'Supports tab-separated values from Microsoft Excel, Office 365, LibreOffice, and Google Sheets.'}
            </span>

            <Button
              variant="primary"
              size="sm"
              icon={<ArrowRight className="w-4 h-4" />}
              onClick={handleParse}
              disabled={!pastedText.trim()}
            >
              Parse & Preview Data
            </Button>
          </div>
        </div>
      </div>

      {/* Preview & Column Mapping Section */}
      {isParsed && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs overflow-hidden space-y-4 p-4 sm:p-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h3 className="text-sm font-black text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <Table className="w-4 h-4 text-emerald-600" />
                <span>Spreadsheet Preview & Column Mapping</span>
              </h3>
              <p className="text-xs text-slate-500">
                Verify recognized columns below. If headers differ, manually change the target field dropdown for any column.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                icon={<RefreshCw className="w-4 h-4" />}
                onClick={handleParse}
              >
                Re-Parse
              </Button>

              <Button
                variant="primary"
                size="sm"
                icon={<Save className="w-4 h-4" />}
                isLoading={isSubmitting}
                onClick={handleConfirmImport}
                disabled={parsedRows.length === 0}
              >
                Confirm & Import {parsedRows.length} Items
              </Button>
            </div>
          </div>

          {/* Validation Metrics */}
          <div className="grid grid-cols-3 gap-3 text-xs">
            <div className="p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Total Preview Rows</span>
              <span className="text-base font-black text-slate-800 dark:text-slate-100">{parsedRows.length}</span>
            </div>

            <div className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/60">
              <span className="text-emerald-700 dark:text-emerald-300 block text-[10px] uppercase font-bold flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Valid Rows
              </span>
              <span className="text-base font-black text-emerald-700 dark:text-emerald-300">{validCount}</span>
            </div>

            <div className={`p-2 rounded-xl border ${duplicateCount > 0 ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-900/60 text-amber-700 dark:text-amber-300' : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-500'}`}>
              <span className="block text-[10px] uppercase font-bold flex items-center gap-1">
                <Info className="w-3 h-3" /> Duplicate Warnings
              </span>
              <span className="text-base font-black">{duplicateCount}</span>
            </div>
          </div>

          {/* MET Numbering Quick Action Bar */}
          <div className="flex flex-wrap items-center justify-between gap-2.5 p-3 rounded-xl bg-blue-50/70 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900/60 text-xs">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-bold text-blue-900 dark:text-blue-200 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-blue-600" /> MET Numbering:
              </span>
              <button
                type="button"
                onClick={() => handleSequenceMetNumbers(true)}
                className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition-colors shadow-2xs cursor-pointer"
                title="Number rows starting from MET - 1"
              >
                Sequence from MET - 1 (MET - 1, MET - 2...)
              </button>
              <button
                type="button"
                onClick={() => handleSequenceMetNumbers(false)}
                className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors cursor-pointer"
                title="Continue sequence from next available MET number"
              >
                Continue Next MET#
              </button>
              <button
                type="button"
                onClick={handleClearConsumablesMetNumbers}
                className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-900 text-amber-800 dark:text-amber-300 hover:bg-amber-100 dark:hover:bg-amber-900 transition-colors cursor-pointer"
                title="Clear MET numbers for consumables and materials (optional)"
              >
                Clear Consumables MET# (Optional)
              </button>
            </div>
            <span className="text-[11px] text-slate-500 italic">
              * MET number option me hai (optional for bulk materials and consumables).
            </span>
          </div>

          {/* Column Mapping Selector Row */}
          <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 text-xs">
            <span className="font-bold text-slate-700 dark:text-slate-300 block mb-2 text-[11px] uppercase tracking-wider">
              Detected Columns & Field Mapping:
            </span>
            <div className="flex flex-wrap gap-2">
              {detectedColumns.map((colName, colIdx) => (
                <div key={colIdx} className="bg-white dark:bg-slate-900 p-2 rounded-lg border border-slate-200 dark:border-slate-700 shadow-2xs">
                  <div className="text-[10px] font-mono text-slate-400 mb-1 truncate max-w-[140px]" title={colName}>
                    Col {colIdx + 1}: &ldquo;{colName}&rdquo;
                  </div>
                  <select
                    value={columnMap[colIdx] || ''}
                    onChange={(e) => handleMappingChange(colIdx, e.target.value)}
                    className="text-xs font-bold px-2 py-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                  >
                    <option value="">(Ignore Column)</option>
                    {TARGET_FIELDS.map((f) => (
                      <option key={f.key} value={f.key}>
                        {f.label}
                      </option>
                    ))}
                  </select>
                </div>
              ))}
            </div>
          </div>

          {/* Interactive Preview Table */}
          <div className="overflow-x-auto max-h-[460px] overflow-y-auto border border-slate-200 dark:border-slate-800 rounded-xl">
            <table className="w-full text-left border-collapse text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800 sticky top-0 z-10 border-b border-slate-200 dark:border-slate-700 text-[11px] font-bold text-slate-600 dark:text-slate-300">
                <tr>
                  <th className="py-2.5 px-3 w-8 text-center">#</th>
                  <th className="py-2.5 px-3 min-w-[200px]">Item Name</th>
                  <th className="py-2.5 px-3 min-w-[130px]">MET Number <span className="text-[10px] font-normal text-slate-400">(Optional)</span></th>
                  <th className="py-2.5 px-3 min-w-[120px]">Category</th>
                  <th className="py-2.5 px-3 min-w-[90px]">Qty</th>
                  <th className="py-2.5 px-3 min-w-[80px]">Unit</th>
                  <th className="py-2.5 px-3 min-w-[140px]">Location</th>
                  <th className="py-2.5 px-3 min-w-[80px]">Min Stock</th>
                  <th className="py-2.5 px-3 min-w-[140px]">Remarks</th>
                  <th className="py-2.5 px-3 w-16 text-center">Delete</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {parsedRows.map((row, idx) => {
                  const errors = getRowErrors(row);
                  const hasErrors = errors.length > 0;
                  const dupMatch = duplicateCandidateMap.get(row.id);
                  const isDup = !!dupMatch && !row.duplicateResolution;

                  return (
                    <tr
                      key={row.id}
                      className={`transition-colors ${
                        hasErrors
                          ? 'bg-rose-50/40 dark:bg-rose-950/20'
                          : isDup
                          ? 'bg-amber-50/40 dark:bg-amber-950/20'
                          : row.duplicateResolution?.action === 'SKIP'
                          ? 'opacity-40 bg-slate-100 dark:bg-slate-800'
                          : 'hover:bg-slate-50/60 dark:hover:bg-slate-800/40'
                      }`}
                    >
                      <td className="py-2 px-3 text-center text-slate-400 font-mono text-[11px]">
                        {idx + 1}
                      </td>

                      <td className="py-2 px-3">
                        <input
                          type="text"
                          value={row.name}
                          onChange={(e) => handleCellChange(row.id, 'name', e.target.value)}
                          className={`w-full px-2 py-1 rounded bg-white dark:bg-slate-800 border ${
                            !row.name.trim() ? 'border-rose-400' : 'border-slate-200 dark:border-slate-700'
                          } text-xs`}
                        />
                        {dupMatch && (
                          <button
                            type="button"
                            onClick={() => setDuplicateModalRow({ row, match: dupMatch })}
                            className="mt-1 text-[10px] font-bold text-amber-700 dark:text-amber-300 underline flex items-center gap-1 cursor-pointer"
                          >
                            <AlertTriangle className="w-3 h-3" />
                            <span>
                              {row.duplicateResolution
                                ? `Action: ${row.duplicateResolution.action}`
                                : 'Duplicate Warning (Click to resolve)'}
                            </span>
                          </button>
                        )}
                      </td>

                      <td className="py-2 px-3">
                        <input
                          type="text"
                          value={row.code}
                          onChange={(e) => handleCellChange(row.id, 'code', e.target.value)}
                          placeholder="e.g. MET-1 (Optional)"
                          className="w-full px-2 py-1 rounded bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-mono placeholder:text-slate-400"
                        />
                      </td>

                      <td className="py-2 px-3">
                        <select
                          value={row.category}
                          onChange={(e) => handleCellChange(row.id, 'category', e.target.value as AssetCategory)}
                          className="w-full px-2 py-1 rounded bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                        >
                          {CATEGORIES.map((c) => (
                            <option key={c} value={c}>
                              {c}
                            </option>
                          ))}
                        </select>
                      </td>

                      <td className="py-2 px-3">
                        <input
                          type="number"
                          min="0"
                          value={row.quantity}
                          onChange={(e) => handleCellChange(row.id, 'quantity', Number(e.target.value))}
                          className="w-full px-2 py-1 rounded bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-center font-bold"
                        />
                      </td>

                      <td className="py-2 px-3">
                        <input
                          type="text"
                          value={row.unit}
                          onChange={(e) => handleCellChange(row.id, 'unit', e.target.value)}
                          className="w-full px-2 py-1 rounded bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-center uppercase"
                        />
                      </td>

                      <td className="py-2 px-3">
                        <input
                          type="text"
                          value={row.location}
                          onChange={(e) => handleCellChange(row.id, 'location', e.target.value)}
                          className="w-full px-2 py-1 rounded bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                        />
                      </td>

                      <td className="py-2 px-3">
                        <input
                          type="number"
                          min="0"
                          value={row.minQuantityThreshold}
                          onChange={(e) => handleCellChange(row.id, 'minQuantityThreshold', Number(e.target.value))}
                          className="w-full px-2 py-1 rounded bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-center"
                        />
                      </td>

                      <td className="py-2 px-3">
                        <input
                          type="text"
                          value={row.remarks}
                          onChange={(e) => handleCellChange(row.id, 'remarks', e.target.value)}
                          className="w-full px-2 py-1 rounded bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                        />
                      </td>

                      <td className="py-2 px-3 text-center">
                        <button
                          type="button"
                          onClick={() => handleDeleteRow(row.id)}
                          className="p-1 text-slate-400 hover:text-rose-600 rounded transition-colors"
                          title="Remove row"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Duplicate Warning Modal */}
      {duplicateModalRow && (
        <DuplicateWarningModal
          isOpen={!!duplicateModalRow}
          onClose={() => setDuplicateModalRow(null)}
          duplicateMatch={duplicateModalRow.match}
          draftItem={{
            name: duplicateModalRow.row.name,
            code: duplicateModalRow.row.code,
            category: duplicateModalRow.row.category,
            quantity: duplicateModalRow.row.quantity,
            unit: duplicateModalRow.row.unit,
            location: duplicateModalRow.row.location,
          }}
          onResolve={(res) => {
            setParsedRows((prev) =>
              prev.map((r) =>
                r.id === duplicateModalRow.row.id
                  ? { ...r, duplicateResolution: res }
                  : r
              )
            );
            toast.success(`Duplicate action set to: ${res.action}`);
          }}
        />
      )}
    </div>
  );
};
