import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useMetc } from '../../hooks/useMetc';
import { AssetCategory, BaseAsset } from '../../types';
import { StockSummaryCards } from '../../components/metc/tables/StockSummaryCards';
import { ItemTable } from '../../components/metc/tables/ItemTable';
import { ItemForm } from '../../components/metc/forms/ItemForm';
import { ItemDetailsModal } from '../../components/metc/details/ItemDetailsModal';
import { AssetTagPrintModal } from '../../components/metc/details/AssetTagPrintModal';
import { ImportModal } from '../../components/metc/forms/ImportModal';
import { Modal } from '../../components/ui/Modal';
import { Button } from '../../components/ui/Button';
import { exportToCSV } from '../../utils/exportUtils';
import { BulkAddTab } from './components/BulkAddTab';
import { PasteFromExcelTab } from './components/PasteFromExcelTab';
import { QuickStockCountTab } from './components/QuickStockCountTab';
import { SiteIssueReturnTab } from './components/SiteIssueReturnTab';
import { PendingCountTrackerTab } from './components/PendingCountTrackerTab';
import { AIInvoiceScannerModal } from './components/invoices/AIInvoiceScannerModal';
import { PurchaseRecordsTab } from './components/invoices/PurchaseRecordsTab';
import { 
  Package, 
  HardHat, 
  Wrench, 
  Fuel, 
  ShieldCheck, 
  Plus, 
  Search, 
  Filter, 
  Upload, 
  Download, 
  Trash2, 
  RefreshCw, 
  AlertTriangle, 
  Boxes, 
  CheckSquare, 
  QrCode, 
  MapPin, 
  X,
  Eye,
  Lock,
  ClipboardCheck,
  ArrowRightLeft,
  FileSpreadsheet,
  PieChart,
  Layers,
  Sparkles,
  Receipt,
  Clock
} from 'lucide-react';
import { toast } from 'sonner';
import { usePermissions } from '../../hooks/usePermissions';
import { useAssetStore } from '../../store/useAssetStore';

export type METCModuleTab = 
  | 'inventory' 
  | 'purchases'
  | 'bulk_add' 
  | 'excel_paste' 
  | 'stock_count' 
  | 'site_issue_return' 
  | 'pending_count';

interface MOUNTECMasterModuleProps {
  defaultCategory?: AssetCategory | 'All';
  defaultTab?: METCModuleTab;
  title?: string;
  subtitle?: string;
}

export const MOUNTECMasterModule: React.FC<MOUNTECMasterModuleProps> = ({
  defaultCategory = 'All',
  defaultTab = 'inventory',
  title = 'MOUNTEC Master Module',
  subtitle = 'Enterprise Equipment, Materials, Tools, Consumables & PPE Inventory Management',
}) => {
  const [activeTab, setActiveTab] = useState<METCModuleTab>(defaultTab);
  const [isInvoiceScannerOpen, setIsInvoiceScannerOpen] = useState(false);
  const { fetchAssets } = useAssetStore();
  const {
    filteredItems,
    sortedItems,
    paginatedItems,
    totalItems,
    totalPages,
    currentPage,
    itemsPerPage,

    categoryFilter,
    setCategoryFilter,
    searchQuery,
    setSearchQuery,
    statusFilter,
    setStatusFilter,
    locationFilter,
    setLocationFilter,
    supplierFilter,
    setSupplierFilter,
    lowStockOnly,
    setLowStockOnly,
    warrantyExpiringOnly,
    setWarrantyExpiringOnly,
    calibrationDueOnly,
    setCalibrationDueOnly,

    sortBy,
    sortOrder,
    handleSort,

    setCurrentPage,
    setItemsPerPage,

    selectedIds,
    toggleSelectAll,
    toggleSelectRow,

    activeItem,
    setActiveItem,
    isFormOpen,
    setIsFormOpen,
    editingItem,
    setEditingItem,
    isImportOpen,
    setIsImportOpen,
    isQrModalOpen,
    setIsQrModalOpen,
    qrItem,
    setQrItem,
    deleteConfirmId,
    setDeleteConfirmId,

    handleCreateOrUpdate,
    handleDelete,
    handleDuplicate,
    handleBulkDelete,
    clearAllAssets,
    restoreDemoData,
    allStoreItems,
  } = useMetc({ initialCategory: defaultCategory as AssetCategory | 'All' });

  const { canEdit, isViewer } = usePermissions();
  const [isFilterExpanded, setIsFilterExpanded] = useState(false);
  const [isClearAllModalOpen, setIsClearAllModalOpen] = useState(false);

  // Category Tab configuration
  const categoryTabs: { id: AssetCategory | 'All'; label: string; icon: any }[] = [
    { id: 'All', label: 'All Assets', icon: Boxes },
    { id: 'Material', label: 'Materials', icon: Package },
    { id: 'Equipment', label: 'Equipment', icon: HardHat },
    { id: 'Tool', label: 'Tools', icon: Wrench },
    { id: 'Consumable', label: 'Consumables', icon: Fuel },
    { id: 'PPE', label: 'PPE Safety', icon: ShieldCheck },
  ];

  // Handle Export CSV
  const handleExportCSV = () => {
    if (filteredItems.length === 0) {
      toast.error('No items to export');
      return;
    }
    const exportData = filteredItems.map((item) => ({
      'Asset ID': item.code,
      'Item Name': item.name,
      'Category': item.category,
      'Brand': item.brand || (item as any).manufacturer || '',
      'Model': item.model || (item as any).materialGrade || '',
      'Quantity': item.quantity,
      'Available Qty': item.availableQuantity,
      'Unit': item.unit,
      'Unit Price ($)': item.unitPrice || item.purchaseCost || 0,
      'Location': item.location,
      'Status': item.status,
      'Supplier': item.supplier || '',
      'Serial Number': item.serialNumber || (item as any).batchNumber || '',
      'Barcode': item.barcode || '',
    }));
    exportToCSV(exportData, `MOUNTEC_${categoryFilter}_Inventory_${new Date().toISOString().slice(0, 10)}.csv`);
    toast.success(`Exported ${filteredItems.length} records to CSV`);
  };

  // Handle Import excel/CSV data
  const handleImportSuccess = (importedRows: any[]) => {
    if (!canEdit) {
      toast.error('Edit access restricted: Only Admin and Super Admin can import assets.');
      return;
    }
    importedRows.forEach((row) => {
      handleCreateOrUpdate(row);
    });
  };

  return (
    <div className="space-y-6">
      {/* Page Title & Main Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-blue-600 dark:text-blue-400 mb-1">
            <span>MOUNTEC SYSTEM</span>
            <span>•</span>
            <span className="uppercase">{categoryFilter} Inventory</span>
            {!canEdit && (
              <>
                <span>•</span>
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300">
                  <Eye className="w-3 h-3" /> Viewer (Read-Only)
                </span>
              </>
            )}
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
            {title}
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{subtitle}</p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2.5">
          {canEdit && (
            <Button
              variant="outline"
              size="sm"
              className="text-rose-600 dark:text-rose-400 border-rose-200 dark:border-rose-900/50 hover:bg-rose-50 dark:hover:bg-rose-950/40"
              icon={<Trash2 className="w-4 h-4 text-rose-500" />}
              onClick={() => setIsClearAllModalOpen(true)}
            >
              Clear All Items
            </Button>
          )}

          {canEdit && (
            <Button
              variant="outline"
              size="sm"
              icon={<Upload className="w-4 h-4 text-emerald-600" />}
              onClick={() => setIsImportOpen(true)}
            >
              Import Excel / CSV
            </Button>
          )}

          <Button
            variant="outline"
            size="sm"
            icon={<Download className="w-4 h-4 text-blue-600" />}
            onClick={handleExportCSV}
          >
            Export CSV
          </Button>

          {canEdit && (
            <Button
              variant="primary"
              size="sm"
              className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold shadow-xs"
              icon={<Sparkles className="w-4 h-4 text-amber-300" />}
              onClick={() => setIsInvoiceScannerOpen(true)}
            >
              AI Invoice Scanner
            </Button>
          )}

          {canEdit && (
            <Button
              variant="primary"
              size="sm"
              icon={<Plus className="w-4 h-4" />}
              onClick={() => {
                setEditingItem(null);
                setIsFormOpen(true);
              }}
            >
              Add New Asset
            </Button>
          )}
        </div>
      </div>

      {/* Module Operations Navigation Sub-Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 border-b border-slate-200 dark:border-slate-800">
        {[
          { id: 'inventory', label: 'Inventory Assets', icon: Boxes },
          { id: 'purchases', label: 'Purchase Records & Invoices', icon: Receipt },
          { id: 'bulk_add', label: 'Bulk Add', icon: Layers },
          { id: 'excel_paste', label: 'Paste from Excel', icon: FileSpreadsheet },
          { id: 'stock_count', label: 'Quick Stock Count', icon: ClipboardCheck },
          { id: 'site_issue_return', label: 'Site Issue & Return', icon: ArrowRightLeft },
          { id: 'pending_count', label: 'Pending Counts', icon: Clock },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as METCModuleTab)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all shrink-0 cursor-pointer ${
                isActive
                  ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
              {tab.id === 'purchases' && (
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-500 dark:text-indigo-400 border border-indigo-500/30">
                  AI OCR
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Tab: Purchase Records & Invoices */}
      {activeTab === 'purchases' && (
        <PurchaseRecordsTab
          onOpenScanner={() => setIsInvoiceScannerOpen(true)}
          onRefreshInventory={fetchAssets}
        />
      )}

      {/* Tab: Bulk Add Rows */}
      {activeTab === 'bulk_add' && (
        <BulkAddTab
          existingItems={allStoreItems}
          onSuccess={() => {
            fetchAssets();
            setActiveTab('inventory');
          }}
          onSwitchToPaste={() => setActiveTab('excel_paste')}
        />
      )}

      {/* Tab: Paste from Excel */}
      {activeTab === 'excel_paste' && (
        <PasteFromExcelTab
          existingItems={allStoreItems}
          onSuccess={() => {
            fetchAssets();
            setActiveTab('inventory');
          }}
          onSwitchToBulk={() => setActiveTab('bulk_add')}
        />
      )}

      {/* Tab: Quick Stock Count */}
      {activeTab === 'stock_count' && (
        <QuickStockCountTab
          items={filteredItems}
          onCountApplied={fetchAssets}
        />
      )}

      {/* Tab: Site Issue & Return */}
      {activeTab === 'site_issue_return' && (
        <SiteIssueReturnTab
          items={allStoreItems}
          onTransactionComplete={fetchAssets}
        />
      )}

      {/* Tab: Pending Count Tracker */}
      {activeTab === 'pending_count' && (
        <PendingCountTrackerTab
          items={allStoreItems}
          onOpenQuickCount={() => setActiveTab('stock_count')}
        />
      )}

      {/* Tab: Main Inventory Asset Table */}
      {activeTab === 'inventory' && (
        <>
          {/* Main Category Filter Navigation Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 border-b border-slate-200 dark:border-slate-800">
            {categoryTabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = categoryFilter === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setCategoryFilter(tab.id as any)}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all shrink-0 ${
                    isActive
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

      {/* Stock Metrics Cards */}
      <StockSummaryCards items={filteredItems} activeCategory={categoryFilter} />

      {/* Bulk Action Bar (Visible when rows are selected) */}
      {selectedIds.length > 0 && (
        <div className="p-3 bg-blue-900 text-white rounded-xl flex items-center justify-between shadow-lg animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center gap-3 text-xs font-semibold">
            <CheckSquare className="w-4 h-4 text-blue-300" />
            <span>{selectedIds.length} items selected</span>
          </div>
          <div className="flex items-center gap-2">
            {canEdit ? (
              <Button
                variant="outline"
                size="sm"
                className="bg-blue-800 text-white border-blue-700 hover:bg-blue-700 text-xs"
                icon={<Trash2 className="w-3.5 h-3.5 text-rose-300" />}
                onClick={handleBulkDelete}
              >
                Archive Selected
              </Button>
            ) : (
              <span className="text-xs text-blue-200">View/Export selection only</span>
            )}
          </div>
        </div>
      )}

      {/* Search & Filter Toolbar */}
      <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-3">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          {/* Live Instant Search Bar */}
          <div className="relative w-full sm:w-96 flex items-center">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 pointer-events-none" />
            <input
              type="text"
              placeholder="Search by name, code, serial, brand, model, barcode..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Escape') {
                  setSearchQuery('');
                }
              }}
              className="w-full pl-9 pr-9 py-2 text-xs bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-slate-900 dark:text-slate-100 transition-all placeholder:text-slate-400"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 p-1 rounded-md text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                title="Clear search (Esc)"
                aria-label="Clear search"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Search Result Counter (when searching) & Quick Toggle Filters */}
          <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto justify-between sm:justify-end">
            {searchQuery && (
              <span className="text-[11px] font-semibold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 px-2.5 py-1 rounded-lg border border-blue-200 dark:border-blue-800/60 shrink-0">
                {filteredItems.length} {filteredItems.length === 1 ? 'result' : 'results'}
              </span>
            )}

            <button
              onClick={() => setLowStockOnly(!lowStockOnly)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors shrink-0 ${
                lowStockOnly
                  ? 'bg-amber-100 dark:bg-amber-950/80 border-amber-300 text-amber-900 dark:text-amber-200 font-semibold'
                  : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
              <span>Low Stock Alerts</span>
            </button>

            <button
              onClick={() => setIsFilterExpanded(!isFilterExpanded)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 shrink-0"
            >
              <Filter className="w-3.5 h-3.5 text-blue-500" />
              <span>{isFilterExpanded ? 'Hide Filters' : 'More Filters'}</span>
            </button>
          </div>
        </div>

        {/* Expanded Filters Drawer */}
        {isFilterExpanded && (
          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            {/* Status Filter */}
            <div>
              <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                Asset Status
              </label>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
              >
                <option value="All">All Statuses</option>
                <option value="Available">Available</option>
                <option value="Issued">Issued</option>
                <option value="Under Repair">Under Repair</option>
                <option value="Low Stock">Low Stock</option>
                <option value="Out of Stock">Out of Stock</option>
                <option value="Lost">Lost</option>
                <option value="Inactive">Inactive</option>
              </select>
            </div>

            {/* Warranty Filter */}
            <div>
              <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                Warranty Status
              </label>
              <button
                onClick={() => setWarrantyExpiringOnly(!warrantyExpiringOnly)}
                className={`w-full text-left px-2.5 py-1.5 rounded-lg border text-xs font-medium ${
                  warrantyExpiringOnly
                    ? 'bg-blue-100 dark:bg-blue-950/80 border-blue-400 text-blue-900 dark:text-blue-200'
                    : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                }`}
              >
                {warrantyExpiringOnly ? 'Showing Warranty Expiring <= 30 Days' : 'Filter Expiring Warranty'}
              </button>
            </div>

            {/* Calibration Filter */}
            <div>
              <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                Calibration Due
              </label>
              <button
                onClick={() => setCalibrationDueOnly(!calibrationDueOnly)}
                className={`w-full text-left px-2.5 py-1.5 rounded-lg border text-xs font-medium ${
                  calibrationDueOnly
                    ? 'bg-sky-100 dark:bg-sky-950/80 border-sky-400 text-sky-900 dark:text-sky-200'
                    : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                }`}
              >
                {calibrationDueOnly ? 'Showing Calibration Due <= 30 Days' : 'Filter Calibration Due'}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Main Data Table Component */}
      <ItemTable
        items={paginatedItems}
        selectedIds={selectedIds}
        onToggleSelectAll={toggleSelectAll}
        onToggleSelectRow={toggleSelectRow}
        onView={(item) => setActiveItem(item)}
        onEdit={(item) => {
          if (!canEdit) {
            toast.error('Only Admin and Super Admin can edit assets.');
            return;
          }
          setEditingItem(item);
          setIsFormOpen(true);
        }}
        onPrintQr={(item) => {
          setQrItem(item);
          setIsQrModalOpen(true);
        }}
        onDuplicate={(item) => {
          if (!canEdit) {
            toast.error('Only Admin and Super Admin can duplicate assets.');
            return;
          }
          handleDuplicate(item);
        }}
        onDelete={(id) => {
          if (!canEdit) {
            toast.error('Only Admin and Super Admin can delete assets.');
            return;
          }
          setDeleteConfirmId(id);
        }}
        sortBy={sortBy}
        sortOrder={sortOrder}
        onSort={handleSort}
        currentPage={currentPage}
        totalPages={totalPages}
        itemsPerPage={itemsPerPage}
        totalItems={totalItems}
        onPageChange={setCurrentPage}
        onItemsPerPageChange={setItemsPerPage}
        searchQuery={searchQuery}
        onClearSearch={() => setSearchQuery('')}
        onAddNew={() => {
          if (!canEdit) {
            toast.error('Only Admin and Super Admin can add new assets.');
            return;
          }
          setEditingItem(null);
          setIsFormOpen(true);
        }}
        canEdit={canEdit}
      />
        </>
      )}

      {/* Add / Edit Form Modal */}
      <Modal
        isOpen={isFormOpen && canEdit}
        onClose={() => {
          setIsFormOpen(false);
          setEditingItem(null);
        }}
        title={editingItem ? `Edit Asset - ${editingItem.code}` : `Register New ${categoryFilter !== 'All' ? categoryFilter : 'MOUNTEC'} Asset`}
        size="lg"
      >
        <ItemForm
          initialData={editingItem}
          defaultCategory={categoryFilter !== 'All' ? (categoryFilter as AssetCategory) : 'Material'}
          onSubmit={handleCreateOrUpdate}
          onCancel={() => {
            setIsFormOpen(false);
            setEditingItem(null);
          }}
        />
      </Modal>

      {/* Details View Drawer / Modal */}
      <ItemDetailsModal
        item={activeItem}
        isOpen={!!activeItem}
        onClose={() => setActiveItem(null)}
        onEdit={(item) => {
          if (!canEdit) {
            toast.error('Only Admin and Super Admin can edit assets.');
            return;
          }
          setEditingItem(item);
          setIsFormOpen(true);
        }}
        onPrintQr={(item) => {
          setQrItem(item);
          setIsQrModalOpen(true);
        }}
        canEdit={canEdit}
      />

      {/* Print QR & Barcode Tag Modal */}
      <AssetTagPrintModal
        item={qrItem}
        isOpen={isQrModalOpen}
        onClose={() => {
          setIsQrModalOpen(false);
          setQrItem(null);
        }}
      />

      {/* Excel / CSV Import Modal */}
      <ImportModal
        isOpen={isImportOpen}
        onClose={() => setIsImportOpen(false)}
        onImportData={handleImportSuccess}
      />

      {/* Clear All Assets Confirmation Modal */}
      <Modal
        isOpen={isClearAllModalOpen}
        onClose={() => setIsClearAllModalOpen(false)}
        title="Clear All Inventory / Delete All Items"
        size="sm"
      >
        <div className="space-y-4 text-slate-900 dark:text-slate-100">
          <div className="flex items-start gap-3 p-3 bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 rounded-xl text-rose-800 dark:text-rose-200 text-xs">
            <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">Are you sure you want to delete all METC items?</p>
              <p className="mt-1 text-[11px] text-rose-700 dark:text-rose-300">
                This will wipe all Materials, Equipment, Tools, Consumables, and PPE items so you can start fresh and add your own items from scratch.
              </p>
            </div>
          </div>
          <div className="flex items-center justify-between pt-2 border-t border-slate-200 dark:border-slate-800">
            <Button
              variant="outline"
              size="sm"
              onClick={async () => {
                await restoreDemoData();
                setIsClearAllModalOpen(false);
                toast.info('Restored sample demo items.');
              }}
              className="text-xs text-slate-500"
            >
              Restore Demo Data
            </Button>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={() => setIsClearAllModalOpen(false)}>
                Cancel
              </Button>
              <Button
                variant="danger"
                size="sm"
                onClick={async () => {
                  await clearAllAssets();
                  setIsClearAllModalOpen(false);
                  toast.success('All assets cleared! You can now add your new items.');
                }}
              >
                Yes, Delete All Items
              </Button>
            </div>
          </div>
        </div>
      </Modal>

      {/* Delete / Archive Confirmation Modal */}
      <Modal
        isOpen={!!deleteConfirmId}
        onClose={() => setDeleteConfirmId(null)}
        title="Confirm Asset Archival"
        size="sm"
      >
        <div className="space-y-4 text-slate-900 dark:text-slate-100">
          <p className="text-xs text-slate-600 dark:text-slate-300">
            Are you sure you want to archive or delete this asset record? This operation will remove the item from active stock counts and move it to archived history.
          </p>
          <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
            <Button variant="outline" size="sm" onClick={() => setDeleteConfirmId(null)}>
              Cancel
            </Button>
            <Button
              variant="danger"
              size="sm"
              onClick={() => deleteConfirmId && handleDelete(deleteConfirmId)}
            >
              Archive Record
            </Button>
          </div>
        </div>
      </Modal>

      {/* AI Invoice Scanner & Auto Purchase Entry Modal */}
      <AIInvoiceScannerModal
        isOpen={isInvoiceScannerOpen}
        onClose={() => setIsInvoiceScannerOpen(false)}
        existingItems={allStoreItems}
        onPurchaseConfirmed={async () => {
          await fetchAssets();
          setActiveTab('purchases');
        }}
      />
    </div>
  );
};
