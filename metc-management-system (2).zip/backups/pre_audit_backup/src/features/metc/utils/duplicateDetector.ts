import { METCItem, AssetCategory } from '../../../types';

export interface DuplicateMatch {
  matchType: 'EXACT_CODE' | 'EXACT_NAME_CATEGORY' | 'SIMILAR_NAME';
  existingItem: METCItem;
  confidenceScore: number; // 0 to 100
  reason: string;
}

export interface DuplicateResolution {
  action: 'UPDATE_STOCK' | 'ADD_NEW' | 'SKIP';
  quantityToAdd?: number;
  reason?: string;
}

/**
 * Normalizes item names by trimming, converting to lower case,
 * collapsing multiple spaces, and removing non-alphanumeric noise.
 */
export function normalizeItemName(name: string): string {
  if (!name) return '';
  return name
    .toLowerCase()
    .replace(/[_-]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Normalizes item codes by trimming and converting to upper case.
 */
export function normalizeItemCode(code: string): string {
  if (!code) return '';
  return code.trim().toUpperCase();
}

/**
 * Calculates simple Levenshtein distance for fuzzy name similarity detection
 */
function levenshteinDistance(a: string, b: string): number {
  const matrix: number[][] = [];
  for (let i = 0; i <= b.length; i++) {
    matrix[i] = [i];
  }
  for (let j = 0; j <= a.length; j++) {
    matrix[0][j] = j;
  }
  for (let i = 1; i <= b.length; i++) {
    for (let j = 1; j <= a.length; j++) {
      if (b.charAt(i - 1) === a.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1,
          Math.min(matrix[i][j - 1] + 1, matrix[i - 1][j] + 1)
        );
      }
    }
  }
  return matrix[b.length][a.length];
}

/**
 * Checks an incoming draft item against an array of existing inventory items
 * to identify potential duplicate candidates without ever merging silently.
 */
export function checkDuplicate(
  draft: {
    name: string;
    code?: string;
    category: AssetCategory;
    unit?: string;
  },
  existingInventory: METCItem[]
): DuplicateMatch | null {
  if (!draft.name || !existingInventory || existingInventory.length === 0) {
    return null;
  }

  const normDraftName = normalizeItemName(draft.name);
  const normDraftCode = draft.code ? normalizeItemCode(draft.code) : '';
  const draftCategory = draft.category;

  // 1. Strongest Check: Exact Item Code Match
  if (normDraftCode) {
    const codeMatch = existingInventory.find(
      (item) => normalizeItemCode(item.code) === normDraftCode
    );
    if (codeMatch) {
      return {
        matchType: 'EXACT_CODE',
        existingItem: codeMatch,
        confidenceScore: 100,
        reason: `Item code "${codeMatch.code}" is already registered to "${codeMatch.name}" in ${codeMatch.category}.`,
      };
    }
  }

  // 2. Exact Normalized Name in Same Category
  const exactNameCategoryMatch = existingInventory.find(
    (item) =>
      item.category === draftCategory &&
      normalizeItemName(item.name) === normDraftName
  );
  if (exactNameCategoryMatch) {
    return {
      matchType: 'EXACT_NAME_CATEGORY',
      existingItem: exactNameCategoryMatch,
      confidenceScore: 95,
      reason: `Identical item name found in ${draftCategory} with code ${exactNameCategoryMatch.code} (Current Stock: ${exactNameCategoryMatch.availableQuantity} ${exactNameCategoryMatch.unit}).`,
    };
  }

  // 3. Exact Normalized Name across different category (High warning)
  const crossCategoryMatch = existingInventory.find(
    (item) => normalizeItemName(item.name) === normDraftName
  );
  if (crossCategoryMatch) {
    return {
      matchType: 'EXACT_NAME_CATEGORY',
      existingItem: crossCategoryMatch,
      confidenceScore: 80,
      reason: `Same name "${crossCategoryMatch.name}" already exists under "${crossCategoryMatch.category}" (Code: ${crossCategoryMatch.code}).`,
    };
  }

  // 4. Fuzzy Similarity Check (e.g. slight typos or plurals: e.g. "Hammer Drill" vs "Hammer Drills")
  for (const item of existingInventory) {
    if (item.category === draftCategory) {
      const normExisting = normalizeItemName(item.name);
      if (Math.abs(normExisting.length - normDraftName.length) <= 3) {
        const dist = levenshteinDistance(normDraftName, normExisting);
        const maxLen = Math.max(normDraftName.length, normExisting.length);
        const similarity = ((maxLen - dist) / maxLen) * 100;
        if (similarity >= 88 && dist <= 2) {
          return {
            matchType: 'SIMILAR_NAME',
            existingItem: item,
            confidenceScore: Math.round(similarity),
            reason: `Closely resembles existing "${item.name}" (${item.code}) with ${Math.round(similarity)}% similarity.`,
          };
        }
      }
    }
  }

  return null;
}
