import { useMemo, useState } from 'react';
import { useTransactionStore } from '../../../store/useTransactionStore';
import { useAssetStore } from '../../../store/useAssetStore';
import { useWorkerStore } from '../../../store/useWorkerStore';
import { IssueRecord, ReturnRecord } from '../../../types';

export const useReturn = () => {
  const { returns, issues, lostItems, repairs } = useTransactionStore();
  const { workers } = useWorkerStore();
  
  const [filters, setFilters] = useState({
    search: '',
    condition: 'All',
    status: 'All',
  });

  // Calculate KPIs
  const kpis = useMemo(() => {
    const todayStr = new Date().toISOString().split('T')[0];
    const todayReturns = returns.filter(r => r.returnDate.startsWith(todayStr)).length;
    
    // Pending Returns: Active issues (and Overdue)
    const pendingIssues = issues.filter(i => i.status === 'Active' || i.status === 'Overdue');
    const pendingReturns = pendingIssues.length;
    
    const overdueReturns = issues.filter(i => i.status === 'Overdue').length;

    const goodCondition = returns.filter(r => r.conditionOnReturn === 'Good').length;
    const damaged = returns.filter(r => r.conditionOnReturn === 'Damaged').length;
    const repairRequired = returns.filter(r => r.conditionOnReturn === 'Repair Required' || r.conditionOnReturn === 'Needs Repair').length;
    
    const lostItemsCount = returns.filter(r => r.conditionOnReturn === 'Lost').length;

    return {
      todayReturns,
      pendingReturns,
      overdueReturns,
      goodCondition,
      damaged,
      repairRequired,
      lostItems: lostItemsCount,
    };
  }, [returns, issues]);

  // Filter Active Returns / Return History
  const filteredReturns = useMemo(() => {
    return returns.filter(r => {
      const matchesSearch = 
        r.returnCode.toLowerCase().includes(filters.search.toLowerCase()) ||
        r.itemName.toLowerCase().includes(filters.search.toLowerCase()) ||
        r.workerName.toLowerCase().includes(filters.search.toLowerCase());
        
      const matchesCondition = filters.condition === 'All' || r.conditionOnReturn === filters.condition;
      
      return matchesSearch && matchesCondition;
    });
  }, [returns, filters]);
  
  // Pending Issues for New Return / Bulk Return
  const pendingIssuesList = useMemo(() => {
    return issues.filter(i => i.status === 'Active' || i.status === 'Overdue' || i.status === 'Partially Returned').map(i => {
      // Find worker department/site
      const worker = workers.find(w => w.id === i.workerId);
      return {
        ...i,
        department: worker?.trade || 'Unknown',
        site: worker?.projectSite || 'Unknown',
      };
    });
  }, [issues, workers]);

  return {
    returns,
    filteredReturns,
    pendingIssuesList,
    kpis,
    filters,
    setFilters,
  };
};
