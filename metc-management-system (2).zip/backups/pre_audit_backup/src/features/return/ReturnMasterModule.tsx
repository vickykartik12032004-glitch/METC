import React, { useState } from 'react';
import { useReturn } from './hooks/useReturn';
import { ReturnDashboardKpis } from './components/dashboard/ReturnDashboardKpis';
import { ReturnQuickActions } from './components/dashboard/ReturnQuickActions';
import { ReturnHistoryTable } from './components/tables/ReturnHistoryTable';
import { PendingReturnsTable } from './components/tables/PendingReturnsTable';
import { NewReturnForm } from './components/forms/NewReturnForm';
import { BulkReturnForm } from './components/forms/BulkReturnForm';
import { ReturnDetailsModal } from './components/details/ReturnDetailsModal';
import { ReturnSlipModal } from './components/details/ReturnSlipModal';

import {
  LayoutDashboard,
  Plus,
  History,
  RotateCcw,
  CheckSquare,
  FileBarChart2,
} from 'lucide-react';
import { toast } from 'sonner';

export type ReturnTabType =
  | 'dashboard'
  | 'new'
  | 'active'
  | 'history'
  | 'bulk'
  | 'pending'
  | 'reports';

export const ReturnMasterModule: React.FC = () => {
  const {
    returns,
    filteredReturns,
    pendingIssuesList,
    kpis,
    filters,
    setFilters,
  } = useReturn();

  const [activeTab, setActiveTab] = useState<ReturnTabType>('dashboard');
  const [selectedReturnForDetails, setSelectedReturnForDetails] = useState<any | null>(null);
  const [selectedReturnForSlip, setSelectedReturnForSlip] = useState<any | null>(null);

  const tabs = [
    { id: 'dashboard', label: 'Return Dashboard', icon: LayoutDashboard },
    { id: 'new', label: 'New Return', icon: Plus },
    { id: 'active', label: 'Active Returns', icon: RotateCcw },
    { id: 'history', label: 'Return History', icon: History },
    { id: 'bulk', label: 'Bulk Return', icon: CheckSquare },
    { id: 'pending', label: 'Pending Returns', icon: Clock },
    { id: 'reports', label: 'Reports', icon: FileBarChart2 },
  ];

  return (
    <div className="space-y-6">
      {/* Header and Tabs */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-4">
          <div>
            <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100 tracking-tight">Enterprise Return Management</h1>
            <p className="text-xs text-slate-500 mt-1">Manage asset returns, condition logging, and stock updates</p>
          </div>
        </div>

        <div className="flex items-center gap-1 overflow-x-auto pb-1 scrollbar-hide">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id as ReturnTabType)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                activeTab === t.id
                  ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              <t.icon className="w-4 h-4" />
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content Area */}
      {activeTab === 'dashboard' && (
        <div className="space-y-6">
          <ReturnDashboardKpis kpis={kpis} onFilterStatus={(status) => {
            if (status === 'Active' || status === 'Overdue') {
              setActiveTab('pending');
            } else {
              setFilters({ ...filters, condition: status });
              setActiveTab('history');
            }
          }} />
          <ReturnQuickActions onAction={(action) => {
            if (action === 'return') setActiveTab('new');
            if (action === 'qr') setActiveTab('new'); // would open scanner
            if (action === 'barcode') setActiveTab('new');
            if (action === 'reports') setActiveTab('reports');
          }} />
          {/* Recent Returns Preview Table could go here */}
        </div>
      )}

      {activeTab === 'new' && (
        <NewReturnForm 
          pendingIssues={pendingIssuesList} 
          onSubmit={() => setActiveTab('history')}
          onCancel={() => setActiveTab('dashboard')} 
        />
      )}

      {activeTab === 'bulk' && (
        <BulkReturnForm 
          pendingIssues={pendingIssuesList}
          onSubmit={() => setActiveTab('history')}
          onCancel={() => setActiveTab('dashboard')} 
        />
      )}

      {(activeTab === 'history' || activeTab === 'active') && (
        <ReturnHistoryTable 
          returns={filteredReturns} 
          filters={filters}
          setFilters={setFilters}
          onViewDetails={setSelectedReturnForDetails} 
          onPrintSlip={setSelectedReturnForSlip}
        />
      )}

      {activeTab === 'pending' && (
        <PendingReturnsTable 
          pendingIssues={pendingIssuesList} 
          onProcessReturn={(issue) => {
             // We can pass an initial issue to NewReturnForm
             setActiveTab('new');
          }}
        />
      )}

      {activeTab === 'reports' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-8 text-center text-slate-500">
          <FileBarChart2 className="w-12 h-12 mx-auto mb-4 text-slate-300" />
          <h2 className="text-lg font-bold text-slate-700 dark:text-slate-200">Return Reports & Analytics</h2>
          <p className="text-sm mt-2">Generate PDF and Excel reports for item returns, damages, and lost items.</p>
        </div>
      )}

      {/* Modals */}
      {selectedReturnForDetails && (
        <ReturnDetailsModal 
          returnRecord={selectedReturnForDetails} 
          isOpen={Boolean(selectedReturnForDetails)} 
          onClose={() => setSelectedReturnForDetails(null)} 
          onPrintSlip={() => setSelectedReturnForSlip(selectedReturnForDetails)}
        />
      )}

      {selectedReturnForSlip && (
        <ReturnSlipModal 
          returnRecord={selectedReturnForSlip} 
          isOpen={Boolean(selectedReturnForSlip)} 
          onClose={() => setSelectedReturnForSlip(null)} 
        />
      )}
    </div>
  );
};

// Clock is imported below instead of in main block to avoid missing var error
import { Clock } from 'lucide-react';
