import { useTransactionStore } from '../../../store/useTransactionStore';
import { useAssetStore } from '../../../store/useAssetStore';
import { useNotificationStore } from '../../../store/useNotificationStore';
import { ReturnRecord, AssetStatus } from '../../../types';

export const processReturn = (data: Omit<ReturnRecord, 'id' | 'returnCode'>) => {
  const { addReturn, issues, updateIssueStatus, addActivity, addRepair, addLostItem } = useTransactionStore.getState();
  const { updateMaterial, updateEquipment, updateTool, updateConsumable, updatePPE, materials, equipment, tools, consumables, ppe } = useAssetStore.getState();
  const { addNotification } = useNotificationStore.getState();

  // 1. Add return record
  addReturn(data);

  // 2. Update issue record
  const issue = issues.find(i => i.id === data.issueId);
  if (issue) {
    const isPartial = data.conditionOnReturn === 'Partial Return' || data.quantityReturned < issue.quantity;
    updateIssueStatus(issue.id, isPartial ? 'Partially Returned' : 'Returned');
  }

  // 3. Update Asset
  const allAssets = [...materials, ...equipment, ...tools, ...consumables, ...ppe];
  const asset = allAssets.find(a => a.id === data.itemId);
  
  if (asset) {
    let newStatus: AssetStatus = 'Available';
    let newAvailableQuantity = asset.availableQuantity;

    switch (data.conditionOnReturn) {
      case 'Good':
      case 'Partial Return':
      case 'Missing Accessories':
        newStatus = 'Available';
        newAvailableQuantity += data.quantityReturned;
        break;
      case 'Damaged':
        newStatus = 'Damaged' as AssetStatus;
        break;
      case 'Needs Repair':
      case 'Repair Required':
        newStatus = 'Under Repair';
        addRepair({
          itemId: asset.id,
          itemName: asset.name,
          serialOrTag: data.serialNumber || '',
          issueDescription: data.notes || 'Repair required upon return',
          sentDate: new Date().toISOString().split('T')[0],
          status: 'Scheduled',
          handledBy: data.receivedBy,
        });
        break;
      case 'Lost':
        newStatus = 'Lost';
        addLostItem({
          itemId: asset.id,
          itemName: asset.name,
          workerId: data.workerId,
          workerName: data.workerName,
          quantityLost: data.quantityReturned,
          reportedDate: new Date().toISOString().split('T')[0],
          location: data.site || 'Unknown',
          estimatedValue: asset.totalValue || 0,
          incidentDetails: data.notes || 'Lost during issue period',
          actionTaken: 'Under Investigation',
          status: 'Reported',
          reportedBy: data.receivedBy,
        });
        break;
      case 'Disposed':
        newStatus = 'Disposed';
        break;
    }

    const updates = {
      status: newStatus,
      availableQuantity: newAvailableQuantity,
    };

    switch (asset.category) {
      case 'Material': updateMaterial(asset.id, updates); break;
      case 'Equipment': updateEquipment(asset.id, updates); break;
      case 'Tool': updateTool(asset.id, updates); break;
      case 'Consumable': updateConsumable(asset.id, updates); break;
      case 'PPE': updatePPE(asset.id, updates); break;
    }

    // 4. Activity Log
    addActivity({
      action: 'Returned',
      targetType: 'Asset',
      targetName: asset.name,
      user: data.receivedBy,
      details: `Returned by ${data.workerName}. Condition: ${data.conditionOnReturn}`,
    });

    // 5. Notification
    addNotification({
      title: 'Item Returned',
      message: `${asset.name} returned by ${data.workerName} (${data.conditionOnReturn})`,
      type: data.conditionOnReturn === 'Good' ? 'success' : 'warning',
    });
  }
};

export const processBulkReturn = (returns: Omit<ReturnRecord, 'id' | 'returnCode'>[]) => {
  returns.forEach(record => {
    processReturn(record);
  });
};
