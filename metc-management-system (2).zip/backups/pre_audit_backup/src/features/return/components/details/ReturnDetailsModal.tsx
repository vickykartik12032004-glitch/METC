import React from 'react';
import { ReturnRecord } from '../../../../types';
import { Modal } from '../../../../components/ui/Modal';
import { Button } from '../../../../components/ui/Button';
import { formatDateTime } from '../../../../lib/utils';
import { StatusBadge } from '../../../../components/common/StatusBadge';
import { Printer, X } from 'lucide-react';

interface Props {
  returnRecord: ReturnRecord;
  isOpen: boolean;
  onClose: () => void;
  onPrintSlip: () => void;
}

export const ReturnDetailsModal: React.FC<Props> = ({ returnRecord, isOpen, onClose, onPrintSlip }) => {
  if (!returnRecord) return null;

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Return Details" size="lg">
      <div className="space-y-6">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="bg-slate-50 dark:bg-slate-800 p-3 rounded-xl border border-slate-100 dark:border-slate-700">
            <span className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Return Code</span>
            <span className="font-mono font-bold text-slate-900 dark:text-slate-100">{returnRecord.returnCode}</span>
          </div>
          <div className="bg-slate-50 dark:bg-slate-800 p-3 rounded-xl border border-slate-100 dark:border-slate-700">
            <span className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Issue Code</span>
            <span className="font-mono font-bold text-slate-900 dark:text-slate-100">{returnRecord.issueCode || returnRecord.issueId}</span>
          </div>
          <div className="bg-slate-50 dark:bg-slate-800 p-3 rounded-xl border border-slate-100 dark:border-slate-700">
            <span className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Return Date</span>
            <span className="font-semibold text-slate-900 dark:text-slate-100 text-sm">{formatDateTime(returnRecord.returnDate)}</span>
          </div>
          <div className="bg-slate-50 dark:bg-slate-800 p-3 rounded-xl border border-slate-100 dark:border-slate-700">
            <span className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Status</span>
            <StatusBadge status={returnRecord.status || 'Completed'} />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 mb-3 border-b border-slate-200 dark:border-slate-800 pb-2">Item Details</h4>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-slate-500">Asset Name</span>
                <span className="font-semibold text-slate-900 dark:text-slate-100">{returnRecord.itemName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Quantity Returned</span>
                <span className="font-bold text-blue-600 dark:text-blue-400">{returnRecord.quantityReturned}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Condition</span>
                <span className="font-medium text-slate-900 dark:text-slate-100">{returnRecord.conditionOnReturn}</span>
              </div>
            </div>
          </div>
          
          <div>
            <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 mb-3 border-b border-slate-200 dark:border-slate-800 pb-2">Worker & Receiver</h4>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-slate-500">Returned By</span>
                <span className="font-semibold text-slate-900 dark:text-slate-100">{returnRecord.workerName}</span>
              </div>
              {returnRecord.department && (
                <div className="flex justify-between">
                  <span className="text-slate-500">Department</span>
                  <span className="font-medium text-slate-900 dark:text-slate-100">{returnRecord.department}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-slate-500">Received By</span>
                <span className="font-medium text-slate-900 dark:text-slate-100">{returnRecord.receivedBy}</span>
              </div>
            </div>
          </div>
        </div>

        <div>
          <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 mb-2">Remarks / Notes</h4>
          <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-xl text-sm text-slate-700 dark:text-slate-300 min-h-[80px] border border-slate-200 dark:border-slate-700">
            {returnRecord.notes || 'No remarks provided.'}
          </div>
        </div>

        <div className="flex justify-end gap-3 pt-4 border-t border-slate-100 dark:border-slate-800">
          <Button variant="outline" onClick={onClose} icon={<X className="w-4 h-4" />}>Close</Button>
          <Button variant="primary" onClick={() => { onClose(); onPrintSlip(); }} icon={<Printer className="w-4 h-4" />}>Print Return Slip</Button>
        </div>
      </div>
    </Modal>
  );
};
