import React, { useRef } from 'react';
import { ReturnRecord } from '../../../../types';
import { Modal } from '../../../../components/ui/Modal';
import { Button } from '../../../../components/ui/Button';
import { formatDateTime } from '../../../../lib/utils';
import { Printer, CheckCircle, AlertTriangle, QrCode } from 'lucide-react';
import { DEFAULT_COMPANY } from '../../../../constants';

interface Props {
  returnRecord: ReturnRecord;
  isOpen: boolean;
  onClose: () => void;
}

export const ReturnSlipModal: React.FC<Props> = ({ returnRecord, isOpen, onClose }) => {
  const printRef = useRef<HTMLDivElement>(null);

  if (!returnRecord) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Return Slip" size="xl">
      <div className="space-y-6">
        <div className="flex justify-end gap-2 print:hidden mb-4">
          <Button variant="primary" size="sm" icon={<Printer className="w-4 h-4" />} onClick={handlePrint}>
            Print Slip
          </Button>
        </div>

        <div 
          ref={printRef}
          className="bg-white p-8 border border-slate-200 rounded-xl shadow-sm text-slate-900 max-w-3xl mx-auto print:border-none print:shadow-none print:p-0"
        >
          {/* Header */}
          <div className="flex justify-between items-start border-b-2 border-slate-900 pb-6 mb-6">
            <div>
              <h1 className="text-2xl font-black tracking-tight uppercase">{DEFAULT_COMPANY.name}</h1>
              <p className="text-sm font-medium text-slate-500 mt-1">Enterprise Asset Return Slip</p>
            </div>
            <div className="text-right">
              <div className="flex flex-col items-end">
                <QrCode className="w-16 h-16 mb-2 text-slate-800" />
                <p className="text-xs font-mono font-bold">{returnRecord.returnCode}</p>
              </div>
            </div>
          </div>

          {/* Details */}
          <div className="grid grid-cols-2 gap-8 mb-8">
            <div className="space-y-4">
              <div>
                <p className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">Returned By (Worker)</p>
                <p className="text-base font-bold">{returnRecord.workerName}</p>
                <p className="text-xs text-slate-600">ID: {returnRecord.workerId}</p>
                {returnRecord.department && <p className="text-xs text-slate-600">Dept: {returnRecord.department}</p>}
              </div>
              <div>
                <p className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">Related Issue</p>
                <p className="text-sm font-mono font-bold">{returnRecord.issueCode || returnRecord.issueId}</p>
              </div>
            </div>
            
            <div className="space-y-4">
              <div>
                <p className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">Return Date & Time</p>
                <p className="text-sm font-semibold">{formatDateTime(returnRecord.returnDate)}</p>
              </div>
              <div>
                <p className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">Processed By</p>
                <p className="text-sm font-semibold">{returnRecord.receivedBy}</p>
              </div>
            </div>
          </div>

          {/* Items Table */}
          <table className="w-full text-left mb-8 border border-slate-200">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="p-3 text-xs font-bold text-slate-700">Item Details</th>
                <th className="p-3 text-xs font-bold text-slate-700">Qty</th>
                <th className="p-3 text-xs font-bold text-slate-700">Condition</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-slate-100">
                <td className="p-3">
                  <p className="font-bold">{returnRecord.itemName}</p>
                  <p className="text-[10px] font-mono text-slate-500 mt-0.5">{returnRecord.itemId}</p>
                </td>
                <td className="p-3 font-bold">{returnRecord.quantityReturned}</td>
                <td className="p-3">
                  <div className="flex items-center gap-1.5 font-semibold text-sm">
                    {returnRecord.conditionOnReturn === 'Good' ? (
                      <CheckCircle className="w-4 h-4 text-emerald-600" />
                    ) : (
                      <AlertTriangle className="w-4 h-4 text-rose-600" />
                    )}
                    {returnRecord.conditionOnReturn}
                  </div>
                </td>
              </tr>
            </tbody>
          </table>

          {/* Remarks */}
          <div className="mb-12">
            <p className="text-[10px] font-bold uppercase text-slate-400 tracking-wider mb-2">Inspection Remarks</p>
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg text-sm min-h-[60px]">
              {returnRecord.notes || 'None'}
            </div>
          </div>

          {/* Signatures */}
          <div className="grid grid-cols-2 gap-12 pt-16 border-t border-slate-200">
            <div className="text-center">
              <div className="border-b-2 border-slate-900 w-full mb-2"></div>
              <p className="text-xs font-bold">Worker Signature</p>
              <p className="text-[10px] text-slate-500">{returnRecord.workerName}</p>
            </div>
            <div className="text-center">
              <div className="border-b-2 border-slate-900 w-full mb-2"></div>
              <p className="text-xs font-bold">Receiver Signature</p>
              <p className="text-[10px] text-slate-500">{returnRecord.receivedBy}</p>
            </div>
          </div>

          {/* Footer */}
          <div className="text-center mt-12 pt-6 border-t border-slate-100">
            <p className="text-[10px] text-slate-500 font-medium">Generated by {DEFAULT_COMPANY.tagline}</p>
          </div>
        </div>
      </div>
    </Modal>
  );
};
