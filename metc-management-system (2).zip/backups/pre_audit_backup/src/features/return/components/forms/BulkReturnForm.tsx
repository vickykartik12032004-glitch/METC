import React, { useState } from 'react';
import { useAuthStore } from '../../../../store/useAuthStore';
import { processBulkReturn } from '../../services/return.service';
import { Button } from '../../../../components/ui/Button';
import { toast } from 'sonner';

interface Props {
  pendingIssues: any[]; // Extended IssueRecord
  onSubmit: () => void;
  onCancel: () => void;
}

export const BulkReturnForm: React.FC<Props> = ({ pendingIssues, onSubmit, onCancel }) => {
  const { user } = useAuthStore();
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [condition, setCondition] = useState<any>('Good');

  const toggleSelect = (id: string) => {
    setSelectedIds(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  const toggleAll = () => {
    if (selectedIds.length === pendingIssues.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(pendingIssues.map(i => i.id));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedIds.length === 0) return toast.error('Select at least one issue to return');

    try {
      const returnsPayload = selectedIds.map(id => {
        const issue = pendingIssues.find(i => i.id === id);
        return {
          issueId: issue.id,
          issueCode: issue.issueCode,
          itemId: issue.itemId,
          itemName: issue.itemName,
          workerId: issue.workerId,
          workerName: issue.workerName,
          department: issue.department,
          site: issue.site,
          quantityReturned: issue.quantity,
          returnDate: new Date().toISOString(),
          conditionOnReturn: condition,
          notes: 'Bulk return processed',
          receivedBy: user?.name || 'Admin',
          status: 'Completed' as any
        };
      });

      processBulkReturn(returnsPayload);
      toast.success(`Successfully processed ${selectedIds.length} returns`);
      onSubmit();
    } catch (err: any) {
      toast.error(err.message || 'Failed to process bulk returns');
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">Bulk Return Processing</h2>
          <p className="text-xs text-slate-500">Return multiple items at once (assumes full quantity return)</p>
        </div>
        <div className="flex items-center gap-3">
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Set Condition for All:</label>
          <select
            value={condition}
            onChange={(e) => setCondition(e.target.value)}
            className="px-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium focus:outline-none"
          >
            <option value="Good">Good / Undamaged</option>
            <option value="Damaged">Damaged / Broken</option>
            <option value="Lost">Lost / Not Returned</option>
          </select>
        </div>
      </div>

      <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
        <div className="max-h-96 overflow-y-auto">
          <table className="w-full text-left text-xs text-slate-600 dark:text-slate-300">
            <thead className="bg-slate-50 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 sticky top-0">
              <tr>
                <th className="py-2.5 px-3">
                  <input type="checkbox" checked={selectedIds.length === pendingIssues.length && pendingIssues.length > 0} onChange={toggleAll} className="rounded border-slate-300 text-blue-600 focus:ring-blue-500" />
                </th>
                <th className="py-2.5 px-3 font-semibold">Issue Ref</th>
                <th className="py-2.5 px-3 font-semibold">Item</th>
                <th className="py-2.5 px-3 font-semibold">Worker</th>
                <th className="py-2.5 px-3 font-semibold">Qty</th>
              </tr>
            </thead>
            <tbody>
              {pendingIssues.map(i => (
                <tr key={i.id} className="border-b border-slate-100 dark:border-slate-800/50 hover:bg-slate-50 dark:hover:bg-slate-800/30">
                  <td className="py-2.5 px-3">
                    <input type="checkbox" checked={selectedIds.includes(i.id)} onChange={() => toggleSelect(i.id)} className="rounded border-slate-300 text-blue-600 focus:ring-blue-500" />
                  </td>
                  <td className="py-2.5 px-3 font-medium text-slate-900 dark:text-slate-100">{i.issueCode}</td>
                  <td className="py-2.5 px-3">{i.itemName}</td>
                  <td className="py-2.5 px-3">{i.workerName}</td>
                  <td className="py-2.5 px-3 font-semibold">{i.quantity}</td>
                </tr>
              ))}
              {pendingIssues.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-slate-500">No pending issues available for return.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <div className="flex justify-between items-center pt-4">
        <span className="text-xs font-semibold text-slate-500">{selectedIds.length} items selected</span>
        <div className="flex gap-3">
          <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
          <Button type="button" variant="primary" onClick={handleSubmit} disabled={selectedIds.length === 0}>
            Process {selectedIds.length} Returns
          </Button>
        </div>
      </div>
    </div>
  );
};
