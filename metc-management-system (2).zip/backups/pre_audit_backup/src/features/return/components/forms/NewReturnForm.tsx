import React, { useState } from 'react';
import { useAuthStore } from '../../../../store/useAuthStore';
import { processReturn } from '../../services/return.service';
import { Button } from '../../../../components/ui/Button';
import { toast } from 'sonner';

interface Props {
  pendingIssues: any[]; // Extended IssueRecord
  onSubmit: () => void;
  onCancel: () => void;
  initialIssueId?: string;
}

export const NewReturnForm: React.FC<Props> = ({ pendingIssues, onSubmit, onCancel, initialIssueId }) => {
  const { user } = useAuthStore();
  
  const [selectedIssueId, setSelectedIssueId] = useState<string>(initialIssueId || '');
  const [quantity, setQuantity] = useState<number>(1);
  const [condition, setCondition] = useState<any>('Good');
  const [notes, setNotes] = useState('');

  const selectedIssue = pendingIssues.find(i => i.id === selectedIssueId);

  // Auto-update max qty if selected issue changes
  React.useEffect(() => {
    if (selectedIssue) {
      setQuantity(selectedIssue.quantity);
    }
  }, [selectedIssueId]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedIssue) return toast.error('Please select an issue to return');
    if (quantity > selectedIssue.quantity) return toast.error('Cannot return more than issued');
    if (quantity < 1) return toast.error('Quantity must be at least 1');

    try {
      processReturn({
        issueId: selectedIssue.id,
        issueCode: selectedIssue.issueCode,
        itemId: selectedIssue.itemId,
        itemName: selectedIssue.itemName,
        workerId: selectedIssue.workerId,
        workerName: selectedIssue.workerName,
        department: selectedIssue.department,
        site: selectedIssue.site,
        quantityReturned: quantity,
        returnDate: new Date().toISOString(),
        conditionOnReturn: condition,
        notes: notes,
        receivedBy: user?.name || 'Admin',
        status: 'Completed'
      });
      toast.success('Return processed successfully');
      onSubmit();
    } catch (err: any) {
      toast.error(err.message || 'Failed to process return');
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm max-w-3xl mx-auto">
      <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100 mb-4">Process Item Return</h2>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Select Pending Issue</label>
          <select
            value={selectedIssueId}
            onChange={(e) => setSelectedIssueId(e.target.value)}
            className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            required
          >
            <option value="">-- Search & Select Issue --</option>
            {pendingIssues.map(i => (
              <option key={i.id} value={i.id}>
                {i.issueCode} - {i.itemName} ({i.quantity} {i.quantity > 1 ? 'units' : 'unit'}) - Issued to {i.workerName}
              </option>
            ))}
          </select>
        </div>

        {selectedIssue && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-100 dark:border-slate-800">
            <div>
              <p className="text-[10px] uppercase font-bold text-slate-500 mb-1">Item Details</p>
              <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">{selectedIssue.itemName}</p>
              <p className="text-xs text-slate-600 dark:text-slate-400">Category: {selectedIssue.itemCategory}</p>
              <p className="text-xs text-slate-600 dark:text-slate-400">Total Issued: {selectedIssue.quantity}</p>
            </div>
            <div>
              <p className="text-[10px] uppercase font-bold text-slate-500 mb-1">Worker Details</p>
              <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">{selectedIssue.workerName}</p>
              <p className="text-xs text-slate-600 dark:text-slate-400">Dept: {selectedIssue.department}</p>
              <p className="text-xs text-slate-600 dark:text-slate-400">Site: {selectedIssue.site}</p>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Quantity Returned</label>
            <input
              type="number"
              min={1}
              max={selectedIssue?.quantity || 1}
              value={quantity}
              onChange={(e) => setQuantity(parseInt(e.target.value) || 1)}
              className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              required
              disabled={!selectedIssue}
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Return Condition</label>
            <select
              value={condition}
              onChange={(e) => setCondition(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              required
              disabled={!selectedIssue}
            >
              <option value="Good">Good / Undamaged</option>
              <option value="Partial Return">Partial Return (Good)</option>
              <option value="Damaged">Damaged / Broken</option>
              <option value="Repair Required">Repair Required</option>
              <option value="Missing Accessories">Missing Accessories</option>
              <option value="Lost">Lost / Not Returned</option>
              <option value="Disposed">Disposed / Scrap</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Remarks & Inspection Notes</label>
          <textarea
            rows={3}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl resize-none font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            placeholder="Enter condition details, damage descriptions, or general notes..."
            disabled={!selectedIssue}
          />
        </div>

        <div className="flex justify-end gap-3 pt-4 border-t border-slate-100 dark:border-slate-800">
          <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
          <Button type="submit" variant="primary" disabled={!selectedIssue}>Process Return</Button>
        </div>
      </form>
    </div>
  );
};
