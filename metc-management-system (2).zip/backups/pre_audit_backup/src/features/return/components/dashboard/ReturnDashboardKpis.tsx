import React from 'react';
import { 
  CalendarCheck, 
  Clock, 
  AlertTriangle, 
  CheckCircle, 
  XOctagon, 
  Wrench, 
  AlertOctagon 
} from 'lucide-react';

interface ReturnKPIs {
  todayReturns: number;
  pendingReturns: number;
  overdueReturns: number;
  goodCondition: number;
  damaged: number;
  repairRequired: number;
  lostItems: number;
}

interface Props {
  kpis: ReturnKPIs;
  onFilterStatus?: (status: string) => void;
}

export const ReturnDashboardKpis: React.FC<Props> = ({ kpis, onFilterStatus }) => {
  const cards = [
    {
      title: "Today's Returns",
      value: kpis.todayReturns,
      sub: 'Items returned today',
      icon: CalendarCheck,
      color: 'text-blue-600 dark:text-blue-400',
      bg: 'bg-blue-50 dark:bg-blue-950/40 border-blue-200 dark:border-blue-900',
    },
    {
      title: 'Pending Returns',
      value: kpis.pendingReturns,
      sub: 'Issued items not yet returned',
      icon: Clock,
      color: 'text-emerald-600 dark:text-emerald-400',
      bg: 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-900',
    },
    {
      title: 'Overdue Returns',
      value: kpis.overdueReturns,
      sub: 'Passed expected return date',
      icon: AlertTriangle,
      color: 'text-amber-600 dark:text-amber-400',
      bg: 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-900',
    },
    {
      title: 'Returned Good',
      value: kpis.goodCondition,
      sub: 'In good condition',
      icon: CheckCircle,
      color: 'text-indigo-600 dark:text-indigo-400',
      bg: 'bg-indigo-50 dark:bg-indigo-950/40 border-indigo-200 dark:border-indigo-900',
    },
    {
      title: 'Returned Damaged',
      value: kpis.damaged,
      sub: 'Damaged upon return',
      icon: XOctagon,
      color: 'text-rose-600 dark:text-rose-400',
      bg: 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-900',
    },
    {
      title: 'Sent for Repair',
      value: kpis.repairRequired,
      sub: 'Needs repair before reuse',
      icon: Wrench,
      color: 'text-cyan-600 dark:text-cyan-400',
      bg: 'bg-cyan-50 dark:bg-cyan-950/40 border-cyan-200 dark:border-cyan-900',
    },
    {
      title: 'Lost Items',
      value: kpis.lostItems,
      sub: 'Reported missing',
      icon: AlertOctagon,
      color: 'text-purple-600 dark:text-purple-400',
      bg: 'bg-purple-50 dark:bg-purple-950/40 border-purple-200 dark:border-purple-900',
    },
  ];

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-3">
      {cards.map((card, idx) => {
        const Icon = card.icon;
        return (
          <div
            key={idx}
            className={`p-3.5 rounded-2xl border ${card.bg} transition-all hover:scale-[1.02] shadow-xs flex flex-col justify-between`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-bold text-slate-600 dark:text-slate-300 truncate">
                {card.title}
              </span>
              <Icon className={`w-4 h-4 ${card.color} shrink-0`} />
            </div>
            <div>
              <div className={`text-2xl font-black ${card.color}`}>{card.value}</div>
              <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5 truncate">
                {card.sub}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};
