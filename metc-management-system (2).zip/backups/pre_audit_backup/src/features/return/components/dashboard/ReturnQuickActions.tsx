import React from 'react';
import { RotateCcw, QrCode, ScanBarcode, FileBarChart2 } from 'lucide-react';

interface Props {
  onAction: (action: 'return' | 'qr' | 'barcode' | 'reports') => void;
}

export const ReturnQuickActions: React.FC<Props> = ({ onAction }) => {
  const actions = [
    {
      label: 'Return Item',
      description: 'Process a new return',
      icon: RotateCcw,
      action: 'return' as const,
      color: 'bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400',
    },
    {
      label: 'Scan QR',
      description: 'Return by QR code',
      icon: QrCode,
      action: 'qr' as const,
      color: 'bg-blue-50 text-blue-600 dark:bg-blue-950/40 dark:text-blue-400',
    },
    {
      label: 'Scan Barcode',
      description: 'Scan item barcode',
      icon: ScanBarcode,
      action: 'barcode' as const,
      color: 'bg-indigo-50 text-indigo-600 dark:bg-indigo-950/40 dark:text-indigo-400',
    },
    {
      label: 'View Reports',
      description: 'Return summaries',
      icon: FileBarChart2,
      action: 'reports' as const,
      color: 'bg-purple-50 text-purple-600 dark:bg-purple-950/40 dark:text-purple-400',
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
      {actions.map((action, idx) => {
        const Icon = action.icon;
        return (
          <button
            key={idx}
            onClick={() => onAction(action.action)}
            className="flex items-center gap-3 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800/80 transition-all text-left shadow-xs group"
          >
            <div className={`p-2.5 rounded-xl ${action.color} group-hover:scale-110 transition-transform`}>
              <Icon className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-900 dark:text-slate-100">{action.label}</div>
              <div className="text-[10px] text-slate-500 dark:text-slate-400">{action.description}</div>
            </div>
          </button>
        );
      })}
    </div>
  );
};
