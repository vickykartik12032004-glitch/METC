import React from 'react';
import { ReturnRecord } from '../../../../types';
import { formatDateTime } from '../../../../lib/utils';
import { StatusBadge } from '../../../../components/common/StatusBadge';
import { SearchBox } from '../../../../components/ui/SearchBox';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '../../../../components/ui/Table';
import { Button } from '../../../../components/ui/Button';
import { Printer, Eye, CheckCircle, AlertTriangle, Wrench, AlertOctagon } from 'lucide-react';

interface Props {
  returns: ReturnRecord[];
  filters: any;
  setFilters: (f: any) => void;
  onViewDetails: (r: ReturnRecord) => void;
  onPrintSlip: (r: ReturnRecord) => void;
}

export const ReturnHistoryTable: React.FC<Props> = ({ returns, filters, setFilters, onViewDetails, onPrintSlip }) => {
  const getConditionIcon = (condition: string) => {
    switch (condition) {
      case 'Good': return <CheckCircle className="w-4 h-4 text-emerald-500" />;
      case 'Damaged': return <AlertTriangle className="w-4 h-4 text-rose-500" />;
      case 'Repair Required':
      case 'Needs Repair': return <Wrench className="w-4 h-4 text-cyan-500" />;
      case 'Lost': return <AlertOctagon className="w-4 h-4 text-purple-500" />;
      default: return null;
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800">
        <div className="flex-1 w-full">
          <SearchBox
            value={filters.search}
            onChange={(val) => setFilters({ ...filters, search: val })}
            placeholder="Search return code, item, worker..."
          />
        </div>
        <div className="flex gap-2">
          <select
            value={filters.condition}
            onChange={(e) => setFilters({ ...filters, condition: e.target.value })}
            className="px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
          >
            <option value="All">All Conditions</option>
            <option value="Good">Good</option>
            <option value="Damaged">Damaged</option>
            <option value="Repair Required">Repair Required</option>
            <option value="Lost">Lost</option>
            <option value="Disposed">Disposed</option>
          </select>
        </div>
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Return Ref</TableHead>
            <TableHead>Item</TableHead>
            <TableHead>Worker</TableHead>
            <TableHead>Qty</TableHead>
            <TableHead>Condition</TableHead>
            <TableHead>Date</TableHead>
            <TableHead>Receiver</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {returns.length === 0 ? (
            <TableRow>
              <TableCell colSpan={8} className="text-center py-8 text-slate-500">
                No return records found matching criteria
              </TableCell>
            </TableRow>
          ) : (
            returns.map((r) => (
              <TableRow key={r.id}>
                <TableCell>
                  <div className="font-bold text-slate-900 dark:text-slate-100">{r.returnCode}</div>
                  <div className="text-[10px] text-slate-500 font-mono">{r.issueCode || r.issueId}</div>
                </TableCell>
                <TableCell>
                  <div className="font-semibold text-slate-800 dark:text-slate-200">{r.itemName}</div>
                </TableCell>
                <TableCell>
                  <div className="font-medium text-slate-800 dark:text-slate-200">{r.workerName}</div>
                </TableCell>
                <TableCell>
                  <strong className="text-blue-600 dark:text-blue-400">{r.quantityReturned}</strong>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-1.5 font-medium text-xs">
                    {getConditionIcon(r.conditionOnReturn)}
                    <span>{r.conditionOnReturn}</span>
                  </div>
                </TableCell>
                <TableCell className="text-xs text-slate-600 dark:text-slate-400">
                  {formatDateTime(r.returnDate)}
                </TableCell>
                <TableCell className="text-xs text-slate-600 dark:text-slate-400">
                  {r.receivedBy}
                </TableCell>
                <TableCell className="text-right space-x-1">
                  <Button variant="outline" size="xs" onClick={() => onViewDetails(r)} icon={<Eye className="w-3.5 h-3.5" />}>View</Button>
                  <Button variant="outline" size="xs" onClick={() => onPrintSlip(r)} icon={<Printer className="w-3.5 h-3.5 text-blue-500" />}>Slip</Button>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
};
