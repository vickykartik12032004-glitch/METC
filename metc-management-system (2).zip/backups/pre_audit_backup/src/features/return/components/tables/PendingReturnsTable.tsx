import React, { useState } from 'react';
import { IssueRecord } from '../../../../types';
import { formatDateTime } from '../../../../lib/utils';
import { StatusBadge } from '../../../../components/common/StatusBadge';
import { SearchBox } from '../../../../components/ui/SearchBox';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '../../../../components/ui/Table';
import { Button } from '../../../../components/ui/Button';
import { RotateCcw, User, Calendar, Package, LayoutGrid, List } from 'lucide-react';

interface Props {
  pendingIssues: any[]; // Extended IssueRecord with department/site
  onProcessReturn: (issue: any) => void;
}

export const PendingReturnsTable: React.FC<Props> = ({ pendingIssues, onProcessReturn }) => {
  const [search, setSearch] = useState('');
  const [viewMode, setViewMode] = useState<'cards' | 'table' | 'auto'>('auto');

  const filtered = pendingIssues.filter(i => 
    (i.issueCode && i.issueCode.toLowerCase().includes(search.toLowerCase())) ||
    (i.itemName && i.itemName.toLowerCase().includes(search.toLowerCase())) ||
    (i.workerName && i.workerName.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="flex-1 w-full max-w-md">
          <SearchBox
            value={search}
            onChange={setSearch}
            placeholder="Search by worker, item or ref code..."
          />
        </div>

        <div className="flex items-center justify-between w-full sm:w-auto gap-3">
          <span className="text-xs text-slate-500 font-medium">
            {filtered.length} pending return{filtered.length !== 1 ? 's' : ''}
          </span>

          <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-0.5 rounded-lg border border-slate-200 dark:border-slate-700">
            <button
              type="button"
              onClick={() => setViewMode('cards')}
              title="Card View"
              className={`p-1.5 rounded-md text-xs font-medium transition-all ${
                viewMode === 'cards' || viewMode === 'auto'
                  ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-2xs'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setViewMode('table')}
              title="Table Spreadsheet View"
              className={`p-1.5 rounded-md text-xs font-medium transition-all ${
                viewMode === 'table'
                  ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-2xs'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* MOBILE RESPONSIVE CARDS VIEW */}
      <div className={`${viewMode === 'table' ? 'hidden' : viewMode === 'cards' ? 'grid' : 'grid md:hidden'} grid-cols-1 sm:grid-cols-2 gap-3`}>
        {filtered.length === 0 ? (
          <div className="col-span-full p-12 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
            <Package className="w-12 h-12 text-slate-300 dark:text-slate-700 mx-auto mb-3" />
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">No Pending Returns</h3>
            <p className="text-xs text-slate-500 mt-1">No outstanding items matching your search filter.</p>
          </div>
        ) : (
          filtered.map((i) => (
            <div
              key={i.id}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs space-y-3 hover:border-slate-300 dark:hover:border-slate-700 transition-all"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <span className="font-mono font-bold text-sm text-blue-600 dark:text-blue-400 block">
                    {i.issueCode}
                  </span>
                  <span className="text-[10px] text-slate-400">
                    Issued: {formatDateTime(i.issueDate)}
                  </span>
                </div>
                <StatusBadge status={i.status} />
              </div>

              <div className="bg-slate-50 dark:bg-slate-800/50 p-3 rounded-xl space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 font-bold text-slate-900 dark:text-slate-100">
                    <User className="w-3.5 h-3.5 text-blue-500" />
                    <span>{i.workerName}</span>
                  </div>
                  <span className="text-[10px] text-slate-500">{i.department || i.site}</span>
                </div>

                <div className="flex items-center justify-between pt-1 border-t border-slate-200/60 dark:border-slate-700/60">
                  <div className="min-w-0 pr-2">
                    <div className="font-bold text-slate-800 dark:text-slate-200 truncate">{i.itemName}</div>
                    <div className="text-[10px] text-slate-400">{i.itemCategory}</div>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 font-extrabold text-xs shrink-0">
                    Qty: {i.quantity}
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800">
                <div className="text-[11px] text-slate-500 flex items-center gap-1">
                  <Calendar className="w-3 h-3 text-slate-400" />
                  <span>Due: {i.expectedReturnDate ? formatDateTime(i.expectedReturnDate) : 'Open-ended'}</span>
                </div>

                <Button
                  variant="primary"
                  size="sm"
                  onClick={() => onProcessReturn(i)}
                  icon={<RotateCcw className="w-3.5 h-3.5" />}
                  className="font-bold"
                >
                  Return Item
                </Button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* DESKTOP SPREADSHEET TABLE VIEW */}
      <div className={`${viewMode === 'cards' ? 'hidden' : viewMode === 'table' ? 'block' : 'hidden md:block'} bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs`}>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Issue Ref</TableHead>
              <TableHead>Item</TableHead>
              <TableHead>Worker</TableHead>
              <TableHead>Qty</TableHead>
              <TableHead>Issue Date</TableHead>
              <TableHead>Due Date</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-8 text-slate-500">
                  No pending returns found.
                </TableCell>
              </TableRow>
            ) : (
              filtered.map((i) => (
                <TableRow key={i.id}>
                  <TableCell>
                    <div className="font-bold text-slate-900 dark:text-slate-100">{i.issueCode}</div>
                  </TableCell>
                  <TableCell>
                    <div className="font-semibold text-slate-800 dark:text-slate-200">{i.itemName}</div>
                    <div className="text-[10px] text-slate-500">{i.itemCategory}</div>
                  </TableCell>
                  <TableCell>
                    <div className="font-medium text-slate-800 dark:text-slate-200">{i.workerName}</div>
                    <div className="text-[10px] text-slate-500">{i.department} • {i.site}</div>
                  </TableCell>
                  <TableCell>
                    <strong className="text-blue-600 dark:text-blue-400">{i.quantity}</strong>
                  </TableCell>
                  <TableCell className="text-xs text-slate-600 dark:text-slate-400">
                    {formatDateTime(i.issueDate)}
                  </TableCell>
                  <TableCell className="text-xs text-slate-600 dark:text-slate-400">
                    {i.expectedReturnDate ? formatDateTime(i.expectedReturnDate) : 'Open-ended'}
                  </TableCell>
                  <TableCell>
                    <StatusBadge status={i.status} />
                  </TableCell>
                  <TableCell className="text-right space-x-1">
                    <Button variant="primary" size="xs" onClick={() => onProcessReturn(i)} icon={<RotateCcw className="w-3.5 h-3.5" />}>
                      Return
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};
