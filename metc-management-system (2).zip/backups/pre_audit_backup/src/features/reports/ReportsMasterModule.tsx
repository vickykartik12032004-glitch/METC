import React, { useState } from 'react';
import { 
  BarChart2, 
  PieChart, 
  TrendingUp, 
  Package, 
  Users, 
  ArrowRightLeft,
  ArrowDownLeft,
  ArrowUpRight,
  Wrench,
  AlertTriangle,
  Building,
  MapPin,
  ClipboardList,
  Clock,
  Briefcase,
  FileText
} from 'lucide-react';
import { ExecutiveDashboard } from './components/dashboard/ExecutiveDashboard';
import { AnalyticsCharts } from './components/charts/AnalyticsCharts';
import { GenericReportTable } from './components/tables/GenericReportTable';
import { ScheduledReports } from './components/dashboard/ScheduledReports';

export type ReportTabType = 
  | 'dashboard'
  | 'analytics'
  | 'inventory'
  | 'workers'
  | 'issues'
  | 'returns'
  | 'transfers'
  | 'repairs'
  | 'lost'
  | 'suppliers'
  | 'departments'
  | 'sites'
  | 'audit'
  | 'scheduled';

export const ReportsMasterModule: React.FC = () => {
  const [activeTab, setActiveTab] = useState<ReportTabType>('dashboard');

  const tabs = [
    { id: 'dashboard', label: 'Executive Dashboard', icon: BarChart2 },
    { id: 'analytics', label: 'Analytics', icon: PieChart },
    { id: 'inventory', label: 'Inventory', icon: Package },
    { id: 'workers', label: 'Workers', icon: Users },
    { id: 'issues', label: 'Issues', icon: ArrowUpRight },
    { id: 'returns', label: 'Returns', icon: ArrowDownLeft },
    { id: 'transfers', label: 'Transfers', icon: ArrowRightLeft },
    { id: 'repairs', label: 'Repairs', icon: Wrench },
    { id: 'lost', label: 'Lost Assets', icon: AlertTriangle },
    { id: 'suppliers', label: 'Suppliers', icon: Briefcase },
    { id: 'departments', label: 'Departments', icon: Building },
    { id: 'sites', label: 'Sites', icon: MapPin },
    { id: 'audit', label: 'Audit Logs', icon: ClipboardList },
    { id: 'scheduled', label: 'Scheduled', icon: Clock },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <ExecutiveDashboard onNavigate={(tab) => setActiveTab(tab as ReportTabType)} />;
      case 'analytics':
        return <AnalyticsCharts />;
      case 'scheduled':
        return <ScheduledReports />;
      default:
        return <GenericReportTable reportType={activeTab} />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm flex flex-col gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100 tracking-tight">Enterprise BI & Analytics</h1>
          <p className="text-xs text-slate-500 mt-1">Real-time reports, charts, and executive dashboards for MOUNTEC PTE LTD</p>
        </div>

        <div className="flex items-center gap-1 overflow-x-auto pb-1 scrollbar-hide">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id as ReportTabType)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                activeTab === t.id
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              <t.icon className="w-4 h-4" />
              {t.label}
            </button>
          ))}
        </div>
      </div>
      {renderContent()}
    </div>
  );
};
