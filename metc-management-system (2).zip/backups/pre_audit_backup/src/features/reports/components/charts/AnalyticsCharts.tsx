import React from 'react';
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid, 
  BarChart, 
  Bar,
  PieChart,
  Pie,
  Cell,
  Legend
} from 'recharts';

export const AnalyticsCharts: React.FC = () => {
  const data = [
    { name: 'Jan', val1: 400, val2: 240 },
    { name: 'Feb', val1: 300, val2: 139 },
    { name: 'Mar', val1: 200, val2: 980 },
    { name: 'Apr', val1: 278, val2: 390 },
    { name: 'May', val1: 189, val2: 480 },
    { name: 'Jun', val1: 239, val2: 380 },
    { name: 'Jul', val1: 349, val2: 430 },
  ];

  const pieData = [
    { name: 'Heavy Equipment', value: 400 },
    { name: 'Power Tools', value: 300 },
    { name: 'Hand Tools', value: 300 },
    { name: 'Vehicles', value: 200 },
  ];

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6'];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
           <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 mb-6">Asset Category Distribution</h3>
           <div className="h-72">
             <ResponsiveContainer width="100%" height="100%">
               <PieChart>
                 <Pie
                   data={pieData}
                   cx="50%"
                   cy="50%"
                   innerRadius={60}
                   outerRadius={100}
                   fill="#8884d8"
                   paddingAngle={5}
                   dataKey="value"
                 >
                   {pieData.map((entry, index) => (
                     <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                   ))}
                 </Pie>
                 <Tooltip />
                 <Legend />
               </PieChart>
             </ResponsiveContainer>
           </div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
           <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 mb-6">Stock Movement Trend</h3>
           <div className="h-72">
             <ResponsiveContainer width="100%" height="100%">
               <BarChart data={data}>
                 <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
                 <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
                 <CartesianGrid vertical={false} strokeDasharray="3 3" opacity={0.5} />
                 <Tooltip cursor={{ fill: 'transparent' }} />
                 <Bar dataKey="val1" fill="#3b82f6" radius={[4, 4, 0, 0]} name="Inward" />
                 <Bar dataKey="val2" fill="#10b981" radius={[4, 4, 0, 0]} name="Outward" />
               </BarChart>
             </ResponsiveContainer>
           </div>
        </div>
      </div>
    </div>
  );
};
