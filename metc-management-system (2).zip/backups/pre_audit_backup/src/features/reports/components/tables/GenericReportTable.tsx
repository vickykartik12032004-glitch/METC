import React, { useMemo, useState } from 'react';
import { useAssetStore } from '../../../../store/useAssetStore';
import { useTransactionStore } from '../../../../store/useTransactionStore';
import { useWorkerStore } from '../../../../store/useWorkerStore';
import { useMaintenanceStore } from '../../../../store/useMaintenanceStore';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '../../../../components/ui/Table';
import { Button } from '../../../../components/ui/Button';
import { Download, FileText, Search, FileSpreadsheet } from 'lucide-react';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import * as XLSX from 'xlsx';
import { formatDateTime, formatCurrency } from '../../../../lib/utils';
import { DEFAULT_COMPANY } from '../../../../constants';

interface Props {
  reportType: string;
}

export const GenericReportTable: React.FC<Props> = ({ reportType }) => {
  const { getAllAssets } = useAssetStore();
  const { issues, returns, transfers, repairs, lostItems, activities } = useTransactionStore();
  const { workers } = useWorkerStore();
  const { maintenances, disposals, vendors } = useMaintenanceStore();

  const [searchTerm, setSearchTerm] = useState('');

  const { data, columns, title } = useMemo(() => {
    let rawData: any[] = [];
    let cols: { header: string; key: string; format?: (val: any) => string }[] = [];
    let reportTitle = '';

    switch (reportType) {
      case 'inventory':
        rawData = getAllAssets();
        cols = [
          { header: 'Code', key: 'code' },
          { header: 'Name', key: 'name' },
          { header: 'Category', key: 'category' },
          { header: 'Status', key: 'status' },
          { header: 'Quantity', key: 'quantity' },
          { header: 'Unit Price', key: 'unitPrice', format: (v) => formatCurrency(v) },
        ];
        reportTitle = 'Master Inventory Valuation';
        break;
      case 'workers':
        rawData = workers;
        cols = [
          { header: 'ID', key: 'workerId' },
          { header: 'Name', key: 'name' },
          { header: 'Role', key: 'role' },
          { header: 'Department', key: 'department' },
          { header: 'Status', key: 'status' },
        ];
        reportTitle = 'Worker Register';
        break;
      case 'issues':
        rawData = issues;
        cols = [
          { header: 'Code', key: 'issueCode' },
          { header: 'Item Name', key: 'itemName' },
          { header: 'Worker', key: 'workerName' },
          { header: 'Date', key: 'issueDate', format: formatDateTime },
          { header: 'Status', key: 'status' },
        ];
        reportTitle = 'Asset Issues Report';
        break;
      case 'returns':
        rawData = returns;
        cols = [
          { header: 'Code', key: 'returnCode' },
          { header: 'Item Name', key: 'itemName' },
          { header: 'Worker', key: 'workerName' },
          { header: 'Date', key: 'returnDate', format: formatDateTime },
          { header: 'Condition', key: 'condition' },
        ];
        reportTitle = 'Asset Returns Report';
        break;
      case 'transfers':
        rawData = transfers;
        cols = [
          { header: 'Code', key: 'transferCode' },
          { header: 'Item Name', key: 'itemName' },
          { header: 'From', key: 'fromWorkerName' },
          { header: 'To', key: 'toWorkerName' },
          { header: 'Date', key: 'transferDate', format: formatDateTime },
          { header: 'Status', key: 'status' },
        ];
        reportTitle = 'Asset Transfers Report';
        break;
      case 'repairs':
        rawData = repairs;
        cols = [
          { header: 'Code', key: 'repairCode' },
          { header: 'Item Name', key: 'itemName' },
          { header: 'Vendor', key: 'repairVendor' },
          { header: 'Date Sent', key: 'sentDate', format: formatDateTime },
          { header: 'Status', key: 'status' },
          { header: 'Cost', key: 'repairCost', format: (v) => formatCurrency(v || 0) },
        ];
        reportTitle = 'Repairs Report';
        break;
      case 'lost':
        rawData = lostItems;
        cols = [
          { header: 'Code', key: 'lostCode' },
          { header: 'Item Name', key: 'itemName' },
          { header: 'Worker', key: 'workerName' },
          { header: 'Date', key: 'reportedDate', format: formatDateTime },
          { header: 'Status', key: 'status' },
          { header: 'Value', key: 'estimatedValue', format: (v) => formatCurrency(v || 0) },
        ];
        reportTitle = 'Lost Assets Report';
        break;
      case 'suppliers':
        rawData = vendors;
        cols = [
          { header: 'Name', key: 'vendorName' },
          { header: 'Contact', key: 'phone' },
          { header: 'Email', key: 'email' },
          { header: 'Status', key: 'status' },
          { header: 'Rating', key: 'rating' },
        ];
        reportTitle = 'Supplier Performance';
        break;
      case 'departments':
        // Generate pseudo department data based on workers
        const depts = Array.from(new Set(workers.map(w => w.trade)));
        rawData = depts.map(d => ({
          department: d,
          workerCount: workers.filter(w => w.trade === d).length,
          status: 'Active'
        }));
        cols = [
          { header: 'Department', key: 'department' },
          { header: 'Total Workers', key: 'workerCount' },
          { header: 'Status', key: 'status' },
        ];
        reportTitle = 'Department Summary';
        break;
      case 'sites':
        // Generate pseudo site data
        const sites = Array.from(new Set(workers.map(w => w.projectSite)));
        rawData = sites.map(s => ({
          site: s,
          workerCount: workers.filter(w => w.projectSite === s).length,
          status: 'Active'
        }));
        cols = [
          { header: 'Project Site', key: 'site' },
          { header: 'Active Workers', key: 'workerCount' },
          { header: 'Status', key: 'status' },
        ];
        reportTitle = 'Site Reports';
        break;
      case 'audit':
        rawData = activities;
        cols = [
          { header: 'Timestamp', key: 'timestamp', format: formatDateTime },
          { header: 'User', key: 'user' },
          { header: 'Action', key: 'action' },
          { header: 'Module', key: 'targetType' },
          { header: 'Details', key: 'details' },
        ];
        reportTitle = 'System Audit Logs';
        break;
      default:
        rawData = [];
        cols = [];
        reportTitle = 'Report';
    }

    return { data: rawData, columns: cols, title: reportTitle };
  }, [reportType, getAllAssets, issues, returns, transfers, repairs, lostItems, workers, vendors, activities]);

  const filteredData = useMemo(() => {
    if (!searchTerm) return data;
    const lower = searchTerm.toLowerCase();
    return data.filter(item => 
      columns.some(c => {
        const val = item[c.key];
        return val && String(val).toLowerCase().includes(lower);
      })
    );
  }, [data, searchTerm, columns]);

  const exportPDF = () => {
    const doc = new jsPDF();
    
    // Header
    doc.setFontSize(18);
    doc.text(`${DEFAULT_COMPANY.name} - ${title}`, 14, 22);
    doc.setFontSize(11);
    doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 14, 30);
    
    const tableCols = columns.map(c => c.header);
    const tableRows = filteredData.map(item => 
      columns.map(c => c.format ? c.format(item[c.key]) : item[c.key] || '-')
    );

    (doc as any).autoTable({
      startY: 40,
      head: [tableCols],
      body: tableRows,
      theme: 'grid',
      headStyles: { fillColor: [41, 128, 185] },
    });

    const pageCount = (doc as any).internal.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i);
      doc.setFontSize(8);
      doc.text(`Page ${i} of ${pageCount} - ${DEFAULT_COMPANY.name}`, 14, doc.internal.pageSize.height - 10);
    }

    doc.save(`${title.replace(/\s+/g, '_')}.pdf`);
  };

  const exportExcel = () => {
    const exportData = filteredData.map(item => {
      const row: any = {};
      columns.forEach(c => {
        row[c.header] = c.format ? c.format(item[c.key]) : item[c.key];
      });
      return row;
    });

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Report");
    XLSX.writeFile(wb, `${title.replace(/\s+/g, '_')}.xlsx`);
  };

  const exportCSV = () => {
    const exportData = filteredData.map(item => {
      const row: any = {};
      columns.forEach(c => {
        row[c.header] = c.format ? c.format(item[c.key]) : item[c.key];
      });
      return row;
    });
    
    const ws = XLSX.utils.json_to_sheet(exportData);
    const csv = XLSX.utils.sheet_to_csv(ws);
    
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `${title.replace(/\s+/g, '_')}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden flex flex-col min-h-[500px]">
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4">
        <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">{title}</h2>
        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="relative flex-1 md:w-64">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search report..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            />
          </div>
          <Button variant="outline" size="sm" icon={<FileText className="w-4 h-4 text-blue-600" />} onClick={exportPDF}>PDF</Button>
          <Button variant="outline" size="sm" icon={<FileSpreadsheet className="w-4 h-4 text-emerald-600" />} onClick={exportExcel}>Excel</Button>
          <Button variant="outline" size="sm" icon={<Download className="w-4 h-4 text-slate-600" />} onClick={exportCSV}>CSV</Button>
        </div>
      </div>
      
      <div className="flex-1 overflow-auto">
        <Table>
          <TableHeader>
            <TableRow>
              {columns.map(c => (
                <TableHead key={c.key}>{c.header}</TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredData.length === 0 && (
              <TableRow>
                <TableCell colSpan={columns.length} className="text-center py-8 text-slate-500">
                  No data available for this report.
                </TableCell>
              </TableRow>
            )}
            {filteredData.map((row, i) => (
              <TableRow key={i}>
                {columns.map(c => (
                  <TableCell key={c.key}>
                    {c.format ? c.format(row[c.key]) : (row[c.key] || '-')}
                  </TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};
