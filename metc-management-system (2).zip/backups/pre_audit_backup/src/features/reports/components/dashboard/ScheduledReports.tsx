import React, { useState } from 'react';
import { 
  Clock, 
  Plus,
  Mail,
  MoreVertical,
  CheckCircle,
  ToggleRight,
  ToggleLeft
} from 'lucide-react';
import { Button } from '../../../../components/ui/Button';

export const ScheduledReports: React.FC = () => {
  const [reports, setReports] = useState([
    { id: 1, name: 'Weekly Executive Summary', type: 'Executive Dashboard', frequency: 'Weekly (Mon)', recipients: 'management@mountec.com', active: true, nextRun: '2026-08-02' },
    { id: 2, name: 'Daily Inventory Valuation', type: 'Inventory', frequency: 'Daily', recipients: 'finance@mountec.com', active: true, nextRun: '2026-07-30' },
    { id: 3, name: 'Monthly Repair Costs', type: 'Repairs', frequency: 'Monthly (1st)', recipients: 'maintenance@mountec.com', active: false, nextRun: '2026-08-01' },
  ]);

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-6">
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">Scheduled Reports</h2>
            <p className="text-sm text-slate-500">Automatically generate and email reports to stakeholders.</p>
          </div>
          <Button variant="primary" icon={<Plus className="w-4 h-4" />}>Schedule New Report</Button>
        </div>

        <div className="space-y-4">
          {reports.map(report => (
            <div key={report.id} className="flex flex-col md:flex-row md:items-center justify-between p-4 border border-slate-200 dark:border-slate-800 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800/50 transition">
              <div className="flex items-start gap-4">
                <div className={`p-3 rounded-xl shrink-0 ${report.active ? 'bg-blue-50 text-blue-500' : 'bg-slate-100 text-slate-400'}`}>
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <h3 className={`font-bold ${report.active ? 'text-slate-900 dark:text-slate-100' : 'text-slate-500'}`}>{report.name}</h3>
                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500 mt-1">
                    <span className="font-medium bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded text-slate-600 dark:text-slate-300">{report.type}</span>
                    <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> {report.frequency}</span>
                    <span className="flex items-center gap-1"><Mail className="w-3.5 h-3.5" /> {report.recipients}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-4 mt-4 md:mt-0 justify-end">
                <div className="text-right hidden sm:block">
                  <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Next Run</p>
                  <p className="text-sm font-medium text-slate-700 dark:text-slate-300">{report.nextRun}</p>
                </div>
                <button 
                  onClick={() => setReports(reports.map(r => r.id === report.id ? { ...r, active: !r.active } : r))}
                  className={`${report.active ? 'text-blue-500' : 'text-slate-400'} transition`}
                >
                  {report.active ? <ToggleRight className="w-8 h-8" /> : <ToggleLeft className="w-8 h-8" />}
                </button>
                <button className="p-2 text-slate-400 hover:text-slate-600 transition">
                  <MoreVertical className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
