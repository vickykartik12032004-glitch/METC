import React, { useMemo } from 'react';
import { 
  Package, 
  DollarSign, 
  Users, 
  AlertTriangle,
  ArrowRightLeft,
  Wrench,
  CheckCircle,
  Clock,
  Briefcase
} from 'lucide-react';
import { useAssetStore } from '../../../../store/useAssetStore';
import { useWorkerStore } from '../../../../store/useWorkerStore';
import { useTransactionStore } from '../../../../store/useTransactionStore';
import { useMaintenanceStore } from '../../../../store/useMaintenanceStore';
import { formatCurrency } from '../../../../lib/utils';
import { ReportTabType } from '../../ReportsMasterModule';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid, BarChart, Bar } from 'recharts';

interface Props {
  onNavigate: (tab: ReportTabType) => void;
}

export const ExecutiveDashboard: React.FC<Props> = ({ onNavigate }) => {
  const { getAllAssets } = useAssetStore();
  const { workers } = useWorkerStore();
  const { issues, returns, transfers, repairs, lostItems } = useTransactionStore();
  const { disposals, vendors } = useMaintenanceStore();

  const assets = getAllAssets();

  const kpis = useMemo(() => {
    const totalAssets = assets.length;
    const totalAssetValue = assets.reduce((sum, a) => sum + ((a.unitPrice || 0) * (a.quantity || 1)), 0);
    const availableAssets = assets.filter(a => a.status === 'Available').length;
    
    // Simplistic approximations for today's logic based on ISO strings
    const todayStr = new Date().toISOString().split('T')[0];
    const issuesToday = issues.filter(i => i.issueDate.startsWith(todayStr)).length;
    const returnsToday = returns.filter(r => r.returnDate.startsWith(todayStr)).length;
    const transfersToday = transfers.filter(t => t.transferDate.startsWith(todayStr)).length;

    const underRepair = repairs.filter(r => r.status === 'In Progress' || r.status === 'In Repair').length;
    const lostAssets = lostItems.length;
    const disposedAssets = disposals.length;

    const activeWorkers = workers.filter(w => w.status === 'Active').length;
    const totalSuppliers = vendors.length;

    const monthlyRepairCost = repairs.reduce((sum, r) => sum + (r.repairCost || 0), 0);
    const monthlyAssetUtilization = totalAssets ? Math.round(((totalAssets - availableAssets) / totalAssets) * 100) : 0;

    return {
      totalAssets, totalAssetValue, availableAssets, issuesToday, returnsToday, transfersToday,
      underRepair, lostAssets, disposedAssets, activeWorkers, totalSuppliers, monthlyRepairCost, monthlyAssetUtilization
    };
  }, [assets, workers, issues, returns, transfers, repairs, lostItems, disposals, vendors]);

  const cards = [
    { title: 'Total Assets', value: kpis.totalAssets.toLocaleString(), icon: Package, color: 'text-blue-500', bg: 'bg-blue-50', tab: 'inventory' },
    { title: 'Total Value', value: formatCurrency(kpis.totalAssetValue), icon: DollarSign, color: 'text-emerald-500', bg: 'bg-emerald-50', tab: 'inventory' },
    { title: 'Asset Utilization', value: `${kpis.monthlyAssetUtilization}%`, icon: Clock, color: 'text-purple-500', bg: 'bg-purple-50', tab: 'analytics' },
    { title: 'Under Repair', value: kpis.underRepair, icon: Wrench, color: 'text-amber-500', bg: 'bg-amber-50', tab: 'repairs' },
    { title: 'Lost Assets', value: kpis.lostAssets, icon: AlertTriangle, color: 'text-rose-500', bg: 'bg-rose-50', tab: 'lost' },
    { title: 'Active Workers', value: kpis.activeWorkers, icon: Users, color: 'text-cyan-500', bg: 'bg-cyan-50', tab: 'workers' },
    { title: 'Total Suppliers', value: kpis.totalSuppliers, icon: Briefcase, color: 'text-indigo-500', bg: 'bg-indigo-50', tab: 'suppliers' },
    { title: 'Monthly Repair Cost', value: formatCurrency(kpis.monthlyRepairCost), icon: DollarSign, color: 'text-red-500', bg: 'bg-red-50', tab: 'repairs' },
  ];

  // Dummy data for charts
  const trendData = [
    { name: 'Jan', issues: 400, returns: 240, repairs: 20 },
    { name: 'Feb', issues: 300, returns: 139, repairs: 25 },
    { name: 'Mar', issues: 200, returns: 980, repairs: 10 },
    { name: 'Apr', issues: 278, returns: 390, repairs: 50 },
    { name: 'May', issues: 189, returns: 480, repairs: 30 },
    { name: 'Jun', issues: 239, returns: 380, repairs: 15 },
    { name: 'Jul', issues: 349, returns: 430, repairs: 25 },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {cards.map((c, i) => (
          <div 
            key={i} 
            onClick={() => onNavigate(c.tab as ReportTabType)}
            className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center justify-between shadow-sm cursor-pointer hover:shadow-md transition-shadow group"
          >
            <div>
              <p className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">{c.title}</p>
              <p className={`text-2xl font-black mt-1 ${c.color}`}>{c.value}</p>
            </div>
            <div className={`p-3 rounded-xl ${c.bg} dark:bg-slate-800 group-hover:scale-110 transition-transform`}>
              <c.icon className={`w-5 h-5 ${c.color}`} />
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
           <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 mb-6">Asset Movement Trend</h3>
           <div className="h-72">
             <ResponsiveContainer width="100%" height="100%">
               <AreaChart data={trendData}>
                 <defs>
                   <linearGradient id="colorIssues" x1="0" y1="0" x2="0" y2="1">
                     <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                     <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                   </linearGradient>
                   <linearGradient id="colorReturns" x1="0" y1="0" x2="0" y2="1">
                     <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                     <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                   </linearGradient>
                 </defs>
                 <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
                 <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
                 <CartesianGrid vertical={false} strokeDasharray="3 3" opacity={0.5} />
                 <Tooltip />
                 <Area type="monotone" dataKey="issues" stroke="#3b82f6" strokeWidth={3} fillOpacity={1} fill="url(#colorIssues)" />
                 <Area type="monotone" dataKey="returns" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#colorReturns)" />
               </AreaChart>
             </ResponsiveContainer>
           </div>
        </div>
        
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
           <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 mb-6">Repair Cost Trend</h3>
           <div className="h-72">
             <ResponsiveContainer width="100%" height="100%">
               <BarChart data={trendData}>
                 <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
                 <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
                 <CartesianGrid vertical={false} strokeDasharray="3 3" opacity={0.5} />
                 <Tooltip cursor={{ fill: 'transparent' }} />
                 <Bar dataKey="repairs" fill="#ef4444" radius={[4, 4, 0, 0]} />
               </BarChart>
             </ResponsiveContainer>
           </div>
        </div>
      </div>
    </div>
  );
};
