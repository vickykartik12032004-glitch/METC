import React, { createContext, useContext, useEffect, useState, useCallback, useRef } from 'react';
import { toast } from 'sonner';
import { onAuthStateChanged } from 'firebase/auth';
import { auth } from '../lib/firebase';
import { User, UserRole, UserSession } from '../types';
import { useAdminStore } from '../store/useAdminStore';
import { useAuthStore } from '../store/useAuthStore';
import {
  loginWithFirebaseEmailPassword,
  buildUserFromFirebase,
  logoutFromFirebase,
} from '../services/firebaseAuth.service';
import {
  getActiveSession,
  destroySession,
  restoreUserFromSession,
  findAccountByEmail,
  getStoredAccounts,
  saveSessionToStorage,
} from '../services/auth.service';

interface AuthContextType {
  user: User | null;
  session: UserSession | null;
  role: UserRole;
  loading: boolean;
  isAuthenticated: boolean;
  login: (email: string, password?: string, rememberMe?: boolean) => Promise<{ success: boolean; error?: string; isLocked?: boolean; lockoutRemainingSeconds?: number }>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const DEFAULT_BYPASS_USER: User = {
  id: 'usr_super_admin_vicky',
  name: 'Vicky Kartik',
  email: 'vickykartik12032004@gmail.com',
  role: 'Super Admin',
  department: 'Executive Management',
  phone: '+65 9123 4567',
  accountStatus: 'Active',
  allSitesAccess: true,
  createdAt: new Date().toISOString(),
};

const DEFAULT_BYPASS_SESSION: UserSession = {
  token: 'sess_super_admin_vicky',
  sessionId: 'sess_super_admin_vicky',
  userId: 'usr_super_admin_vicky',
  email: 'vickykartik12032004@gmail.com',
  role: 'Super Admin',
  issuedAt: Date.now(),
  expiresAt: Date.now() + 365 * 24 * 60 * 60 * 1000,
  rememberMe: true,
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(DEFAULT_BYPASS_USER);
  const [session, setSession] = useState<UserSession | null>(DEFAULT_BYPASS_SESSION);
  const [loading, setLoading] = useState<boolean>(false);
  const sessionCheckTimer = useRef<NodeJS.Timeout | null>(null);

  const role: UserRole = user?.role || 'Super Admin';
  // Lock screen is temporarily disabled; always consider session active
  const isAuthenticated = true;

  /**
   * Synchronize active user with Whitelist governance rules
   */
  const applyWhitelistGovernance = useCallback((baseUser: User): User => {
    if (!baseUser || !baseUser.email || typeof baseUser.email !== 'string') return baseUser;
    const adminStore = useAdminStore.getState();
    const authorized = adminStore.checkAuthorizedEmail(baseUser.email);

    if (authorized && authorized.status === 'Active') {
      return {
        ...baseUser,
        name: authorized.fullName || baseUser.name,
        role: (authorized.role as UserRole) || baseUser.role || 'Super Admin',
        department: authorized.department || baseUser.department || 'Operations',
        projectSite: authorized.site || baseUser.projectSite || 'HQ - Tower A',
      };
    }

    return baseUser;
  }, []);

  /**
   * Initialize & check Firebase Auth session on application load
   */
  useEffect(() => {
    let isMounted = true;

    async function initialize() {
      try {
        // Preload local admin seed cache
        await getStoredAccounts();

        // 1. Check local session storage first
        const activeSess = getActiveSession();
        if (activeSess) {
          const restored = await restoreUserFromSession(activeSess);
          if (restored && isMounted) {
            const governed = applyWhitelistGovernance(restored);
            setUser(governed);
            setSession(activeSess);
            useAuthStore.getState().setUser(governed);
          }
        } else {
          // Default to Super Admin so lock screen is bypassed
          useAuthStore.getState().setUser(DEFAULT_BYPASS_USER);
        }
      } catch (err) {
        console.error('Session check error:', err);
      } finally {
        if (isMounted) setLoading(false);
      }
    }

    initialize();

    // 2. Listen to Firebase onAuthStateChanged
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser && isMounted) {
        try {
          const appUser = await buildUserFromFirebase(fbUser);
          const governed = applyWhitelistGovernance(appUser);
          setUser(governed);
          useAuthStore.getState().setUser(governed);

          const token = await fbUser.getIdToken();
          const sess: UserSession = {
            token,
            sessionId: `sess_${fbUser.uid}`,
            userId: fbUser.uid,
            email: fbUser.email || '',
            role: governed.role,
            issuedAt: Date.now(),
            expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000,
            rememberMe: true,
          };
          setSession(sess);
          saveSessionToStorage(sess);
        } catch (e) {
          console.error('Firebase user mapping error:', e);
        }
      } else if (!fbUser && !getActiveSession()) {
        if (isMounted) {
          // Lock screen temporarily disabled: preserve default bypass user
          setUser(DEFAULT_BYPASS_USER);
          setSession(DEFAULT_BYPASS_SESSION);
          useAuthStore.getState().setUser(DEFAULT_BYPASS_USER);
        }
      }
      if (isMounted) setLoading(false);
    });

    return () => {
      isMounted = false;
      unsubscribe();
      if (sessionCheckTimer.current) clearInterval(sessionCheckTimer.current);
    };
  }, [applyWhitelistGovernance]);

  /**
   * Periodic Session Expiration Check
   */
  useEffect(() => {
    if (!session?.expiresAt) return;

    const interval = setInterval(() => {
      const now = Date.now();
      if (session.expiresAt <= now) {
        toast.error('Your session has expired. Please sign in again.');
        logout();
      }
    }, 30000); // every 30 seconds

    sessionCheckTimer.current = interval;
    return () => clearInterval(interval);
  }, [session]);

  /**
   * Refresh current user profile state
   */
  const refreshUser = async () => {
    if (!user) return;
    const account = await findAccountByEmail(user.email);
    if (account) {
      const { passwordHash: _h, passwordSalt: _s, ...clean } = account;
      const governed = applyWhitelistGovernance(clean);
      setUser(governed);
      useAuthStore.getState().setUser(governed);
    }
  };

  /**
   * Firebase Email & Password Login
   */
  const login = async (
    email: string,
    passwordPlain?: string,
    rememberMe: boolean = true
  ): Promise<{ success: boolean; error?: string; isLocked?: boolean; lockoutRemainingSeconds?: number }> => {
    setLoading(true);
    try {
      const normalizedEmail = email.trim().toLowerCase();
      const password = passwordPlain || '';

      const result = await loginWithFirebaseEmailPassword(normalizedEmail, password, rememberMe);

      if (!result.success || !result.user || !result.session) {
        return {
          success: false,
          error: result.error || 'Invalid email or password',
          isLocked: result.isLocked,
          lockoutRemainingSeconds: result.lockoutRemainingSeconds,
        };
      }

      const governedUser = applyWhitelistGovernance(result.user);
      setUser(governedUser);
      setSession(result.session);
      useAuthStore.getState().setUser(governedUser);

      // Audit log entry
      useAdminStore.getState().addAuditLog({
        user: governedUser.name,
        email: governedUser.email,
        userRole: governedUser.role,
        ipAddress: '127.0.0.1',
        action: 'Login',
        module: 'Firebase Authentication',
        details: `Successful Firebase Email/Password login for ${governedUser.name} (${governedUser.email})`,
        severity: 'Info',
      });

      toast.success(`Welcome back, ${governedUser.name}!`);
      return { success: true };
    } catch (err: any) {
      return {
        success: false,
        error: 'Invalid email or password',
      };
    } finally {
      setLoading(false);
    }
  };

  /**
   * Complete Logout
   */
  const logout = async () => {
    try {
      setLoading(true);
      if (user) {
        useAdminStore.getState().addAuditLog({
          user: user.name,
          email: user.email,
          userRole: user.role,
          ipAddress: '127.0.0.1',
          action: 'Logout',
          module: 'Firebase Authentication',
          details: `User ${user.name} (${user.email}) logged out.`,
          severity: 'Info',
        });
      }
      await logoutFromFirebase();
      destroySession();
      setUser(DEFAULT_BYPASS_USER);
      setSession(DEFAULT_BYPASS_SESSION);
      useAuthStore.getState().setUser(DEFAULT_BYPASS_USER);
      toast.info('Session reset. Lock screen is currently disabled.');
    } catch (e) {
      setUser(DEFAULT_BYPASS_USER);
      setSession(DEFAULT_BYPASS_SESSION);
      useAuthStore.getState().setUser(DEFAULT_BYPASS_USER);
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        session,
        role,
        loading,
        isAuthenticated,
        login,
        logout,
        refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuthContext() {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuthContext must be used within an AuthProvider');
  }
  return ctx;
}
