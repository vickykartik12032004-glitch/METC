import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'sonner';
import { GoogleOAuthProvider } from '@react-oauth/google';
import { AuthProvider } from './contexts/AuthContext';
import { MainLayout } from './components/layout/MainLayout';
import { ProtectedRoute } from './components/layout/ProtectedRoute';
import { useThemeStore } from './store/useThemeStore';
import { realtimeSync } from './services/realtimeSync';

// Auth Pages
import { LoginPage } from './pages/auth/LoginPage';
import { RegisterPage } from './pages/auth/RegisterPage';
import { ForgotPasswordPage } from './pages/auth/ForgotPasswordPage';
import { ResetPasswordPage } from './pages/auth/ResetPasswordPage';
import { UnauthorizedPage } from './pages/auth/UnauthorizedPage';

// System Application Pages
import { Dashboard } from './pages/Dashboard';
import { Materials } from './pages/Materials';
import { EquipmentPage } from './pages/Equipment';
import { ToolsPage } from './pages/Tools';
import { Consumables } from './pages/Consumables';
import { PPE } from './pages/PPE';
import { WorkersPage } from './pages/Workers';
import { IssuePage } from './pages/Issue';
import { ReturnPage } from './pages/Return';
import { TransferPage } from './pages/Transfer';
import { MaintenancePage } from './pages/Maintenance';
import { LostItemsPage } from './pages/LostItems';
import { ReportsPage } from './pages/Reports';
import { NotificationsPage } from './pages/Notifications';
import { SettingsPage } from './pages/Settings';
import { AdminPage } from './pages/admin/AdminPage';
import { ProfilePage } from './pages/Profile';
import { NotFound } from './pages/NotFound';

export const App: React.FC = () => {
  const { isDarkMode } = useThemeStore();

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  useEffect(() => {
    realtimeSync.init();
  }, []);

  return (
    <GoogleOAuthProvider clientId={(import.meta as any).env.VITE_GOOGLE_CLIENT_ID || '1016629934279-d65tntr8kmdm3is0t1624sotc091924k.apps.googleusercontent.com'}>
      <AuthProvider>
        <BrowserRouter>
          <Toaster position="top-right" richColors />
          <Routes>
          {/* Public Authentication Routes - Lock screen disabled temporarily */}
          <Route path="/login" element={<Navigate to="/dashboard" replace />} />
          <Route path="/register" element={<Navigate to="/dashboard" replace />} />
          <Route path="/forgot-password" element={<Navigate to="/dashboard" replace />} />
          <Route path="/reset-password" element={<Navigate to="/dashboard" replace />} />
          <Route path="/unauthorized" element={<Navigate to="/dashboard" replace />} />

          {/* Protected Application Routes inside MainLayout */}
          <Route
            element={
              <ProtectedRoute>
                <MainLayout />
              </ProtectedRoute>
            }
          >
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            
            {/* Dashboard - Accessible to all logged-in roles */}
            <Route path="/dashboard" element={<Dashboard />} />

            {/* Asset Category Pages - Requires view_assets */}
            <Route
              path="/materials"
              element={
                <ProtectedRoute requiredPermission="view_assets">
                  <Materials />
                </ProtectedRoute>
              }
            />
            <Route
              path="/equipment"
              element={
                <ProtectedRoute requiredPermission="view_assets">
                  <EquipmentPage />
                </ProtectedRoute>
              }
            />
            <Route
              path="/tools"
              element={
                <ProtectedRoute requiredPermission="view_assets">
                  <ToolsPage />
                </ProtectedRoute>
              }
            />
            <Route
              path="/consumables"
              element={
                <ProtectedRoute requiredPermission="view_assets">
                  <Consumables />
                </ProtectedRoute>
              }
            />
            <Route
              path="/ppe"
              element={
                <ProtectedRoute requiredPermission="view_assets">
                  <PPE />
                </ProtectedRoute>
              }
            />

            {/* Workers Management - Requires view_workers */}
            <Route
              path="/workers"
              element={
                <ProtectedRoute requiredPermission="view_workers">
                  <WorkersPage />
                </ProtectedRoute>
              }
            />

            {/* Operations & Transactions */}
            <Route
              path="/issue"
              element={
                <ProtectedRoute requiredPermission="issue_items">
                  <IssuePage />
                </ProtectedRoute>
              }
            />
            <Route
              path="/return"
              element={
                <ProtectedRoute requiredPermission="return_items">
                  <ReturnPage />
                </ProtectedRoute>
              }
            />
            <Route
              path="/transfer"
              element={
                <ProtectedRoute requiredPermission="transfer_items">
                  <TransferPage />
                </ProtectedRoute>
              }
            />
            <Route
              path="/maintenance"
              element={
                <ProtectedRoute requiredPermission="repair_items">
                  <MaintenancePage />
                </ProtectedRoute>
              }
            />
            <Route
              path="/lost-items"
              element={
                <ProtectedRoute requiredPermission="report_lost">
                  <LostItemsPage />
                </ProtectedRoute>
              }
            />

            {/* Reports & Notifications */}
            <Route
              path="/reports"
              element={
                <ProtectedRoute requiredPermission="view_reports">
                  <ReportsPage />
                </ProtectedRoute>
              }
            />
            <Route path="/notifications" element={<NotificationsPage />} />

            {/* Settings & Administration - Restricted to manage_settings */}
            <Route
              path="/settings"
              element={
                <ProtectedRoute requiredPermission="manage_settings">
                  <SettingsPage />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin"
              element={
                <ProtectedRoute requiredPermission="manage_settings">
                  <AdminPage />
                </ProtectedRoute>
              }
            />
            <Route
              path="/administration"
              element={
                <ProtectedRoute requiredPermission="manage_settings">
                  <AdminPage />
                </ProtectedRoute>
              }
            />

            {/* Profile - Available to all authenticated users */}
            <Route path="/profile" element={<ProfilePage />} />
          </Route>

          {/* 404 Catch All - Protected Route */}
          <Route
            path="*"
            element={
              <ProtectedRoute>
                <NotFound />
              </ProtectedRoute>
            }
          />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
    </GoogleOAuthProvider>
  );
};

export default App;
