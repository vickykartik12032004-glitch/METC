import { z } from 'zod';

// Roles Validation
export const roleSchema = z.object({
  name: z.string().min(2, 'Role name is required'),
  description: z.string().optional(),
  permissions: z.record(z.string(), z.boolean()).optional(),
});

// Departments Validation
export const departmentSchema = z.object({
  code: z.string().min(2, 'Code is required'),
  name: z.string().min(2, 'Department name is required'),
  manager_name: z.string().optional(),
});

// Branches Validation
export const branchSchema = z.object({
  code: z.string().min(2, 'Branch code is required'),
  name: z.string().min(2, 'Branch name is required'),
  address: z.string().optional(),
  city: z.string().optional(),
  country: z.string().default('United States'),
});

// Sites Validation
export const siteSchema = z.object({
  code: z.string().min(2, 'Site code is required'),
  name: z.string().min(2, 'Site name is required'),
  branch_id: z.string().uuid().optional().nullable(),
  address: z.string().optional(),
  project_manager: z.string().optional(),
});

// Users Validation
export const userSchema = z.object({
  email: z.string().email('Valid email is required'),
  full_name: z.string().min(2, 'Full name is required'),
  phone: z.string().optional(),
  role_id: z.string().uuid().optional().nullable(),
  branch_id: z.string().uuid().optional().nullable(),
  status: z.enum(['active', 'inactive', 'suspended']).default('active'),
  avatar_url: z.string().url().optional().nullable(),
});

// Workers Validation
export const workerSchema = z.object({
  worker_id: z.string().min(2, 'Worker ID is required'),
  employee_number: z.string().min(2, 'Employee number is required'),
  name: z.string().min(2, 'Worker name is required'),
  photo_url: z.string().optional().nullable(),
  phone: z.string().min(5, 'Phone number is required'),
  email: z.string().email().optional().nullable(),
  trade: z.string().min(2, 'Trade / Skill is required'),
  department_id: z.string().uuid().optional().nullable(),
  company: z.string().default('MOUNTEC PTE LTD'),
  site_id: z.string().uuid().optional().nullable(),
  status: z.enum(['Active', 'Inactive', 'On Leave', 'Terminated']).default('Active'),
  joining_date: z.string().optional(),
  remarks: z.string().optional().nullable(),
});

// Suppliers Validation
export const supplierSchema = z.object({
  supplier_code: z.string().optional(),
  supplier_name: z.string().min(2, 'Supplier name is required'),
  contact_person: z.string().optional(),
  phone: z.string().optional(),
  email: z.string().email().optional().nullable(),
  address: z.string().optional(),
  remarks: z.string().optional(),
});

// METC Categories Validation
export const categorySchema = z.object({
  code: z.string().min(2, 'Category code is required'),
  name: z.string().min(2, 'Category name is required'),
  description: z.string().optional(),
});

// METC Items Validation
export const metcItemSchema = z.object({
  asset_id: z.string().min(2, 'Asset ID is required'),
  category_id: z.string().uuid('Category is required'),
  item_name: z.string().min(2, 'Item name is required'),
  description: z.string().optional().nullable(),
  brand: z.string().optional().nullable(),
  model: z.string().optional().nullable(),
  serial_number: z.string().optional().nullable(),
  asset_number: z.string().optional().nullable(),
  qr_code: z.string().optional().nullable(),
  barcode: z.string().optional().nullable(),
  unit: z.string().default('Units'),
  quantity: z.number().min(0, 'Quantity must be non-negative'),
  minimum_stock: z.number().min(0).default(0),
  maximum_stock: z.number().min(0).default(1000),
  current_stock: z.number().min(0).default(0),
  purchase_date: z.string().optional().nullable(),
  purchase_cost: z.number().min(0).optional().default(0),
  supplier_id: z.string().uuid().optional().nullable(),
  warranty_expiry: z.string().optional().nullable(),
  calibration_due: z.string().optional().nullable(),
  storage_location: z.string().optional().nullable(),
  rack_number: z.string().optional().nullable(),
  site_id: z.string().uuid().optional().nullable(),
  photo_url: z.string().optional().nullable(),
  status: z.enum(['Available', 'Issued', 'Repair', 'Lost', 'Disposed', 'Inactive', 'Low Stock', 'Out of Stock']).default('Available'),
  remarks: z.string().optional().nullable(),
});

// Issue Transaction Validation
export const issueTransactionSchema = z.object({
  issue_number: z.string().min(2, 'Issue number is required'),
  worker_id: z.string().uuid('Worker selection is required'),
  item_id: z.string().uuid('Item selection is required'),
  quantity: z.number().positive('Quantity must be greater than 0'),
  issue_date: z.string().optional(),
  expected_return: z.string().optional().nullable(),
  purpose: z.string().optional(),
  site_id: z.string().uuid().optional().nullable(),
  issued_by: z.string().uuid().optional().nullable(),
  remarks: z.string().optional(),
});

// Return Transaction Validation
export const returnTransactionSchema = z.object({
  return_number: z.string().min(2, 'Return number is required'),
  issue_id: z.string().uuid('Issue reference is required'),
  item_id: z.string().uuid('Item selection is required'),
  worker_id: z.string().uuid().optional().nullable(),
  quantity_returned: z.number().positive('Quantity returned must be greater than 0'),
  condition: z.enum(['Good', 'Damaged', 'Needs Repair', 'Lost']).default('Good'),
  remarks: z.string().optional(),
  returned_by: z.string().uuid().optional().nullable(),
});

// Transfer Transaction Validation
export const transferTransactionSchema = z.object({
  transfer_number: z.string().min(2, 'Transfer number is required'),
  item_id: z.string().uuid('Item selection is required'),
  quantity: z.number().positive('Quantity must be positive'),
  from_site_id: z.string().uuid().optional().nullable(),
  to_site_id: z.string().uuid().optional().nullable(),
  from_worker_id: z.string().uuid().optional().nullable(),
  to_worker_id: z.string().uuid().optional().nullable(),
  remarks: z.string().optional(),
});

// Repair Transaction Validation
export const repairTransactionSchema = z.object({
  repair_number: z.string().min(2, 'Repair number is required'),
  item_id: z.string().uuid('Item selection is required'),
  vendor: z.string().optional(),
  repair_cost: z.number().min(0).optional().default(0),
  expected_completion: z.string().optional().nullable(),
  fault_description: z.string().min(5, 'Detailed fault description is required'),
  remarks: z.string().optional(),
});

// Lost Transaction Validation
export const lostTransactionSchema = z.object({
  lost_number: z.string().min(2, 'Lost report number is required'),
  item_id: z.string().uuid('Item selection is required'),
  worker_id: z.string().uuid().optional().nullable(),
  quantity_lost: z.number().positive().default(1),
  reason: z.string().min(5, 'Reason for loss is required'),
  investigation_notes: z.string().optional(),
  estimated_value: z.number().min(0).optional(),
});

// Stock Adjustment Validation
export const stockAdjustmentSchema = z.object({
  adjustment_number: z.string().min(2, 'Adjustment number is required'),
  item_id: z.string().uuid('Item selection is required'),
  quantity_change: z.number(),
  new_quantity: z.number().min(0, 'New quantity must be 0 or positive'),
  reason: z.string().min(3, 'Reason is required'),
});

// Settings Validation
export const settingsSchema = z.object({
  company_name: z.string().min(2, 'Company name is required'),
  logo_url: z.string().optional().nullable(),
  theme: z.enum(['light', 'dark', 'system']).default('light'),
  currency: z.string().default('USD'),
  timezone: z.string().default('UTC'),
  tagline: z.string().optional(),
  hq_address: z.string().optional(),
  corporate_email: z.string().email().optional(),
});
