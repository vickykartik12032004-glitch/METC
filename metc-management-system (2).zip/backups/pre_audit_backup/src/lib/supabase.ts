import { createClient } from '@supabase/supabase-js';
import type { Database } from '../types/database.types';

const env = (import.meta as any).env || {};
const supabaseUrl = env.VITE_SUPABASE_URL || 'https://placeholder.supabase.co';
const supabaseAnonKey = env.VITE_SUPABASE_ANON_KEY || 'placeholder-anon-key';

export const isSupabaseConfigured = Boolean(
  env.VITE_SUPABASE_URL && env.VITE_SUPABASE_ANON_KEY
);

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
});

export const STORAGE_BUCKETS = {
  ITEM_IMAGES: 'item-images',
  WORKER_IMAGES: 'worker-images',
  DOCUMENTS: 'documents',
  COMPANY_LOGO: 'company-logo',
} as const;

/**
 * Uploads a file to a specified Supabase Storage Bucket
 */
export async function uploadFileToBucket(
  bucket: keyof typeof STORAGE_BUCKETS,
  filePath: string,
  file: File
): Promise<{ url: string | null; error: Error | null }> {
  if (!isSupabaseConfigured) {
    return {
      url: URL.createObjectURL(file),
      error: null,
    };
  }

  const bucketName = STORAGE_BUCKETS[bucket];
  const { data, error } = await supabase.storage
    .from(bucketName)
    .upload(filePath, file, { upsert: true });

  if (error) {
    console.error(`Error uploading to ${bucketName}:`, error.message);
    return { url: null, error };
  }

  const { data: publicUrlData } = supabase.storage
    .from(bucketName)
    .getPublicUrl(data.path);

  return { url: publicUrlData.publicUrl, error: null };
}

/**
 * Get Public URL for a stored file
 */
export function getPublicStorageUrl(
  bucket: keyof typeof STORAGE_BUCKETS,
  filePath: string
): string {
  if (!isSupabaseConfigured) return filePath;
  const bucketName = STORAGE_BUCKETS[bucket];
  return supabase.storage.from(bucketName).getPublicUrl(filePath).data.publicUrl;
}
