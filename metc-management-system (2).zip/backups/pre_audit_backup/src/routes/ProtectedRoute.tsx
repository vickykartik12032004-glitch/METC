import { ProtectedRoute } from '../components/layout/ProtectedRoute';

export { ProtectedRoute };
export default ProtectedRoute;
