/**
 * Enterprise Cryptographic & Security Utilities
 * Uses standard Web Crypto API for secure SHA-256 hashing with salt and cryptographically strong random tokens.
 */

// Helper to convert ArrayBuffer to Hex string
function bufferToHex(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

// Helper to convert hex string to Uint8Array
function hexToBytes(hex: string): Uint8Array {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < hex.length; i += 2) {
    bytes[i / 2] = parseInt(hex.substring(i, i + 2), 16);
  }
  return bytes;
}

/**
 * Generate a cryptographically random salt (16 bytes hex)
 */
export function generateSalt(length = 16): string {
  const array = new Uint8Array(length);
  if (typeof window !== 'undefined' && window.crypto) {
    window.crypto.getRandomValues(array);
  } else {
    for (let i = 0; i < length; i++) {
      array[i] = Math.floor(Math.random() * 256);
    }
  }
  return bufferToHex(array.buffer);
}

/**
 * Generates a SHA-256 hash of password combined with salt
 */
export async function hashPassword(
  password: string,
  providedSalt?: string
): Promise<{ hash: string; salt: string }> {
  const salt = providedSalt || generateSalt();
  const data = new TextEncoder().encode(salt + ':' + password);
  
  if (typeof window !== 'undefined' && window.crypto?.subtle) {
    const hashBuffer = await window.crypto.subtle.digest('SHA-256', data);
    return {
      hash: bufferToHex(hashBuffer),
      salt,
    };
  }

  // Pure JS fallback if SubtleCrypto is unavailable in certain test environments
  let h = 0x811c9dc5;
  for (let i = 0; i < data.length; i++) {
    h ^= data[i];
    h = Math.imul(h, 0x01000193);
  }
  return {
    hash: ('00000000' + (h >>> 0).toString(16)).slice(-8) + salt,
    salt,
  };
}

/**
 * Verifies if candidate password matches stored hash and salt
 */
export async function verifyPassword(
  candidatePassword: string,
  storedHash: string,
  storedSalt: string
): Promise<boolean> {
  if (!candidatePassword || !storedHash || !storedSalt) return false;
  const { hash } = await hashPassword(candidatePassword, storedSalt);
  return hash === storedHash;
}

/**
 * Generates a cryptographically secure random token (e.g. for session IDs, reset tokens)
 */
export function generateSecureToken(byteLength = 24): string {
  const array = new Uint8Array(byteLength);
  if (typeof window !== 'undefined' && window.crypto) {
    window.crypto.getRandomValues(array);
  } else {
    for (let i = 0; i < byteLength; i++) {
      array[i] = Math.floor(Math.random() * 256);
    }
  }
  return bufferToHex(array.buffer);
}

/**
 * In-memory / Storage rate limiter and lockout tracker
 */
export interface RateLimitEntry {
  failedAttempts: number;
  lockedUntil: number | null; // epoch timestamp
  lastAttemptAt: number;
}

const RATE_LIMIT_STORAGE_KEY = 'metc_auth_rate_limits';
const MAX_ATTEMPTS = 5;
const LOCKOUT_DURATION_MS = 2 * 60 * 1000; // 2 minutes

export function getRateLimitStatus(identifier: string): {
  isLocked: boolean;
  remainingLockoutSeconds: number;
  attemptsCount: number;
} {
  try {
    const stored = localStorage.getItem(RATE_LIMIT_STORAGE_KEY);
    const data: Record<string, RateLimitEntry> = stored ? JSON.parse(stored) : {};
    const entry = data[identifier.toLowerCase().trim()];

    if (!entry) {
      return { isLocked: false, remainingLockoutSeconds: 0, attemptsCount: 0 };
    }

    const now = Date.now();
    if (entry.lockedUntil && entry.lockedUntil > now) {
      const remainingSec = Math.ceil((entry.lockedUntil - now) / 1000);
      return {
        isLocked: true,
        remainingLockoutSeconds: remainingSec,
        attemptsCount: entry.failedAttempts,
      };
    }

    // Lockout expired, reset if needed
    if (entry.lockedUntil && entry.lockedUntil <= now) {
      delete data[identifier.toLowerCase().trim()];
      localStorage.setItem(RATE_LIMIT_STORAGE_KEY, JSON.stringify(data));
      return { isLocked: false, remainingLockoutSeconds: 0, attemptsCount: 0 };
    }

    return {
      isLocked: false,
      remainingLockoutSeconds: 0,
      attemptsCount: entry.failedAttempts,
    };
  } catch (e) {
    return { isLocked: false, remainingLockoutSeconds: 0, attemptsCount: 0 };
  }
}

export function recordFailedAttempt(identifier: string): {
  isNowLocked: boolean;
  lockoutMinutes: number;
  attemptsCount: number;
} {
  try {
    const stored = localStorage.getItem(RATE_LIMIT_STORAGE_KEY);
    const data: Record<string, RateLimitEntry> = stored ? JSON.parse(stored) : {};
    const key = identifier.toLowerCase().trim();
    const now = Date.now();

    const current = data[key] || { failedAttempts: 0, lockedUntil: null, lastAttemptAt: now };
    current.failedAttempts += 1;
    current.lastAttemptAt = now;

    let isNowLocked = false;
    if (current.failedAttempts >= MAX_ATTEMPTS) {
      current.lockedUntil = now + LOCKOUT_DURATION_MS;
      isNowLocked = true;
    }

    data[key] = current;
    localStorage.setItem(RATE_LIMIT_STORAGE_KEY, JSON.stringify(data));

    return {
      isNowLocked,
      lockoutMinutes: Math.ceil(LOCKOUT_DURATION_MS / 60000),
      attemptsCount: current.failedAttempts,
    };
  } catch (e) {
    return { isNowLocked: false, lockoutMinutes: 0, attemptsCount: 1 };
  }
}

export function resetFailedAttempts(identifier: string): void {
  try {
    const stored = localStorage.getItem(RATE_LIMIT_STORAGE_KEY);
    if (!stored) return;
    const data: Record<string, RateLimitEntry> = JSON.parse(stored);
    delete data[identifier.toLowerCase().trim()];
    localStorage.setItem(RATE_LIMIT_STORAGE_KEY, JSON.stringify(data));
  } catch (e) {
    // Ignore storage errors
  }
}
