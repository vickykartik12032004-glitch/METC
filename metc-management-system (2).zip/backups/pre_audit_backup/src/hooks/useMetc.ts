import { useState, useMemo, useEffect, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { onAuthStateChanged } from 'firebase/auth';
import { useAssetStore } from '../store/useAssetStore';
import { METCItem, AssetCategory, AssetStatus } from '../types';
import { fetchMETCItems, createMETCItemDb, updateMETCItemDb, deleteMETCItemDb } from '../services/metc.service';
import { saveItemToFirestore, deleteRealtimeItem, subscribeToUserItems, subscribeToOrganizationMetcItems, clearAllUserFirestoreItems } from '../services/firestoreSync.service';
import { ensureFirebaseAuthSession } from '../services/firebaseAuth.service';
import { auth } from '../lib/firebase';
import { toast } from 'sonner';
import { getNextMetNumber } from '../utils/metAssetNumber';

export interface UseMetcOptions {
  initialCategory?: AssetCategory | 'All';
}

export function useMetc(options: UseMetcOptions = {}) {
  const { initialCategory = 'All' } = options;
  const [searchParams, setSearchParams] = useSearchParams();
  const urlSearch = searchParams.get('search') || '';

  const { 
    materials, 
    equipment, 
    tools, 
    consumables, 
    ppe, 
    addMaterial, 
    updateMaterial, 
    deleteMaterial,
    addEquipment, 
    updateEquipment, 
    deleteEquipment,
    addTool, 
    updateTool, 
    deleteTool,
    addConsumable, 
    updateConsumable, 
    deleteConsumable,
    addPPE, 
    updatePPE, 
    deletePPE,
    getAllAssets,
    clearAllAssets,
    restoreDemoData
  } = useAssetStore();

  // Filter & Search states
  const [categoryFilter, setCategoryFilter] = useState<AssetCategory | 'All'>(initialCategory);
  const [searchQuery, setSearchQuery] = useState<string>(urlSearch);
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [locationFilter, setLocationFilter] = useState<string>('All');
  const [supplierFilter, setSupplierFilter] = useState<string>('All');
  const [lowStockOnly, setLowStockOnly] = useState<boolean>(false);
  const [warrantyExpiringOnly, setWarrantyExpiringOnly] = useState<boolean>(false);
  const [calibrationDueOnly, setCalibrationDueOnly] = useState<boolean>(false);

  // Synchronize state when URL search parameter changes
  useEffect(() => {
    if (urlSearch && urlSearch !== searchQuery) {
      setSearchQuery(urlSearch);
    }
  }, [urlSearch]);

  // Sorting state
  const [sortBy, setSortBy] = useState<string>('updatedAt');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  // Pagination state
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [itemsPerPage, setItemsPerPage] = useState<number>(10);

  // Selection & Modal states
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [activeItem, setActiveItem] = useState<METCItem | null>(null);
  const [isFormOpen, setIsFormOpen] = useState<boolean>(false);
  const [editingItem, setEditingItem] = useState<METCItem | null>(null);
  const [isImportOpen, setIsImportOpen] = useState<boolean>(false);
  const [isQrModalOpen, setIsQrModalOpen] = useState<boolean>(false);
  const [qrItem, setQrItem] = useState<METCItem | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Combine store assets
  const allStoreItems = useMemo<METCItem[]>(() => {
    return [...materials, ...equipment, ...tools, ...consumables, ...(ppe || [])];
  }, [materials, equipment, tools, consumables, ppe]);

  // Real-time Firestore Synchronization across tabs & devices
  useEffect(() => {
    let unsubscribeUser: (() => void) | null = null;
    let unsubscribeOrg: (() => void) | null = null;

    const unsubscribeAuth = onAuthStateChanged(auth, (firebaseUser) => {
      // Clean up any existing listeners on auth change
      if (unsubscribeUser) {
        unsubscribeUser();
        unsubscribeUser = null;
      }
      if (unsubscribeOrg) {
        unsubscribeOrg();
        unsubscribeOrg = null;
      }

      if (!firebaseUser) {
        return;
      }

      const uid = firebaseUser.uid;

      // 1. Subscribe to /users/{userId}/items in real-time
      unsubscribeUser = subscribeToUserItems(
        uid,
        (items) => {
          if (!items || items.length === 0) return;
          const store = useAssetStore.getState();
          items.forEach((item) => {
            const cat = (item.category || 'Material') as AssetCategory;
            store.applyRemoteAssetUpsert(cat, item);
          });
        },
        (err) => {
          console.warn('[RealtimeSync] User items sync note:', err.message);
        }
      );

      // 2. Also subscribe to shared /metc_items in real-time
      unsubscribeOrg = subscribeToOrganizationMetcItems(
        (items) => {
          if (!items || items.length === 0) return;
          const store = useAssetStore.getState();
          items.forEach((item) => {
            const cat = (item.category || 'Material') as AssetCategory;
            store.applyRemoteAssetUpsert(cat, item);
          });
        },
        (err) => {
          console.warn('[RealtimeSync] Org items sync note:', err.message);
        }
      );
    });

    return () => {
      unsubscribeAuth();
      if (unsubscribeUser) unsubscribeUser();
      if (unsubscribeOrg) unsubscribeOrg();
    };
  }, []);

  // Filtered & Search items calculation
  const filteredItems = useMemo(() => {
    return allStoreItems.filter((item) => {
      // Category filter
      if (categoryFilter !== 'All' && item.category !== categoryFilter) {
        return false;
      }

      // Status filter
      if (statusFilter !== 'All' && item.status !== statusFilter) {
        return false;
      }

      // Location filter
      if (locationFilter !== 'All' && !item.location.toLowerCase().includes(locationFilter.toLowerCase())) {
        return false;
      }

      // Supplier filter
      if (supplierFilter !== 'All' && item.supplier && !item.supplier.toLowerCase().includes(supplierFilter.toLowerCase())) {
        return false;
      }

      // Low stock check
      if (lowStockOnly) {
        const minVal = item.minQuantityThreshold ?? item.minimumStock ?? 10;
        const currentVal = item.availableQuantity ?? item.quantity ?? 0;
        if (currentVal > minVal && item.status !== 'Low Stock' && item.status !== 'Out of Stock') {
          return false;
        }
      }

      // Warranty expiring soon (within 30 days)
      if (warrantyExpiringOnly) {
        if (!item.warrantyExpiry) return false;
        const exp = new Date(item.warrantyExpiry).getTime();
        const now = new Date().getTime();
        const diffDays = (exp - now) / (1000 * 3600 * 24);
        if (diffDays < 0 || diffDays > 30) return false;
      }

      // Calibration due soon (within 30 days)
      if (calibrationDueOnly) {
        if (!item.calibrationDue) return false;
        const due = new Date(item.calibrationDue).getTime();
        const now = new Date().getTime();
        const diffDays = (due - now) / (1000 * 3600 * 24);
        if (diffDays < 0 || diffDays > 30) return false;
      }

      // Search query filter across Name, Code/ID, Serial, Brand, Model, Barcode, Location, Category, Unit, Description, Notes
      if (searchQuery.trim() !== '') {
        const rawQuery = searchQuery.trim().toLowerCase();
        const tokens = rawQuery.split(/\s+/).filter(Boolean);

        const searchableFields: string[] = [
          item.name || '',
          item.code || '',
          item.id || '',
          item.category || '',
          item.location || '',
          item.unit || '',
          item.brand || (item as any).manufacturer || '',
          item.model || (item as any).materialGrade || '',
          item.serialNumber || (item as any).batchNumber || '',
          item.barcode || '',
          item.supplier || '',
          item.description || '',
          item.status || '',
          (item as any).notes || '',
          (item as any).specifications || (item as any).specification || '',
          (item as any).assignedWorkerName || '',
          (item as any).currentProject || '',
        ];

        const corpus = searchableFields.join(' ').toLowerCase();

        // Match if full query phrase is inside corpus or every individual token matches somewhere in the corpus
        const matchesFull = corpus.includes(rawQuery);
        const matchesAllTokens = tokens.length > 1 && tokens.every((token) => corpus.includes(token));

        if (!matchesFull && !matchesAllTokens) {
          return false;
        }
      }

      return true;
    });
  }, [
    allStoreItems,
    categoryFilter,
    statusFilter,
    locationFilter,
    supplierFilter,
    lowStockOnly,
    warrantyExpiringOnly,
    calibrationDueOnly,
    searchQuery,
  ]);

  // Sorted items calculation
  const sortedItems = useMemo(() => {
    return [...filteredItems].sort((a, b) => {
      let valA: any = (a as any)[sortBy] ?? '';
      let valB: any = (b as any)[sortBy] ?? '';

      if (sortBy === 'name') {
        valA = a.name.toLowerCase();
        valB = b.name.toLowerCase();
      } else if (sortBy === 'code') {
        valA = a.code.toLowerCase();
        valB = b.code.toLowerCase();
      } else if (sortBy === 'quantity') {
        valA = a.quantity ?? 0;
        valB = b.quantity ?? 0;
      } else if (sortBy === 'availableQuantity') {
        valA = a.availableQuantity ?? 0;
        valB = b.availableQuantity ?? 0;
      } else if (sortBy === 'unitPrice') {
        valA = a.unitPrice ?? 0;
        valB = b.unitPrice ?? 0;
      }

      if (valA < valB) return sortOrder === 'asc' ? -1 : 1;
      if (valA > valB) return sortOrder === 'asc' ? 1 : -1;
      return 0;
    });
  }, [filteredItems, sortBy, sortOrder]);

  // Pagination calculation
  const totalItems = sortedItems.length;
  const totalPages = Math.ceil(totalItems / itemsPerPage) || 1;
  const paginatedItems = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return sortedItems.slice(start, start + itemsPerPage);
  }, [sortedItems, currentPage, itemsPerPage]);

  // Reset page when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [categoryFilter, searchQuery, statusFilter, locationFilter, supplierFilter, lowStockOnly]);

  // Sort Handler
  const handleSort = (field: string) => {
    if (sortBy === field) {
      setSortOrder((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortBy(field);
      setSortOrder('asc');
    }
  };

  // Select Row handlers
  const toggleSelectAll = useCallback(() => {
    if (selectedIds.length === paginatedItems.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(paginatedItems.map((i) => i.id));
    }
  }, [selectedIds, paginatedItems]);

  const toggleSelectRow = useCallback((id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  }, []);

  // CRUD Actions
  const handleCreateOrUpdate = async (formData: any) => {
    try {
      const explicitCat = formData.category || editingItem?.category;
      const category: AssetCategory = (
        explicitCat && explicitCat !== 'All'
          ? explicitCat
          : categoryFilter !== 'All'
          ? categoryFilter
          : 'Material'
      ) as AssetCategory;

      const quantity = Number(formData.quantity) || 0;
      const minStock = Number(formData.minQuantityThreshold ?? formData.minimumStock) || 10;
      const unitPrice = Number(formData.unitPrice ?? formData.purchaseCost) || 0;

      let availableQty = Number(formData.availableQuantity);
      if (isNaN(availableQty)) {
        if (editingItem && typeof editingItem.availableQuantity === 'number' && typeof editingItem.quantity === 'number') {
          const diff = quantity - editingItem.quantity;
          availableQty = Math.max(0, editingItem.availableQuantity + diff);
        } else {
          availableQty = quantity;
        }
      }

      let calculatedStatus: AssetStatus = formData.status || 'Available';
      if (quantity === 0) {
        calculatedStatus = 'Out of Stock';
      } else if (quantity <= minStock) {
        calculatedStatus = 'Low Stock';
      }

      const cleanCode = (formData.code && typeof formData.code === 'string') ? formData.code.trim() : '';
      const cleanAssetNumber = (formData.assetNumber && typeof formData.assetNumber === 'string') 
        ? formData.assetNumber.trim() 
        : (cleanCode || '');

      const itemPayload = {
        ...formData,
        category,
        code: cleanCode,
        assetNumber: cleanAssetNumber,
        quantity,
        availableQuantity: availableQty,
        minQuantityThreshold: minStock,
        minimumStock: minStock,
        maximumStock: Number(formData.maximumStock) || 1000,
        unitPrice,
        totalValue: quantity * unitPrice,
        status: calculatedStatus,
        barcode: formData.barcode || (cleanCode ? `BC-${cleanCode}` : `BC-${Date.now()}`),
        qrCode: formData.qrCode || (cleanCode ? `QR-${cleanCode}` : `QR-${Date.now()}`),
      };

      // Save or update across local state & cloud services
      let createdOrUpdatedId = editingItem?.id || `item_${Date.now()}`;

      if (editingItem) {
        // Update item in Zustand, Central Cloud Database, and Firestore
        if (category === 'Material') await updateMaterial(editingItem.id, itemPayload);
        else if (category === 'Equipment') await updateEquipment(editingItem.id, itemPayload);
        else if (category === 'Tool') await updateTool(editingItem.id, itemPayload);
        else if (category === 'Consumable') await updateConsumable(editingItem.id, itemPayload);
        else if (category === 'PPE') await updatePPE(editingItem.id, itemPayload);
        else {
          const store = useAssetStore.getState();
          if (store.materials.some((m) => m.id === editingItem.id)) await updateMaterial(editingItem.id, itemPayload);
          else if (store.equipment.some((e) => e.id === editingItem.id)) await updateEquipment(editingItem.id, itemPayload);
          else if (store.tools.some((t) => t.id === editingItem.id)) await updateTool(editingItem.id, itemPayload);
          else if (store.consumables.some((c) => c.id === editingItem.id)) await updateConsumable(editingItem.id, itemPayload);
          else if (store.ppe.some((p) => p.id === editingItem.id)) await updatePPE(editingItem.id, itemPayload);
        }

        // Update in Supabase (if configured)
        await updateMETCItemDb(editingItem.id, itemPayload);
      } else {
        // Create item in Zustand and Central Cloud Database
        let resItem: any;
        if (category === 'Material') resItem = await addMaterial(itemPayload);
        else if (category === 'Equipment') resItem = await addEquipment(itemPayload);
        else if (category === 'Tool') resItem = await addTool(itemPayload);
        else if (category === 'Consumable') resItem = await addConsumable(itemPayload);
        else if (category === 'PPE') resItem = await addPPE(itemPayload);

        if (resItem?.id) createdOrUpdatedId = resItem.id;

        // Create in Supabase (if configured)
        await createMETCItemDb(itemPayload);
      }

      // Save to Firebase Firestore database for persistent multi-device real-time sync
      try {
        const uid = auth.currentUser?.uid || (await ensureFirebaseAuthSession());
        if (uid) {
          await saveItemToFirestore({
            id: createdOrUpdatedId,
            userId: uid,
            name: formData.name,
            category,
            quantity,
            availableQuantity: availableQty,
            status: calculatedStatus,
            notes: formData.description || formData.remarks || '',
            ...itemPayload,
          }, uid);
        }
      } catch (firestoreErr) {
        console.warn('[Firestore] Background cloud sync note:', firestoreErr);
      }

      toast.success(
        editingItem 
          ? `Saved and synced ${category} item "${formData.name}" across devices`
          : `Created and synced new ${category} item "${formData.name}" to cloud`
      );

      setIsFormOpen(false);
      setEditingItem(null);
    } catch (err: any) {
      toast.error(err.message || 'Error saving item');
    }
  };

  const handleDelete = async (id: string) => {
    const itemToDelete = allStoreItems.find((i) => i.id === id);
    if (!itemToDelete) return;

    if (itemToDelete.category === 'Material') await deleteMaterial(id);
    else if (itemToDelete.category === 'Equipment') await deleteEquipment(id);
    else if (itemToDelete.category === 'Tool') await deleteTool(id);
    else if (itemToDelete.category === 'Consumable') await deleteConsumable(id);
    else if (itemToDelete.category === 'PPE') await deletePPE(id);

    await deleteMETCItemDb(id);

    // Delete from Firestore in background
    try {
      const uid = auth.currentUser?.uid || (await ensureFirebaseAuthSession());
      await deleteRealtimeItem(uid, id);
    } catch (e) {
      console.warn('[Firestore] Delete notice:', e);
    }

    toast.success(`Item ${itemToDelete.name} archived and removed from cloud sync`);
    setDeleteConfirmId(null);
    setSelectedIds((prev) => prev.filter((i) => i !== id));
  };

  const handleDuplicate = (item: METCItem) => {
    const hasMet = !!(item.code && item.code.trim().length > 0);
    const nextCode = hasMet ? getNextMetNumber(allStoreItems, false, true) : '';
    const duplicateData = {
      ...item,
      name: `${item.name} (Copy)`,
      code: nextCode,
      assetNumber: nextCode,
      barcode: nextCode ? `BC-${nextCode}` : `BC-${Date.now()}`,
      qrCode: nextCode ? `QR-${nextCode}` : `QR-${Date.now()}`,
    };
    delete (duplicateData as any).id;
    delete (duplicateData as any).createdAt;
    delete (duplicateData as any).updatedAt;

    setEditingItem(null);
    handleCreateOrUpdate(duplicateData);
  };

  const handleBulkDelete = () => {
    if (selectedIds.length === 0) return;
    selectedIds.forEach((id) => {
      handleDelete(id);
    });
    setSelectedIds([]);
    toast.success(`Archived ${selectedIds.length} items`);
  };

  const handleClearAllAssets = useCallback(async () => {
    await clearAllAssets();
    if (auth.currentUser) {
      try {
        await clearAllUserFirestoreItems(auth.currentUser.uid);
      } catch (e) {
        console.warn('Failed clearing user firestore items:', e);
      }
    }
  }, [clearAllAssets]);

  return {
    // Data
    allStoreItems,
    filteredItems,
    sortedItems,
    paginatedItems,
    totalItems,
    totalPages,
    currentPage,
    itemsPerPage,

    // Filters
    categoryFilter,
    setCategoryFilter,
    searchQuery,
    setSearchQuery,
    clearSearch: () => setSearchQuery(''),
    statusFilter,
    setStatusFilter,
    locationFilter,
    setLocationFilter,
    supplierFilter,
    setSupplierFilter,
    lowStockOnly,
    setLowStockOnly,
    warrantyExpiringOnly,
    setWarrantyExpiringOnly,
    calibrationDueOnly,
    setCalibrationDueOnly,

    // Sorting
    sortBy,
    sortOrder,
    handleSort,

    // Pagination
    setCurrentPage,
    setItemsPerPage,

    // Selection
    selectedIds,
    setSelectedIds,
    toggleSelectAll,
    toggleSelectRow,

    // Modals & States
    activeItem,
    setActiveItem,
    isFormOpen,
    setIsFormOpen,
    editingItem,
    setEditingItem,
    isImportOpen,
    setIsImportOpen,
    isQrModalOpen,
    setIsQrModalOpen,
    qrItem,
    setQrItem,
    deleteConfirmId,
    setDeleteConfirmId,
    isLoading,

    // Actions
    handleCreateOrUpdate,
    handleDelete,
    handleDuplicate,
    handleBulkDelete,
    clearAllAssets: handleClearAllAssets,
    restoreDemoData,
  };
}
