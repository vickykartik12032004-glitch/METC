import { useEffect, useState } from 'react';
import { realtimeSync, SyncConnectionStatus } from '../services/realtimeSync';

export interface RealtimeSyncInfo {
  status: SyncConnectionStatus;
  lastSyncTime: Date;
  isOnline: boolean;
  isSyncing: boolean;
  isOffline: boolean;
  forceSync: () => Promise<void>;
}

export function useRealtimeSync(): RealtimeSyncInfo {
  const [status, setStatus] = useState<SyncConnectionStatus>(realtimeSync.getStatus());
  const [lastSyncTime, setLastSyncTime] = useState<Date>(realtimeSync.getLastSyncTime());

  useEffect(() => {
    // Initialize real-time sync if not already done
    realtimeSync.init();

    const unsubscribe = realtimeSync.subscribe((newStatus, details) => {
      setStatus(newStatus);
      if (details?.lastSyncTime) {
        setLastSyncTime(details.lastSyncTime);
      }
    });

    return () => unsubscribe();
  }, []);

  return {
    status,
    lastSyncTime,
    isOnline: status === 'online',
    isSyncing: status === 'syncing',
    isOffline: status === 'offline',
    forceSync: () => realtimeSync.forceSync(),
  };
}
