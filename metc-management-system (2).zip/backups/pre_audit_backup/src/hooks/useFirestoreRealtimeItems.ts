import { useState, useEffect, useCallback } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import {
  subscribeToUserItems,
  createRealtimeItem,
  updateRealtimeItemFields,
  adjustRealtimeItemQuantity,
  deleteRealtimeItem,
  SyncedItem,
} from '../services/firestoreSync.service';
import { auth } from '../lib/firebase';

export interface UseFirestoreRealtimeItemsResult {
  items: SyncedItem[];
  loading: boolean;
  error: string | null;
  isFromCache: boolean;
  hasPendingWrites: boolean;
  createItem: (
    itemData: Omit<SyncedItem, 'id' | 'userId' | 'createdAt' | 'updatedAt' | '_metadata'> & { id?: string }
  ) => Promise<string>;
  updateItemFields: (
    itemId: string,
    fields: Partial<Omit<SyncedItem, 'id' | 'userId' | 'createdAt' | '_metadata'>>
  ) => Promise<void>;
  adjustQuantity: (itemId: string, delta: number) => Promise<void>;
  deleteItem: (itemId: string) => Promise<void>;
}

/**
 * Custom React Hook for live multi-device Firestore synchronization
 * - Automatically listens for real-time changes
 * - Handles offline persistence & pending writes
 * - Safely unsubscribes on unmount
 */
export function useFirestoreRealtimeItems(): UseFirestoreRealtimeItemsResult {
  const [items, setItems] = useState<SyncedItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [isFromCache, setIsFromCache] = useState<boolean>(false);
  const [hasPendingWrites, setHasPendingWrites] = useState<boolean>(false);
  const [activeUid, setActiveUid] = useState<string | null>(auth.currentUser?.uid || null);

  useEffect(() => {
    let unsubscribeListener: (() => void) | null = null;

    const unsubscribeAuth = onAuthStateChanged(auth, (firebaseUser) => {
      if (unsubscribeListener) {
        unsubscribeListener();
        unsubscribeListener = null;
      }

      if (!firebaseUser) {
        setActiveUid(null);
        setItems([]);
        setLoading(false);
        setError(null);
        return;
      }

      setActiveUid(firebaseUser.uid);
      setLoading(true);
      setError(null);

      unsubscribeListener = subscribeToUserItems(
        firebaseUser.uid,
        (updatedItems, metadata) => {
          setItems(updatedItems);
          setIsFromCache(metadata.fromCache);
          setHasPendingWrites(metadata.hasPendingWrites);
          setLoading(false);
          setError(null);
        },
        (err) => {
          console.warn('[useFirestoreRealtimeItems] Listener notice:', err.message);
          setError(err.message || 'Unable to sync real-time data.');
          setLoading(false);
        }
      );
    });

    return () => {
      unsubscribeAuth();
      if (unsubscribeListener) {
        unsubscribeListener();
      }
    };
  }, []);

  const createItem = useCallback(
    async (
      itemData: Omit<SyncedItem, 'id' | 'userId' | 'createdAt' | 'updatedAt' | '_metadata'> & { id?: string }
    ) => {
      if (!activeUid) return '';
      return await createRealtimeItem(activeUid, itemData);
    },
    [activeUid]
  );

  const updateItemFields = useCallback(
    async (
      itemId: string,
      fields: Partial<Omit<SyncedItem, 'id' | 'userId' | 'createdAt' | '_metadata'>>
    ) => {
      if (!activeUid) return;
      await updateRealtimeItemFields(activeUid, itemId, fields);
    },
    [activeUid]
  );

  const adjustQuantity = useCallback(
    async (itemId: string, delta: number) => {
      if (!activeUid) return;
      await adjustRealtimeItemQuantity(activeUid, itemId, delta);
    },
    [activeUid]
  );

  const deleteItem = useCallback(
    async (itemId: string) => {
      if (!activeUid) return;
      await deleteRealtimeItem(activeUid, itemId);
    },
    [activeUid]
  );

  return {
    items,
    loading,
    error,
    isFromCache,
    hasPendingWrites,
    createItem,
    updateItemFields,
    adjustQuantity,
    deleteItem,
  };
}
