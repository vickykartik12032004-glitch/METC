import { useMemo } from 'react';
import { useAuthContext } from '../contexts/AuthContext';
import { useAdminStore } from '../store/useAdminStore';
import { ROLE_PERMISSIONS } from '../constants';
import { Permission, UserRole } from '../types';
import { AdminModule, ModulePermissions } from '../features/admin/types';

export function usePermissions() {
  const { user, role } = useAuthContext();
  const roles = useAdminStore((state) => state.roles);
  const sites = useAdminStore((state) => state.sites);

  const currentRoleName = (role || user?.role || 'Worker') as string;
  const isSuperAdmin = currentRoleName === 'Super Admin';
  const isAdmin = currentRoleName === 'Admin';
  const canEdit = isSuperAdmin || isAdmin;
  const isViewer = !canEdit;
  const isSupervisor = currentRoleName === 'Supervisor' || currentRoleName === 'Site Supervisor';
  const isWorker = currentRoleName === 'Worker' || currentRoleName === 'User' || currentRoleName === 'Store Keeper' || currentRoleName === 'Viewer';

  // Check if account status is active
  const isAccountActive = !user?.accountStatus || user.accountStatus === 'Active';

  // Find the dynamic role object configured by Super Admin
  const roleConfig = useMemo(() => {
    return roles.find(
      (r) => r.name.toLowerCase() === currentRoleName.toLowerCase() || r.id.toLowerCase() === currentRoleName.toLowerCase()
    );
  }, [roles, currentRoleName]);

  /**
   * Check dynamic module permission (View, Create, Update, Delete, Approve, Export, Import)
   * RULE: Edit/Update and Delete are STRICTLY restricted to Admin and Super Admin.
   * All other roles are viewers (read-only for inventory, workers, and settings).
   */
  const hasModulePermission = (module: AdminModule, action: keyof ModulePermissions = 'view'): boolean => {
    // If account is locked/inactive, deny permissions
    if (!isAccountActive) return false;

    // Super Admin has unrestricted, immutable access to all modules and all actions
    if (isSuperAdmin) return true;

    // Strict rule: Edit/Update and Delete are ONLY allowed for Super Admin and Admin
    if ((action === 'update' || action === 'delete' || action === 'import') && !canEdit) {
      return false;
    }

    // Creating new master assets, workers, or changing settings is ONLY allowed for Super Admin and Admin
    if (action === 'create' && ['Materials', 'Equipment', 'Tools', 'Consumables', 'PPE', 'Workers', 'Settings', 'Administration'].includes(module) && !canEdit) {
      return false;
    }

    // Check dynamic store configuration if available
    if (roleConfig && roleConfig.permissions && roleConfig.permissions[module]) {
      const allowed = Boolean(roleConfig.permissions[module][action]);
      if ((action === 'update' || action === 'delete') && !canEdit) return false;
      return allowed;
    }

    // Fallback based on role
    if (isAdmin) {
      if (module === 'Administration' && action === 'delete') return false;
      return true;
    }

    // Non-admin roles (Supervisors, Workers, Viewers) have view-only access
    if (action === 'view') {
      if (['Settings', 'Administration'].includes(module)) return false;
      return true;
    }

    // Allow supervisors to approve or export requests
    if (isSupervisor && (action === 'approve' || action === 'export')) {
      return true;
    }

    // Allow workers/supervisors to submit transaction requests (Issue/Return) if applicable
    if (action === 'create' && ['Issue', 'Return'].includes(module)) {
      return true;
    }

    return false;
  };

  /**
   * Check if user is authorized for a specific Project Site
   */
  const hasSiteAccess = (siteNameOrId?: string): boolean => {
    if (!siteNameOrId) return true;
    if (isSuperAdmin) return true;
    if (user?.allSitesAccess === true) return true;

    const assigned = user?.assignedSites || [];
    if (assigned.length === 0) {
      // If user has a primary site attribute, check it
      if (user?.projectSite && user.projectSite.toLowerCase() === siteNameOrId.toLowerCase()) {
        return true;
      }
      return true; // default open if not explicitly restricted
    }

    // Check against assigned sites array
    const normalizedTarget = siteNameOrId.trim().toLowerCase();
    return assigned.some(
      (s) => s.trim().toLowerCase() === normalizedTarget || s.toLowerCase().includes(normalizedTarget) || normalizedTarget.includes(s.toLowerCase())
    );
  };

  /**
   * Get list of accessible site names for current user
   */
  const getAllowedSites = (): string[] => {
    const allSiteNames = sites.map((s) => s.siteName);
    if (isSuperAdmin || user?.allSitesAccess === true) {
      return allSiteNames.length > 0 ? allSiteNames : ['Corporate HQ - Marina Bay', 'Tuas Mega Logistics Depot', 'Changi Airport Terminal 5 Expansion'];
    }
    if (user?.assignedSites && user.assignedSites.length > 0) {
      return user.assignedSites;
    }
    if (user?.projectSite) {
      return [user.projectSite];
    }
    return allSiteNames.length > 0 ? allSiteNames : ['Tuas Mega Logistics Depot'];
  };

  // Backwards compatibility with static permission string checks
  const permissionsList = ROLE_PERMISSIONS[currentRoleName as UserRole] || [];
  const hasPermission = (permission: Permission): boolean => {
    if (!isAccountActive) return false;
    if (isSuperAdmin) return true;

    // Map legacy permission string to module permissions
    switch (permission) {
      case 'view_dashboard':
        return hasModulePermission('Dashboard', 'view');
      case 'view_assets':
        return (
          hasModulePermission('Materials', 'view') ||
          hasModulePermission('Equipment', 'view') ||
          hasModulePermission('Tools', 'view')
        );
      case 'manage_assets':
        return (
          hasModulePermission('Materials', 'create') ||
          hasModulePermission('Equipment', 'create') ||
          hasModulePermission('Tools', 'create')
        );
      case 'view_workers':
        return hasModulePermission('Workers', 'view');
      case 'manage_workers':
        return hasModulePermission('Workers', 'create') || hasModulePermission('Workers', 'update');
      case 'issue_items':
        return hasModulePermission('Issue', 'create') || hasModulePermission('Issue', 'view');
      case 'return_items':
        return hasModulePermission('Return', 'create') || hasModulePermission('Return', 'view');
      case 'transfer_items':
        return hasModulePermission('Transfer', 'view') || hasModulePermission('Transfer', 'create');
      case 'repair_items':
        return hasModulePermission('Repair', 'view') || hasModulePermission('Repair', 'create');
      case 'report_lost':
        return hasModulePermission('Repair', 'create') || hasModulePermission('Materials', 'update');
      case 'view_reports':
        return hasModulePermission('Reports', 'view');
      case 'export_reports':
        return hasModulePermission('Reports', 'export');
      case 'manage_settings':
        return hasModulePermission('Settings', 'update') || hasModulePermission('Administration', 'update');
      case 'manage_users':
        return hasModulePermission('Administration', 'create') || hasModulePermission('Administration', 'update');
      default:
        return permissionsList.includes(permission);
    }
  };

  return {
    // Current role meta
    currentRole: currentRoleName,
    role: currentRoleName,
    isSuperAdmin,
    isAdmin,
    canEdit,
    isViewer,
    isSupervisor,
    isWorker,
    isAccountActive,

    // Module-level permission evaluators
    hasModulePermission,
    canView: (module: AdminModule) => hasModulePermission(module, 'view'),
    canCreate: (module: AdminModule) => hasModulePermission(module, 'create'),
    canUpdate: (module: AdminModule) => hasModulePermission(module, 'update'),
    canDelete: (module: AdminModule) => hasModulePermission(module, 'delete'),
    canApprove: (module: AdminModule) => hasModulePermission(module, 'approve'),
    canExport: (module: AdminModule) => hasModulePermission(module, 'export'),
    canImport: (module: AdminModule) => hasModulePermission(module, 'import'),

    // Site-level access evaluators
    hasSiteAccess,
    getAllowedSites,
    isAllSitesAccess: isSuperAdmin || Boolean(user?.allSitesAccess),

    // Legacy helpers for complete backward compatibility
    permissions: permissionsList,
    hasPermission,
    canViewDashboard: () => hasModulePermission('Dashboard', 'view'),
    canManageInventory: () => hasModulePermission('Materials', 'create') || hasModulePermission('Equipment', 'create'),
    canViewInventory: () => hasModulePermission('Materials', 'view') || hasModulePermission('Equipment', 'view'),
    canManageWorkers: () => hasModulePermission('Workers', 'create') || hasModulePermission('Workers', 'update'),
    canViewWorkers: () => hasModulePermission('Workers', 'view'),
    canIssueItems: () => hasModulePermission('Issue', 'create') || hasModulePermission('Issue', 'view'),
    canReturnItems: () => hasModulePermission('Return', 'create') || hasModulePermission('Return', 'view'),
    canTransferItems: () => hasModulePermission('Transfer', 'create') || hasModulePermission('Transfer', 'view'),
    canRepairItems: () => hasModulePermission('Repair', 'create') || hasModulePermission('Repair', 'view'),
    canReportLost: () => hasModulePermission('Repair', 'create') || hasModulePermission('Materials', 'update'),
    canViewReports: () => hasModulePermission('Reports', 'view'),
    canExportReports: () => hasModulePermission('Reports', 'export'),
    canManageSettings: () => hasModulePermission('Settings', 'update') || isSuperAdmin,
    canManageUsers: () => hasModulePermission('Administration', 'create') || isSuperAdmin,
  };
}

export default usePermissions;
