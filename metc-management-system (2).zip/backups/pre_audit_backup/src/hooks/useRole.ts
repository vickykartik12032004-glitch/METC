import { useAuthContext } from '../contexts/AuthContext';
import { UserRole } from '../types';

export function useRole() {
  const { role, switchRole, user } = useAuthContext();

  const isSuperAdmin = role === 'Super Admin';
  const isAdmin = role === 'Admin';
  const canEdit = isSuperAdmin || isAdmin;
  const isViewer = !canEdit;

  return {
    role: role as UserRole,
    userRole: role,
    isSuperAdmin,
    isAdmin,
    canEdit,
    isViewer,
    isSupervisor: role === 'Supervisor' || role === 'Site Supervisor',
    isWorker: role === 'Worker' || role === 'User' || role === 'Store Keeper' || role === 'Viewer',
    isStoreKeeper: role === 'Store Keeper',
    isSiteSupervisor: role === 'Site Supervisor' || role === 'Supervisor',
    switchRole,
    user,
  };
}

export default useRole;
