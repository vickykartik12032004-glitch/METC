import { useState, useEffect, useMemo, useCallback } from 'react';
import { useAssetStore } from '../../store/useAssetStore';
import { useTransactionStore } from '../../store/useTransactionStore';
import { useWorkerStore } from '../../store/useWorkerStore';
import {
  DashboardService,
  DashboardKpi,
  ChartDataPoint,
  CategoryDistribution,
  InventoryStatusPoint,
  ActivityItem,
  LowStockItem,
  ExpiringItem,
  RecentIssueRecord,
  SystemNotification,
  WeatherData,
  CompanyMetrics,
} from '../../services/dashboard.service';

export type TimeFilter = 'Today' | 'This Week' | 'This Month' | 'This Year';

export function useDashboard() {
  const [timeFilter, setTimeFilter] = useState<TimeFilter>('This Month');
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [activeKpiCategory, setActiveKpiCategory] = useState<'all' | 'inventory' | 'operations' | 'workforce'>('all');
  const [currentTime, setCurrentTime] = useState<Date>(new Date());

  // Store subscriptions
  const materials = useAssetStore((s) => s.materials);
  const equipment = useAssetStore((s) => s.equipment);
  const tools = useAssetStore((s) => s.tools);
  const consumables = useAssetStore((s) => s.consumables);
  const ppe = useAssetStore((s) => s.ppe);
  const issues = useTransactionStore((s) => s.issues);
  const returns = useTransactionStore((s) => s.returns);
  const repairs = useTransactionStore((s) => s.repairs);
  const lostItems = useTransactionStore((s) => s.lostItems);
  const activitiesStore = useTransactionStore((s) => s.activities);
  const workers = useWorkerStore((s) => s.workers);

  // Clock ticker for real-time header display
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Fetch / Refresh handler
  const handleRefresh = useCallback(() => {
    setIsLoading(true);
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 600);
    return () => clearTimeout(timer);
  }, []);

  // Base Data
  const rawKpis = useMemo(
    () => DashboardService.getKpiCards(),
    [materials, equipment, tools, consumables, ppe, issues, returns, repairs, lostItems, workers]
  );
  const monthlyTrends = useMemo(
    () => DashboardService.getMonthlyTrends(),
    [issues, returns, repairs]
  );
  const categoryDist = useMemo(
    () => DashboardService.getCategoryDistribution(),
    [materials, equipment, tools, consumables, ppe]
  );
  const inventoryStatus = useMemo(
    () => DashboardService.getInventoryStatus(),
    [materials, equipment, tools, consumables, ppe]
  );
  const rawActivities = useMemo(
    () => DashboardService.getRecentActivities(),
    [activitiesStore]
  );
  const rawLowStock = useMemo(
    () => DashboardService.getLowStockItems(),
    [materials, equipment, tools, consumables, ppe]
  );
  const rawExpiring = useMemo(
    () => DashboardService.getExpiringItems(),
    [equipment, ppe]
  );
  const rawRecentIssues = useMemo(
    () => DashboardService.getRecentIssues(),
    [issues]
  );
  const rawNotifications = useMemo(() => DashboardService.getNotifications(), []);
  const weather = useMemo(() => DashboardService.getWeather(), []);
  const company = useMemo(
    () => DashboardService.getCompanySummary(),
    [materials, equipment, tools, consumables, ppe, workers]
  );

  // Filter KPI Cards based on category filter
  const kpiCards = useMemo(() => {
    let filtered = rawKpis;
    if (activeKpiCategory !== 'all') {
      filtered = filtered.filter((k) => k.category === activeKpiCategory);
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      filtered = filtered.filter((k) => k.title.toLowerCase().includes(q));
    }
    return filtered;
  }, [rawKpis, activeKpiCategory, searchQuery]);

  // Filter Activities based on search query
  const activities = useMemo(() => {
    if (!searchQuery.trim()) return rawActivities;
    const q = searchQuery.toLowerCase();
    return rawActivities.filter(
      (a) =>
        a.user.toLowerCase().includes(q) ||
        a.action.toLowerCase().includes(q) ||
        a.target.toLowerCase().includes(q)
    );
  }, [rawActivities, searchQuery]);

  // Filter Low Stock based on search query
  const lowStockItems = useMemo(() => {
    if (!searchQuery.trim()) return rawLowStock;
    const q = searchQuery.toLowerCase();
    return rawLowStock.filter(
      (i) =>
        i.name.toLowerCase().includes(q) ||
        i.code.toLowerCase().includes(q) ||
        i.category.toLowerCase().includes(q)
    );
  }, [rawLowStock, searchQuery]);

  // Filter Recent Issues based on search query
  const recentIssues = useMemo(() => {
    if (!searchQuery.trim()) return rawRecentIssues;
    const q = searchQuery.toLowerCase();
    return rawRecentIssues.filter(
      (i) =>
        i.workerName.toLowerCase().includes(q) ||
        i.itemName.toLowerCase().includes(q) ||
        i.issueCode.toLowerCase().includes(q)
    );
  }, [rawRecentIssues, searchQuery]);

  // Formatted date string
  const formattedDate = useMemo(() => {
    return currentTime.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  }, [currentTime]);

  // Formatted time string
  const formattedTime = useMemo(() => {
    return currentTime.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
    });
  }, [currentTime]);

  return {
    timeFilter,
    setTimeFilter,
    searchQuery,
    setSearchQuery,
    isLoading,
    handleRefresh,
    activeKpiCategory,
    setActiveKpiCategory,
    formattedDate,
    formattedTime,
    kpiCards,
    monthlyTrends,
    categoryDist,
    inventoryStatus,
    activities,
    lowStockItems,
    expiringItems: rawExpiring,
    recentIssues,
    notifications: rawNotifications,
    weather,
    company,
  };
}
