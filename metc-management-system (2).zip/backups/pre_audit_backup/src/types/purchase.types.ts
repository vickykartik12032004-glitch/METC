import { AssetCategory } from './index';

export type PurchaseStatus = 'Draft' | 'Confirmed' | 'Voided';

export type LineItemAction = 'UPDATE_EXISTING' | 'CREATE_NEW' | 'IGNORE';

export type LineItemMatchStatus = 'matched' | 'new_suggestion' | 'unmatched';

export interface InvoiceAttachment {
  fileName: string;
  fileType: string;
  fileSize: number;
  dataUrl?: string; // Base64 data URL for images and PDFs
}

export interface PurchaseLineItem {
  id: string;
  rawDescription: string;
  productCode?: string;
  name: string;
  category: AssetCategory;
  code?: string; // MET number or blank if optional
  quantity: number;
  unit: string;
  unitPrice: number;
  totalPrice: number;
  matchedAssetId?: string;
  matchedAssetCode?: string;
  matchedAssetName?: string;
  action: LineItemAction;
  status: LineItemMatchStatus;
  confidence: number; // 0 to 1 confidence from OCR
  notes?: string;
}

export interface PurchaseAuditEntry {
  timestamp: string;
  user: string;
  action: string;
  note?: string;
}

export interface PurchaseRecord {
  id: string;
  idempotencyKey: string;
  invoiceNumber: string;
  invoiceDate: string;
  purchaseOrderNumber?: string;
  supplierName: string;
  supplierContact?: string;
  currency: string;
  paymentTerms?: string;
  subtotal: number;
  taxRate?: number; // e.g. 9 for 9% GST
  taxAmount: number;
  discountAmount: number;
  freightAmount: number;
  grandTotal: number;
  lineItemsCount: number;
  status: PurchaseStatus;
  invoiceFile?: InvoiceAttachment;
  lineItems: PurchaseLineItem[];
  stockUpdated: boolean;
  createdAt: string;
  updatedAt: string;
  createdByUser: string;
  auditTrail: PurchaseAuditEntry[];
}

export interface ExtractedInvoiceData {
  supplier: {
    name: string;
    contact?: string;
    uenOrTaxNumber?: string;
  };
  invoice: {
    invoiceNumber: string;
    invoiceDate: string;
    purchaseOrderNumber?: string;
    paymentTerms?: string;
    currency: string;
  };
  financials: {
    subtotal: number;
    taxRate?: number;
    taxAmount: number;
    discountAmount: number;
    freightAmount: number;
    grandTotal: number;
  };
  lineItems: Array<{
    description: string;
    productCode?: string;
    quantity: number;
    unit: string;
    unitPrice: number;
    total: number;
    categorySuggestion?: AssetCategory;
    confidence?: number;
  }>;
  rawOcrNotes?: string;
}

export interface InvoiceDiscrepancyCheck {
  hasDiscrepancy: boolean;
  isDuplicateInvoice: boolean;
  existingInvoiceId?: string;
  existingInvoiceDate?: string;
  calculatedLineTotal: number;
  reportedSubtotal: number;
  subtotalDiff: number;
  calculatedGrandTotal: number;
  reportedGrandTotal: number;
  grandTotalDiff: number;
  lowConfidenceRowsCount: number;
  missingValuesRowsCount: number;
  warnings: string[];
}
