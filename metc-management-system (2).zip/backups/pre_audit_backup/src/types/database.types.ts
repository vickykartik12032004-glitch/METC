export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export interface Database {
  public: {
    Tables: {
      roles: {
        Row: {
          id: string;
          name: string;
          description: string | null;
          permissions: Json;
          created_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          description?: string | null;
          permissions?: Json;
          created_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          description?: string | null;
          permissions?: Json;
          created_at?: string;
        };
      };
      departments: {
        Row: {
          id: string;
          code: string;
          name: string;
          manager_name: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          code: string;
          name: string;
          manager_name?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          code?: string;
          name?: string;
          manager_name?: string | null;
          created_at?: string;
        };
      };
      branches: {
        Row: {
          id: string;
          code: string;
          name: string;
          address: string | null;
          city: string | null;
          country: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          code: string;
          name: string;
          address?: string | null;
          city?: string | null;
          country?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          code?: string;
          name?: string;
          address?: string | null;
          city?: string | null;
          country?: string | null;
          created_at?: string;
        };
      };
      sites: {
        Row: {
          id: string;
          code: string;
          name: string;
          branch_id: string | null;
          address: string | null;
          project_manager: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          code: string;
          name: string;
          branch_id?: string | null;
          address?: string | null;
          project_manager?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          code?: string;
          name?: string;
          branch_id?: string | null;
          address?: string | null;
          project_manager?: string | null;
          created_at?: string;
        };
      };
      users: {
        Row: {
          id: string;
          email: string;
          full_name: string;
          phone: string | null;
          role_id: string | null;
          branch_id: string | null;
          status: 'active' | 'inactive' | 'suspended';
          avatar_url: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          email: string;
          full_name: string;
          phone?: string | null;
          role_id?: string | null;
          branch_id?: string | null;
          status?: 'active' | 'inactive' | 'suspended';
          avatar_url?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          email?: string;
          full_name?: string;
          phone?: string | null;
          role_id?: string | null;
          branch_id?: string | null;
          status?: 'active' | 'inactive' | 'suspended';
          avatar_url?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      workers: {
        Row: {
          id: string;
          worker_id: string;
          employee_number: string;
          name: string;
          photo_url: string | null;
          phone: string;
          email: string | null;
          trade: string;
          department_id: string | null;
          company: string | null;
          site_id: string | null;
          status: 'Active' | 'Inactive' | 'On Leave' | 'Terminated';
          joining_date: string | null;
          remarks: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          worker_id: string;
          employee_number: string;
          name: string;
          photo_url?: string | null;
          phone: string;
          email?: string | null;
          trade: string;
          department_id?: string | null;
          company?: string | null;
          site_id?: string | null;
          status?: 'Active' | 'Inactive' | 'On Leave' | 'Terminated';
          joining_date?: string | null;
          remarks?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          worker_id?: string;
          employee_number?: string;
          name?: string;
          photo_url?: string | null;
          phone?: string;
          email?: string | null;
          trade?: string;
          department_id?: string | null;
          company?: string | null;
          site_id?: string | null;
          status?: 'Active' | 'Inactive' | 'On Leave' | 'Terminated';
          joining_date?: string | null;
          remarks?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      suppliers: {
        Row: {
          id: string;
          supplier_code: string | null;
          supplier_name: string;
          contact_person: string | null;
          phone: string | null;
          email: string | null;
          address: string | null;
          remarks: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          supplier_code?: string | null;
          supplier_name: string;
          contact_person?: string | null;
          phone?: string | null;
          email?: string | null;
          address?: string | null;
          remarks?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          supplier_code?: string | null;
          supplier_name?: string;
          contact_person?: string | null;
          phone?: string | null;
          email?: string | null;
          address?: string | null;
          remarks?: string | null;
          created_at?: string;
        };
      };
      metc_categories: {
        Row: {
          id: string;
          code: string;
          name: string;
          description: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          code: string;
          name: string;
          description?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          code?: string;
          name?: string;
          description?: string | null;
          created_at?: string;
        };
      };
      metc_items: {
        Row: {
          id: string;
          asset_id: string;
          category_id: string;
          item_name: string;
          description: string | null;
          brand: string | null;
          model: string | null;
          serial_number: string | null;
          asset_number: string | null;
          qr_code: string | null;
          barcode: string | null;
          unit: string;
          quantity: number;
          minimum_stock: number;
          maximum_stock: number;
          current_stock: number;
          purchase_date: string | null;
          purchase_cost: number | null;
          supplier_id: string | null;
          warranty_expiry: string | null;
          calibration_due: string | null;
          storage_location: string | null;
          rack_number: string | null;
          site_id: string | null;
          photo_url: string | null;
          status: 'Available' | 'Issued' | 'Repair' | 'Lost' | 'Disposed' | 'Inactive' | 'Low Stock' | 'Out of Stock';
          remarks: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          asset_id: string;
          category_id: string;
          item_name: string;
          description?: string | null;
          brand?: string | null;
          model?: string | null;
          serial_number?: string | null;
          asset_number?: string | null;
          qr_code?: string | null;
          barcode?: string | null;
          unit?: string;
          quantity?: number;
          minimum_stock?: number;
          maximum_stock?: number;
          current_stock?: number;
          purchase_date?: string | null;
          purchase_cost?: number | null;
          supplier_id?: string | null;
          warranty_expiry?: string | null;
          calibration_due?: string | null;
          storage_location?: string | null;
          rack_number?: string | null;
          site_id?: string | null;
          photo_url?: string | null;
          status?: 'Available' | 'Issued' | 'Repair' | 'Lost' | 'Disposed' | 'Inactive' | 'Low Stock' | 'Out of Stock';
          remarks?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          asset_id?: string;
          category_id?: string;
          item_name?: string;
          description?: string | null;
          brand?: string | null;
          model?: string | null;
          serial_number?: string | null;
          asset_number?: string | null;
          qr_code?: string | null;
          barcode?: string | null;
          unit?: string;
          quantity?: number;
          minimum_stock?: number;
          maximum_stock?: number;
          current_stock?: number;
          purchase_date?: string | null;
          purchase_cost?: number | null;
          supplier_id?: string | null;
          warranty_expiry?: string | null;
          calibration_due?: string | null;
          storage_location?: string | null;
          rack_number?: string | null;
          site_id?: string | null;
          photo_url?: string | null;
          status?: 'Available' | 'Issued' | 'Repair' | 'Lost' | 'Disposed' | 'Inactive' | 'Low Stock' | 'Out of Stock';
          remarks?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      item_documents: {
        Row: {
          id: string;
          item_id: string;
          title: string;
          file_url: string;
          file_type: string | null;
          uploaded_by: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          item_id: string;
          title: string;
          file_url: string;
          file_type?: string | null;
          uploaded_by?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          item_id?: string;
          title?: string;
          file_url?: string;
          file_type?: string | null;
          uploaded_by?: string | null;
          created_at?: string;
        };
      };
      issue_transactions: {
        Row: {
          id: string;
          issue_number: string;
          worker_id: string;
          item_id: string;
          quantity: number;
          issue_date: string;
          expected_return: string | null;
          purpose: string | null;
          site_id: string | null;
          issued_by: string | null;
          status: 'Active' | 'Returned' | 'Partially Returned' | 'Overdue' | 'Lost';
          remarks: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          issue_number: string;
          worker_id: string;
          item_id: string;
          quantity?: number;
          issue_date?: string;
          expected_return?: string | null;
          purpose?: string | null;
          site_id?: string | null;
          issued_by?: string | null;
          status?: 'Active' | 'Returned' | 'Partially Returned' | 'Overdue' | 'Lost';
          remarks?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          issue_number?: string;
          worker_id?: string;
          item_id?: string;
          quantity?: number;
          issue_date?: string;
          expected_return?: string | null;
          purpose?: string | null;
          site_id?: string | null;
          issued_by?: string | null;
          status?: 'Active' | 'Returned' | 'Partially Returned' | 'Overdue' | 'Lost';
          remarks?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      return_transactions: {
        Row: {
          id: string;
          return_number: string;
          issue_id: string;
          item_id: string;
          worker_id: string | null;
          return_date: string;
          quantity_returned: number;
          condition: 'Good' | 'Damaged' | 'Needs Repair' | 'Lost';
          remarks: string | null;
          returned_by: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          return_number: string;
          issue_id: string;
          item_id: string;
          worker_id?: string | null;
          return_date?: string;
          quantity_returned?: number;
          condition?: 'Good' | 'Damaged' | 'Needs Repair' | 'Lost';
          remarks?: string | null;
          returned_by?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          return_number?: string;
          issue_id?: string;
          item_id?: string;
          worker_id?: string | null;
          return_date?: string;
          quantity_returned?: number;
          condition?: 'Good' | 'Damaged' | 'Needs Repair' | 'Lost';
          remarks?: string | null;
          returned_by?: string | null;
          created_at?: string;
        };
      };
      transfer_transactions: {
        Row: {
          id: string;
          transfer_number: string;
          item_id: string;
          quantity: number;
          from_site_id: string | null;
          to_site_id: string | null;
          from_worker_id: string | null;
          to_worker_id: string | null;
          transfer_date: string;
          remarks: string | null;
          initiated_by: string | null;
          status: 'Pending' | 'In Transit' | 'Completed' | 'Cancelled';
          created_at: string;
        };
        Insert: {
          id?: string;
          transfer_number: string;
          item_id: string;
          quantity?: number;
          from_site_id?: string | null;
          to_site_id?: string | null;
          from_worker_id?: string | null;
          to_worker_id?: string | null;
          transfer_date?: string;
          remarks?: string | null;
          initiated_by?: string | null;
          status?: 'Pending' | 'In Transit' | 'Completed' | 'Cancelled';
          created_at?: string;
        };
        Update: {
          id?: string;
          transfer_number?: string;
          item_id?: string;
          quantity?: number;
          from_site_id?: string | null;
          to_site_id?: string | null;
          from_worker_id?: string | null;
          to_worker_id?: string | null;
          transfer_date?: string;
          remarks?: string | null;
          initiated_by?: string | null;
          status?: 'Pending' | 'In Transit' | 'Completed' | 'Cancelled';
          created_at?: string;
        };
      };
      repair_transactions: {
        Row: {
          id: string;
          repair_number: string;
          item_id: string;
          vendor: string | null;
          repair_cost: number | null;
          issue_date: string;
          expected_completion: string | null;
          completed_date: string | null;
          repair_status: 'Scheduled' | 'In Repair' | 'Repaired' | 'Beyond Repair' | 'Cancelled';
          fault_description: string;
          remarks: string | null;
          handled_by: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          repair_number: string;
          item_id: string;
          vendor?: string | null;
          repair_cost?: number | null;
          issue_date?: string;
          expected_completion?: string | null;
          completed_date?: string | null;
          repair_status?: 'Scheduled' | 'In Repair' | 'Repaired' | 'Beyond Repair' | 'Cancelled';
          fault_description: string;
          remarks?: string | null;
          handled_by?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          repair_number?: string;
          item_id?: string;
          vendor?: string | null;
          repair_cost?: number | null;
          issue_date?: string;
          expected_completion?: string | null;
          completed_date?: string | null;
          repair_status?: 'Scheduled' | 'In Repair' | 'Repaired' | 'Beyond Repair' | 'Cancelled';
          fault_description?: string;
          remarks?: string | null;
          handled_by?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      lost_transactions: {
        Row: {
          id: string;
          lost_number: string;
          item_id: string;
          worker_id: string | null;
          quantity_lost: number;
          lost_date: string;
          reason: string;
          investigation_notes: string | null;
          recovered: boolean;
          estimated_value: number | null;
          action_taken: 'Worker Charged' | 'Company Absorbed' | 'Under Investigation' | 'Insurance Claim' | null;
          reported_by: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          lost_number: string;
          item_id: string;
          worker_id?: string | null;
          quantity_lost?: number;
          lost_date?: string;
          reason: string;
          investigation_notes?: string | null;
          recovered?: boolean;
          estimated_value?: number | null;
          action_taken?: 'Worker Charged' | 'Company Absorbed' | 'Under Investigation' | 'Insurance Claim' | null;
          reported_by?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          lost_number?: string;
          item_id?: string;
          worker_id?: string | null;
          quantity_lost?: number;
          lost_date?: string;
          reason?: string;
          investigation_notes?: string | null;
          recovered?: boolean;
          estimated_value?: number | null;
          action_taken?: 'Worker Charged' | 'Company Absorbed' | 'Under Investigation' | 'Insurance Claim' | null;
          reported_by?: string | null;
          created_at?: string;
        };
      };
      stock_adjustments: {
        Row: {
          id: string;
          adjustment_number: string;
          item_id: string;
          quantity_change: number;
          new_quantity: number;
          reason: string;
          created_by: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          adjustment_number: string;
          item_id: string;
          quantity_change: number;
          new_quantity: number;
          reason: string;
          created_by?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          adjustment_number?: string;
          item_id?: string;
          quantity_change?: number;
          new_quantity?: number;
          reason?: string;
          created_by?: string | null;
          created_at?: string;
        };
      };
      notifications: {
        Row: {
          id: string;
          title: string;
          message: string;
          priority: 'info' | 'warning' | 'danger' | 'success' | 'error';
          read_status: boolean;
          user_id: string | null;
          link: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          title: string;
          message: string;
          priority?: 'info' | 'warning' | 'danger' | 'success' | 'error';
          read_status?: boolean;
          user_id?: string | null;
          link?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          title?: string;
          message?: string;
          priority?: 'info' | 'warning' | 'danger' | 'success' | 'error';
          read_status?: boolean;
          user_id?: string | null;
          link?: string | null;
          created_at?: string;
        };
      };
      activity_logs: {
        Row: {
          id: string;
          user_id: string | null;
          user_name: string | null;
          action: string;
          table_name: string;
          record_id: string | null;
          details: Json;
          ip_address: string | null;
          timestamp: string;
        };
        Insert: {
          id?: string;
          user_id?: string | null;
          user_name?: string | null;
          action: string;
          table_name: string;
          record_id?: string | null;
          details?: Json;
          ip_address?: string | null;
          timestamp?: string;
        };
        Update: {
          id?: string;
          user_id?: string | null;
          user_name?: string | null;
          action?: string;
          table_name?: string;
          record_id?: string | null;
          details?: Json;
          ip_address?: string | null;
          timestamp?: string;
        };
      };
      settings: {
        Row: {
          id: string;
          company_name: string;
          logo_url: string | null;
          theme: 'light' | 'dark' | 'system';
          currency: string;
          timezone: string;
          tagline: string | null;
          hq_address: string | null;
          corporate_email: string | null;
          updated_at: string;
        };
        Insert: {
          id?: string;
          company_name?: string;
          logo_url?: string | null;
          theme?: 'light' | 'dark' | 'system';
          currency?: string;
          timezone?: string;
          tagline?: string | null;
          hq_address?: string | null;
          corporate_email?: string | null;
          updated_at?: string;
        };
        Update: {
          id?: string;
          company_name?: string;
          logo_url?: string | null;
          theme?: 'light' | 'dark' | 'system';
          currency?: string;
          timezone?: string;
          tagline?: string | null;
          hq_address?: string | null;
          corporate_email?: string | null;
          updated_at?: string;
        };
      };
    };
    Views: {
      [_ in never]: never;
    };
    Functions: {
      [_ in never]: never;
    };
    Enums: {
      [_ in never]: never;
    };
  };
}
