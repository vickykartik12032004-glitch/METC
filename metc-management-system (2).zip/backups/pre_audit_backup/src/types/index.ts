export type UserRole = 'Super Admin' | 'Admin' | 'Supervisor' | 'Worker' | 'Store Keeper' | 'Site Supervisor' | 'User' | 'Viewer';

export interface UserSession {
  token: string;
  sessionId: string;
  userId: string;
  email: string;
  role: UserRole;
  issuedAt: number;
  expiresAt: number;
  rememberMe: boolean;
}

export interface ItemDocument {
  id: string;
  item_id: string;
  title: string;
  file_url: string;
  file_type?: string;
  uploaded_by?: string;
  created_at: string;
}

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  avatar?: string;
  department?: string;
  phone?: string;
  projectSite?: string;
  assignedSites?: string[];
  allSitesAccess?: boolean;
  accountStatus?: 'Active' | 'Inactive' | 'Locked' | 'Deactivated';
  passwordHash?: string;
  passwordSalt?: string;
  lastLogin?: string;
  createdAt: string;
}

export type AssetCategory = 'Material' | 'Equipment' | 'Tool' | 'Consumable' | 'PPE';

export type AssetStatus = 
  | 'Available' 
  | 'Issued' 
  | 'In Transit' 
  | 'Under Repair' 
  | 'Lost' 
  | 'Low Stock' 
  | 'Out of Stock' 
  | 'Decommissioned'
  | 'Repair'
  | 'Disposed'
  | 'Inactive';

export interface BaseAsset {
  id: string;
  code: string; // e.g., MAT-101, EQP-202, TOL-303, CON-404
  name: string;
  category: AssetCategory;
  description?: string;
  unit: string; // e.g., Kg, Bags, Units, Sets, Meters, Liters
  quantity: number;
  minQuantityThreshold?: number;
  availableQuantity: number;
  location: string; // Site/Warehouse location
  status: AssetStatus;
  unitPrice?: number;
  totalValue?: number;
  supplier?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Material extends BaseAsset {
  category: 'Material';
  materialGrade?: string;
  batchNumber?: string;
  storageConditions?: string;
}

export interface Equipment extends BaseAsset {
  category: 'Equipment';
  serialNumber: string;
  modelNumber?: string;
  manufacturer?: string;
  powerSource?: string;
  lastMaintenanceDate?: string;
  nextMaintenanceDate?: string;
}

export interface Tool extends BaseAsset {
  category: 'Tool';
  brand?: string;
  condition: 'New' | 'Good' | 'Fair' | 'Requires Service';
  assignedBox?: string;
}

export interface Consumable extends BaseAsset {
  category: 'Consumable';
  expiryDate?: string;
  reorderLevel: number;
}

export interface PPEItem extends BaseAsset {
  category: 'PPE';
  size?: string;
  safetyStandard?: string; // e.g. ANSI Z87.1, EN 397, ISO 20345
  inspectionDueDate?: string;
}

export type METCItem = Material | Equipment | Tool | Consumable | PPEItem;

export interface Worker {
  id: string;
  workerCode: string; // e.g. WRK-001
  name: string;
  trade: string; // e.g., Electrician, Mason, Carpenter, Welder, Pipefitter, Safety Officer
  phone: string;
  email?: string;
  projectSite: string; // e.g., Tower A, Metro Line 3, Bridge West
  site?: string;
  department?: string;
  branch?: string;
  employeeNumber?: string;
  company?: string;
  photoUrl?: string;
  status: 'Active' | 'Inactive' | 'On Leave' | 'Terminated' | 'Resigned';
  badgeNumber: string;
  wpId?: string;
  assignedItemsCount: number;
  overdueItemsCount?: number;
  joinedDate: string;
  joiningDate?: string;
  remarks?: string;
  createdAt?: string;
  updatedAt?: string;
  documents?: any[];
}

export interface IssueRecord {
  id: string;
  issueCode: string;
  itemId: string;
  itemName: string;
  itemCategory: AssetCategory;
  workerId: string;
  workerName: string;
  quantity: number;
  issueDate: string;
  expectedReturnDate?: string;
  projectSite: string;
  issuedBy: string; // User Name
  remarks?: string;
  status: 'Active' | 'Returned' | 'Overdue' | 'Partially Returned' | 'Lost';
}

export interface ReturnRecord {
  id: string;
  returnCode: string;
  issueId: string;
  issueCode?: string; // added
  itemId: string;
  itemName: string;
  workerId: string;
  workerName: string;
  department?: string; // added
  site?: string; // added
  assetId?: string; // added
  serialNumber?: string; // added
  quantityReturned: number;
  returnDate: string;
  conditionOnReturn: 'Good' | 'Damaged' | 'Needs Repair' | 'Repair Required' | 'Lost' | 'Disposed' | 'Missing Accessories' | 'Partial Return';
  receivedBy: string; // returned by (user)
  notes?: string;
  photos?: string[]; // added
  signature?: string; // added
  status?: 'Completed' | 'Pending'; // added
}

export interface TransferRecord {
  id: string;
  transferCode: string;
  transferType?: 'Worker to Worker' | 'Worker to Store' | 'Store to Worker' | 'Site to Site' | 'Branch to Branch' | 'Store to Site' | 'Site to Store';
  itemId: string;
  itemName: string;
  itemCategory?: string;
  assetId?: string;
  serialNumber?: string;
  quantity: number;
  
  fromLocation: string;
  toLocation: string;
  fromWorkerId?: string;
  fromWorkerName?: string;
  toWorkerId?: string;
  toWorkerName?: string;
  fromSite?: string;
  toSite?: string;
  fromBranch?: string;
  toBranch?: string;

  reason?: string;
  priority?: 'Low' | 'Medium' | 'High' | 'Critical';
  expectedCompletionDate?: string;
  remarks?: string;
  photoAttachment?: string;

  transferDate: string;
  initiatedBy: string;
  
  supervisorApproval?: string;
  storeKeeperApproval?: string;
  adminApproval?: string;
  approvedBy?: string;
  approvedAt?: string;
  
  status: 'Pending' | 'In Transit' | 'Completed' | 'Rejected' | 'Cancelled';
  notes?: string;
}

export interface RepairRecord {
  id: string;
  repairCode: string;
  repairDate?: string;
  createdBy?: string;
  itemId: string;
  itemName: string;
  assetId?: string;
  serialNumber?: string;
  serialOrTag?: string; // backwards compatibility
  currentHolder?: string;
  site?: string;
  repairType?: 'Corrective' | 'Preventive' | 'Calibration' | 'Inspection' | 'Warranty Repair' | 'Emergency Repair';
  repairPriority?: 'Low' | 'Medium' | 'High' | 'Critical';
  issueDescription: string;
  photoUrl?: string;
  videoUrl?: string;
  estimatedCost?: number;
  repairVendor?: string;
  sentDate: string;
  expectedCompletionDate?: string;
  estimatedReturnDate?: string; // backwards compatibility
  actualReturnDate?: string;
  repairCost?: number;
  remarks?: string;
  status: 'Pending' | 'Approved' | 'Assigned' | 'In Progress' | 'Waiting Parts' | 'Completed' | 'Rejected' | 'Cancelled' | 'Scheduled' | 'In Repair' | 'Repaired' | 'Beyond Repair';
  handledBy: string;
}

export interface LostItemRecord {
  id: string;
  lostCode: string;
  incidentCode?: string;
  itemId: string;
  itemName: string;
  workerId?: string;
  workerName?: string;
  quantityLost: number;
  reportedDate: string;
  location: string;
  estimatedValue: number;
  incidentDetails: string;
  policeReportUrl?: string;
  recovered?: boolean;
  recoveryDate?: string;
  recoveryNotes?: string;
  actionTaken: 'Worker Charged' | 'Company Absorbed' | 'Under Investigation' | 'Insurance Claim';
  status: 'Reported' | 'Closed' | 'Pending Review';
  reportedBy: string;
}

export interface MaintenanceRecord {
  id: string;
  maintenanceCode: string;
  itemId: string;
  itemName: string;
  frequency: 'Weekly' | 'Monthly' | 'Quarterly' | 'Half Yearly' | 'Yearly';
  lastMaintenance?: string;
  nextMaintenance: string;
  responsiblePerson: string;
  calibrationDue?: boolean;
  calibrationCertificateUrl?: string;
  calibrationVendor?: string;
  status: 'Scheduled' | 'Completed' | 'Overdue';
}

export interface DisposalRecord {
  id: string;
  disposalCode: string;
  itemId: string;
  itemName: string;
  reason: string;
  approvedBy: string;
  disposalDate: string;
  disposalValue?: number;
  certificateUrl?: string;
  status: 'Pending' | 'Approved' | 'Disposed';
}

export interface VendorRecord {
  id: string;
  vendorName: string;
  phone: string;
  email: string;
  address: string;
  rating?: number;
  status: 'Active' | 'Inactive';
}

export interface ActivityLog {
  id: string;
  action: 'Created' | 'Issued' | 'Returned' | 'Transferred' | 'Sent for Repair' | 'Reported Lost' | 'Updated' | 'Stock Received' | 'Purchase Voided' | 'Purchase Deleted';
  targetType: 'Asset' | 'Worker' | 'User' | 'System' | 'Purchase Record';
  targetName: string;
  user: string;
  timestamp: string;
  details: string;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'warning' | 'danger' | 'success' | 'error';
  createdAt: string;
  timestamp?: string;
  read: boolean;
  link?: string;
}

export interface SystemSettings {
  companyName: string;
  defaultCurrency: string;
  lowStockAlertEmail: boolean;
  overdueItemReminderDays: number;
  enableAutoBarcode: boolean;
  themeMode: 'light' | 'dark' | 'system';
}

export type Permission = 
  | 'view_dashboard'
  | 'manage_assets'
  | 'view_assets'
  | 'manage_workers'
  | 'view_workers'
  | 'issue_items'
  | 'return_items'
  | 'transfer_items'
  | 'repair_items'
  | 'report_lost'
  | 'view_reports'
  | 'export_reports'
  | 'manage_settings'
  | 'manage_users';

export interface StockAdjustment {
  id: string;
  adjustmentCode: string;
  itemId: string;
  itemName: string;
  itemCode: string;
  category: AssetCategory;
  previousQuantity: number;
  newQuantity: number;
  difference: number;
  reason: string;
  user: string;
  timestamp: string;
  location?: string;
  remarks?: string;
}

export type StocktakingItemStatus = 'Not Counted' | 'In Progress' | 'Counted' | 'Needs Review';

export interface StocktakingItem {
  itemId: string;
  itemCode: string;
  itemName: string;
  category: AssetCategory;
  location: string;
  expectedQuantity: number;
  countedQuantity?: number;
  difference?: number;
  status: StocktakingItemStatus;
  reason?: string;
  countedAt?: string;
  countedBy?: string;
  remarks?: string;
}

export interface StocktakingSession {
  id: string;
  sessionCode: string;
  title: string;
  categories: AssetCategory[];
  locations: string[];
  status: 'Draft' | 'In Progress' | 'Completed';
  startedAt: string;
  completedAt?: string;
  createdBy: string;
  items: StocktakingItem[];
  totalExpected?: number;
  totalCounted?: number;
  totalDiscrepancies?: number;
  notes?: string;
}

export interface SiteIssueItem {
  itemId: string;
  itemCode: string;
  itemName: string;
  category: AssetCategory;
  unit: string;
  requestedQuantity: number;
  issuedQuantity: number;
  returnedQuantity: number;
  damagedQuantity: number;
  missingQuantity: number;
  isReusable: boolean;
  status: 'Issued' | 'Partially Returned' | 'Returned' | 'Consumed';
}

export interface SiteReturnItem {
  itemId: string;
  itemName: string;
  itemCode: string;
  category: AssetCategory;
  returnQty: number;
  workingQty: number;
  damagedQty: number;
  missingQty: number;
  condition: string;
  remarks?: string;
}

export interface SiteReturnRecord {
  id: string;
  returnCode: string;
  issueId: string;
  issueReference: string;
  site: string;
  supervisorName: string;
  returnDate: string;
  receivedBy: string;
  remarks?: string;
  items: SiteReturnItem[];
}

export interface SiteIssueTransaction {
  id: string;
  reference: string;
  site: string;
  supervisorId: string;
  supervisorName: string;
  issuer: string;
  date: string;
  expectedReturnDate?: string;
  remarks?: string;
  status: 'Active' | 'Partially Returned' | 'Completed';
  items: SiteIssueItem[];
  returnHistory?: SiteReturnRecord[];
  createdAt: string;
  updatedAt: string;
}

export * from './access.types';

