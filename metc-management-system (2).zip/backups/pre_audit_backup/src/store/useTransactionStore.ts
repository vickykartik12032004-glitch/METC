import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { 
  INITIAL_ACTIVITIES, 
  INITIAL_ISSUES, 
  INITIAL_LOST, 
  INITIAL_REPAIRS, 
  INITIAL_RETURNS, 
  INITIAL_TRANSFERS 
} from '../data/mockData';
import { 
  ActivityLog, 
  IssueRecord, 
  LostItemRecord, 
  RepairRecord, 
  ReturnRecord, 
  TransferRecord 
} from '../types';
import { cloudApi } from '../services/apiClient';

interface TransactionStore {
  issues: IssueRecord[];
  returns: ReturnRecord[];
  transfers: TransferRecord[];
  repairs: RepairRecord[];
  lostItems: LostItemRecord[];
  activities: ActivityLog[];

  // Mutators
  addIssue: (record: Omit<IssueRecord, 'id' | 'issueCode' | 'status'>) => Promise<IssueRecord>;
  updateIssueStatus: (id: string, status: IssueRecord['status']) => void;

  addReturn: (record: Omit<ReturnRecord, 'id' | 'returnCode'>) => Promise<ReturnRecord>;

  addTransfer: (record: Omit<TransferRecord, 'id' | 'transferCode' | 'status'>) => Promise<TransferRecord>;
  updateTransferStatus: (id: string, status: TransferRecord['status']) => Promise<void>;

  addRepair: (record: Omit<RepairRecord, 'id' | 'repairCode'>) => Promise<RepairRecord>;
  updateRepairStatus: (id: string, status: RepairRecord['status']) => Promise<void>;

  addLostItem: (record: Omit<LostItemRecord, 'id' | 'lostCode'>) => Promise<LostItemRecord>;
  updateLostItemStatus: (id: string, status: LostItemRecord['status']) => void;

  addActivity: (activity: Omit<ActivityLog, 'id' | 'timestamp'>) => void;
  clearAllTransactions: (skipCloud?: boolean) => Promise<void>;

  // Real-time Cloud Sync Ingestion Handlers
  syncAllTransactions: (data: {
    issues?: IssueRecord[];
    returns?: ReturnRecord[];
    transfers?: TransferRecord[];
    repairs?: RepairRecord[];
    lostItems?: LostItemRecord[];
    activities?: ActivityLog[];
  }) => void;
  applyRemoteTransactionCreated: (type: string, record: any) => void;
  applyRemoteTransactionUpdated: (type: string, id: string, status: any, record?: any) => void;
  applyRemoteActivityLogged: (log: ActivityLog) => void;
}

export const useTransactionStore = create<TransactionStore>()(
  persist(
    (set, get) => ({
      issues: [],
      returns: [],
      transfers: [],
      repairs: [],
      lostItems: [],
      activities: [],

      addIssue: async (record) => {
        const tempId = `iss-${Date.now()}`;
        const newIssue: IssueRecord = {
          ...record,
          id: tempId,
          issueCode: `ISS-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`,
          status: 'Active',
        };
        set((state) => ({ issues: [newIssue, ...state.issues] }));

        try {
          const res = await cloudApi.createIssue(newIssue);
          if (res.data?.issue) {
            set((state) => ({
              issues: state.issues.map((i) => (i.id === tempId ? res.data.issue : i)),
            }));
            return res.data.issue;
          }
        } catch (err) {
          console.error('Failed to sync issue with cloud database:', err);
        }
        return newIssue;
      },

      updateIssueStatus: (id, status) => {
        set((state) => ({
          issues: state.issues.map((i) => (i.id === id ? { ...i, status } : i)),
        }));
      },

      addReturn: async (record) => {
        const tempId = `ret-${Date.now()}`;
        const newReturn: ReturnRecord = {
          ...record,
          id: tempId,
          returnCode: `RET-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`,
        };
        set((state) => ({ returns: [newReturn, ...state.returns] }));

        try {
          const res = await cloudApi.createReturn(newReturn);
          if (res.data?.returnRecord) {
            set((state) => ({
              returns: state.returns.map((r) => (r.id === tempId ? res.data.returnRecord : r)),
            }));
            return res.data.returnRecord;
          }
        } catch (err) {
          console.error('Failed to sync return with cloud database:', err);
        }
        return newReturn;
      },

      addTransfer: async (record) => {
        const tempId = `trf-${Date.now()}`;
        const newTransfer: TransferRecord = {
          ...record,
          id: tempId,
          transferCode: `TRF-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`,
          status: 'Pending',
        };
        set((state) => ({ transfers: [newTransfer, ...state.transfers] }));

        try {
          const res = await cloudApi.createTransfer(newTransfer);
          if (res.data) {
            set((state) => ({
              transfers: state.transfers.map((t) => (t.id === tempId ? res.data : t)),
            }));
            return res.data;
          }
        } catch (err) {
          console.error('Failed to sync transfer:', err);
        }
        return newTransfer;
      },

      updateTransferStatus: async (id, status) => {
        set((state) => ({
          transfers: state.transfers.map((t) => (t.id === id ? { ...t, status } : t)),
        }));
        try {
          await cloudApi.updateTransferStatus(id, status);
        } catch (err) {
          console.error(`Failed to update transfer status for ${id}:`, err);
        }
      },

      addRepair: async (record) => {
        const tempId = `rep-${Date.now()}`;
        const newRepair: RepairRecord = {
          ...record,
          id: tempId,
          repairCode: `REP-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`,
        };
        set((state) => ({ repairs: [newRepair, ...state.repairs] }));

        try {
          const res = await cloudApi.createRepair(newRepair);
          if (res.data) {
            set((state) => ({
              repairs: state.repairs.map((r) => (r.id === tempId ? res.data : r)),
            }));
            return res.data;
          }
        } catch (err) {
          console.error('Failed to sync repair:', err);
        }
        return newRepair;
      },

      updateRepairStatus: async (id, status) => {
        set((state) => ({
          repairs: state.repairs.map((r) => (r.id === id ? { ...r, status } : r)),
        }));
        try {
          await cloudApi.updateRepairStatus(id, status);
        } catch (err) {
          console.error(`Failed to update repair status for ${id}:`, err);
        }
      },

      addLostItem: async (record) => {
        const tempId = `lst-${Date.now()}`;
        const newLost: LostItemRecord = {
          ...record,
          id: tempId,
          lostCode: `LST-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`,
        };
        set((state) => ({ lostItems: [newLost, ...state.lostItems] }));

        try {
          const res = await cloudApi.createLostItem(newLost);
          if (res.data) {
            set((state) => ({
              lostItems: state.lostItems.map((l) => (l.id === tempId ? res.data : l)),
            }));
            return res.data;
          }
        } catch (err) {
          console.error('Failed to sync lost item record:', err);
        }
        return newLost;
      },

      updateLostItemStatus: (id, status) => {
        set((state) => ({
          lostItems: state.lostItems.map((l) => (l.id === id ? { ...l, status } : l)),
        }));
      },

      addActivity: async (activity) => {
        const newAct: ActivityLog = {
          ...activity,
          id: `act-${Date.now()}`,
          timestamp: new Date().toISOString(),
        };
        set((state) => ({ activities: [newAct, ...state.activities] }));
        try {
          await cloudApi.logActivity(activity);
        } catch (err) {
          // silent fallback
        }
      },

      clearAllTransactions: async (skipCloud?: boolean) => {
        set({
          issues: [],
          returns: [],
          transfers: [],
          repairs: [],
          lostItems: [],
          activities: [],
        });
        if (!skipCloud) {
          try {
            await cloudApi.clearAllTransactions();
          } catch (err) {
            console.warn('[TransactionStore] Failed to clear cloud transactions:', err);
          }
        }
      },

      // ==========================
      // REAL-TIME CLOUD INGESTION
      // ==========================
      syncAllTransactions: (data) => {
        set((state) => ({
          issues: data.issues || state.issues,
          returns: data.returns || state.returns,
          transfers: data.transfers || state.transfers,
          repairs: data.repairs || state.repairs,
          lostItems: data.lostItems || state.lostItems,
          activities: data.activities || state.activities,
        }));
      },

      applyRemoteTransactionCreated: (type, record) => {
        const t = (type || '').toUpperCase();
        set((state) => {
          if (t === 'ISSUE') {
            if (state.issues.some((i) => i.id === record.id)) return state;
            return { issues: [record, ...state.issues] };
          }
          if (t === 'RETURN') {
            if (state.returns.some((r) => r.id === record.id)) return state;
            return { returns: [record, ...state.returns] };
          }
          if (t === 'TRANSFER') {
            if (state.transfers.some((tr) => tr.id === record.id)) return state;
            return { transfers: [record, ...state.transfers] };
          }
          if (t === 'REPAIR') {
            if (state.repairs.some((rep) => rep.id === record.id)) return state;
            return { repairs: [record, ...state.repairs] };
          }
          if (t === 'LOST') {
            if (state.lostItems.some((l) => l.id === record.id)) return state;
            return { lostItems: [record, ...state.lostItems] };
          }
          return state;
        });
      },

      applyRemoteTransactionUpdated: (type, id, status, record) => {
        const t = (type || '').toUpperCase();
        set((state) => {
          if (t === 'TRANSFER') {
            return {
              transfers: state.transfers.map((tr) =>
                tr.id === id ? { ...tr, ...(record || {}), status } : tr
              ),
            };
          }
          if (t === 'REPAIR') {
            return {
              repairs: state.repairs.map((r) =>
                r.id === id ? { ...r, ...(record || {}), status } : r
              ),
            };
          }
          if (t === 'ISSUE') {
            return {
              issues: state.issues.map((i) =>
                i.id === id ? { ...i, ...(record || {}), status } : i
              ),
            };
          }
          if (t === 'LOST') {
            return {
              lostItems: state.lostItems.map((l) =>
                l.id === id ? { ...l, ...(record || {}), status } : l
              ),
            };
          }
          return state;
        });
      },

      applyRemoteActivityLogged: (log) => {
        set((state) => {
          if (state.activities.some((a) => a.id === log.id)) return state;
          return { activities: [log, ...state.activities.slice(0, 499)] };
        });
      },
    }),
    {
      name: 'metc-transactions-cloud-storage',
      version: 2,
      migrate: (persistedState: any, version: number) => {
        const state = persistedState as any;
        if (version < 2 || !state) {
          return {
            ...state,
            issues: [],
            returns: [],
            transfers: [],
            repairs: [],
            lostItems: [],
            activities: [],
          };
        }
        return state;
      },
    }
  )
);
