import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import {
  AppNotification,
  EmailTemplate,
  EmailQueueItem,
  PushQueueItem,
  ReminderRule,
  EscalationRule,
  NotificationHistoryItem,
  NotificationSettingsState,
  NotificationPriority,
  NotificationModule
} from '../features/notifications/types';
import {
  INITIAL_EMAIL_TEMPLATES,
  INITIAL_REMINDER_RULES,
  INITIAL_ESCALATION_RULES,
  INITIAL_NOTIFICATION_SETTINGS,
  INITIAL_APP_NOTIFICATIONS,
  INITIAL_NOTIFICATION_HISTORY
} from '../features/notifications/data/initialNotificationData';

interface NotificationStoreState {
  notifications: AppNotification[];
  emailTemplates: EmailTemplate[];
  emailQueue: EmailQueueItem[];
  pushQueue: PushQueueItem[];
  reminderRules: ReminderRule[];
  escalationRules: EscalationRule[];
  history: NotificationHistoryItem[];
  settings: NotificationSettingsState;

  // Actions
  addNotification: (notification: Partial<AppNotification> & { title: string; message: string }) => void;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  deleteNotification: (id: string) => void;
  archiveNotification: (id: string) => void;
  pinNotification: (id: string) => void;
  clearAll: () => void;

  // Queue actions
  syncAllNotifications: (notifications: any[]) => void;
  addEmailToQueue: (item: EmailQueueItem) => void;
  addPushToQueue: (item: PushQueueItem) => void;
  clearQueues: () => void;

  // Templates
  updateEmailTemplate: (id: string, updated: Partial<EmailTemplate>) => void;
  resetTemplatesToDefault: () => void;

  // Rules
  addReminderRule: (rule: ReminderRule) => void;
  toggleReminderRule: (id: string) => void;
  deleteReminderRule: (id: string) => void;

  addEscalationRule: (rule: EscalationRule) => void;
  toggleEscalationRule: (id: string) => void;
  deleteEscalationRule: (id: string) => void;

  // Settings
  updateSettings: (newSettings: Partial<NotificationSettingsState>) => void;
  toggleModuleSetting: (module: keyof NotificationSettingsState['modules']) => void;
  toggleChannelSetting: (channel: keyof NotificationSettingsState['channels']) => void;

  // History
  addHistoryItem: (item: NotificationHistoryItem) => void;
  clearHistory: () => void;
}

export const useNotificationStore = create<NotificationStoreState>()(
  persist(
    (set, get) => ({
      notifications: INITIAL_APP_NOTIFICATIONS,
      emailTemplates: INITIAL_EMAIL_TEMPLATES,
      emailQueue: [
        {
          id: 'email-q1',
          templateCode: 'LOW_STOCK_ALERT',
          recipientEmail: 'purchasing@mountec.sg',
          recipientName: 'Store Keeper',
          subject: 'MOUNTEC PTE LTD: Low Stock Alert - Ready-Mix Concrete M30',
          bodyHtml: '<p>Current stock 5 cu.m is below threshold 50 cu.m.</p>',
          status: 'Sent',
          createdAt: new Date(Date.now() - 3600000).toISOString(),
          sentAt: new Date(Date.now() - 3500000).toISOString()
        }
      ],
      pushQueue: [
        {
          id: 'push-q1',
          title: 'Overdue Asset Warning',
          message: 'Bosch Rotary Hammer Drill overdue by 4 days (Jean-Pierre Dubois)',
          targetRoles: ['Supervisor', 'Admin'],
          status: 'Delivered',
          createdAt: new Date(Date.now() - 7200000).toISOString(),
          deliveredAt: new Date(Date.now() - 7100000).toISOString(),
          retryCount: 0
        }
      ],
      reminderRules: INITIAL_REMINDER_RULES,
      escalationRules: INITIAL_ESCALATION_RULES,
      history: INITIAL_NOTIFICATION_HISTORY,
      settings: INITIAL_NOTIFICATION_SETTINGS,

      // In-App Notification handlers
      addNotification: (rawNotif) => {
        set((state) => {
          const now = new Date().toISOString();
          const newNotif: AppNotification = {
            id: rawNotif.id || `notif-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
            title: rawNotif.title,
            message: rawNotif.message,
            priority: rawNotif.priority || 'Medium',
            module: rawNotif.module || 'Issue',
            recipientRole: rawNotif.recipientRole || 'All',
            status: rawNotif.status || 'Unread',
            read: rawNotif.status === 'Read' || rawNotif.read || false,
            type: rawNotif.type || 'info',
            createdAt: rawNotif.createdAt || now,
            ...rawNotif,
          };
          const historyEntry: NotificationHistoryItem = {
            id: `hist-${Date.now()}`,
            notificationId: newNotif.id,
            title: newNotif.title,
            recipient: newNotif.recipientRole || 'All Roles',
            channel: 'In-App',
            deliveryStatus: 'Delivered',
            createdBy: 'MOUNTEC System Engine',
            createdAt: newNotif.createdAt,
            deliveredAt: newNotif.createdAt
          };
          return {
            notifications: [newNotif, ...state.notifications],
            history: [historyEntry, ...state.history]
          };
        });
      },

      markAsRead: (id) => {
        set((state) => ({
          notifications: state.notifications.map((n) =>
            n.id === id ? { ...n, status: 'Read', readAt: new Date().toISOString() } : n
          ),
        }));
      },

      markAllAsRead: () => {
        const now = new Date().toISOString();
        set((state) => ({
          notifications: state.notifications.map((n) => ({ ...n, status: 'Read', readAt: now })),
        }));
      },

      deleteNotification: (id) => {
        set((state) => ({
          notifications: state.notifications.filter((n) => n.id !== id),
        }));
      },

      archiveNotification: (id) => {
        set((state) => ({
          notifications: state.notifications.map((n) =>
            n.id === id ? { ...n, isArchived: !n.isArchived } : n
          ),
        }));
      },

      pinNotification: (id) => {
        set((state) => ({
          notifications: state.notifications.map((n) =>
            n.id === id ? { ...n, isPinned: !n.isPinned } : n
          ),
        }));
      },

      clearAll: () => {
        set({ notifications: [] });
      },

      syncAllNotifications: (notifications: any[]) => {
        if (Array.isArray(notifications)) {
          set({ notifications });
        }
      },

      // Queue Actions
      addEmailToQueue: (item) => {
        set((state) => ({
          emailQueue: [item, ...state.emailQueue],
          history: [
            {
              id: `hist-${Date.now()}`,
              notificationId: item.id,
              title: item.subject,
              recipient: item.recipientEmail,
              channel: 'Email',
              deliveryStatus: item.status,
              createdBy: 'Email Service',
              createdAt: item.createdAt,
              deliveredAt: item.sentAt
            },
            ...state.history
          ]
        }));
      },

      addPushToQueue: (item) => {
        set((state) => ({
          pushQueue: [item, ...state.pushQueue],
          history: [
            {
              id: `hist-${Date.now()}`,
              notificationId: item.id,
              title: item.title,
              recipient: item.targetRoles.join(', '),
              channel: 'Push',
              deliveryStatus: item.status,
              createdBy: 'Push Dispatcher',
              createdAt: item.createdAt,
              deliveredAt: item.deliveredAt
            },
            ...state.history
          ]
        }));
      },

      clearQueues: () => {
        set({ emailQueue: [], pushQueue: [] });
      },

      // Email Templates
      updateEmailTemplate: (id, updated) => {
        set((state) => ({
          emailTemplates: state.emailTemplates.map((t) =>
            t.id === id ? { ...t, ...updated, updatedAt: new Date().toISOString() } : t
          ),
        }));
      },

      resetTemplatesToDefault: () => {
        set({ emailTemplates: INITIAL_EMAIL_TEMPLATES });
      },

      // Reminder Rules
      addReminderRule: (rule) => {
        set((state) => ({ reminderRules: [rule, ...state.reminderRules] }));
      },

      toggleReminderRule: (id) => {
        set((state) => ({
          reminderRules: state.reminderRules.map((r) =>
            r.id === id ? { ...r, active: !r.active } : r
          ),
        }));
      },

      deleteReminderRule: (id) => {
        set((state) => ({
          reminderRules: state.reminderRules.filter((r) => r.id !== id),
        }));
      },

      // Escalation Rules
      addEscalationRule: (rule) => {
        set((state) => ({ escalationRules: [rule, ...state.escalationRules] }));
      },

      toggleEscalationRule: (id) => {
        set((state) => ({
          escalationRules: state.escalationRules.map((r) =>
            r.id === id ? { ...r, active: !r.active } : r
          ),
        }));
      },

      deleteEscalationRule: (id) => {
        set((state) => ({
          escalationRules: state.escalationRules.filter((r) => r.id !== id),
        }));
      },

      // Settings
      updateSettings: (newSettings) => {
        set((state) => ({
          settings: { ...state.settings, ...newSettings }
        }));
      },

      toggleModuleSetting: (moduleKey) => {
        set((state) => ({
          settings: {
            ...state.settings,
            modules: {
              ...state.settings.modules,
              [moduleKey]: !state.settings.modules[moduleKey]
            }
          }
        }));
      },

      toggleChannelSetting: (channelKey) => {
        set((state) => ({
          settings: {
            ...state.settings,
            channels: {
              ...state.settings.channels,
              [channelKey]: !state.settings.channels[channelKey]
            }
          }
        }));
      },

      // History
      addHistoryItem: (item) => {
        set((state) => ({ history: [item, ...state.history] }));
      },

      clearHistory: () => {
        set({ history: [] });
      }
    }),
    {
      name: 'mountec-enterprise-notifications-v2',
    }
  )
);
