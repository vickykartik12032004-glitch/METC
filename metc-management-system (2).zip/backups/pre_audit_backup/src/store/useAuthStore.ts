import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { ROLE_PERMISSIONS } from '../constants';
import { Permission, User, UserRole } from '../types';

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  setUser: (user: User | null) => void;
  logout: () => void;
  switchRole: (role: UserRole) => void;
  hasPermission: (permission: Permission) => boolean;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      isAuthenticated: false,
      isLoading: false,

      setUser: (user: User | null) => {
        set({
          user,
          isAuthenticated: Boolean(user),
          isLoading: false,
        });
      },

      logout: () => {
        set({ user: null, isAuthenticated: false, isLoading: false });
      },

      switchRole: (role: UserRole) => {
        const currentUser = get().user;
        if (currentUser) {
          set({
            user: { ...currentUser, role },
          });
        }
      },

      hasPermission: (permission: Permission) => {
        const currentUser = get().user;
        if (!currentUser) return false;
        const permissions = ROLE_PERMISSIONS[currentUser.role] || [];
        return permissions.includes(permission);
      },
    }),
    {
      name: 'metc-auth-storage',
    }
  )
);
