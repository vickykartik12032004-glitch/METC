import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { 
  INITIAL_CONSUMABLES, 
  INITIAL_EQUIPMENT, 
  INITIAL_MATERIALS, 
  INITIAL_PPE,
  INITIAL_TOOLS 
} from '../data/mockData';
import { Consumable, Equipment, Material, METCItem, PPEItem, Tool } from '../types';
import { cloudApi } from '../services/apiClient';
import { saveItemToFirestore } from '../services/firestoreSync.service';

interface AssetStore {
  materials: Material[];
  equipment: Equipment[];
  tools: Tool[];
  consumables: Consumable[];
  ppe: PPEItem[];

  // Mutators
  addMaterial: (item: Omit<Material, 'id' | 'createdAt' | 'updatedAt'>) => Promise<Material>;
  updateMaterial: (id: string, item: Partial<Material>) => Promise<void>;
  deleteMaterial: (id: string) => Promise<void>;

  addEquipment: (item: Omit<Equipment, 'id' | 'createdAt' | 'updatedAt'>) => Promise<Equipment>;
  updateEquipment: (id: string, item: Partial<Equipment>) => Promise<void>;
  deleteEquipment: (id: string) => Promise<void>;

  addTool: (item: Omit<Tool, 'id' | 'createdAt' | 'updatedAt'>) => Promise<Tool>;
  updateTool: (id: string, item: Partial<Tool>) => Promise<void>;
  deleteTool: (id: string) => Promise<void>;

  addConsumable: (item: Omit<Consumable, 'id' | 'createdAt' | 'updatedAt'>) => Promise<Consumable>;
  updateConsumable: (id: string, item: Partial<Consumable>) => Promise<void>;
  deleteConsumable: (id: string) => Promise<void>;

  addPPE: (item: Omit<PPEItem, 'id' | 'createdAt' | 'updatedAt'>) => Promise<PPEItem>;
  updatePPE: (id: string, item: Partial<PPEItem>) => Promise<void>;
  deletePPE: (id: string) => Promise<void>;

  // Real-time Cloud Sync Ingestion Handlers
  syncAllAssets: (data: {
    materials?: Material[];
    equipment?: Equipment[];
    tools?: Tool[];
    consumables?: Consumable[];
    ppe?: PPEItem[];
  }) => void;
  applyRemoteAssetUpsert: (category: string, item: any) => void;
  applyRemoteAssetCreated: (category: string, item: any) => void;
  applyRemoteAssetUpdated: (category: string, item: any) => void;
  applyRemoteAssetDeleted: (category: string, id: string) => void;
  applyRemoteStockUpdated: (assetId: string, availableQuantity: number, status?: any) => void;

  getAllAssets: () => METCItem[];
  fetchAssets: () => Promise<void>;
  bulkAddAssets: (items: any[], author?: string) => Promise<any[]>;
  clearAllAssets: (skipCloud?: boolean) => Promise<void>;
  resetToDefault: () => void;
  restoreDemoData: () => Promise<void>;
}

export const useAssetStore = create<AssetStore>()(
  persist(
    (set, get) => ({
      materials: [],
      equipment: [],
      tools: [],
      consumables: [],
      ppe: [],

      // ==========================
      // MATERIAL
      // ==========================
      addMaterial: async (item) => {
        const now = new Date().toISOString();
        const tempId = `mat-${Date.now()}`;
        const newMat: Material = {
          ...item,
          id: tempId,
          createdAt: now,
          updatedAt: now,
        };
        // Optimistic UI update
        set((state) => ({ materials: [newMat, ...state.materials] }));

        try {
          const res = await cloudApi.createAsset('material', newMat);
          if (res.data) {
            set((state) => ({
              materials: state.materials.map((m) => (m.id === tempId ? res.data : m)),
            }));
            return res.data;
          }
        } catch (err) {
          console.error('Failed to sync added material with cloud:', err);
        }
        return newMat;
      },

      updateMaterial: async (id, updated) => {
        const now = new Date().toISOString();
        let targetItem: any = null;
        set((state) => ({
          materials: state.materials.map((m) => {
            if (m.id === id) {
              const oldQty = m.quantity;
              const newQty = updated.quantity !== undefined ? Number(updated.quantity) : oldQty;
              let newAvail = updated.availableQuantity !== undefined ? Number(updated.availableQuantity) : undefined;
              if (newAvail === undefined && updated.quantity !== undefined) {
                const diff = (newQty || 0) - (oldQty || 0);
                newAvail = Math.max(0, (m.availableQuantity || 0) + diff);
              }
              targetItem = {
                ...m,
                ...updated,
                quantity: newQty,
                availableQuantity: newAvail !== undefined ? newAvail : m.availableQuantity,
                updatedAt: now,
              };
              return targetItem;
            }
            return m;
          }),
        }));
        try {
          await cloudApi.updateAsset('material', id, { ...updated, updatedAt: now });
        } catch (err) {
          console.error(`Failed to sync material ${id} update:`, err);
        }
        if (targetItem) {
          try {
            await saveItemToFirestore(targetItem);
          } catch (fbErr) {
            console.error(`Failed to sync material ${id} to Firestore:`, fbErr);
          }
        }
      },

      deleteMaterial: async (id) => {
        set((state) => ({ materials: state.materials.filter((m) => m.id !== id) }));
        try {
          await cloudApi.deleteAsset('material', id);
        } catch (err) {
          console.error(`Failed to delete material ${id}:`, err);
        }
      },

      // ==========================
      // EQUIPMENT
      // ==========================
      addEquipment: async (item) => {
        const now = new Date().toISOString();
        const tempId = `eqp-${Date.now()}`;
        const newEqp: Equipment = {
          ...item,
          id: tempId,
          createdAt: now,
          updatedAt: now,
        };
        set((state) => ({ equipment: [newEqp, ...state.equipment] }));

        try {
          const res = await cloudApi.createAsset('equipment', newEqp);
          if (res.data) {
            set((state) => ({
              equipment: state.equipment.map((e) => (e.id === tempId ? res.data : e)),
            }));
            try {
              await saveItemToFirestore(res.data);
            } catch (fbErr) {
              console.warn('Failed to mirror equipment to Firestore:', fbErr);
            }
            return res.data;
          }
        } catch (err) {
          console.error('Failed to sync added equipment:', err);
        }
        try {
          await saveItemToFirestore(newEqp);
        } catch (fbErr) {
          console.warn('Failed to mirror equipment to Firestore:', fbErr);
        }
        return newEqp;
      },

      updateEquipment: async (id, updated) => {
        const now = new Date().toISOString();
        let targetItem: any = null;
        set((state) => ({
          equipment: state.equipment.map((e) => {
            if (e.id === id) {
              const oldQty = e.quantity;
              const newQty = updated.quantity !== undefined ? Number(updated.quantity) : oldQty;
              let newAvail = updated.availableQuantity !== undefined ? Number(updated.availableQuantity) : undefined;
              if (newAvail === undefined && updated.quantity !== undefined) {
                const diff = (newQty || 0) - (oldQty || 0);
                newAvail = Math.max(0, (e.availableQuantity || 0) + diff);
              }
              targetItem = {
                ...e,
                ...updated,
                quantity: newQty,
                availableQuantity: newAvail !== undefined ? newAvail : e.availableQuantity,
                updatedAt: now,
              };
              return targetItem;
            }
            return e;
          }),
        }));
        try {
          await cloudApi.updateAsset('equipment', id, { ...updated, updatedAt: now });
        } catch (err) {
          console.error(`Failed to sync equipment ${id} update:`, err);
        }
        if (targetItem) {
          try {
            await saveItemToFirestore(targetItem);
          } catch (fbErr) {
            console.error(`Failed to sync equipment ${id} to Firestore:`, fbErr);
          }
        }
      },

      deleteEquipment: async (id) => {
        set((state) => ({ equipment: state.equipment.filter((e) => e.id !== id) }));
        try {
          await cloudApi.deleteAsset('equipment', id);
        } catch (err) {
          console.error(`Failed to delete equipment ${id}:`, err);
        }
      },

      // ==========================
      // TOOLS
      // ==========================
      addTool: async (item) => {
        const now = new Date().toISOString();
        const tempId = `tol-${Date.now()}`;
        const newTool: Tool = {
          ...item,
          id: tempId,
          createdAt: now,
          updatedAt: now,
        };
        set((state) => ({ tools: [newTool, ...state.tools] }));

        try {
          const res = await cloudApi.createAsset('tool', newTool);
          if (res.data) {
            set((state) => ({
              tools: state.tools.map((t) => (t.id === tempId ? res.data : t)),
            }));
            try {
              await saveItemToFirestore(res.data);
            } catch (fbErr) {
              console.warn('Failed to mirror tool to Firestore:', fbErr);
            }
            return res.data;
          }
        } catch (err) {
          console.error('Failed to sync added tool:', err);
        }
        try {
          await saveItemToFirestore(newTool);
        } catch (fbErr) {
          console.warn('Failed to mirror tool to Firestore:', fbErr);
        }
        return newTool;
      },

      updateTool: async (id, updated) => {
        const now = new Date().toISOString();
        let targetItem: any = null;
        set((state) => ({
          tools: state.tools.map((t) => {
            if (t.id === id) {
              const oldQty = t.quantity;
              const newQty = updated.quantity !== undefined ? Number(updated.quantity) : oldQty;
              let newAvail = updated.availableQuantity !== undefined ? Number(updated.availableQuantity) : undefined;
              if (newAvail === undefined && updated.quantity !== undefined) {
                const diff = (newQty || 0) - (oldQty || 0);
                newAvail = Math.max(0, (t.availableQuantity || 0) + diff);
              }
              targetItem = {
                ...t,
                ...updated,
                quantity: newQty,
                availableQuantity: newAvail !== undefined ? newAvail : t.availableQuantity,
                updatedAt: now,
              };
              return targetItem;
            }
            return t;
          }),
        }));
        try {
          await cloudApi.updateAsset('tool', id, { ...updated, updatedAt: now });
        } catch (err) {
          console.error(`Failed to sync tool ${id} update:`, err);
        }
        if (targetItem) {
          try {
            await saveItemToFirestore(targetItem);
          } catch (fbErr) {
            console.error(`Failed to sync tool ${id} to Firestore:`, fbErr);
          }
        }
      },

      deleteTool: async (id) => {
        set((state) => ({ tools: state.tools.filter((t) => t.id !== id) }));
        try {
          await cloudApi.deleteAsset('tool', id);
        } catch (err) {
          console.error(`Failed to delete tool ${id}:`, err);
        }
      },

      // ==========================
      // CONSUMABLES
      // ==========================
      addConsumable: async (item) => {
        const now = new Date().toISOString();
        const tempId = `con-${Date.now()}`;
        const newCon: Consumable = {
          ...item,
          id: tempId,
          createdAt: now,
          updatedAt: now,
        };
        set((state) => ({ consumables: [newCon, ...state.consumables] }));

        try {
          const res = await cloudApi.createAsset('consumable', newCon);
          if (res.data) {
            set((state) => ({
              consumables: state.consumables.map((c) => (c.id === tempId ? res.data : c)),
            }));
            try {
              await saveItemToFirestore(res.data);
            } catch (fbErr) {
              console.warn('Failed to mirror consumable to Firestore:', fbErr);
            }
            return res.data;
          }
        } catch (err) {
          console.error('Failed to sync added consumable:', err);
        }
        try {
          await saveItemToFirestore(newCon);
        } catch (fbErr) {
          console.warn('Failed to mirror consumable to Firestore:', fbErr);
        }
        return newCon;
      },

      updateConsumable: async (id, updated) => {
        const now = new Date().toISOString();
        let targetItem: any = null;
        set((state) => ({
          consumables: state.consumables.map((c) => {
            if (c.id === id) {
              const oldQty = c.quantity;
              const newQty = updated.quantity !== undefined ? Number(updated.quantity) : oldQty;
              let newAvail = updated.availableQuantity !== undefined ? Number(updated.availableQuantity) : undefined;
              if (newAvail === undefined && updated.quantity !== undefined) {
                const diff = (newQty || 0) - (oldQty || 0);
                newAvail = Math.max(0, (c.availableQuantity || 0) + diff);
              }
              targetItem = {
                ...c,
                ...updated,
                quantity: newQty,
                availableQuantity: newAvail !== undefined ? newAvail : c.availableQuantity,
                updatedAt: now,
              };
              return targetItem;
            }
            return c;
          }),
        }));
        try {
          await cloudApi.updateAsset('consumable', id, { ...updated, updatedAt: now });
        } catch (err) {
          console.error(`Failed to sync consumable ${id} update:`, err);
        }
        if (targetItem) {
          try {
            await saveItemToFirestore(targetItem);
          } catch (fbErr) {
            console.error(`Failed to sync consumable ${id} to Firestore:`, fbErr);
          }
        }
      },

      deleteConsumable: async (id) => {
        set((state) => ({ consumables: state.consumables.filter((c) => c.id !== id) }));
        try {
          await cloudApi.deleteAsset('consumable', id);
        } catch (err) {
          console.error(`Failed to delete consumable ${id}:`, err);
        }
      },

      // ==========================
      // PPE
      // ==========================
      addPPE: async (item) => {
        const now = new Date().toISOString();
        const tempId = `ppe-${Date.now()}`;
        const newPpe: PPEItem = {
          ...item,
          id: tempId,
          createdAt: now,
          updatedAt: now,
        };
        set((state) => ({ ppe: [newPpe, ...state.ppe] }));

        try {
          const res = await cloudApi.createAsset('ppe', newPpe);
          if (res.data) {
            set((state) => ({
              ppe: state.ppe.map((p) => (p.id === tempId ? res.data : p)),
            }));
            try {
              await saveItemToFirestore(res.data);
            } catch (fbErr) {
              console.warn('Failed to mirror PPE to Firestore:', fbErr);
            }
            return res.data;
          }
        } catch (err) {
          console.error('Failed to sync added PPE:', err);
        }
        try {
          await saveItemToFirestore(newPpe);
        } catch (fbErr) {
          console.warn('Failed to mirror PPE to Firestore:', fbErr);
        }
        return newPpe;
      },

      updatePPE: async (id, updated) => {
        const now = new Date().toISOString();
        let targetItem: any = null;
        set((state) => ({
          ppe: state.ppe.map((p) => {
            if (p.id === id) {
              const oldQty = p.quantity;
              const newQty = updated.quantity !== undefined ? Number(updated.quantity) : oldQty;
              let newAvail = updated.availableQuantity !== undefined ? Number(updated.availableQuantity) : undefined;
              if (newAvail === undefined && updated.quantity !== undefined) {
                const diff = (newQty || 0) - (oldQty || 0);
                newAvail = Math.max(0, (p.availableQuantity || 0) + diff);
              }
              targetItem = {
                ...p,
                ...updated,
                quantity: newQty,
                availableQuantity: newAvail !== undefined ? newAvail : p.availableQuantity,
                updatedAt: now,
              };
              return targetItem;
            }
            return p;
          }),
        }));
        try {
          await cloudApi.updateAsset('ppe', id, { ...updated, updatedAt: now });
        } catch (err) {
          console.error(`Failed to sync PPE ${id} update:`, err);
        }
        if (targetItem) {
          try {
            await saveItemToFirestore(targetItem);
          } catch (fbErr) {
            console.error(`Failed to sync PPE ${id} to Firestore:`, fbErr);
          }
        }
      },

      deletePPE: async (id) => {
        set((state) => ({ ppe: state.ppe.filter((p) => p.id !== id) }));
        try {
          await cloudApi.deleteAsset('ppe', id);
        } catch (err) {
          console.error(`Failed to delete PPE ${id}:`, err);
        }
      },

      // ==========================
      // REAL-TIME CLOUD INGESTION
      // ==========================
      syncAllAssets: (data) => {
        set((state) => ({
          materials: Array.isArray(data.materials) ? data.materials : state.materials,
          equipment: Array.isArray(data.equipment) ? data.equipment : state.equipment,
          tools: Array.isArray(data.tools) ? data.tools : state.tools,
          consumables: Array.isArray(data.consumables) ? data.consumables : state.consumables,
          ppe: Array.isArray(data.ppe) ? data.ppe : state.ppe,
        }));
      },

      applyRemoteAssetUpsert: (category, item) => {
        if (!item || !item.id) return;
        const cat = (item.category || category || '').toLowerCase();
        const incomingId = item.id;
        const now = new Date().toISOString();

        set((state) => {
          const updateOrAppend = (list: any[], shouldInclude: boolean) => {
            const exists = list.some((x) => x.id === incomingId);
            if (shouldInclude) {
              if (exists) {
                return list.map((x) => {
                  if (x.id !== incomingId) return x;
                  const existingTime = x.updatedAt ? new Date(x.updatedAt).getTime() : 0;
                  const incomingTime = item.updatedAt ? new Date(item.updatedAt).getTime() : Date.now();
                  if (existingTime > incomingTime + 1500) {
                    return x; // keep newer local copy
                  }
                  const newQty = typeof item.quantity === 'number' ? item.quantity : Number(item.quantity) || x.quantity;
                  const newAvail = typeof item.availableQuantity === 'number' ? item.availableQuantity : (Number(item.availableQuantity) ?? x.availableQuantity);
                  return {
                    ...x,
                    ...item,
                    quantity: newQty,
                    availableQuantity: newAvail,
                    status: item.status || x.status,
                    updatedAt: item.updatedAt || now,
                  };
                });
              } else {
                return [item, ...list];
              }
            } else {
              return exists ? list.filter((x) => x.id !== incomingId) : list;
            }
          };

          const isMat = cat.includes('material');
          const isEqp = cat.includes('equipment');
          const isTool = cat.includes('tool');
          const isCon = cat.includes('consumable');
          const isPpe = cat.includes('ppe');

          const hasMat = state.materials.some((x) => x.id === incomingId);
          const hasEqp = state.equipment.some((x) => x.id === incomingId);
          const hasTool = state.tools.some((x) => x.id === incomingId);
          const hasCon = state.consumables.some((x) => x.id === incomingId);
          const hasPpe = state.ppe.some((x) => x.id === incomingId);

          return {
            materials: updateOrAppend(state.materials, isMat || (hasMat && !isEqp && !isTool && !isCon && !isPpe)),
            equipment: updateOrAppend(state.equipment, isEqp || (hasEqp && !isMat && !isTool && !isCon && !isPpe)),
            tools: updateOrAppend(state.tools, isTool || (hasTool && !isMat && !isEqp && !isCon && !isPpe)),
            consumables: updateOrAppend(state.consumables, isCon || (hasCon && !isMat && !isEqp && !isTool && !isPpe)),
            ppe: updateOrAppend(state.ppe, isPpe || (hasPpe && !isMat && !isEqp && !isTool && !isCon)),
          };
        });
      },

      applyRemoteAssetCreated: (category, item) => {
        get().applyRemoteAssetUpsert(category, item);
      },

      applyRemoteAssetUpdated: (category, item) => {
        get().applyRemoteAssetUpsert(category, item);
      },

      applyRemoteAssetDeleted: (_category, id) => {
        set((state) => ({
          materials: state.materials.filter((m) => m.id !== id),
          equipment: state.equipment.filter((e) => e.id !== id),
          tools: state.tools.filter((t) => t.id !== id),
          consumables: state.consumables.filter((c) => c.id !== id),
          ppe: state.ppe.filter((p) => p.id !== id),
        }));
      },

      applyRemoteStockUpdated: (assetId, availableQuantity, status) => {
        const updater = (item: any) => {
          if (item.id === assetId) {
            return {
              ...item,
              availableQuantity,
              status: status || item.status,
              updatedAt: new Date().toISOString(),
            };
          }
          return item;
        };

        set((state) => ({
          materials: state.materials.map(updater),
          equipment: state.equipment.map(updater),
          tools: state.tools.map(updater),
          consumables: state.consumables.map(updater),
          ppe: state.ppe.map(updater),
        }));
      },

      getAllAssets: () => {
        const { materials, equipment, tools, consumables, ppe } = get();
        return [...(materials || []), ...(equipment || []), ...(tools || []), ...(consumables || []), ...(ppe || [])];
      },

      fetchAssets: async () => {
        try {
          const res = await cloudApi.getFullSnapshot();
          if (res?.data) {
            get().syncAllAssets(res.data);
          }
        } catch (err) {
          console.warn('[AssetStore] fetchAssets sync notice:', err);
        }
      },

      bulkAddAssets: async (items: any[], author = 'Store Keeper') => {
        try {
          const res = await cloudApi.bulkAddAssets(items, author);
          if (res?.data && Array.isArray(res.data)) {
            res.data.forEach((item: any) => {
              const cat = (item.category || 'Material') as string;
              get().applyRemoteAssetUpsert(cat, item);
            });
            return res.data;
          }
        } catch (err) {
          console.error('[AssetStore] Failed to bulk add assets:', err);
          throw err;
        }
        return [];
      },

      clearAllAssets: async (skipCloud?: boolean) => {
        set({
          materials: [],
          equipment: [],
          tools: [],
          consumables: [],
          ppe: [],
        });
        if (!skipCloud) {
          try {
            await cloudApi.clearAllAssets();
          } catch (err) {
            console.warn('[AssetStore] Failed to clear cloud assets:', err);
          }
        }
      },

      resetToDefault: () => {
        set({
          materials: [],
          equipment: [],
          tools: [],
          consumables: [],
          ppe: [],
        });
      },

      restoreDemoData: async () => {
        try {
          const res = await cloudApi.restoreDemoAssets();
          if (res?.data && Array.isArray(res.data)) {
            const mats = res.data.filter((x: any) => (x.category || '').toLowerCase() === 'material');
            const eqps = res.data.filter((x: any) => (x.category || '').toLowerCase() === 'equipment');
            const tls = res.data.filter((x: any) => (x.category || '').toLowerCase() === 'tool');
            const cons = res.data.filter((x: any) => (x.category || '').toLowerCase() === 'consumable');
            const ppes = res.data.filter((x: any) => (x.category || '').toLowerCase() === 'ppe');
            set({
              materials: mats.length > 0 ? mats : INITIAL_MATERIALS,
              equipment: eqps.length > 0 ? eqps : INITIAL_EQUIPMENT,
              tools: tls.length > 0 ? tls : INITIAL_TOOLS,
              consumables: cons.length > 0 ? cons : INITIAL_CONSUMABLES,
              ppe: ppes.length > 0 ? ppes : INITIAL_PPE,
            });
            return;
          }
        } catch (err) {
          console.warn('[AssetStore] Cloud restore demo error, setting local defaults:', err);
        }
        set({
          materials: INITIAL_MATERIALS,
          equipment: INITIAL_EQUIPMENT,
          tools: INITIAL_TOOLS,
          consumables: INITIAL_CONSUMABLES,
          ppe: INITIAL_PPE,
        });
      },
    }),
    {
      name: 'metc-assets-cloud-storage',
      version: 7,
      migrate: (persistedState: any, version: number) => {
        const state = persistedState as any;
        if (version < 7 || !state) {
          return {
            ...state,
            materials: [],
            equipment: [],
            tools: [],
            consumables: [],
            ppe: [],
          };
        }
        return state;
      },
    }
  )
);
