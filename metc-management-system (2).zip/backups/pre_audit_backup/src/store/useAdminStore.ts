import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import {
  CompanyProfile,
  AdminUser,
  AuthorizedUser,
  AdminRole,
  Department,
  Branch,
  ProjectSite,
  Supplier,
  UnitOfMeasure,
  EmailSettings,
  ApplicationSettings,
  SecuritySettings,
  AuditLog,
  BackupRecord,
  BackupSettings,
  SystemHealth,
  LicenseInfo,
  AdminTab,
  AdminModule,
  ModulePermissions,
  UserStatus
} from '../features/admin/types';
import {
  INITIAL_COMPANY_PROFILE,
  INITIAL_USERS,
  INITIAL_AUTHORIZED_USERS,
  INITIAL_ROLES,
  INITIAL_DEPARTMENTS,
  INITIAL_BRANCHES,
  INITIAL_SITES,
  INITIAL_SUPPLIERS,
  INITIAL_UNITS,
  INITIAL_EMAIL_SETTINGS,
  INITIAL_APP_SETTINGS,
  INITIAL_SECURITY_SETTINGS,
  INITIAL_AUDIT_LOGS,
  INITIAL_BACKUPS,
  INITIAL_BACKUP_SETTINGS,
  INITIAL_SYSTEM_HEALTH,
  INITIAL_LICENSE_INFO,
  createFullMatrix,
  createAdminMatrix,
  createSupervisorMatrix,
  createWorkerMatrix
} from '../features/admin/data/initialAdminData';

interface AdminStore {
  // Active state
  activeTab: AdminTab;
  setActiveTab: (tab: AdminTab) => void;
  globalSearchQuery: string;
  setGlobalSearchQuery: (query: string) => void;

  // Data State
  companyProfile: CompanyProfile;
  users: AdminUser[];
  authorizedUsers: AuthorizedUser[];
  roles: AdminRole[];
  departments: Department[];
  branches: Branch[];
  sites: ProjectSite[];
  suppliers: Supplier[];
  units: UnitOfMeasure[];
  emailSettings: EmailSettings;
  appSettings: ApplicationSettings;
  securitySettings: SecuritySettings;
  auditLogs: AuditLog[];
  backups: BackupRecord[];
  backupSettings: BackupSettings;
  systemHealth: SystemHealth;
  licenseInfo: LicenseInfo;

  // Company Profile Actions
  updateCompanyProfile: (profile: Partial<CompanyProfile>) => void;

  // Authorized User Whitelist Actions
  addAuthorizedUser: (user: Omit<AuthorizedUser, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateAuthorizedUser: (id: string, updates: Partial<AuthorizedUser>) => void;
  deleteAuthorizedUser: (id: string) => void;
  activateAuthorizedUser: (id: string) => void;
  deactivateAuthorizedUser: (id: string) => void;
  checkAuthorizedEmail: (email: string) => AuthorizedUser | null;

  // User Management Actions
  addUser: (user: Omit<AdminUser, 'id' | 'createdAt'>) => void;
  updateUser: (id: string, user: Partial<AdminUser>) => void;
  deleteUser: (id: string) => void; // Soft Delete
  deactivateUser: (id: string) => void;
  activateUser: (id: string) => void;
  toggleUserStatus: (id: string) => void;
  updateUserRole: (id: string, newRole: string) => void;
  updateUserSiteAccess: (id: string, assignedSites: string[], allSitesAccess?: boolean) => void;
  resetUserPassword: (id: string) => string; // returns temporary password
  lockUser: (id: string) => void;
  unlockUser: (id: string) => void;

  // Role Management Actions
  addRole: (role: Omit<AdminRole, 'id' | 'createdAt'>) => void;
  updateRole: (id: string, role: Partial<AdminRole>) => void;
  deleteRole: (id: string) => void;
  assignPermission: (roleId: string, module: AdminModule, permissionKey: keyof ModulePermissions, value: boolean) => void;
  grantAllPermissions: (roleId: string) => void;
  revokeAllPermissions: (roleId: string) => void;
  resetRolePermissions: (roleId: string) => void;

  // Departments Actions
  addDepartment: (dept: Omit<Department, 'id' | 'createdAt'>) => void;
  updateDepartment: (id: string, dept: Partial<Department>) => void;
  deleteDepartment: (id: string) => void;

  // Branches Actions
  addBranch: (branch: Omit<Branch, 'id' | 'createdAt'>) => void;
  updateBranch: (id: string, branch: Partial<Branch>) => void;
  deleteBranch: (id: string) => void;

  // Sites / Projects Actions
  addSite: (site: Omit<ProjectSite, 'id' | 'createdAt'>) => void;
  updateSite: (id: string, site: Partial<ProjectSite>) => void;
  deleteSite: (id: string) => void;
  archiveSite: (id: string) => void;
  restoreSite: (id: string) => void;
  toggleSiteStatus: (id: string, status: 'Active' | 'Inactive' | 'Completed' | 'On Hold' | 'Archived') => void;
  resolveDuplicateSite: (id: string, resolvedCode: string, note?: string) => void;
  assignUsersToSite: (siteId: string, userIds: string[], roleKey?: 'assignedSupervisors' | 'assignedWorkers' | 'assignedAdmins') => void;
  resetSitesToMaster: () => void;

  // Suppliers Actions
  addSupplier: (sup: Omit<Supplier, 'id' | 'createdAt'>) => void;
  updateSupplier: (id: string, sup: Partial<Supplier>) => void;
  deleteSupplier: (id: string) => void;

  // Units Actions
  addUnit: (unit: Omit<UnitOfMeasure, 'id' | 'createdAt'>) => void;
  updateUnit: (id: string, unit: Partial<UnitOfMeasure>) => void;
  deleteUnit: (id: string) => void;

  // Email Settings Actions
  updateEmailSettings: (settings: Partial<EmailSettings>) => void;

  // Application Settings Actions
  updateAppSettings: (settings: Partial<ApplicationSettings>) => void;

  // Security Settings Actions
  updateSecuritySettings: (settings: Partial<SecuritySettings>) => void;

  // Audit Logs Actions
  addAuditLog: (log: Omit<AuditLog, 'id' | 'timestamp'>) => void;
  clearAuditLogs: () => void;

  // Backup & Restore Actions
  createBackup: (type?: 'Manual' | 'Automatic', name?: string) => BackupRecord;
  restoreBackup: (backupId: string) => void;
  updateBackupSettings: (settings: Partial<BackupSettings>) => void;

  // System Health Refresh
  refreshHealthMetrics: () => void;

  // Real-time Cloud Sync
  syncAllAdminData: (data: {
    companyProfile?: any;
    users?: any[];
    authorizedUsers?: any[];
    roles?: any[];
    departments?: any[];
    branches?: any[];
    sites?: any[];
    suppliers?: any[];
    units?: any[];
    emailSettings?: any;
    appSettings?: any;
    securitySettings?: any;
    auditLogs?: any[];
  }) => void;
}

export const useAdminStore = create<AdminStore>()(
  persist(
    (set, get) => ({
      activeTab: 'company',
      setActiveTab: (tab) => set({ activeTab: tab }),
      globalSearchQuery: '',
      setGlobalSearchQuery: (query) => set({ globalSearchQuery: query }),

      companyProfile: INITIAL_COMPANY_PROFILE,
      users: INITIAL_USERS,
      authorizedUsers: INITIAL_AUTHORIZED_USERS,
      roles: INITIAL_ROLES,
      departments: INITIAL_DEPARTMENTS,
      branches: INITIAL_BRANCHES,
      sites: INITIAL_SITES,
      suppliers: INITIAL_SUPPLIERS,
      units: INITIAL_UNITS,
      emailSettings: INITIAL_EMAIL_SETTINGS,
      appSettings: INITIAL_APP_SETTINGS,
      securitySettings: INITIAL_SECURITY_SETTINGS,
      auditLogs: INITIAL_AUDIT_LOGS,
      backups: INITIAL_BACKUPS,
      backupSettings: INITIAL_BACKUP_SETTINGS,
      systemHealth: INITIAL_SYSTEM_HEALTH,
      licenseInfo: INITIAL_LICENSE_INFO,

      // Company Profile
      updateCompanyProfile: (profile) => {
        set((state) => ({
          companyProfile: { ...state.companyProfile, ...profile }
        }));
        get().addAuditLog({
          user: 'Admin',
          email: 'admin@mountec.sg',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'Settings Changes',
          module: 'Company Profile',
          details: 'Updated Company Profile details for MOUNTEC PTE LTD',
          severity: 'Info',
        });
      },

      // Authorized User Whitelist Management
      addAuthorizedUser: (userData) => {
        const id = `auth-usr-${Date.now().toString().slice(-4)}`;
        const now = new Date().toISOString();
        const newAuthUser: AuthorizedUser = {
          ...userData,
          id,
          createdAt: now,
          updatedAt: now,
        };
        set((state) => ({ authorizedUsers: [newAuthUser, ...state.authorizedUsers] }));
        get().addAuditLog({
          user: 'Super Admin',
          email: 'admin@mountec.com',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'Create',
          module: 'Authorized Users Whitelist',
          details: `Added new authorized Google Account: ${newAuthUser.fullName} (${newAuthUser.googleEmail}) with role ${newAuthUser.role}`,
          severity: 'Info',
        });
      },

      updateAuthorizedUser: (id, updates) => {
        const now = new Date().toISOString();
        set((state) => ({
          authorizedUsers: state.authorizedUsers.map((u) =>
            u.id === id ? { ...u, ...updates, updatedAt: now } : u
          ),
        }));
        get().addAuditLog({
          user: 'Super Admin',
          email: 'admin@mountec.com',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'User Changes',
          module: 'Authorized Users Whitelist',
          details: `Updated authorized Google user record ID: ${id}`,
          severity: 'Info',
        });
      },

      deleteAuthorizedUser: (id) => {
        const target = get().authorizedUsers.find((u) => u.id === id);
        set((state) => ({
          authorizedUsers: state.authorizedUsers.filter((u) => u.id !== id),
        }));
        get().addAuditLog({
          user: 'Super Admin',
          email: 'admin@mountec.com',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'Delete',
          module: 'Authorized Users Whitelist',
          details: `Revoked Google authorization and removed account: ${target?.googleEmail || id}`,
          severity: 'Warning',
        });
      },

      activateAuthorizedUser: (id) => {
        const now = new Date().toISOString();
        set((state) => ({
          authorizedUsers: state.authorizedUsers.map((u) =>
            u.id === id ? { ...u, status: 'Active', updatedAt: now } : u
          ),
        }));
        get().addAuditLog({
          user: 'Super Admin',
          email: 'admin@mountec.com',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'User Changes',
          module: 'Authorized Users Whitelist',
          details: `Activated Google account authorization for ID: ${id}`,
          severity: 'Info',
        });
      },

      deactivateAuthorizedUser: (id) => {
        const now = new Date().toISOString();
        set((state) => ({
          authorizedUsers: state.authorizedUsers.map((u) =>
            u.id === id ? { ...u, status: 'Inactive', updatedAt: now } : u
          ),
        }));
        get().addAuditLog({
          user: 'Super Admin',
          email: 'admin@mountec.com',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'User Changes',
          module: 'Authorized Users Whitelist',
          details: `Deactivated Google account authorization for ID: ${id}`,
          severity: 'Warning',
        });
      },

      checkAuthorizedEmail: (email) => {
        if (!email || typeof email !== 'string') return null;
        const normalized = email.trim().toLowerCase();
        const list = get().authorizedUsers || INITIAL_AUTHORIZED_USERS || [];
        const found = list.find((u) => {
          if (!u || !u.googleEmail || typeof u.googleEmail !== 'string') return false;
          return u.googleEmail.trim().toLowerCase() === normalized;
        });
        return found || null;
      },

      // Users
      addUser: (userData) => {
        const id = `usr-${Date.now().toString().slice(-4)}`;
        const defaultTempPass = `Mnc#${Math.floor(100000 + Math.random() * 900000)}`;
        const newUser: AdminUser = {
          ...userData,
          id,
          tempPassword: userData.tempPassword || userData.password || defaultTempPass,
          createdAt: new Date().toISOString(),
          failedLoginAttempts: 0,
        };
        set((state) => ({ users: [newUser, ...state.users] }));
        get().addAuditLog({
          user: 'Admin',
          email: 'admin@mountec.sg',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'Create',
          module: 'User Management',
          details: `Created new user ${newUser.fullName} (${newUser.email}) assigned role ${newUser.role}`,
          severity: 'Info',
        });
      },

      updateUser: (id, userData) => {
        set((state) => ({
          users: state.users.map((u) => (u.id === id ? { ...u, ...userData } : u))
        }));
        get().addAuditLog({
          user: 'Admin',
          email: 'admin@mountec.sg',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'User Changes',
          module: 'User Management',
          details: `Updated details for user ID: ${id}`,
          severity: 'Info',
        });
      },

      deleteUser: (id) => {
        // Soft Delete
        set((state) => ({
          users: state.users.map((u) => (u.id === id ? { ...u, isSoftDeleted: true, status: 'Deactivated' as UserStatus } : u))
        }));
        get().addAuditLog({
          user: 'Admin',
          email: 'admin@mountec.sg',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'Delete',
          module: 'User Management',
          details: `Soft deleted user ID: ${id}`,
          severity: 'Warning',
        });
      },

      deactivateUser: (id) => {
        set((state) => ({
          users: state.users.map((u) => (u.id === id ? { ...u, status: 'Deactivated' as UserStatus } : u))
        }));
        get().addAuditLog({
          user: 'Admin',
          email: 'admin@mountec.sg',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'User Changes',
          module: 'User Management',
          details: `Deactivated user ID: ${id}`,
          severity: 'Warning',
        });
      },

      activateUser: (id) => {
        set((state) => ({
          users: state.users.map((u) => (u.id === id ? { ...u, status: 'Active' as UserStatus, failedLoginAttempts: 0 } : u))
        }));
        get().addAuditLog({
          user: 'Admin',
          email: 'admin@mountec.sg',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'User Changes',
          module: 'User Management',
          details: `Activated user ID: ${id}`,
          severity: 'Info',
        });
      },

      toggleUserStatus: (id) => {
        const target = get().users.find((u) => u.id === id);
        if (!target) return;
        const newStatus: UserStatus = target.status === 'Active' ? 'Inactive' : 'Active';
        set((state) => ({
          users: state.users.map((u) => (u.id === id ? { ...u, status: newStatus, failedLoginAttempts: 0 } : u))
        }));
        get().addAuditLog({
          user: 'Super Admin',
          email: 'admin@mountec.com',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'User Changes',
          module: 'User Management',
          details: `Toggled user status for ${target.fullName} (${target.email}) to: ${newStatus}`,
          severity: newStatus === 'Active' ? 'Info' : 'Warning',
        });
      },

      updateUserRole: (id, newRole) => {
        const target = get().users.find((u) => u.id === id);
        set((state) => ({
          users: state.users.map((u) => (u.id === id ? { ...u, role: newRole } : u))
        }));
        get().addAuditLog({
          user: 'Super Admin',
          email: 'admin@mountec.com',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'User Changes',
          module: 'User Management',
          details: `Updated role for user ${target?.fullName || id} to: ${newRole}`,
          severity: 'Warning',
        });
      },

      updateUserSiteAccess: (id, assignedSites, allSitesAccess = false) => {
        const target = get().users.find((u) => u.id === id);
        set((state) => ({
          users: state.users.map((u) => (u.id === id ? { ...u, assignedSites, allSitesAccess } : u))
        }));
        get().addAuditLog({
          user: 'Super Admin',
          email: 'admin@mountec.com',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'User Changes',
          module: 'User Management',
          details: `Updated site authorization for ${target?.fullName || id}: ${allSitesAccess ? 'All Sites' : assignedSites.join(', ')}`,
          severity: 'Info',
        });
      },

      resetUserPassword: (id) => {
        const tempPassword = `Mnc#${Math.floor(100000 + Math.random() * 900000)}`;
        set((state) => ({
          users: state.users.map((u) => (u.id === id ? { ...u, failedLoginAttempts: 0, tempPassword } : u))
        }));
        get().addAuditLog({
          user: 'Admin',
          email: 'admin@mountec.sg',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'User Changes',
          module: 'User Management',
          details: `Reset password for user ID: ${id}. Temporary credential generated.`,
          severity: 'Warning',
        });
        return tempPassword;
      },

      lockUser: (id) => {
        set((state) => ({
          users: state.users.map((u) => (u.id === id ? { ...u, status: 'Locked' as UserStatus } : u))
        }));
        get().addAuditLog({
          user: 'Admin',
          email: 'admin@mountec.sg',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'User Changes',
          module: 'User Management',
          details: `Locked user account ID: ${id}`,
          severity: 'Warning',
        });
      },

      unlockUser: (id) => {
        set((state) => ({
          users: state.users.map((u) => (u.id === id ? { ...u, status: 'Active' as UserStatus, failedLoginAttempts: 0 } : u))
        }));
        get().addAuditLog({
          user: 'Admin',
          email: 'admin@mountec.sg',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'User Changes',
          module: 'User Management',
          details: `Unlocked user account ID: ${id}`,
          severity: 'Info',
        });
      },

      // Roles
      addRole: (roleData) => {
        const newRole: AdminRole = {
          ...roleData,
          id: `role-custom-${Date.now().toString().slice(-4)}`,
          createdAt: new Date().toISOString(),
          isCustom: true,
          userCount: 0,
        };
        set((state) => ({ roles: [...state.roles, newRole] }));
        get().addAuditLog({
          user: 'Admin',
          email: 'admin@mountec.sg',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'Role Changes',
          module: 'Role Management',
          details: `Created custom role: ${newRole.name}`,
          severity: 'Info',
        });
      },

      updateRole: (id, roleData) => {
        set((state) => ({
          roles: state.roles.map((r) => (r.id === id ? { ...r, ...roleData } : r))
        }));
        get().addAuditLog({
          user: 'Admin',
          email: 'admin@mountec.sg',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'Role Changes',
          module: 'Role Management',
          details: `Updated role permissions/description for role ID: ${id}`,
          severity: 'Info',
        });
      },

      deleteRole: (id) => {
        set((state) => ({
          roles: state.roles.filter((r) => r.id !== id || !r.isCustom)
        }));
        get().addAuditLog({
          user: 'Admin',
          email: 'admin@mountec.sg',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'Delete',
          module: 'Role Management',
          details: `Deleted role ID: ${id}`,
          severity: 'Warning',
        });
      },

      assignPermission: (roleId, module, permissionKey, value) => {
        set((state) => ({
          roles: state.roles.map((r) => {
            if (r.id !== roleId) return r;
            // Super Admin permissions are permanent and cannot be downgraded
            if (r.name === 'Super Admin') return r;

            const updatedPerms = { ...r.permissions };
            if (!updatedPerms[module]) {
              updatedPerms[module] = {
                view: false,
                create: false,
                update: false,
                delete: false,
                approve: false,
                export: false,
                import: false,
              };
            }
            updatedPerms[module] = {
              ...updatedPerms[module],
              [permissionKey]: value,
            };
            return { ...r, permissions: updatedPerms };
          })
        }));
      },

      grantAllPermissions: (roleId) => {
        set((state) => ({
          roles: state.roles.map((r) => {
            if (r.id !== roleId) return r;
            if (r.name === 'Super Admin') return r;
            return { ...r, permissions: createFullMatrix() };
          })
        }));
        get().addAuditLog({
          user: 'Super Admin',
          email: 'admin@mountec.com',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'Role Changes',
          module: 'Role Management',
          details: `Granted all permissions to role ID: ${roleId}`,
          severity: 'Info',
        });
      },

      revokeAllPermissions: (roleId) => {
        set((state) => ({
          roles: state.roles.map((r) => {
            if (r.id !== roleId) return r;
            if (r.name === 'Super Admin') return r;
            // Revoke all except view on Dashboard
            const emptyMatrix: Record<AdminModule, ModulePermissions> = {} as any;
            const allMods: AdminModule[] = [
              'Dashboard', 'Materials', 'Equipment', 'Tools', 'Consumables',
              'PPE', 'Workers', 'Issue', 'Return', 'Transfer', 'Repair',
              'Lost Items', 'Reports', 'Notifications', 'Settings', 'Administration'
            ];
            allMods.forEach((m) => {
              emptyMatrix[m] = {
                view: m === 'Dashboard',
                create: false,
                update: false,
                delete: false,
                approve: false,
                export: false,
                import: false,
              };
            });
            return { ...r, permissions: emptyMatrix };
          })
        }));
        get().addAuditLog({
          user: 'Super Admin',
          email: 'admin@mountec.com',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'Role Changes',
          module: 'Role Management',
          details: `Revoked operations permissions for role ID: ${roleId}`,
          severity: 'Warning',
        });
      },

      resetRolePermissions: (roleId) => {
        set((state) => ({
          roles: state.roles.map((r) => {
            if (r.id !== roleId) return r;
            let defaultMatrix: Record<AdminModule, ModulePermissions>;
            if (r.name === 'Super Admin') {
              defaultMatrix = createFullMatrix();
            } else if (r.name === 'Admin') {
              defaultMatrix = createAdminMatrix();
            } else if (r.name === 'Supervisor' || r.name === 'Site Supervisor') {
              defaultMatrix = createSupervisorMatrix();
            } else {
              defaultMatrix = createWorkerMatrix();
            }
            return { ...r, permissions: defaultMatrix };
          })
        }));
        get().addAuditLog({
          user: 'Super Admin',
          email: 'admin@mountec.com',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'Role Changes',
          module: 'Role Management',
          details: `Reset permissions matrix to system defaults for role ID: ${roleId}`,
          severity: 'Info',
        });
      },

      // Departments
      addDepartment: (deptData) => {
        const id = `dept-${Date.now().toString().slice(-4)}`;
        const newDept: Department = {
          ...deptData,
          id,
          createdAt: new Date().toISOString(),
        };
        set((state) => ({ departments: [...state.departments, newDept] }));
      },

      updateDepartment: (id, deptData) => {
        set((state) => ({
          departments: state.departments.map((d) => (d.id === id ? { ...d, ...deptData } : d))
        }));
      },

      deleteDepartment: (id) => {
        set((state) => ({
          departments: state.departments.filter((d) => d.id !== id)
        }));
      },

      // Branches
      addBranch: (branchData) => {
        const id = `br-${Date.now().toString().slice(-4)}`;
        const newBranch: Branch = {
          ...branchData,
          id,
          createdAt: new Date().toISOString(),
        };
        set((state) => ({ branches: [...state.branches, newBranch] }));
      },

      updateBranch: (id, branchData) => {
        set((state) => ({
          branches: state.branches.map((b) => (b.id === id ? { ...b, ...branchData } : b))
        }));
      },

      deleteBranch: (id) => {
        set((state) => ({
          branches: state.branches.filter((b) => b.id !== id)
        }));
      },

      // Sites / Projects Management
      addSite: (siteData) => {
        const series = siteData.siteCode?.startsWith('M-') ? 'M' : siteData.siteCode?.startsWith('Q-') ? 'Q' : 'M';
        const id = `proj-${series.toLowerCase()}-${(siteData.siteCode || Date.now().toString()).replace(/[^a-zA-Z0-9]/g, '-').toLowerCase()}-${Date.now().toString().slice(-4)}`;
        const newSite: ProjectSite = {
          ...siteData,
          id,
          siteCode: siteData.siteCode || siteData.projectCode || 'P-000',
          projectCode: siteData.projectCode || siteData.siteCode || 'P-000',
          siteName: siteData.siteName || `${siteData.siteCode}_${siteData.projectName}`,
          series,
          status: siteData.status || 'Active',
          workerCount: siteData.workerCount || 0,
          isArchived: false,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        set((state) => ({ sites: [newSite, ...state.sites] }));
        get().addAuditLog({
          user: 'Admin',
          email: 'admin@mountec.sg',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'Create',
          module: 'Sites & Locations',
          details: `Created new project site: [${newSite.siteCode}] ${newSite.projectName}`,
          severity: 'Info',
        });
      },

      updateSite: (id, siteData) => {
        set((state) => ({
          sites: state.sites.map((s) => {
            if (s.id !== id) return s;
            const updatedSiteCode = siteData.siteCode || siteData.projectCode || s.siteCode;
            const updatedProjectName = siteData.projectName !== undefined ? siteData.projectName : s.projectName;
            const updatedSiteName = siteData.siteName || `${updatedSiteCode}_${updatedProjectName}`;
            return {
              ...s,
              ...siteData,
              siteCode: updatedSiteCode,
              projectCode: updatedSiteCode,
              projectName: updatedProjectName,
              siteName: updatedSiteName,
              updatedAt: new Date().toISOString(),
            };
          })
        }));
        get().addAuditLog({
          user: 'Admin',
          email: 'admin@mountec.sg',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'Edit',
          module: 'Sites & Locations',
          details: `Updated project site specifications for ID: ${id}`,
          severity: 'Info',
        });
      },

      deleteSite: (id) => {
        const target = get().sites.find((s) => s.id === id);
        set((state) => ({
          sites: state.sites.filter((s) => s.id !== id)
        }));
        get().addAuditLog({
          user: 'Admin',
          email: 'admin@mountec.sg',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'Delete',
          module: 'Sites & Locations',
          details: `Deleted project site: ${target?.siteName || id}`,
          severity: 'Warning',
        });
      },

      archiveSite: (id) => {
        set((state) => ({
          sites: state.sites.map((s) =>
            s.id === id
              ? { ...s, isArchived: true, status: 'Archived' as const, updatedAt: new Date().toISOString() }
              : s
          )
        }));
        const target = get().sites.find((s) => s.id === id);
        get().addAuditLog({
          user: 'Admin',
          email: 'admin@mountec.sg',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'Edit',
          module: 'Sites & Locations',
          details: `Archived project site: ${target?.siteName || id}`,
          severity: 'Info',
        });
      },

      restoreSite: (id) => {
        set((state) => ({
          sites: state.sites.map((s) =>
            s.id === id
              ? { ...s, isArchived: false, status: 'Active' as const, updatedAt: new Date().toISOString() }
              : s
          )
        }));
        const target = get().sites.find((s) => s.id === id);
        get().addAuditLog({
          user: 'Admin',
          email: 'admin@mountec.sg',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'Edit',
          module: 'Sites & Locations',
          details: `Restored archived project site to active state: ${target?.siteName || id}`,
          severity: 'Info',
        });
      },

      toggleSiteStatus: (id, status) => {
        set((state) => ({
          sites: state.sites.map((s) =>
            s.id === id
              ? { ...s, status, isArchived: status === 'Archived', updatedAt: new Date().toISOString() }
              : s
          )
        }));
      },

      resolveDuplicateSite: (id, resolvedCode, note) => {
        set((state) => ({
          sites: state.sites.map((s) => {
            if (s.id !== id) return s;
            return {
              ...s,
              siteCode: resolvedCode,
              projectCode: resolvedCode,
              siteName: `${resolvedCode}_${s.projectName}`,
              rawMasterCode: `${resolvedCode}_${s.projectName}`,
              isDuplicateId: false,
              duplicateNotes: note ? `Resolved by Super Admin: ${note}` : `Resolved duplicate ID to ${resolvedCode}`,
              updatedAt: new Date().toISOString(),
            };
          })
        }));
        get().addAuditLog({
          user: 'Super Admin',
          email: 'admin@mountec.com',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'Security Changes',
          module: 'Sites & Locations',
          details: `Resolved duplicate project ID for ${id} to ${resolvedCode}. Note: ${note || 'Manual resolution'}`,
          severity: 'Critical',
        });
      },

      assignUsersToSite: (siteId, userIds, roleKey = 'assignedSupervisors') => {
        set((state) => ({
          sites: state.sites.map((s) => {
            if (s.id !== siteId) return s;
            return {
              ...s,
              [roleKey]: userIds,
              assignedUsers: Array.from(new Set([...(s.assignedUsers || []), ...userIds])),
              updatedAt: new Date().toISOString(),
            };
          })
        }));
      },

      resetSitesToMaster: () => {
        set({ sites: INITIAL_SITES });
        get().addAuditLog({
          user: 'Super Admin',
          email: 'admin@mountec.com',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'Settings Changes',
          module: 'Sites & Locations',
          details: `Reset all project sites to Master Project List (${INITIAL_SITES.length} projects)`,
          severity: 'Critical',
        });
      },

      // Suppliers
      addSupplier: (supData) => {
        const id = `sup-${Date.now().toString().slice(-4)}`;
        const newSup: Supplier = {
          ...supData,
          id,
          createdAt: new Date().toISOString(),
        };
        set((state) => ({ suppliers: [...state.suppliers, newSup] }));
      },

      updateSupplier: (id, supData) => {
        set((state) => ({
          suppliers: state.suppliers.map((s) => (s.id === id ? { ...s, ...supData } : s))
        }));
      },

      deleteSupplier: (id) => {
        set((state) => ({
          suppliers: state.suppliers.filter((s) => s.id !== id)
        }));
      },

      // Units
      addUnit: (unitData) => {
        const id = `u-${Date.now().toString().slice(-4)}`;
        const newUnit: UnitOfMeasure = {
          ...unitData,
          id,
          createdAt: new Date().toISOString(),
        };
        set((state) => ({ units: [...state.units, newUnit] }));
      },

      updateUnit: (id, unitData) => {
        set((state) => ({
          units: state.units.map((u) => (u.id === id ? { ...u, ...unitData } : u))
        }));
      },

      deleteUnit: (id) => {
        set((state) => ({
          units: state.units.filter((u) => u.id !== id)
        }));
      },

      // Email Settings
      updateEmailSettings: (settings) => {
        set((state) => ({
          emailSettings: { ...state.emailSettings, ...settings }
        }));
      },

      // App Settings
      updateAppSettings: (settings) => {
        set((state) => ({
          appSettings: { ...state.appSettings, ...settings }
        }));
      },

      // Security Settings
      updateSecuritySettings: (settings) => {
        set((state) => ({
          securitySettings: { ...state.securitySettings, ...settings }
        }));
        get().addAuditLog({
          user: 'Admin',
          email: 'admin@mountec.sg',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'Security Changes',
          module: 'Security Governance',
          details: 'Updated Security policy, session timeout or 2FA rules',
          severity: 'Warning',
        });
      },

      // Audit Logs
      addAuditLog: (log) => {
        const newLog: AuditLog = {
          ...log,
          id: `audit-${Date.now().toString().slice(-6)}`,
          timestamp: new Date().toISOString(),
        };
        set((state) => ({ auditLogs: [newLog, ...state.auditLogs] }));
      },

      clearAuditLogs: () => {
        set({ auditLogs: [] });
      },

      // Backup & Restore
      createBackup: (type = 'Manual', name) => {
        const now = new Date();
        const dateStr = now.toISOString().replace(/[:-]/g, '').slice(0, 8);
        const fileName = name || `MOUNTEC_DB_${type.toUpperCase()}_${dateStr}.sql`;
        const newBackup: BackupRecord = {
          id: `bk-${Date.now().toString().slice(-4)}`,
          name: fileName,
          type,
          sizeMb: Number((140 + Math.random() * 10).toFixed(1)),
          createdAt: now.toISOString(),
          createdBy: 'Super Admin',
          status: 'Completed',
          downloadUrl: '#',
        };
        set((state) => ({ backups: [newBackup, ...state.backups] }));
        get().addAuditLog({
          user: 'Admin',
          email: 'admin@mountec.sg',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'Create',
          module: 'Backup Engine',
          details: `Created ${type} database backup snapshot: ${fileName}`,
          severity: 'Info',
        });
        return newBackup;
      },

      restoreBackup: (backupId) => {
        const backup = get().backups.find((b) => b.id === backupId);
        get().addAuditLog({
          user: 'Admin',
          email: 'admin@mountec.sg',
          userRole: 'Super Admin',
          ipAddress: '127.0.0.1',
          action: 'Settings Changes',
          module: 'Restore Engine',
          details: `Restored database system state from snapshot: ${backup?.name || backupId}`,
          severity: 'Critical',
        });
      },

      updateBackupSettings: (settings) => {
        set((state) => ({
          backupSettings: { ...state.backupSettings, ...settings }
        }));
      },

      refreshHealthMetrics: () => {
        set((state) => ({
          systemHealth: {
            ...state.systemHealth,
            dbPingMs: Math.floor(10 + Math.random() * 8),
            apiResponseTimeMs: Math.floor(35 + Math.random() * 15),
            cpuLoadPercent: Math.floor(8 + Math.random() * 10),
            memoryUsageMb: Math.floor(500 + Math.random() * 50),
            userCount: state.users.filter((u) => !u.isSoftDeleted).length,
            lastCheckedAt: new Date().toISOString(),
          }
        }));
      },

      syncAllAdminData: (data) => {
        set((state) => ({
          companyProfile: data.companyProfile || state.companyProfile,
          users: data.users || state.users,
          authorizedUsers: data.authorizedUsers || state.authorizedUsers,
          roles: data.roles || state.roles,
          departments: data.departments || state.departments,
          branches: data.branches || state.branches,
          sites: data.sites || state.sites,
          suppliers: data.suppliers || state.suppliers,
          units: data.units || state.units,
          emailSettings: data.emailSettings || state.emailSettings,
          appSettings: data.appSettings || state.appSettings,
          securitySettings: data.securitySettings || state.securitySettings,
          auditLogs: data.auditLogs || state.auditLogs,
        }));
      },
    }),
    {
      name: 'mountec_admin_store_v4',
      version: 4,
      migrate: (persistedState: any, version: number) => {
        if (!persistedState || version < 4) {
          return {
            ...persistedState,
            roles: INITIAL_ROLES,
            sites: persistedState?.sites?.length >= 100 ? persistedState.sites : INITIAL_SITES,
            users: persistedState?.users || INITIAL_USERS,
            authorizedUsers: persistedState?.authorizedUsers || INITIAL_AUTHORIZED_USERS,
          };
        }
        return persistedState;
      },
    }
  )
);
