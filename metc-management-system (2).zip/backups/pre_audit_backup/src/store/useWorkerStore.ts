import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { INITIAL_WORKERS } from '../data/mockData';
import { Worker } from '../types';
import { cloudApi } from '../services/apiClient';

interface WorkerStore {
  workers: Worker[];
  addWorker: (worker: Omit<Worker, 'id' | 'assignedItemsCount'>) => Promise<Worker>;
  bulkAddWorkers: (newWorkers: Array<Omit<Worker, 'id' | 'assignedItemsCount'>>) => Promise<Worker[]>;
  updateWorker: (id: string, worker: Partial<Worker>) => Promise<void>;
  deleteWorker: (id: string) => Promise<void>;
  clearAllWorkers: (skipCloud?: boolean) => Promise<void>;
  restoreDemoWorkers: () => Promise<void>;

  // Real-time Cloud Sync Ingestion Handlers
  syncAllWorkers: (workers: Worker[]) => void;
  applyRemoteWorkerCreated: (worker: Worker) => void;
  applyRemoteWorkerUpdated: (worker: Worker) => void;
  applyRemoteWorkerDeleted: (id: string) => void;
}

export const useWorkerStore = create<WorkerStore>()(
  persist(
    (set, get) => ({
      workers: INITIAL_WORKERS || [],

      addWorker: async (worker) => {
        const tempId = `wrk-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
        const newWorker: Worker = {
          ...worker,
          id: tempId,
          assignedItemsCount: 0,
        };
        set((state) => ({ workers: [newWorker, ...state.workers] }));

        try {
          const res = await cloudApi.createWorker(newWorker);
          if (res.data) {
            set((state) => ({
              workers: state.workers.map((w) => (w.id === tempId ? res.data : w)),
            }));
            return res.data;
          }
        } catch (err) {
          console.error('Failed to sync added worker:', err);
        }
        return newWorker;
      },

      bulkAddWorkers: async (newWorkersList) => {
        const createdWorkers: Worker[] = [];
        for (const w of newWorkersList) {
          const tempId = `wrk-${Date.now()}-${Math.floor(Math.random() * 10000)}`;
          const newWorker: Worker = {
            ...w,
            id: tempId,
            assignedItemsCount: 0,
          };
          createdWorkers.push(newWorker);
        }
        set((state) => ({ workers: [...createdWorkers, ...state.workers] }));

        // Sync each to cloud in parallel / sequence
        for (const w of createdWorkers) {
          try {
            await cloudApi.createWorker(w);
          } catch (e) {
            console.warn('Failed cloud sync for worker:', w.name, e);
          }
        }
        return createdWorkers;
      },

      updateWorker: async (id, updated) => {
        set((state) => ({
          workers: state.workers.map((w) => (w.id === id ? { ...w, ...updated } : w)),
        }));
        try {
          await cloudApi.updateWorker(id, updated);
        } catch (err) {
          console.error(`Failed to sync worker ${id} update:`, err);
        }
      },

      deleteWorker: async (id) => {
        set((state) => ({
          workers: state.workers.filter((w) => w.id !== id),
        }));
        try {
          await cloudApi.deleteWorker(id);
        } catch (err) {
          console.error(`Failed to delete worker ${id}:`, err);
        }
      },

      clearAllWorkers: async (skipCloud?: boolean) => {
        set({ workers: [] });
        if (!skipCloud) {
          try {
            await cloudApi.clearAllWorkers();
          } catch (err) {
            console.warn('[WorkerStore] Failed to clear cloud workers:', err);
          }
        }
      },

      restoreDemoWorkers: async () => {
        try {
          const res = await cloudApi.restoreDemoWorkers();
          if (res?.data && Array.isArray(res.data) && res.data.length > 0) {
            set({ workers: res.data });
            return;
          }
        } catch (err) {
          console.warn('[WorkerStore] Cloud restore demo error, falling back:', err);
        }
        set({ workers: INITIAL_WORKERS });
      },

      // ==========================
      // REAL-TIME CLOUD INGESTION
      // ==========================
      syncAllWorkers: (workers) => {
        if (Array.isArray(workers)) {
          set({ workers });
        }
      },

      applyRemoteWorkerCreated: (worker) => {
        set((state) => {
          if (state.workers.some((w) => w.id === worker.id)) return state;
          return { workers: [worker, ...state.workers] };
        });
      },

      applyRemoteWorkerUpdated: (worker) => {
        set((state) => ({
          workers: state.workers.map((w) => (w.id === worker.id ? { ...w, ...worker } : w)),
        }));
      },

      applyRemoteWorkerDeleted: (id) => {
        set((state) => ({
          workers: state.workers.filter((w) => w.id !== id),
        }));
      },
    }),
    {
      name: 'metc-workers-cloud-storage',
      version: 4,
      migrate: (persistedState: any, version: number) => {
        const state = persistedState as any;
        if (version < 4 || !state || !Array.isArray(state.workers) || state.workers.length === 0) {
          return {
            ...state,
            workers: INITIAL_WORKERS || [],
          };
        }
        return state;
      },
      onRehydrateStorage: () => (state) => {
        if (state && (!state.workers || !Array.isArray(state.workers) || state.workers.length === 0)) {
          state.workers = INITIAL_WORKERS || [];
        }
      },
    }
  )
);
