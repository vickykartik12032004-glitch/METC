import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { MaintenanceRecord, DisposalRecord, VendorRecord } from '../types';
import { cloudApi } from '../services/apiClient';

interface MaintenanceStore {
  maintenances: MaintenanceRecord[];
  disposals: DisposalRecord[];
  vendors: VendorRecord[];
  
  addMaintenance: (record: Omit<MaintenanceRecord, 'id' | 'maintenanceCode'>) => Promise<MaintenanceRecord>;
  updateMaintenanceStatus: (id: string, status: MaintenanceRecord['status']) => Promise<void>;
  
  addDisposal: (record: Omit<DisposalRecord, 'id' | 'disposalCode'>) => void;
  updateDisposalStatus: (id: string, status: DisposalRecord['status']) => void;
  
  addVendor: (record: Omit<VendorRecord, 'id'>) => void;

  // Real-time Cloud Sync Ingestion Handlers
  syncAllMaintenance: (records: MaintenanceRecord[]) => void;
  applyRemoteMaintenanceUpdated: (record: MaintenanceRecord) => void;
}

export const useMaintenanceStore = create<MaintenanceStore>()(
  persist(
    (set) => ({
      maintenances: [],
      disposals: [],
      vendors: [
        { id: 'ven-1', vendorName: 'QuickFix Machinery', phone: '123-456-789', email: 'service@quickfix.com', address: '123 Industrial Ave', rating: 4.8, status: 'Active' },
        { id: 'ven-2', vendorName: 'ProCalibrate', phone: '987-654-321', email: 'calib@procalibrate.com', address: '45 Tech Park', rating: 4.5, status: 'Active' }
      ],

      addMaintenance: async (record) => {
        const tempId = `mtn-${Date.now()}`;
        const newRecord: MaintenanceRecord = {
          ...record,
          id: tempId,
          maintenanceCode: `MTN-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`,
        };
        set((state) => ({ maintenances: [newRecord, ...state.maintenances] }));

        try {
          const res = await cloudApi.createMaintenance(newRecord);
          if (res.data) {
            set((state) => ({
              maintenances: state.maintenances.map((m) => (m.id === tempId ? res.data : m)),
            }));
            return res.data;
          }
        } catch (err) {
          console.error('Failed to sync maintenance record:', err);
        }
        return newRecord;
      },

      updateMaintenanceStatus: async (id, status) => {
        set((state) => ({
          maintenances: state.maintenances.map((r) => (r.id === id ? { ...r, status } : r)),
        }));
        try {
          await cloudApi.updateMaintenance(id, { status });
        } catch (err) {
          console.error(`Failed to update maintenance status for ${id}:`, err);
        }
      },

      addDisposal: (record) => {
        const newRecord: DisposalRecord = {
          ...record,
          id: `dsp-${Date.now()}`,
          disposalCode: `DSP-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`,
        };
        set((state) => ({ disposals: [newRecord, ...state.disposals] }));
      },

      updateDisposalStatus: (id, status) => {
        set((state) => ({
          disposals: state.disposals.map((r) => (r.id === id ? { ...r, status } : r)),
        }));
      },

      addVendor: (record) => {
        const newRecord: VendorRecord = {
          ...record,
          id: `ven-${Date.now()}`,
        };
        set((state) => ({ vendors: [newRecord, ...state.vendors] }));
      },

      // ==========================
      // REAL-TIME CLOUD INGESTION
      // ==========================
      syncAllMaintenance: (records) => {
        if (Array.isArray(records)) {
          set({ maintenances: records });
        }
      },

      applyRemoteMaintenanceUpdated: (record) => {
        set((state) => {
          const exists = state.maintenances.some((m) => m.id === record.id);
          if (exists) {
            return {
              maintenances: state.maintenances.map((m) => (m.id === record.id ? { ...m, ...record } : m)),
            };
          }
          return { maintenances: [record, ...state.maintenances] };
        });
      },
    }),
    {
      name: 'metc-maintenance-cloud-storage',
    }
  )
);
