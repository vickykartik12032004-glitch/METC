import React, { useState } from 'react';
import { ExpiringItem } from '../../services/dashboard.service';
import { ShieldAlert, Calendar, AlertCircle, Wrench, Check } from 'lucide-react';

interface ExpiringItemsPanelProps {
  items: ExpiringItem[];
}

export const ExpiringItemsPanel: React.FC<ExpiringItemsPanelProps> = ({ items }) => {
  const [activeTab, setActiveTab] = useState<'All' | 'Calibration' | 'Warranty' | 'Expiry'>('All');

  const filteredItems = items.filter((item) => {
    if (activeTab === 'All') return true;
    return item.type === activeTab;
  });

  return (
    <div className="space-y-3">
      {/* Tab Filter */}
      <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800/80 p-1 rounded-xl text-xs border border-slate-200 dark:border-slate-700">
        {(['All', 'Calibration', 'Warranty', 'Expiry'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
              activeTab === tab
                ? 'bg-blue-600 text-white shadow-2xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* List Items */}
      <div className="space-y-2.5">
        {filteredItems.map((item) => {
          const isOverdue = item.daysRemaining < 0;
          const isUrgent = item.daysRemaining >= 0 && item.daysRemaining <= 7;

          return (
            <div
              key={item.id}
              className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/60 flex items-center justify-between gap-3 text-xs"
            >
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-900 dark:text-slate-100">
                    {item.itemName}
                  </span>
                  <span className="px-1.5 py-0.5 rounded bg-blue-100 dark:bg-blue-950/80 text-blue-700 dark:text-blue-300 font-bold text-[10px]">
                    {item.type}
                  </span>
                </div>

                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Tag: <span className="font-mono">{item.itemCode}</span> • Assigned: {item.assignedTo || 'Unassigned'}
                </p>

                <div className="flex items-center gap-1.5 text-[10px] text-slate-500 pt-0.5">
                  <Calendar className="w-3 h-3 text-slate-400" />
                  <span>Due Date: {item.dueDate}</span>
                </div>
              </div>

              {/* Status Badge & Action */}
              <div className="text-right shrink-0 space-y-1">
                {isOverdue ? (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 font-extrabold text-[10px]">
                    <AlertCircle className="w-3 h-3" />
                    Overdue ({Math.abs(item.daysRemaining)}d ago)
                  </span>
                ) : isUrgent ? (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300 font-extrabold text-[10px]">
                    <ShieldAlert className="w-3 h-3" />
                    {item.daysRemaining} days left
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-[10px]">
                    {item.daysRemaining} days left
                  </span>
                )}

                <div>
                  <button className="text-[10px] text-blue-600 dark:text-blue-400 font-bold hover:underline">
                    Renew / Calibrate →
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
