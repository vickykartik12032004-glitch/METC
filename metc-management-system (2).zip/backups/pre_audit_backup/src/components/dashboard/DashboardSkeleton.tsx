import React from 'react';

export const DashboardSkeleton: React.FC = () => {
  return (
    <div className="space-y-6 animate-pulse">
      {/* Header Skeleton */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-slate-200 dark:bg-slate-800" />
            <div className="space-y-2">
              <div className="w-48 h-6 rounded-md bg-slate-200 dark:bg-slate-800" />
              <div className="w-32 h-4 rounded-md bg-slate-200 dark:bg-slate-800" />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-36 h-9 rounded-xl bg-slate-200 dark:bg-slate-800" />
            <div className="w-24 h-9 rounded-xl bg-slate-200 dark:bg-slate-800" />
          </div>
        </div>
      </div>

      {/* KPI Grid Skeleton */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {Array.from({ length: 12 }).map((_, i) => (
          <div
            key={i}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 h-32 space-y-3"
          >
            <div className="flex items-center justify-between">
              <div className="w-20 h-3 rounded bg-slate-200 dark:bg-slate-800" />
              <div className="w-8 h-8 rounded-xl bg-slate-200 dark:bg-slate-800" />
            </div>
            <div className="w-24 h-8 rounded bg-slate-200 dark:bg-slate-800" />
            <div className="w-full h-3 rounded bg-slate-200 dark:bg-slate-800" />
          </div>
        ))}
      </div>

      {/* Charts Skeleton */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 h-80 space-y-4">
          <div className="w-48 h-5 rounded bg-slate-200 dark:bg-slate-800" />
          <div className="w-full h-60 rounded-xl bg-slate-100 dark:bg-slate-800/50" />
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 h-80 space-y-4">
          <div className="w-36 h-5 rounded bg-slate-200 dark:bg-slate-800" />
          <div className="w-full h-60 rounded-xl bg-slate-100 dark:bg-slate-800/50" />
        </div>
      </div>

      {/* Bottom Grid Skeleton */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 h-72 space-y-3">
          <div className="w-40 h-5 rounded bg-slate-200 dark:bg-slate-800" />
          <div className="w-full h-12 rounded-xl bg-slate-100 dark:bg-slate-800/50" />
          <div className="w-full h-12 rounded-xl bg-slate-100 dark:bg-slate-800/50" />
          <div className="w-full h-12 rounded-xl bg-slate-100 dark:bg-slate-800/50" />
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 h-72 space-y-3">
          <div className="w-40 h-5 rounded bg-slate-200 dark:bg-slate-800" />
          <div className="w-full h-12 rounded-xl bg-slate-100 dark:bg-slate-800/50" />
          <div className="w-full h-12 rounded-xl bg-slate-100 dark:bg-slate-800/50" />
          <div className="w-full h-12 rounded-xl bg-slate-100 dark:bg-slate-800/50" />
        </div>
      </div>
    </div>
  );
};
