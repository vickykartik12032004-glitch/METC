import React from 'react';
import { SearchX, RotateCcw } from 'lucide-react';

interface DashboardEmptyStateProps {
  searchQuery: string;
  onClearSearch: () => void;
}

export const DashboardEmptyState: React.FC<DashboardEmptyStateProps> = ({
  searchQuery,
  onClearSearch,
}) => {
  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-12 text-center space-y-4 my-6">
      <div className="w-16 h-16 rounded-3xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto text-slate-400">
        <SearchX className="w-8 h-8" />
      </div>

      <div className="space-y-1">
        <h3 className="text-lg font-black text-slate-900 dark:text-slate-100">
          No matching records found
        </h3>
        <p className="text-xs text-slate-500 max-w-sm mx-auto">
          We couldn't find any MOUNTEC metrics, activities, or low stock items matching "{searchQuery}".
        </p>
      </div>

      <button
        onClick={onClearSearch}
        className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs inline-flex items-center gap-1.5 shadow-sm active:scale-95 transition-all"
      >
        <RotateCcw className="w-3.5 h-3.5" />
        <span>Clear Search Filter</span>
      </button>
    </div>
  );
};
