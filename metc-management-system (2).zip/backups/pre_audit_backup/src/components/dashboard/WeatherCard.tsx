import React from 'react';
import { WeatherData } from '../../services/dashboard.service';
import { Sun, Thermometer, Wind, Droplets, ShieldCheck, MapPin } from 'lucide-react';

interface WeatherCardProps {
  weather: WeatherData;
}

export const WeatherCard: React.FC<WeatherCardProps> = ({ weather }) => {
  return (
    <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-indigo-950 text-white rounded-2xl p-5 shadow-lg border border-slate-700/60 relative overflow-hidden space-y-4">
      {/* Decorative Glow Circle */}
      <div className="absolute top-0 right-0 w-36 h-36 bg-blue-500/10 rounded-full blur-2xl pointer-events-none" />

      {/* Header Location */}
      <div className="flex items-center justify-between text-xs text-slate-300">
        <div className="flex items-center gap-1.5 font-bold">
          <MapPin className="w-3.5 h-3.5 text-blue-400" />
          <span>{weather.siteName}</span>
        </div>
        <span className="text-[10px] bg-slate-800/80 px-2 py-0.5 rounded-full border border-slate-700 text-blue-300 font-mono">
          {weather.updatedAt}
        </span>
      </div>

      {/* Temperature & Condition */}
      <div className="flex items-center justify-between py-1">
        <div>
          <div className="text-3xl sm:text-4xl font-black tracking-tight text-white flex items-baseline gap-2">
            <span>{weather.temperatureC}°C</span>
            <span className="text-lg font-normal text-slate-400">/ {weather.temperatureF}°F</span>
          </div>
          <p className="text-xs text-amber-300 font-medium mt-1">{weather.condition}</p>
        </div>

        <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400 shadow-inner">
          <Sun className="w-8 h-8 animate-spin-slow" />
        </div>
      </div>

      {/* Metrics Row: Humidity, Wind, UV */}
      <div className="grid grid-cols-3 gap-2 pt-3 border-t border-slate-700/80 text-center text-xs">
        <div className="bg-slate-800/60 rounded-xl p-2 border border-slate-700/50">
          <Droplets className="w-3.5 h-3.5 text-blue-400 mx-auto mb-1" />
          <p className="text-[10px] text-slate-400">Humidity</p>
          <p className="font-bold text-slate-100">{weather.humidity}%</p>
        </div>

        <div className="bg-slate-800/60 rounded-xl p-2 border border-slate-700/50">
          <Wind className="w-3.5 h-3.5 text-cyan-400 mx-auto mb-1" />
          <p className="text-[10px] text-slate-400">Wind</p>
          <p className="font-bold text-slate-100">{weather.windSpeedKm} km/h</p>
        </div>

        <div className="bg-slate-800/60 rounded-xl p-2 border border-slate-700/50">
          <Thermometer className="w-3.5 h-3.5 text-amber-400 mx-auto mb-1" />
          <p className="text-[10px] text-slate-400">UV Index</p>
          <p className="font-bold text-slate-100">{weather.uvIndex}</p>
        </div>
      </div>

      {/* Site Operational Safety Banner */}
      <div className="flex items-center gap-2 p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold">
        <ShieldCheck className="w-4 h-4 shrink-0 text-emerald-400" />
        <span className="line-clamp-1">{weather.safetyStatus}</span>
      </div>
    </div>
  );
};
