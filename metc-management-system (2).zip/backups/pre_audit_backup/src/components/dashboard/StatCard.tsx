import React from 'react';
import { cn } from '../../lib/utils';

export interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: React.ReactNode;
  gradient?: 'blue' | 'emerald' | 'amber' | 'rose' | 'purple' | 'slate';
  trend?: {
    value: string;
    isPositive: boolean;
  };
  progressWidth?: string;
  onClick?: () => void;
}

export const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  subtitle,
  icon,
  gradient = 'blue',
  trend,
  progressWidth,
  onClick,
}) => {
  const gradients = {
    blue: 'from-blue-600/10 via-blue-500/5 to-transparent border-slate-200/80 dark:border-slate-800 text-blue-600 dark:text-blue-400',
    emerald: 'from-emerald-600/10 via-emerald-500/5 to-transparent border-slate-200/80 dark:border-slate-800 text-emerald-600 dark:text-emerald-400',
    amber: 'from-amber-600/10 via-amber-500/5 to-transparent border-slate-200/80 dark:border-slate-800 text-amber-600 dark:text-amber-400',
    rose: 'from-rose-600/10 via-rose-500/5 to-transparent border-slate-200/80 dark:border-slate-800 text-rose-600 dark:text-rose-400',
    purple: 'from-purple-600/10 via-purple-500/5 to-transparent border-slate-200/80 dark:border-slate-800 text-purple-600 dark:text-purple-400',
    slate: 'from-slate-600/10 via-slate-500/5 to-transparent border-slate-200/80 dark:border-slate-800 text-slate-600 dark:text-slate-400',
  };

  const iconBg = {
    blue: 'bg-blue-100 dark:bg-blue-950/80 text-blue-600 dark:text-blue-400',
    emerald: 'bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400',
    amber: 'bg-amber-100 dark:bg-amber-950/80 text-amber-600 dark:text-amber-400',
    rose: 'bg-rose-100 dark:bg-rose-950/80 text-rose-600 dark:text-rose-400',
    purple: 'bg-purple-100 dark:bg-purple-950/80 text-purple-600 dark:text-purple-400',
    slate: 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400',
  };

  const progressBarBg = {
    blue: 'bg-blue-500',
    emerald: 'bg-emerald-500',
    amber: 'bg-amber-500',
    rose: 'bg-rose-500',
    purple: 'bg-purple-500',
    slate: 'bg-slate-500',
  };

  const defaultProgress = {
    blue: '75%',
    emerald: '88%',
    amber: '42%',
    rose: '15%',
    purple: '60%',
    slate: '50%',
  };

  return (
    <div
      onClick={onClick}
      className={cn(
        'relative bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl p-5 shadow-xs hover:shadow-md transition-all duration-200 cursor-pointer overflow-hidden group',
        gradients[gradient]
      )}
    >
      <div className="flex items-start justify-between mb-2">
        <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
          {title}
        </span>
        <div className={cn('p-2.5 rounded-lg transition-transform duration-200 group-hover:scale-105', iconBg[gradient])}>
          {icon}
        </div>
      </div>

      <div className="text-2xl md:text-3xl font-extrabold text-slate-800 dark:text-slate-100 tracking-tight">
        {value}
      </div>

      <div className="flex items-center justify-between mt-1 text-xs">
        {subtitle && <p className="text-slate-500 dark:text-slate-400 text-xs">{subtitle}</p>}
        {trend && (
          <span className={cn('text-[11px] font-bold px-1.5 py-0.5 rounded', trend.isPositive ? 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40' : 'text-rose-600 bg-rose-50 dark:bg-rose-950/40')}>
            {trend.isPositive ? '+' : ''}{trend.value}
          </span>
        )}
      </div>

      {/* Geometric horizontal bar */}
      <div className="mt-3 h-1 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
        <div
          className={cn('h-1 rounded-full transition-all duration-500', progressBarBg[gradient])}
          style={{ width: progressWidth || defaultProgress[gradient] }}
        />
      </div>
    </div>
  );
};
