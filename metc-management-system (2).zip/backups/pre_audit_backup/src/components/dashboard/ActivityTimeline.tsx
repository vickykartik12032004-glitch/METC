import React from 'react';
import { ActivityItem } from '../../services/dashboard.service';
import { 
  ArrowUpRight, 
  ArrowDownLeft, 
  Wrench, 
  UserPlus, 
  Cpu, 
  Clock, 
  CheckCircle2, 
  Hourglass 
} from 'lucide-react';

interface ActivityTimelineProps {
  activities: ActivityItem[];
}

export const ActivityTimeline: React.FC<ActivityTimelineProps> = ({ activities }) => {
  const getTypeIcon = (type: ActivityItem['type']) => {
    switch (type) {
      case 'issue':
        return <ArrowUpRight className="w-3.5 h-3.5 text-blue-500" />;
      case 'return':
        return <ArrowDownLeft className="w-3.5 h-3.5 text-emerald-500" />;
      case 'repair':
        return <Wrench className="w-3.5 h-3.5 text-amber-500" />;
      case 'worker':
        return <UserPlus className="w-3.5 h-3.5 text-purple-500" />;
      case 'system':
        return <Cpu className="w-3.5 h-3.5 text-cyan-500" />;
      default:
        return <Clock className="w-3.5 h-3.5 text-slate-500" />;
    }
  };

  return (
    <div className="space-y-4">
      {activities.map((item, idx) => (
        <div key={item.id} className="relative flex items-start gap-3 text-xs group">
          {/* Timeline Connector Vertical Line */}
          {idx !== activities.length - 1 && (
            <span className="absolute left-4 top-8 -bottom-4 w-0.5 bg-slate-200 dark:bg-slate-800" />
          )}

          {/* User Avatar Circle */}
          <div className="relative z-10 w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center shrink-0 font-bold text-slate-700 dark:text-slate-300 shadow-2xs group-hover:scale-110 transition-transform">
            {item.user.charAt(0)}
          </div>

          {/* Activity Content Box */}
          <div className="flex-1 bg-slate-50/80 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-700/60 rounded-xl p-3 space-y-1 hover:bg-slate-100/60 dark:hover:bg-slate-800/80 transition-colors">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="font-bold text-slate-900 dark:text-slate-100">{item.user}</span>
                <span className="text-[10px] text-slate-500 bg-slate-200 dark:bg-slate-700 px-1.5 py-0.5 rounded-md font-medium">
                  {item.role}
                </span>
              </div>

              <span className="text-[10px] text-slate-400 font-mono whitespace-nowrap flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {item.timestamp}
              </span>
            </div>

            <p className="font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
              {getTypeIcon(item.type)}
              <span>{item.action}</span>
            </p>

            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              {item.target}
            </p>

            <div className="pt-1 flex items-center justify-between text-[10px]">
              <span className={`font-bold flex items-center gap-1 ${
                item.status === 'Completed'
                  ? 'text-emerald-600 dark:text-emerald-400'
                  : 'text-amber-600 dark:text-amber-400'
              }`}>
                {item.status === 'Completed' ? (
                  <CheckCircle2 className="w-3 h-3" />
                ) : (
                  <Hourglass className="w-3 h-3 animate-spin" />
                )}
                {item.status}
              </span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};
