import React from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell, 
  Legend 
} from 'recharts';

export const AssetCategoryChart: React.FC = () => {
  const data = [
    { name: 'Materials', count: 120, value: 58000 },
    { name: 'Equipment', count: 6, value: 844000 },
    { name: 'Tools', count: 27, value: 20900 },
    { name: 'Consumables', count: 375, value: 8250 },
  ];

  const COLORS = ['#2563eb', '#10b981', '#f59e0b', '#8b5cf6'];

  return (
    <div className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={80}
            paddingAngle={5}
            dataKey="count"
          >
            {data.map((_, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip 
            contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', color: '#fff', fontSize: '12px' }} 
          />
          <Legend verticalAlign="bottom" height={36} wrapperStyle={{ fontSize: '12px' }} />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
};

export const MonthlyTransactionsChart: React.FC = () => {
  const data = [
    { month: 'Oct', Issued: 45, Returned: 38, Repaired: 4 },
    { month: 'Nov', Issued: 60, Returned: 52, Repaired: 6 },
    { month: 'Dec', Issued: 80, Returned: 71, Repaired: 5 },
    { month: 'Jan', Issued: 95, Returned: 84, Repaired: 8 },
    { month: 'Feb', Issued: 110, Returned: 92, Repaired: 3 },
  ];

  return (
    <div className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data}>
          <XAxis dataKey="month" stroke="#94a3b8" fontSize={11} />
          <YAxis stroke="#94a3b8" fontSize={11} />
          <Tooltip 
            contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', color: '#fff', fontSize: '12px' }} 
          />
          <Legend verticalAlign="top" wrapperStyle={{ fontSize: '12px', paddingBottom: '10px' }} />
          <Bar dataKey="Issued" fill="#10b981" radius={[4, 4, 0, 0]} />
          <Bar dataKey="Returned" fill="#0284c7" radius={[4, 4, 0, 0]} />
          <Bar dataKey="Repaired" fill="#f59e0b" radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};
