import React from 'react';
import { motion } from 'motion/react';
import { ArrowUpRight, ArrowDownRight, Minus } from 'lucide-react';
import { DashboardKpi } from '../../services/dashboard.service';

interface DashboardCardProps {
  kpi: DashboardKpi;
  icon: React.ReactNode;
  onClick?: () => void;
}

const colorStyles = {
  blue: {
    bg: 'bg-blue-500/10 dark:bg-blue-500/15',
    border: 'border-blue-200 dark:border-blue-800/60 hover:border-blue-500/50',
    iconBg: 'bg-blue-600 text-white shadow-blue-500/20',
    accentText: 'text-blue-600 dark:text-blue-400',
    glow: 'group-hover:shadow-blue-500/10',
  },
  emerald: {
    bg: 'bg-emerald-500/10 dark:bg-emerald-500/15',
    border: 'border-emerald-200 dark:border-emerald-800/60 hover:border-emerald-500/50',
    iconBg: 'bg-emerald-600 text-white shadow-emerald-500/20',
    accentText: 'text-emerald-600 dark:text-emerald-400',
    glow: 'group-hover:shadow-emerald-500/10',
  },
  purple: {
    bg: 'bg-purple-500/10 dark:bg-purple-500/15',
    border: 'border-purple-200 dark:border-purple-800/60 hover:border-purple-500/50',
    iconBg: 'bg-purple-600 text-white shadow-purple-500/20',
    accentText: 'text-purple-600 dark:text-purple-400',
    glow: 'group-hover:shadow-purple-500/10',
  },
  amber: {
    bg: 'bg-amber-500/10 dark:bg-amber-500/15',
    border: 'border-amber-200 dark:border-amber-800/60 hover:border-amber-500/50',
    iconBg: 'bg-amber-600 text-white shadow-amber-500/20',
    accentText: 'text-amber-600 dark:text-amber-400',
    glow: 'group-hover:shadow-amber-500/10',
  },
  rose: {
    bg: 'bg-rose-500/10 dark:bg-rose-500/15',
    border: 'border-rose-200 dark:border-rose-800/60 hover:border-rose-500/50',
    iconBg: 'bg-rose-600 text-white shadow-rose-500/20',
    accentText: 'text-rose-600 dark:text-rose-400',
    glow: 'group-hover:shadow-rose-500/10',
  },
  indigo: {
    bg: 'bg-indigo-500/10 dark:bg-indigo-500/15',
    border: 'border-indigo-200 dark:border-indigo-800/60 hover:border-indigo-500/50',
    iconBg: 'bg-indigo-600 text-white shadow-indigo-500/20',
    accentText: 'text-indigo-600 dark:text-indigo-400',
    glow: 'group-hover:shadow-indigo-500/10',
  },
  cyan: {
    bg: 'bg-cyan-500/10 dark:bg-cyan-500/15',
    border: 'border-cyan-200 dark:border-cyan-800/60 hover:border-cyan-500/50',
    iconBg: 'bg-cyan-600 text-white shadow-cyan-500/20',
    accentText: 'text-cyan-600 dark:text-cyan-400',
    glow: 'group-hover:shadow-cyan-500/10',
  },
  teal: {
    bg: 'bg-teal-500/10 dark:bg-teal-500/15',
    border: 'border-teal-200 dark:border-teal-800/60 hover:border-teal-500/50',
    iconBg: 'bg-teal-600 text-white shadow-teal-500/20',
    accentText: 'text-teal-600 dark:text-teal-400',
    glow: 'group-hover:shadow-teal-500/10',
  },
};

export const DashboardCard: React.FC<DashboardCardProps> = ({ kpi, icon, onClick }) => {
  const styles = colorStyles[kpi.color] || colorStyles.blue;
  const isPositive = kpi.todayDiff > 0;
  const isNegative = kpi.todayDiff < 0;

  // Determine indicator status (Green/Red depends on whether positive diff is good or bad)
  const isGoodChange = kpi.isPositiveGood ? isPositive : isNegative;

  return (
    <motion.div
      whileHover={{ y: -4, scale: 1.01 }}
      transition={{ duration: 0.2, ease: 'easeOut' }}
      onClick={onClick}
      className={`group relative bg-white dark:bg-slate-900 border ${styles.border} rounded-2xl p-4 sm:p-5 shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer overflow-hidden ${styles.glow}`}
    >
      {/* Background Accent Gradient Overlay */}
      <div className={`absolute top-0 right-0 w-28 h-28 ${styles.bg} rounded-bl-full pointer-events-none transition-opacity duration-300 opacity-50 group-hover:opacity-100`} />

      <div className="relative z-10 space-y-3">
        {/* Card Header: Icon & Title */}
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-slate-500 dark:text-slate-400 tracking-wide uppercase truncate pr-2">
            {kpi.title}
          </span>

          <div className={`w-9 h-9 rounded-xl ${styles.iconBg} flex items-center justify-center shadow-md shrink-0 transition-transform group-hover:scale-110`}>
            {icon}
          </div>
        </div>

        {/* Card Main Metric Value */}
        <div className="flex items-baseline justify-between">
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-slate-100 tracking-tight">
            {kpi.value.toLocaleString()}
            {kpi.unit && <span className="text-xs font-medium text-slate-500 ml-1">{kpi.unit}</span>}
          </h2>
        </div>

        {/* Card Footer: Today's Diff & Percent Change */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800/80 text-[11px]">
          <div className="flex items-center gap-1 font-semibold">
            {isPositive && (
              <span className={`inline-flex items-center gap-0.5 ${isGoodChange ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}`}>
                <ArrowUpRight className="w-3.5 h-3.5" />
                <span>+{kpi.todayDiff} today</span>
              </span>
            )}
            {isNegative && (
              <span className={`inline-flex items-center gap-0.5 ${isGoodChange ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}`}>
                <ArrowDownRight className="w-3.5 h-3.5" />
                <span>{kpi.todayDiff} today</span>
              </span>
            )}
            {!isPositive && !isNegative && (
              <span className="inline-flex items-center gap-0.5 text-slate-400">
                <Minus className="w-3.5 h-3.5" />
                <span>0 today</span>
              </span>
            )}
          </div>

          <div className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
            isGoodChange
              ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300'
              : 'bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300'
          }`}>
            {kpi.percentChange > 0 ? `+${kpi.percentChange}%` : `${kpi.percentChange}%`}
          </div>
        </div>
      </div>
    </motion.div>
  );
};
