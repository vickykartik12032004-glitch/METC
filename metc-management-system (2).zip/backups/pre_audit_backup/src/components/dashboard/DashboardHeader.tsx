import React from 'react';
import { 
  Calendar, 
  Clock, 
  RefreshCw, 
  Search, 
  SlidersHorizontal, 
  Sparkles, 
  User as UserIcon, 
  Building2,
  ShieldCheck
} from 'lucide-react';
import { TimeFilter } from '../../hooks/dashboard/useDashboard';
import { User, UserRole } from '../../types';
import { RoleBadge } from '../common/RoleBadge';

interface DashboardHeaderProps {
  user: User | null;
  role: UserRole;
  formattedDate: string;
  formattedTime: string;
  timeFilter: TimeFilter;
  onTimeFilterChange: (filter: TimeFilter) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  isLoading: boolean;
  onRefresh: () => void;
}

export const DashboardHeader: React.FC<DashboardHeaderProps> = ({
  user,
  role,
  formattedDate,
  formattedTime,
  timeFilter,
  onTimeFilterChange,
  searchQuery,
  onSearchChange,
  isLoading,
  onRefresh,
}) => {
  const timeFilterOptions: TimeFilter[] = ['Today', 'This Week', 'This Month', 'This Year'];

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 md:p-6 shadow-sm space-y-5">
      {/* Top Banner Row */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        {/* User Greeting & Status */}
        <div className="flex items-start sm:items-center gap-3.5">
          <div className="relative">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-purple-600 flex items-center justify-center text-white font-black text-xl shadow-lg shadow-blue-500/20 ring-2 ring-blue-500/30">
              {user?.name ? user.name.charAt(0) : 'A'}
            </div>
            <span className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900 animate-pulse" />
          </div>

          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 tracking-tight">
                Welcome back, {user?.name || 'Administrator'}
              </h1>
              <RoleBadge role={role} />
            </div>

            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 flex items-center gap-2 flex-wrap">
              <span className="flex items-center gap-1">
                <Building2 className="w-3.5 h-3.5 text-blue-500" />
                {user?.department || 'Site Operations'}
              </span>
              <span>•</span>
              <span className="text-slate-600 dark:text-slate-300 font-medium">MOUNTEC Enterprise Hub</span>
            </p>
          </div>
        </div>

        {/* Date & Time Live Widgets */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/60 text-xs text-slate-700 dark:text-slate-300 font-semibold shadow-2xs">
            <Calendar className="w-4 h-4 text-blue-500" />
            <span>{formattedDate}</span>
          </div>

          <div className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-blue-50 dark:bg-blue-950/50 border border-blue-200/80 dark:border-blue-900/60 text-xs text-blue-700 dark:text-blue-300 font-bold shadow-2xs">
            <Clock className="w-4 h-4 text-blue-600 dark:text-blue-400 animate-pulse" />
            <span>{formattedTime}</span>
          </div>

          <button
            onClick={onRefresh}
            disabled={isLoading}
            className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 transition-all active:scale-95 disabled:opacity-50"
            title="Refresh Live Telemetry"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-blue-500' : ''}`} />
          </button>
        </div>
      </div>

      {/* Bottom Filter & Search Bar Row */}
      <div className="pt-4 border-t border-slate-100 dark:border-slate-800/80 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Search Bar */}
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Global Search: Filter KPI cards, activities, issues & stock..."
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
          />
        </div>

        {/* Time Filter Pills */}
        <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700 self-start md:self-auto overflow-x-auto max-w-full">
          <SlidersHorizontal className="w-3.5 h-3.5 text-slate-400 ml-2 mr-1 shrink-0" />
          {timeFilterOptions.map((option) => (
            <button
              key={option}
              onClick={() => onTimeFilterChange(option)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all ${
                timeFilter === option
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
              }`}
            >
              {option}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
