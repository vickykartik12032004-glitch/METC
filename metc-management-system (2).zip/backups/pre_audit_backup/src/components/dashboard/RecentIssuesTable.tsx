import React from 'react';
import { useNavigate } from 'react-router-dom';
import { RecentIssueRecord } from '../../services/dashboard.service';
import { Clock, User, Package, Calendar, ArrowUpRight, Eye } from 'lucide-react';

interface RecentIssuesTableProps {
  issues: RecentIssueRecord[];
}

export const RecentIssuesTable: React.FC<RecentIssuesTableProps> = ({ issues }) => {
  const navigate = useNavigate();

  const getStatusBadge = (status: RecentIssueRecord['status']) => {
    switch (status) {
      case 'Active':
        return (
          <span className="px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-950/80 text-blue-700 dark:text-blue-300 font-extrabold text-[10px]">
            Active Issue
          </span>
        );
      case 'Returned':
        return (
          <span className="px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 font-extrabold text-[10px]">
            Returned
          </span>
        );
      case 'Overdue':
        return (
          <span className="px-2 py-0.5 rounded-full bg-rose-100 dark:bg-rose-950/80 text-rose-700 dark:text-rose-300 font-extrabold text-[10px] animate-pulse">
            Overdue
          </span>
        );
      case 'Pending Return':
        return (
          <span className="px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950/80 text-amber-700 dark:text-amber-300 font-extrabold text-[10px]">
            Pending Return
          </span>
        );
    }
  };

  return (
    <div className="space-y-3">
      {/* MOBILE RESPONSIVE CARDS VIEW (Visible on mobile/tablet screens) */}
      <div className="grid grid-cols-1 gap-2.5 md:hidden">
        {issues.map((rec) => (
          <div
            key={rec.id}
            onClick={() => navigate('/issue')}
            className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200/80 dark:border-slate-700/80 space-y-2 cursor-pointer hover:border-blue-400 transition-colors"
          >
            <div className="flex items-start justify-between gap-2">
              <div>
                <span className="font-mono font-bold text-xs text-blue-600 dark:text-blue-400">
                  {rec.issueCode}
                </span>
                <div className="font-bold text-xs text-slate-900 dark:text-slate-100 mt-0.5">
                  {rec.workerName}
                </div>
                <span className="text-[10px] text-slate-500">{rec.workerRole}</span>
              </div>
              {getStatusBadge(rec.status)}
            </div>

            <div className="flex items-center justify-between pt-1 border-t border-slate-200/60 dark:border-slate-700/60 text-xs">
              <div className="min-w-0 pr-2">
                <span className="font-medium text-slate-800 dark:text-slate-200 block truncate">
                  {rec.itemName}
                </span>
                <span className="text-[10px] text-slate-400 font-mono">{rec.itemCode}</span>
              </div>

              <div className="text-right shrink-0">
                <span className="text-[10px] text-slate-400 block">Due Date:</span>
                <span className="font-mono text-xs font-semibold text-slate-700 dark:text-slate-300">
                  {rec.expectedReturnDate}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* DESKTOP SPREADSHEET TABLE VIEW */}
      <div className="hidden md:block overflow-x-auto">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider text-[10px]">
              <th className="py-2.5 px-3">Issue Code</th>
              <th className="py-2.5 px-3">Worker Details</th>
              <th className="py-2.5 px-3">Item</th>
              <th className="py-2.5 px-3">Issue Date</th>
              <th className="py-2.5 px-3">Expected Return</th>
              <th className="py-2.5 px-3 text-center">Status</th>
              <th className="py-2.5 px-3 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80">
            {issues.map((rec) => (
              <tr
                key={rec.id}
                className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors"
              >
                <td className="py-3 px-3 font-mono font-bold text-blue-600 dark:text-blue-400 whitespace-nowrap">
                  {rec.issueCode}
                </td>
                <td className="py-3 px-3 whitespace-nowrap">
                  <div className="font-bold text-slate-900 dark:text-slate-100">{rec.workerName}</div>
                  <div className="text-[10px] text-slate-500">{rec.workerRole}</div>
                </td>
                <td className="py-3 px-3 whitespace-nowrap">
                  <div className="font-bold text-slate-800 dark:text-slate-200">{rec.itemName}</div>
                  <div className="text-[10px] text-slate-400 font-mono">{rec.itemCode}</div>
                </td>
                <td className="py-3 px-3 text-slate-600 dark:text-slate-300 font-mono whitespace-nowrap">
                  {rec.issueDate}
                </td>
                <td className="py-3 px-3 text-slate-600 dark:text-slate-300 font-mono whitespace-nowrap">
                  {rec.expectedReturnDate}
                </td>
                <td className="py-3 px-3 text-center whitespace-nowrap">
                  {getStatusBadge(rec.status)}
                </td>
                <td className="py-3 px-3 text-right whitespace-nowrap">
                  <button
                    onClick={() => navigate('/issue')}
                    className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-blue-50 dark:hover:bg-blue-900/50 text-slate-600 dark:text-slate-300 hover:text-blue-600 transition-colors inline-flex items-center gap-1"
                    title="View Issue Details"
                  >
                    <Eye className="w-3.5 h-3.5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
