import React from 'react';
import { useNavigate } from 'react-router-dom';
import { LowStockItem } from '../../services/dashboard.service';
import { AlertTriangle, ShoppingCart, MapPin, Package } from 'lucide-react';

interface LowStockTableProps {
  items: LowStockItem[];
}

export const LowStockTable: React.FC<LowStockTableProps> = ({ items }) => {
  const navigate = useNavigate();

  return (
    <div className="space-y-3">
      {items.map((item) => {
        const percentage = Math.min(100, Math.round((item.currentStock / item.minStock) * 100));
        const isCritical = item.status === 'Critical';

        return (
          <div
            key={item.id}
            className={`p-3.5 rounded-xl border transition-all duration-200 text-xs space-y-2 ${
              isCritical
                ? 'bg-rose-50/50 dark:bg-rose-950/30 border-rose-200/80 dark:border-rose-900/60'
                : 'bg-amber-50/50 dark:bg-amber-950/30 border-amber-200/80 dark:border-amber-900/60'
            }`}
          >
            {/* Top row */}
            <div className="flex items-start justify-between gap-2">
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="font-extrabold text-slate-900 dark:text-slate-100">
                    {item.name}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded-md font-bold text-[10px] uppercase ${
                      isCritical
                        ? 'bg-rose-100 dark:bg-rose-900/60 text-rose-700 dark:text-rose-300'
                        : 'bg-amber-100 dark:bg-amber-900/60 text-amber-700 dark:text-amber-300'
                    }`}
                  >
                    {item.status}
                  </span>
                </div>

                <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400">
                  <span className="font-mono text-slate-600 dark:text-slate-300">{item.code}</span>
                  <span>•</span>
                  <span className="flex items-center gap-0.5">
                    <Package className="w-3 h-3 text-slate-400" />
                    {item.category}
                  </span>
                  <span>•</span>
                  <span className="flex items-center gap-0.5">
                    <MapPin className="w-3 h-3 text-slate-400" />
                    {item.location}
                  </span>
                </div>
              </div>

              {/* Action Button */}
              <button
                onClick={() => navigate('/materials')}
                className="px-2.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-[11px] flex items-center gap-1 shadow-2xs active:scale-95 transition-transform"
              >
                <ShoppingCart className="w-3 h-3" />
                <span>Restock</span>
              </button>
            </div>

            {/* Stock Level Progress Bar */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-slate-500">
                  Current: <strong className="text-slate-900 dark:text-slate-100">{item.currentStock} {item.unit}</strong>
                </span>
                <span className="text-slate-500">
                  Threshold: <strong className="text-slate-700 dark:text-slate-300">{item.minStock} {item.unit}</strong>
                </span>
              </div>

              <div className="w-full h-2 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                <div
                  className={`h-full transition-all duration-500 ${
                    isCritical ? 'bg-rose-500' : 'bg-amber-500'
                  }`}
                  style={{ width: `${percentage}%` }}
                />
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};
