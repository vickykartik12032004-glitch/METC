import React from 'react';
import { useTransactionStore } from '../../store/useTransactionStore';
import { formatDateTime } from '../../lib/utils';
import { ArrowUpRight, ArrowDownLeft, ArrowRightLeft, Hammer, ShieldAlert, PlusCircle } from 'lucide-react';

export const RecentActivityList: React.FC = () => {
  const { activities } = useTransactionStore();

  const getActionIcon = (action: string) => {
    switch (action) {
      case 'Issued':
        return <ArrowUpRight className="w-4 h-4 text-emerald-500" />;
      case 'Returned':
        return <ArrowDownLeft className="w-4 h-4 text-sky-500" />;
      case 'Transferred':
        return <ArrowRightLeft className="w-4 h-4 text-purple-500" />;
      case 'Sent for Repair':
        return <Hammer className="w-4 h-4 text-amber-500" />;
      case 'Reported Lost':
        return <ShieldAlert className="w-4 h-4 text-rose-500" />;
      default:
        return <PlusCircle className="w-4 h-4 text-blue-500" />;
    }
  };

  return (
    <div className="space-y-3">
      {activities.slice(0, 5).map((act) => (
        <div
          key={act.id}
          className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 transition-colors hover:bg-slate-100/80 dark:hover:bg-slate-800"
        >
          <div className="p-2 rounded-lg bg-white dark:bg-slate-900 shadow-2xs border border-slate-200 dark:border-slate-700 shrink-0">
            {getActionIcon(act.action)}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between gap-2">
              <p className="text-xs font-semibold text-slate-900 dark:text-slate-100 truncate">
                {act.action}: <span className="font-normal text-slate-700 dark:text-slate-300">{act.targetName}</span>
              </p>
              <span className="text-[10px] text-slate-400 shrink-0">{formatDateTime(act.timestamp)}</span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 truncate">{act.details}</p>
            <p className="text-[10px] text-slate-400 mt-1">By: <strong className="font-medium text-slate-600 dark:text-slate-300">{act.user}</strong></p>
          </div>
        </div>
      ))}
    </div>
  );
};
