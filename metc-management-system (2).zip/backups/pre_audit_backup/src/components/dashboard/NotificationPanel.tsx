import React, { useState } from 'react';
import { SystemNotification } from '../../services/dashboard.service';
import { AlertTriangle, CheckCircle, ShieldAlert, Info, Bell, CheckCheck } from 'lucide-react';

interface NotificationPanelProps {
  notifications: SystemNotification[];
}

export const NotificationPanel: React.FC<NotificationPanelProps> = ({ notifications: initial }) => {
  const [list, setList] = useState<SystemNotification[]>(initial);

  const unreadCount = list.filter((n) => !n.read).length;

  const handleMarkAllRead = () => {
    setList(list.map((n) => ({ ...n, read: true })));
  };

  const getNotifIcon = (type: SystemNotification['type']) => {
    switch (type) {
      case 'low_stock':
        return <AlertTriangle className="w-4 h-4 text-amber-500" />;
      case 'repair_complete':
        return <CheckCircle className="w-4 h-4 text-emerald-500" />;
      case 'warranty_expiry':
        return <ShieldAlert className="w-4 h-4 text-rose-500" />;
      case 'system_alert':
        return <Info className="w-4 h-4 text-blue-500" />;
    }
  };

  return (
    <div className="space-y-3">
      {/* Header Bar */}
      <div className="flex items-center justify-between text-xs pb-2 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-2">
          <Bell className="w-4 h-4 text-blue-500" />
          <span className="font-bold text-slate-900 dark:text-slate-100">Live Alerts Feed</span>
          {unreadCount > 0 && (
            <span className="px-2 py-0.5 rounded-full bg-rose-500 text-white font-extrabold text-[10px]">
              {unreadCount} Unread
            </span>
          )}
        </div>

        {unreadCount > 0 && (
          <button
            onClick={handleMarkAllRead}
            className="text-[11px] text-blue-600 dark:text-blue-400 font-bold hover:underline flex items-center gap-1"
          >
            <CheckCheck className="w-3.5 h-3.5" />
            Mark all read
          </button>
        )}
      </div>

      {/* List */}
      <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
        {list.map((n) => (
          <div
            key={n.id}
            className={`p-3 rounded-xl border text-xs space-y-1 transition-all ${
              !n.read
                ? 'bg-blue-50/50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-900/60 font-semibold'
                : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700/60 opacity-80'
            }`}
          >
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2">
                {getNotifIcon(n.type)}
                <span className="font-bold text-slate-900 dark:text-slate-100">{n.title}</span>
              </div>
              <span className="text-[10px] text-slate-400 font-mono shrink-0">{n.timeAgo}</span>
            </div>

            <p className="text-[11px] text-slate-600 dark:text-slate-300 font-normal leading-relaxed pl-6">
              {n.message}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};
