import React from 'react';
import { CompanyMetrics } from '../../services/dashboard.service';
import { Building2, MapPin, Users, Layers, DollarSign, HardHat } from 'lucide-react';

interface CompanySummaryProps {
  company: CompanyMetrics;
}

export const CompanySummary: React.FC<CompanySummaryProps> = ({ company }) => {
  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
      {/* Company Header */}
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-slate-900 to-slate-700 dark:from-blue-600 dark:to-indigo-600 flex items-center justify-center text-white font-black text-xl shadow-md">
          <Building2 className="w-6 h-6" />
        </div>
        <div>
          <h3 className="text-base font-black text-slate-900 dark:text-slate-100 tracking-tight">
            {company.companyName}
          </h3>
          <p className="text-xs text-slate-500">Enterprise Asset & Workforce Portfolio</p>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 pt-2 text-xs">
        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60 space-y-1">
          <div className="flex items-center gap-1 text-slate-500 text-[10px] font-bold">
            <Building2 className="w-3 h-3 text-blue-500" />
            <span>Branches</span>
          </div>
          <p className="text-lg font-black text-slate-900 dark:text-slate-100">{company.branchCount}</p>
        </div>

        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60 space-y-1">
          <div className="flex items-center gap-1 text-slate-500 text-[10px] font-bold">
            <MapPin className="w-3 h-3 text-emerald-500" />
            <span>Sites</span>
          </div>
          <p className="text-lg font-black text-slate-900 dark:text-slate-100">{company.siteCount}</p>
        </div>

        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60 space-y-1">
          <div className="flex items-center gap-1 text-slate-500 text-[10px] font-bold">
            <Layers className="w-3 h-3 text-purple-500" />
            <span>Departments</span>
          </div>
          <p className="text-lg font-black text-slate-900 dark:text-slate-100">{company.departmentCount}</p>
        </div>

        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60 space-y-1">
          <div className="flex items-center gap-1 text-slate-500 text-[10px] font-bold">
            <Users className="w-3 h-3 text-amber-500" />
            <span>Workers</span>
          </div>
          <p className="text-lg font-black text-slate-900 dark:text-slate-100">{company.workerCount}</p>
        </div>

        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60 space-y-1">
          <div className="flex items-center gap-1 text-slate-500 text-[10px] font-bold">
            <HardHat className="w-3 h-3 text-cyan-500" />
            <span>Projects</span>
          </div>
          <p className="text-lg font-black text-slate-900 dark:text-slate-100">{company.activeProjects}</p>
        </div>

        <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border border-emerald-500/20 space-y-1">
          <div className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 text-[10px] font-bold">
            <DollarSign className="w-3 h-3" />
            <span>Asset Value</span>
          </div>
          <p className="text-lg font-black text-emerald-700 dark:text-emerald-300">{company.totalAssetValue}</p>
        </div>
      </div>
    </div>
  );
};
