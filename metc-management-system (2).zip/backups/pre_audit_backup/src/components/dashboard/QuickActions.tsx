import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { 
  ArrowUpRight, 
  ArrowDownLeft, 
  ArrowRightLeft, 
  PlusCircle, 
  UserPlus, 
  FileText, 
  Bell, 
  Settings 
} from 'lucide-react';

export const QuickActions: React.FC = () => {
  const navigate = useNavigate();

  const actions = [
    {
      label: 'Issue Item',
      description: 'Dispatch asset to worker',
      icon: <ArrowUpRight className="w-4 h-4 text-blue-600 dark:text-blue-400" />,
      bg: 'bg-blue-50 dark:bg-blue-950/50 hover:bg-blue-100 dark:hover:bg-blue-900/60 border-blue-200 dark:border-blue-800/60',
      path: '/issue',
    },
    {
      label: 'Return Item',
      description: 'Receive returned MOUNTEC',
      icon: <ArrowDownLeft className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />,
      bg: 'bg-emerald-50 dark:bg-emerald-950/50 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 border-emerald-200 dark:border-emerald-800/60',
      path: '/return',
    },
    {
      label: 'Transfer Item',
      description: 'Move between sites',
      icon: <ArrowRightLeft className="w-4 h-4 text-purple-600 dark:text-purple-400" />,
      bg: 'bg-purple-50 dark:bg-purple-950/50 hover:bg-purple-100 dark:hover:bg-purple-900/60 border-purple-200 dark:border-purple-800/60',
      path: '/transfer',
    },
    {
      label: 'Add New Item',
      description: 'Register asset in database',
      icon: <PlusCircle className="w-4 h-4 text-amber-600 dark:text-amber-400" />,
      bg: 'bg-amber-50 dark:bg-amber-950/50 hover:bg-amber-100 dark:hover:bg-amber-900/60 border-amber-200 dark:border-amber-800/60',
      path: '/materials',
    },
    {
      label: 'Register Worker',
      description: 'Add personnel profile',
      icon: <UserPlus className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />,
      bg: 'bg-cyan-50 dark:bg-cyan-950/50 hover:bg-cyan-100 dark:hover:bg-cyan-900/60 border-cyan-200 dark:border-cyan-800/60',
      path: '/workers',
    },
    {
      label: 'Generate Report',
      description: 'Export PDF / Excel audit',
      icon: <FileText className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />,
      bg: 'bg-indigo-50 dark:bg-indigo-950/50 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 border-indigo-200 dark:border-indigo-800/60',
      path: '/reports',
    },
    {
      label: 'Notifications',
      description: 'View active alerts',
      icon: <Bell className="w-4 h-4 text-rose-600 dark:text-rose-400" />,
      bg: 'bg-rose-50 dark:bg-rose-950/50 hover:bg-rose-100 dark:hover:bg-rose-900/60 border-rose-200 dark:border-rose-800/60',
      path: '/notifications',
    },
    {
      label: 'Settings',
      description: 'System configuration',
      icon: <Settings className="w-4 h-4 text-slate-600 dark:text-slate-400" />,
      bg: 'bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border-slate-200 dark:border-slate-700',
      path: '/settings',
    },
  ];

  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
      {actions.map((act) => (
        <motion.button
          key={act.label}
          whileHover={{ scale: 1.03, y: -2 }}
          whileTap={{ scale: 0.97 }}
          onClick={() => navigate(act.path)}
          className={`flex flex-col items-start p-3 rounded-xl border ${act.bg} text-left transition-all duration-200 cursor-pointer shadow-2xs group`}
        >
          <div className="p-2 rounded-lg bg-white dark:bg-slate-900 shadow-xs mb-2 group-hover:scale-110 transition-transform">
            {act.icon}
          </div>
          <span className="text-xs font-bold text-slate-900 dark:text-slate-100 leading-tight">
            {act.label}
          </span>
          <span className="text-[10px] text-slate-500 dark:text-slate-400 line-clamp-1 mt-0.5">
            {act.description}
          </span>
        </motion.button>
      ))}
    </div>
  );
};
