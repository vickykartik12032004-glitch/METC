import React, { ErrorInfo, ReactNode } from 'react';
import { AlertOctagon, RefreshCw } from 'lucide-react';
import { Button } from '../ui/Button';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends (React.Component as any)<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
    };
  }

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('MOUNTEC System Error Boundary caught error:', error, errorInfo);
  }

  public handleReset = () => {
    this.setState({ hasError: false, error: null });
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center p-6 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100">
          <div className="max-w-md w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xl p-8 text-center">
            <div className="w-16 h-16 rounded-full bg-rose-100 dark:bg-rose-950/80 text-rose-600 dark:text-rose-400 flex items-center justify-center mx-auto mb-4">
              <AlertOctagon className="w-8 h-8" />
            </div>
            <h2 className="text-xl font-bold mb-2">Something went wrong</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-6">
              The application encountered an unexpected runtime exception. You can refresh or try again.
            </p>
            {this.state.error && (
              <pre className="text-[11px] bg-slate-100 dark:bg-slate-950 p-3 rounded-lg text-rose-600 dark:text-rose-400 text-left overflow-x-auto mb-6 max-h-32 border border-slate-200 dark:border-slate-800">
                {this.state.error.message}
              </pre>
            )}
            <Button variant="primary" onClick={this.handleReset} icon={<RefreshCw className="w-4 h-4" />} className="w-full">
              Reload MOUNTEC System
            </Button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
