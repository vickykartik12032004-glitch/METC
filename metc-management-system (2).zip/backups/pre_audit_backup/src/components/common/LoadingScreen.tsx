import React from 'react';
import { Loader } from '../ui/Loader';

export const LoadingScreen: React.FC = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-950">
      <div className="flex flex-col items-center">
        <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-blue-500/20 mb-4 animate-pulse">
          M
        </div>
        <Loader size="lg" label="Loading MOUNTEC Enterprise Platform..." />
      </div>
    </div>
  );
};
