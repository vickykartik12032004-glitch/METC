import React from 'react';
import { AssetStatus } from '../../types';
import { Badge } from '../ui/Badge';

export interface StatusBadgeProps {
  status: AssetStatus | string;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status }) => {
  switch (status) {
    case 'Available':
      return <Badge variant="success" dot>Available</Badge>;
    case 'Issued':
      return <Badge variant="primary" dot>Issued</Badge>;
    case 'In Transit':
      return <Badge variant="info" dot>In Transit</Badge>;
    case 'Under Repair':
      return <Badge variant="warning" dot>Under Repair</Badge>;
    case 'Lost':
      return <Badge variant="danger" dot>Lost</Badge>;
    case 'Low Stock':
      return <Badge variant="warning" dot>Low Stock</Badge>;
    case 'Out of Stock':
      return <Badge variant="danger" dot>Out of Stock</Badge>;
    case 'Decommissioned':
      return <Badge variant="default">Decommissioned</Badge>;
    case 'Active':
      return <Badge variant="success" dot>Active</Badge>;
    case 'Completed':
      return <Badge variant="success">Completed</Badge>;
    case 'Pending':
      return <Badge variant="warning">Pending</Badge>;
    case 'Returned':
      return <Badge variant="success">Returned</Badge>;
    default:
      return <Badge variant="default">{status}</Badge>;
  }
};
