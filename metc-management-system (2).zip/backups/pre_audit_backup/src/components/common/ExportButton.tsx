import React, { useState } from 'react';
import { Download, FileSpreadsheet, FileText } from 'lucide-react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';
import { Button } from '../ui/Button';

export interface ExportButtonProps {
  title: string;
  columns: { header: string; key: string }[];
  data: Record<string, any>[];
  filename?: string;
}

export const ExportButton: React.FC<ExportButtonProps> = ({
  title,
  columns,
  data,
  filename = 'MOUNTEC_Export',
}) => {
  const [isOpen, setIsOpen] = useState(false);

  const exportToPDF = () => {
    const doc = new jsPDF();
    doc.setFontSize(16);
    doc.text(`MOUNTEC Management System - ${title}`, 14, 15);
    doc.setFontSize(10);
    doc.text(`Generated on: ${new Date().toLocaleString()}`, 14, 22);

    const tableHeaders = columns.map((col) => col.header);
    const tableData = data.map((row) => columns.map((col) => String(row[col.key] ?? '')));

    autoTable(doc, {
      head: [tableHeaders],
      body: tableData,
      startY: 28,
      styles: { fontSize: 8 },
      headStyles: { fillColor: [30, 58, 138] },
    });

    doc.save(`${filename}_${Date.now()}.pdf`);
    setIsOpen(false);
  };

  const exportToExcel = () => {
    const formattedData = data.map((row) => {
      const formattedRow: Record<string, any> = {};
      columns.forEach((col) => {
        formattedRow[col.header] = row[col.key] ?? '';
      });
      return formattedRow;
    });

    const worksheet = XLSX.utils.json_to_sheet(formattedData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, title.substring(0, 30));
    XLSX.writeFile(workbook, `${filename}_${Date.now()}.xlsx`);
    setIsOpen(false);
  };

  return (
    <div className="relative inline-block text-left">
      <Button
        variant="outline"
        size="sm"
        icon={<Download className="w-3.5 h-3.5" />}
        onClick={() => setIsOpen(!isOpen)}
      >
        Export
      </Button>

      {isOpen && (
        <div className="absolute right-0 mt-1 w-44 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-lg z-30 py-1">
          <button
            onClick={exportToPDF}
            className="flex items-center gap-2.5 w-full px-3 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <FileText className="w-4 h-4 text-rose-500" />
            <span>Export as PDF</span>
          </button>
          <button
            onClick={exportToExcel}
            className="flex items-center gap-2.5 w-full px-3 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-500" />
            <span>Export as Excel</span>
          </button>
        </div>
      )}
    </div>
  );
};
