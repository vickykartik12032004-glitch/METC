import React from 'react';
import { UserRole } from '../../types';
import { Badge } from '../ui/Badge';

export interface RoleBadgeProps {
  role: UserRole;
}

export const RoleBadge: React.FC<RoleBadgeProps> = ({ role }) => {
  switch (role) {
    case 'Super Admin':
      return (
        <Badge variant="danger" dot className="bg-purple-950/60 text-purple-300 border-purple-800">
          Super Admin
        </Badge>
      );
    case 'Admin':
      return (
        <Badge variant="primary" dot className="bg-blue-950/60 text-blue-300 border-blue-800">
          Admin
        </Badge>
      );
    case 'Supervisor':
    case 'Site Supervisor':
      return (
        <Badge variant="warning" dot className="bg-amber-950/60 text-amber-300 border-amber-800">
          Supervisor
        </Badge>
      );
    case 'Worker':
      return (
        <Badge variant="success" dot className="bg-emerald-950/60 text-emerald-300 border-emerald-800">
          Worker
        </Badge>
      );
    case 'Viewer':
      return (
        <Badge variant="default" dot className="bg-slate-800 text-slate-300 border-slate-700">
          Viewer (Read-Only)
        </Badge>
      );
    case 'Store Keeper':
      return <Badge variant="primary">Store Keeper</Badge>;
    case 'User':
      return <Badge variant="default">User</Badge>;
    default:
      return <Badge variant="default">{role}</Badge>;
  }
};
