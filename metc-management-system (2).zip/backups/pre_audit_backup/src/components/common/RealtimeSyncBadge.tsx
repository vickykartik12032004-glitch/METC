import React, { useState, useRef, useEffect } from 'react';
import { Cloud, CloudOff, RefreshCw, CheckCircle2, Wifi, Zap, Activity, Server } from 'lucide-react';
import { useRealtimeSync } from '../../hooks/useRealtimeSync';
import { getCloudServerOrigin } from '../../services/apiClient';

export const RealtimeSyncBadge: React.FC = () => {
  const { status, isOnline, isSyncing, isOffline, lastSyncTime, forceSync } = useRealtimeSync();
  const [isOpen, setIsOpen] = useState(false);
  const [syncingManual, setSyncingManual] = useState(false);
  const popoverRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (popoverRef.current && !popoverRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleManualSync = async () => {
    try {
      setSyncingManual(true);
      await forceSync();
    } finally {
      setTimeout(() => setSyncingManual(false), 500);
    }
  };

  const getStatusConfig = () => {
    if (isSyncing || syncingManual) {
      return {
        label: 'Syncing',
        dotColor: 'bg-amber-500',
        textColor: 'text-amber-700 dark:text-amber-400',
        bgColor: 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-900/50',
        icon: <RefreshCw className="w-3 h-3 text-amber-600 dark:text-amber-400 animate-spin" />,
      };
    }
    if (isOnline) {
      return {
        label: 'Online',
        dotColor: 'bg-emerald-500',
        textColor: 'text-emerald-700 dark:text-emerald-400',
        bgColor: 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-900/50',
        icon: <Cloud className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />,
      };
    }
    return {
      label: 'Offline',
      dotColor: 'bg-rose-500',
      textColor: 'text-rose-700 dark:text-rose-400',
      bgColor: 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-900/50',
      icon: <CloudOff className="w-3 h-3 text-rose-600 dark:text-rose-400" />,
    };
  };

  const config = getStatusConfig();

  return (
    <div className="relative" ref={popoverRef}>
      {/* Live Badge Button */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border transition-all duration-150 hover:shadow-xs ${config.bgColor} ${config.textColor}`}
        title={`Cloud Database: ${config.label}`}
      >
        <span className="relative flex h-2 w-2">
          {isOnline && !syncingManual && (
            <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${config.dotColor}`} />
          )}
          <span className={`relative inline-flex rounded-full h-2 w-2 ${config.dotColor}`} />
        </span>
        <span className="hidden sm:inline-block tracking-tight text-[11px] font-bold">{config.label}</span>
      </button>

      {/* Popover Card */}
      {isOpen && (
        <div className="absolute right-0 mt-2 w-72 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xl z-50 p-3.5 animate-in fade-in slide-in-from-top-1">
          <div className="flex items-center justify-between pb-2.5 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-lg bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400">
                <Zap className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100">Central Cloud Sync</h4>
                <p className="text-[10px] text-slate-500 dark:text-slate-400">Real-Time Single Source of Truth</p>
              </div>
            </div>
            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${config.bgColor} ${config.textColor}`}>
              {config.label}
            </span>
          </div>

          <div className="py-2.5 space-y-2 text-xs">
            <div className="flex items-center justify-between text-slate-600 dark:text-slate-300">
              <span className="text-[11px] text-slate-500">Database Engine:</span>
              <span className="font-semibold text-[11px] text-slate-800 dark:text-slate-200 flex items-center gap-1">
                <Activity className="w-3 h-3 text-emerald-500" /> Firestore & Cloud DB
              </span>
            </div>

            <div className="flex items-center justify-between text-slate-600 dark:text-slate-300">
              <span className="text-[11px] text-slate-500">Cross-Device Sync:</span>
              <span className="font-semibold text-[11px] text-blue-600 dark:text-blue-400 flex items-center gap-1">
                <Cloud className="w-3 h-3" /> onSnapshot Realtime
              </span>
            </div>

            <div className="flex items-center justify-between text-slate-600 dark:text-slate-300">
              <span className="text-[11px] text-slate-500">Cloud Endpoint:</span>
              <span className="font-medium text-[10px] text-slate-600 dark:text-slate-400 truncate max-w-[130px] flex items-center gap-1" title={getCloudServerOrigin() || 'Active Cloud Host'}>
                <Server className="w-3 h-3 text-slate-400" />
                {getCloudServerOrigin() ? 'Connected Live' : 'Cloud Host'}
              </span>
            </div>

            <div className="flex items-center justify-between text-slate-600 dark:text-slate-300">
              <span className="text-[11px] text-slate-500">Last Synced:</span>
              <span className="font-medium text-[11px] text-slate-700 dark:text-slate-300">
                {lastSyncTime ? new Date(lastSyncTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : 'Pending'}
              </span>
            </div>
          </div>

          <div className="pt-2.5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <p className="text-[10px] text-slate-400 max-w-[140px] leading-tight">
              Multi-device updates synchronize instantly.
            </p>
            <button
              type="button"
              onClick={handleManualSync}
              disabled={syncingManual}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-semibold transition-colors disabled:opacity-50"
            >
              <RefreshCw className={`w-3 h-3 ${syncingManual ? 'animate-spin' : ''}`} />
              <span>{syncingManual ? 'Syncing...' : 'Sync Now'}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
