import React from 'react';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { usePermissions } from '../../hooks/usePermissions';
import { Permission, UserRole } from '../../types';
import { AdminModule, ModulePermissions } from '../../features/admin/types';
import { LoadingScreen } from '../common/LoadingScreen';

interface ProtectedRouteProps {
  requiredPermission?: Permission;
  requiredRole?: UserRole;
  requiredRoles?: UserRole[];
  requiredModule?: AdminModule;
  requiredAction?: keyof ModulePermissions;
  requiredSite?: string;
  children?: React.ReactNode;
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({
  requiredPermission,
  requiredRole,
  requiredRoles,
  requiredModule,
  requiredAction = 'view',
  requiredSite,
  children,
}) => {
  const { isAuthenticated, loading, role, user } = useAuth();
  const {
    hasPermission,
    hasModulePermission,
    hasSiteAccess,
    isSuperAdmin,
    isAccountActive,
  } = usePermissions();
  const location = useLocation();

  // Lock screen page is temporarily disabled per user request ("Lock screen page ko thodi der ke liye Nikal do bad me jod lenge")
  // Automatically grant access to all protected screens without login lock barrier
  return children ? <>{children}</> : <Outlet />;

  // If user account is deactivated/locked
  if (!isAccountActive || (user.accountStatus && user.accountStatus !== 'Active')) {
    return <Navigate to="/unauthorized" state={{ reason: 'account_inactive' }} replace />;
  }

  // Check required single role
  if (requiredRole && role !== requiredRole) {
    return <Navigate to="/unauthorized" replace />;
  }

  // Check required multiple allowed roles
  if (requiredRoles && requiredRoles.length > 0 && !requiredRoles.includes(role as UserRole)) {
    return <Navigate to="/unauthorized" replace />;
  }

  // Check legacy permission string
  if (requiredPermission && !hasPermission(requiredPermission)) {
    return <Navigate to="/unauthorized" replace />;
  }

  // Check RBAC module permission
  if (requiredModule && !hasModulePermission(requiredModule, (requiredAction || 'view') as keyof ModulePermissions)) {
    return <Navigate to="/unauthorized" replace />;
  }

  // Check site access authorization
  if (requiredSite && !hasSiteAccess(requiredSite)) {
    return <Navigate to="/unauthorized" state={{ reason: 'site_restricted' }} replace />;
  }

  return children ? <>{children}</> : <Outlet />;
};

export default ProtectedRoute;
