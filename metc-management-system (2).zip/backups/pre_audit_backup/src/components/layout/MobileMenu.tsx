import React from 'react';
import { NavLink } from 'react-router-dom';
import { X, LayoutDashboard, Package, HardHat, Wrench, Fuel, Users, ArrowUpRight, ArrowDownLeft, ArrowRightLeft, Hammer, ShieldAlert, ShieldCheck, FileText, Bell, Settings, UserCheck } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { usePermissions } from '../../hooks/usePermissions';
import { RoleBadge } from '../common/RoleBadge';

export interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MobileMenu: React.FC<MobileMenuProps> = ({ isOpen, onClose }) => {
  const { user, role } = useAuth();
  const { 
    canViewDashboard, 
    canViewInventory, 
    canViewWorkers, 
    canIssueItems, 
    canReturnItems, 
    canTransferItems, 
    canRepairItems, 
    canReportLost, 
    canViewReports, 
    canManageSettings 
  } = usePermissions();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex md:hidden">
      <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs" onClick={onClose} />
      <div className="relative w-72 bg-slate-900 text-slate-300 h-full p-4 flex flex-col justify-between z-10 shadow-2xl">
        <div>
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold text-lg">
                M
              </div>
              <div>
                <h2 className="text-sm font-bold text-white">MOUNTEC SYSTEM</h2>
                <p className="text-[10px] text-slate-400">Enterprise Edition</p>
              </div>
            </div>
            <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white">
              <X className="w-5 h-5" />
            </button>
          </div>

          {user && (
            <div className="p-3 my-3 bg-slate-800 rounded-xl border border-slate-700/60 flex items-center justify-between">
              <div>
                <p className="text-xs font-semibold text-white">{user.name}</p>
                <p className="text-[10px] text-slate-400">{user.email}</p>
              </div>
              <RoleBadge role={role} />
            </div>
          )}

          <nav className="space-y-1 mt-3 overflow-y-auto max-h-[calc(100vh-220px)]">
            {canViewDashboard() && (
              <NavLink
                to="/dashboard"
                onClick={onClose}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-medium ${
                    isActive ? 'bg-blue-600 text-white font-semibold' : 'text-slate-400 hover:text-white'
                  }`
                }
              >
                <LayoutDashboard className="w-4 h-4" />
                <span>Dashboard</span>
              </NavLink>
            )}

            {canViewInventory() && (
              <>
                <p className="text-[10px] uppercase font-bold text-slate-500 pt-2 px-3">Assets</p>
                <NavLink
                  to="/materials"
                  onClick={onClose}
                  className="flex items-center gap-3 px-3 py-2 text-xs font-medium text-slate-400 hover:text-white"
                >
                  <Package className="w-4 h-4" />
                  <span>Materials</span>
                </NavLink>
                <NavLink
                  to="/equipment"
                  onClick={onClose}
                  className="flex items-center gap-3 px-3 py-2 text-xs font-medium text-slate-400 hover:text-white"
                >
                  <HardHat className="w-4 h-4" />
                  <span>Equipment</span>
                </NavLink>
                <NavLink
                  to="/tools"
                  onClick={onClose}
                  className="flex items-center gap-3 px-3 py-2 text-xs font-medium text-slate-400 hover:text-white"
                >
                  <Wrench className="w-4 h-4" />
                  <span>Tools</span>
                </NavLink>
                <NavLink
                  to="/consumables"
                  onClick={onClose}
                  className="flex items-center gap-3 px-3 py-2 text-xs font-medium text-slate-400 hover:text-white"
                >
                  <Fuel className="w-4 h-4" />
                  <span>Consumables</span>
                </NavLink>
                <NavLink
                  to="/ppe"
                  onClick={onClose}
                  className="flex items-center gap-3 px-3 py-2 text-xs font-medium text-slate-400 hover:text-white"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>PPE</span>
                </NavLink>
              </>
            )}

            <p className="text-[10px] uppercase font-bold text-slate-500 pt-2 px-3">Operations</p>
            {canViewWorkers() && (
              <NavLink
                to="/workers"
                onClick={onClose}
                className="flex items-center gap-3 px-3 py-2 text-xs font-medium text-slate-400 hover:text-white"
              >
                <Users className="w-4 h-4" />
                <span>Workers</span>
              </NavLink>
            )}
            {canIssueItems() && (
              <NavLink
                to="/issue"
                onClick={onClose}
                className="flex items-center gap-3 px-3 py-2 text-xs font-medium text-slate-400 hover:text-white"
              >
                <ArrowUpRight className="w-4 h-4" />
                <span>Issue</span>
              </NavLink>
            )}
            {canReturnItems() && (
              <NavLink
                to="/return"
                onClick={onClose}
                className="flex items-center gap-3 px-3 py-2 text-xs font-medium text-slate-400 hover:text-white"
              >
                <ArrowDownLeft className="w-4 h-4" />
                <span>Return</span>
              </NavLink>
            )}
            {canTransferItems() && (
              <NavLink
                to="/transfer"
                onClick={onClose}
                className="flex items-center gap-3 px-3 py-2 text-xs font-medium text-slate-400 hover:text-white"
              >
                <ArrowRightLeft className="w-4 h-4" />
                <span>Transfer</span>
              </NavLink>
            )}
            {canRepairItems() && (
              <NavLink
                to="/repair"
                onClick={onClose}
                className="flex items-center gap-3 px-3 py-2 text-xs font-medium text-slate-400 hover:text-white"
              >
                <Hammer className="w-4 h-4" />
                <span>Repair</span>
              </NavLink>
            )}
            {canReportLost() && (
              <NavLink
                to="/lost-items"
                onClick={onClose}
                className="flex items-center gap-3 px-3 py-2 text-xs font-medium text-slate-400 hover:text-white"
              >
                <ShieldAlert className="w-4 h-4" />
                <span>Lost Items</span>
              </NavLink>
            )}
            {canViewReports() && (
              <NavLink
                to="/reports"
                onClick={onClose}
                className="flex items-center gap-3 px-3 py-2 text-xs font-medium text-slate-400 hover:text-white"
              >
                <FileText className="w-4 h-4" />
                <span>Reports</span>
              </NavLink>
            )}
            <NavLink
              to="/notifications"
              onClick={onClose}
              className="flex items-center gap-3 px-3 py-2 text-xs font-medium text-slate-400 hover:text-white"
            >
              <Bell className="w-4 h-4" />
              <span>Notifications</span>
            </NavLink>
            <NavLink
              to="/profile"
              onClick={onClose}
              className="flex items-center gap-3 px-3 py-2 text-xs font-medium text-slate-400 hover:text-white"
            >
              <UserCheck className="w-4 h-4" />
              <span>My Profile</span>
            </NavLink>
            {canManageSettings() && (
              <>
                <NavLink
                  to="/admin"
                  onClick={onClose}
                  className="flex items-center gap-3 px-3 py-2 text-xs font-medium text-slate-400 hover:text-white"
                >
                  <ShieldCheck className="w-4 h-4 text-purple-400" />
                  <span>Administration & Users</span>
                </NavLink>
                <NavLink
                  to="/settings"
                  onClick={onClose}
                  className="flex items-center gap-3 px-3 py-2 text-xs font-medium text-slate-400 hover:text-white"
                >
                  <Settings className="w-4 h-4" />
                  <span>Settings</span>
                </NavLink>
              </>
            )}
          </nav>
        </div>

        <div className="pt-4 border-t border-slate-800 text-[10px] text-slate-500">
          MOUNTEC PTE LTD• v2.5.0-EE
        </div>
      </div>
    </div>
  );
};

export default MobileMenu;
