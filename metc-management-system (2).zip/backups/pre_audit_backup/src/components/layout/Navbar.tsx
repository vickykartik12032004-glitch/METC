import React, { useState, useMemo, useRef, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { 
  Menu, 
  Sun, 
  Moon, 
  Bell, 
  User, 
  LogOut, 
  Search, 
  ShieldCheck, 
  Building2,
  X,
  Package,
  Wrench,
  HardHat,
  Fuel,
  ArrowRight,
  SearchX
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { useRole } from '../../hooks/useRole';
import { useThemeStore } from '../../store/useThemeStore';
import { useNotificationStore } from '../../store/useNotificationStore';
import { useAssetStore } from '../../store/useAssetStore';
import { Avatar } from '../ui/Avatar';
import { RoleBadge } from '../common/RoleBadge';
import { RealtimeSyncBadge } from '../common/RealtimeSyncBadge';
import { METCItem } from '../../types';

export interface NavbarProps {
  onOpenMobileMenu: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenMobileMenu }) => {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const { role, switchRole } = useRole();
  const { theme, setTheme, toggleSidebar } = useThemeStore();
  const { notifications, markAsRead } = useNotificationStore();
  const { materials, equipment, tools, consumables, ppe } = useAssetStore();

  const [profileOpen, setProfileOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [globalSearch, setGlobalSearch] = useState('');
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  const unreadCount = notifications.filter((n) => n.status === 'Unread' || n.read === false).length;

  // Combine all assets for live search
  const allAssets = useMemo<METCItem[]>(() => {
    return [...materials, ...equipment, ...tools, ...consumables, ...(ppe || [])];
  }, [materials, equipment, tools, consumables, ppe]);

  // Real-time live filtered search results
  const liveSearchResults = useMemo(() => {
    if (!globalSearch.trim()) return [];
    const q = globalSearch.trim().toLowerCase();
    const tokens = q.split(/\s+/).filter(Boolean);

    return allAssets
      .filter((item) => {
        const corpus = [
          item.name || '',
          item.code || '',
          item.id || '',
          item.category || '',
          item.location || '',
          item.brand || (item as any).manufacturer || '',
          item.model || '',
          item.serialNumber || '',
          item.barcode || '',
          item.supplier || '',
        ]
          .join(' ')
          .toLowerCase();

        return corpus.includes(q) || (tokens.length > 1 && tokens.every((tok) => corpus.includes(tok)));
      })
      .slice(0, 8); // Top 8 matches
  }, [allAssets, globalSearch]);

  // Click outside listener to close search dropdown
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(e.target as Node)) {
        setIsSearchFocused(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (globalSearch.trim()) {
      setIsSearchFocused(false);
      navigate(`/materials?search=${encodeURIComponent(globalSearch.trim())}`);
    }
  };

  const handleSelectItem = (item: METCItem) => {
    setIsSearchFocused(false);
    setGlobalSearch('');
    const targetRoute =
      item.category === 'Material'
        ? '/materials'
        : item.category === 'Equipment'
        ? '/equipment'
        : item.category === 'Tool'
        ? '/tools'
        : item.category === 'Consumable'
        ? '/consumables'
        : item.category === 'PPE'
        ? '/ppe'
        : '/materials';

    navigate(`${targetRoute}?search=${encodeURIComponent(item.code || item.name)}`);
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Equipment':
        return <HardHat className="w-3.5 h-3.5 text-amber-500" />;
      case 'Tool':
        return <Wrench className="w-3.5 h-3.5 text-blue-500" />;
      case 'Consumable':
        return <Fuel className="w-3.5 h-3.5 text-emerald-500" />;
      case 'PPE':
        return <ShieldCheck className="w-3.5 h-3.5 text-rose-500" />;
      default:
        return <Package className="w-3.5 h-3.5 text-purple-500" />;
    }
  };

  return (
    <header className="sticky top-0 z-30 h-16 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-4 md:px-6 flex items-center justify-between shadow-2xs">
      {/* Left side: Mobile button, Sidebar collapse toggle, Global Search */}
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenMobileMenu}
          className="p-2 rounded-lg text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 md:hidden"
        >
          <Menu className="w-5 h-5" />
        </button>

        <button
          onClick={toggleSidebar}
          className="p-2 rounded-lg text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 hidden md:block"
          title="Toggle Sidebar"
        >
          <Menu className="w-5 h-5" />
        </button>

        {/* Global Live Search Bar with Instant Results Dropdown */}
        <div ref={searchContainerRef} className="relative hidden sm:block min-w-[240px] md:min-w-[320px]">
          <form onSubmit={handleSearchSubmit} className="relative flex items-center">
            <Search className="absolute left-3 w-4 h-4 text-slate-400 pointer-events-none" />
            <input
              type="text"
              value={globalSearch}
              onChange={(e) => {
                setGlobalSearch(e.target.value);
                setIsSearchFocused(true);
              }}
              onFocus={() => setIsSearchFocused(true)}
              onKeyDown={(e) => {
                if (e.key === 'Escape') {
                  setIsSearchFocused(false);
                }
              }}
              placeholder="Search assets, tools, codes, serials..."
              className="w-full pl-9 pr-8 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
            />
            {globalSearch && (
              <button
                type="button"
                onClick={() => {
                  setGlobalSearch('');
                  setIsSearchFocused(false);
                }}
                className="absolute right-2.5 p-0.5 rounded text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                title="Clear search"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </form>

          {/* Instant Live Search Results Popover */}
          {isSearchFocused && globalSearch.trim().length > 0 && (
            <div className="absolute left-0 right-0 top-full mt-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xl z-50 overflow-hidden text-xs divide-y divide-slate-100 dark:divide-slate-800 animate-in fade-in slide-in-from-top-1 duration-150">
              <div className="px-3 py-2 bg-slate-50 dark:bg-slate-800/50 flex items-center justify-between text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                <span>Matching Items</span>
                <span>{liveSearchResults.length} found</span>
              </div>

              {liveSearchResults.length === 0 ? (
                <div className="p-6 text-center space-y-1.5">
                  <div className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto text-amber-500">
                    <SearchX className="w-4 h-4" />
                  </div>
                  <p className="font-bold text-slate-800 dark:text-slate-200">No items found</p>
                  <p className="text-[11px] text-slate-400">
                    No assets match &ldquo;{globalSearch}&rdquo;
                  </p>
                </div>
              ) : (
                <div className="max-h-72 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/60">
                  {liveSearchResults.map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => handleSelectItem(item)}
                      className="w-full px-3 py-2.5 text-left flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/70 transition-colors group"
                    >
                      <div className="flex items-center gap-2.5 min-w-0 pr-2">
                        <div className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 shrink-0">
                          {getCategoryIcon(item.category)}
                        </div>
                        <div className="min-w-0">
                          <div className="font-semibold text-slate-900 dark:text-slate-100 truncate group-hover:text-blue-600 dark:group-hover:text-blue-400">
                            {item.name}
                          </div>
                          <div className="text-[10px] text-slate-400 flex items-center gap-1.5 mt-0.5">
                            <span className="font-mono text-blue-600 dark:text-blue-400 font-semibold">{item.code}</span>
                            <span>•</span>
                            <span>{item.category}</span>
                            <span>•</span>
                            <span className="truncate">{item.location}</span>
                          </div>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <span className="inline-block px-1.5 py-0.5 rounded text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                          {item.availableQuantity ?? item.quantity} {item.unit || 'units'}
                        </span>
                      </div>
                    </button>
                  ))}
                </div>
              )}

              {liveSearchResults.length > 0 && (
                <div className="p-2 bg-slate-50 dark:bg-slate-800/40 text-center">
                  <button
                    type="button"
                    onClick={handleSearchSubmit}
                    className="text-[11px] font-semibold text-blue-600 dark:text-blue-400 hover:underline inline-flex items-center gap-1"
                  >
                    <span>View all matching inventory results</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Right side: Theme Toggle, Notification Bell, User Avatar */}
      <div className="flex items-center gap-2 md:gap-3">
        {/* Real-time Cloud Connection Status Badge */}
        <RealtimeSyncBadge />

        {/* Dark Mode Toggle */}
        <button
          onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
          className="p-2 rounded-lg text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          title="Toggle Dark/Light Mode"
        >
          {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-600" />}
        </button>

        {/* Notification Bell */}
        <div className="relative">
          <button
            onClick={() => setNotifOpen(!notifOpen)}
            className="relative p-2 rounded-lg text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-rose-500 ring-2 ring-white dark:ring-slate-900 animate-pulse" />
            )}
          </button>

          {/* Notification Popover */}
          {notifOpen && (
            <div className="absolute right-0 mt-2 w-80 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xl z-50 p-3">
              <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100 dark:border-slate-800">
                <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100">Notifications ({unreadCount})</h4>
                <Link
                  to="/notifications"
                  onClick={() => setNotifOpen(false)}
                  className="text-[11px] font-medium text-blue-600 dark:text-blue-400 hover:underline"
                >
                  View All
                </Link>
              </div>

              <div className="space-y-2 max-h-60 overflow-y-auto">
                {notifications.slice(0, 4).map((n) => (
                  <div
                    key={n.id}
                    onClick={() => {
                      markAsRead(n.id);
                      if (n.link) navigate(n.link);
                      setNotifOpen(false);
                    }}
                    className={`p-2 rounded-lg text-xs cursor-pointer transition-colors ${
                      n.status === 'Read' || n.read === true ? 'bg-transparent text-slate-500' : 'bg-blue-50 dark:bg-blue-950/40 text-slate-800 dark:text-slate-200 font-medium'
                    }`}
                  >
                    <p className="font-semibold text-xs text-slate-900 dark:text-slate-100">{n.title}</p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2 mt-0.5">{n.message}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* User Profile Dropdown Menu */}
        <div className="relative">
          <button
            onClick={() => setProfileOpen(!profileOpen)}
            className="flex items-center gap-2 p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <Avatar src={user?.avatar} name={user?.name || 'User'} size="sm" />
            <div className="hidden sm:block text-left">
              <p className="text-xs font-semibold text-slate-900 dark:text-slate-100 leading-tight">{user?.name}</p>
              <p className="text-[10px] text-slate-500 dark:text-slate-400">{role}</p>
            </div>
          </button>

          {profileOpen && (
            <div className="absolute right-0 mt-2 w-56 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xl z-50 py-1">
              <div className="px-4 py-2.5 border-b border-slate-100 dark:border-slate-800">
                <p className="text-xs font-semibold text-slate-900 dark:text-slate-100">{user?.name}</p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">{user?.email}</p>
                <p className="text-[11px] font-medium text-slate-400 mt-1">MOUNTEC PTE LTD</p>
                <div className="mt-1.5">
                  <RoleBadge role={role} />
                </div>
              </div>

              <Link
                to="/profile"
                onClick={() => setProfileOpen(false)}
                className="flex items-center gap-2.5 px-4 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <User className="w-4 h-4 text-slate-400" />
                <span>My Profile</span>
              </Link>

              <Link
                to="/admin"
                onClick={() => setProfileOpen(false)}
                className="flex items-center gap-2.5 px-4 py-2 text-xs text-purple-600 dark:text-purple-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors font-medium"
              >
                <ShieldCheck className="w-4 h-4 text-purple-500" />
                <span>Administration & Users</span>
              </Link>

              <Link
                to="/settings"
                onClick={() => setProfileOpen(false)}
                className="flex items-center gap-2.5 px-4 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <Building2 className="w-4 h-4 text-slate-400" />
                <span>System Settings</span>
              </Link>

              <div className="border-t border-slate-100 dark:border-slate-800 my-1" />

              <button
                onClick={async () => {
                  setProfileOpen(false);
                  await logout();
                  navigate('/login');
                }}
                className="flex items-center gap-2.5 w-full px-4 py-2 text-xs text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign Out</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Navbar;
