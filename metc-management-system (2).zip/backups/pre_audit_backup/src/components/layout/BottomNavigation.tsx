import React, { useState } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Boxes, 
  Users, 
  Menu, 
  PlusCircle,
  ArrowUpRight,
  ArrowDownLeft,
  ArrowRightLeft,
  QrCode,
  Sparkles,
  X,
  Package,
  HardHat,
  Wrench,
  Fuel,
  ShieldCheck,
  Hammer
} from 'lucide-react';
import { usePermissions } from '../../hooks/usePermissions';
import { useNotificationStore } from '../../store/useNotificationStore';
import { motion, AnimatePresence } from 'motion/react';

interface BottomNavigationProps {
  onOpenMenu: () => void;
}

export const BottomNavigation: React.FC<BottomNavigationProps> = ({ onOpenMenu }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const { canViewDashboard, canViewInventory, canViewWorkers, canIssueItems, canReturnItems, canTransferItems } = usePermissions();
  const { notifications } = useNotificationStore();
  const [isActionSheetOpen, setIsActionSheetOpen] = useState(false);

  const unreadCount = notifications.filter((n) => n.status === 'Unread' || n.read === false).length;

  const isInventoryActive = ['/materials', '/equipment', '/tools', '/consumables', '/ppe'].some(
    (path) => location.pathname === path
  );

  const handleQuickAction = (path: string) => {
    setIsActionSheetOpen(false);
    navigate(path);
  };

  return (
    <>
      {/* Mobile Bottom Quick Action Modal Sheet */}
      <AnimatePresence>
        {isActionSheetOpen && (
          <div className="fixed inset-0 z-50 flex items-end justify-center md:hidden">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsActionSheetOpen(false)}
              className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs"
            />

            {/* Bottom Sheet Card */}
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="relative w-full max-w-lg bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 rounded-t-3xl p-5 shadow-2xl z-10 space-y-4 max-h-[85vh] overflow-y-auto"
            >
              {/* Drag Handle Bar */}
              <div className="w-12 h-1.5 bg-slate-300 dark:bg-slate-700 rounded-full mx-auto" />

              {/* Header */}
              <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">Quick Actions</h3>
                    <p className="text-[11px] text-slate-500">Tap to start an operation</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsActionSheetOpen(false)}
                  className="p-2 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Primary Operations Grid */}
              <div className="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => handleQuickAction('/issue')}
                  className="p-3.5 rounded-2xl bg-blue-50/80 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800/60 text-left flex items-start gap-3 hover:bg-blue-100 dark:hover:bg-blue-900/50 transition-all active:scale-98"
                >
                  <div className="p-2 rounded-xl bg-blue-600 text-white shrink-0 shadow-xs">
                    <ArrowUpRight className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900 dark:text-slate-100">Issue Item</div>
                    <div className="text-[10px] text-slate-500">Dispatch to worker</div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => handleQuickAction('/return')}
                  className="p-3.5 rounded-2xl bg-emerald-50/80 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 text-left flex items-start gap-3 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 transition-all active:scale-98"
                >
                  <div className="p-2 rounded-xl bg-emerald-600 text-white shrink-0 shadow-xs">
                    <ArrowDownLeft className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900 dark:text-slate-100">Return Item</div>
                    <div className="text-[10px] text-slate-500">Receive from site</div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => handleQuickAction('/transfer')}
                  className="p-3.5 rounded-2xl bg-purple-50/80 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-800/60 text-left flex items-start gap-3 hover:bg-purple-100 dark:hover:bg-purple-900/50 transition-all active:scale-98"
                >
                  <div className="p-2 rounded-xl bg-purple-600 text-white shrink-0 shadow-xs">
                    <ArrowRightLeft className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900 dark:text-slate-100">Transfer Item</div>
                    <div className="text-[10px] text-slate-500">Move location / site</div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => handleQuickAction('/materials')}
                  className="p-3.5 rounded-2xl bg-amber-50/80 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 text-left flex items-start gap-3 hover:bg-amber-100 dark:hover:bg-amber-900/50 transition-all active:scale-98"
                >
                  <div className="p-2 rounded-xl bg-amber-600 text-white shrink-0 shadow-xs">
                    <PlusCircle className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900 dark:text-slate-100">Add New Asset</div>
                    <div className="text-[10px] text-slate-500">Register new item</div>
                  </div>
                </button>
              </div>

              {/* Asset Categories Fast Picker */}
              <div className="pt-2">
                <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-2 px-1">
                  Browse Asset Categories
                </p>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => handleQuickAction('/materials')}
                    className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 flex flex-col items-center text-center gap-1.5 hover:border-blue-500 transition-colors"
                  >
                    <Package className="w-4 h-4 text-blue-500" />
                    <span className="text-[11px] font-bold text-slate-800 dark:text-slate-200">Materials</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleQuickAction('/equipment')}
                    className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 flex flex-col items-center text-center gap-1.5 hover:border-amber-500 transition-colors"
                  >
                    <HardHat className="w-4 h-4 text-amber-500" />
                    <span className="text-[11px] font-bold text-slate-800 dark:text-slate-200">Equipment</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleQuickAction('/tools')}
                    className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 flex flex-col items-center text-center gap-1.5 hover:border-purple-500 transition-colors"
                  >
                    <Wrench className="w-4 h-4 text-purple-500" />
                    <span className="text-[11px] font-bold text-slate-800 dark:text-slate-200">Tools</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleQuickAction('/consumables')}
                    className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 flex flex-col items-center text-center gap-1.5 hover:border-emerald-500 transition-colors"
                  >
                    <Fuel className="w-4 h-4 text-emerald-500" />
                    <span className="text-[11px] font-bold text-slate-800 dark:text-slate-200">Consumables</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleQuickAction('/ppe')}
                    className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 flex flex-col items-center text-center gap-1.5 hover:border-rose-500 transition-colors"
                  >
                    <ShieldCheck className="w-4 h-4 text-rose-500" />
                    <span className="text-[11px] font-bold text-slate-800 dark:text-slate-200">PPE Safety</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleQuickAction('/maintenance')}
                    className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 flex flex-col items-center text-center gap-1.5 hover:border-orange-500 transition-colors"
                  >
                    <Hammer className="w-4 h-4 text-orange-500" />
                    <span className="text-[11px] font-bold text-slate-800 dark:text-slate-200">Maintenance</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Main Native Bottom Navigation Bar */}
      <nav
        aria-label="Mobile Navigation"
        className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 md:hidden pb-[env(safe-area-inset-bottom)] shadow-[0_-4px_20px_rgba(0,0,0,0.06)]"
      >
        <div className="flex items-center justify-around h-16 px-2 max-w-lg mx-auto">
          {/* 1. Dashboard Tab */}
          <NavLink
            to="/dashboard"
            className={({ isActive }) =>
              `flex flex-col items-center justify-center flex-1 h-full py-1 text-center transition-all ${
                isActive
                  ? 'text-blue-600 dark:text-blue-400 font-bold'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
              }`
            }
          >
            {({ isActive }) => (
              <>
                <div className="relative">
                  <LayoutDashboard className={`w-5 h-5 transition-transform ${isActive ? 'scale-110' : ''}`} />
                  {isActive && (
                    <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-blue-600 dark:bg-blue-400" />
                  )}
                </div>
                <span className="text-[10px] mt-1 leading-none tracking-tight">Dashboard</span>
              </>
            )}
          </NavLink>

          {/* 2. Assets / METC Tab */}
          <NavLink
            to="/materials"
            className={({ isActive }) =>
              `flex flex-col items-center justify-center flex-1 h-full py-1 text-center transition-all ${
                isActive || isInventoryActive
                  ? 'text-blue-600 dark:text-blue-400 font-bold'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
              }`
            }
          >
            {() => (
              <>
                <div className="relative">
                  <Boxes className={`w-5 h-5 transition-transform ${isInventoryActive ? 'scale-110' : ''}`} />
                  {isInventoryActive && (
                    <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-blue-600 dark:bg-blue-400" />
                  )}
                </div>
                <span className="text-[10px] mt-1 leading-none tracking-tight">Assets</span>
              </>
            )}
          </NavLink>

          {/* 3. Center Quick Action Center Button */}
          <div className="flex flex-col items-center justify-center flex-1 -mt-5">
            <button
              type="button"
              onClick={() => setIsActionSheetOpen(true)}
              aria-label="Open Quick Action Menu"
              className="w-12 h-12 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center shadow-lg shadow-blue-500/30 ring-4 ring-white dark:ring-slate-900 active:scale-95 transition-transform hover:scale-105"
            >
              <PlusCircle className="w-6 h-6" />
            </button>
            <span className="text-[9px] font-bold text-slate-500 dark:text-slate-400 mt-1 leading-none">
              Quick Action
            </span>
          </div>

          {/* 4. Workers Tab */}
          <NavLink
            to="/workers"
            className={({ isActive }) =>
              `flex flex-col items-center justify-center flex-1 h-full py-1 text-center transition-all ${
                isActive
                  ? 'text-blue-600 dark:text-blue-400 font-bold'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
              }`
            }
          >
            {({ isActive }) => (
              <>
                <div className="relative">
                  <Users className={`w-5 h-5 transition-transform ${isActive ? 'scale-110' : ''}`} />
                  {isActive && (
                    <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-blue-600 dark:bg-blue-400" />
                  )}
                </div>
                <span className="text-[10px] mt-1 leading-none tracking-tight">Workers</span>
              </>
            )}
          </NavLink>

          {/* 5. Menu / More Tab */}
          <button
            type="button"
            onClick={onOpenMenu}
            className="flex flex-col items-center justify-center flex-1 h-full py-1 text-center text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 transition-all relative"
          >
            <div className="relative">
              <Menu className="w-5 h-5" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1.5 w-3 h-3 rounded-full bg-rose-500 text-[8px] font-bold text-white flex items-center justify-center ring-1 ring-white dark:ring-slate-900">
                  {unreadCount > 9 ? '9+' : unreadCount}
                </span>
              )}
            </div>
            <span className="text-[10px] mt-1 leading-none tracking-tight">Menu</span>
          </button>
        </div>
      </nav>
    </>
  );
};
