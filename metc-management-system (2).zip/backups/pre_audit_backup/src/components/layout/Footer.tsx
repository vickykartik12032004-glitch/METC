import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="h-10 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center justify-between px-6 md:px-8 text-[10px] text-slate-400 dark:text-slate-500 font-medium uppercase tracking-widest mt-auto shrink-0">
      <div>
        <span>© {new Date().getFullYear()} MOUNTEC Global Corp. All rights reserved.</span>
      </div>
      <div className="flex items-center gap-4">
        <span>Enterprise Ver 4.2.0-stable</span>
      </div>
    </footer>
  );
};
