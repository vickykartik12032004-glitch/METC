import React from 'react';
import { Navigate } from 'react-router-dom';
import { Permission } from '../../types';
import { useAuthStore } from '../../store/useAuthStore';
import { Button } from '../ui/Button';
import { ShieldAlert } from 'lucide-react';

export interface RoleGuardProps {
  permission: Permission;
  children: React.ReactNode;
}

export const RoleGuard: React.FC<RoleGuardProps> = ({ permission, children }) => {
  const { hasPermission, user } = useAuthStore();

  if (!hasPermission(permission)) {
    return (
      <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
        <div className="w-16 h-16 rounded-full bg-rose-100 dark:bg-rose-950/80 text-rose-600 dark:text-rose-400 flex items-center justify-center mb-4">
          <ShieldAlert className="w-8 h-8" />
        </div>
        <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100 mb-1">Access Restricted</h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mb-6">
          Your current role (<strong className="font-semibold text-slate-700 dark:text-slate-200">{user?.role}</strong>) does not have sufficient permissions to view this module ({permission}).
        </p>
        <Button variant="outline" onClick={() => window.history.back()}>
          Go Back
        </Button>
      </div>
    );
  }

  return <>{children}</>;
};
