import React, { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Boxes, 
  Package, 
  HardHat, 
  Wrench, 
  Fuel, 
  Users, 
  ArrowUpRight, 
  ArrowDownLeft, 
  ArrowRightLeft, 
  Hammer, 
  AlertTriangle, 
  FileText, 
  Bell, 
  Settings, 
  ChevronDown, 
  ChevronRight, 
  Building2,
  ShieldAlert,
  ShieldCheck,
  UserCheck
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { usePermissions } from '../../hooks/usePermissions';
import { useThemeStore } from '../../store/useThemeStore';
import { cn } from '../../lib/utils';
import { RoleBadge } from '../common/RoleBadge';

export const Sidebar: React.FC = () => {
  const location = useLocation();
  const { user, role } = useAuth();
  const { 
    hasPermission, 
    canViewDashboard, 
    canViewInventory, 
    canViewWorkers, 
    canIssueItems, 
    canReturnItems, 
    canTransferItems, 
    canRepairItems, 
    canReportLost, 
    canViewReports, 
    canManageSettings 
  } = usePermissions();

  const { sidebarCollapsed } = useThemeStore();
  const [metcOpen, setMetcOpen] = useState(
    ['/materials', '/equipment', '/tools', '/consumables', '/ppe'].some((path) => location.pathname.startsWith(path))
  );

  const isMetcActive = ['/materials', '/equipment', '/tools', '/consumables', '/ppe'].some((path) => location.pathname === path);

  return (
    <aside
      className={cn(
        'fixed top-0 left-0 z-40 h-screen bg-slate-900 text-slate-300 border-r border-slate-800 transition-all duration-300 flex flex-col justify-between hidden md:flex',
        sidebarCollapsed ? 'w-20' : 'w-64'
      )}
    >
      <div>
        {/* Brand Header */}
        <div className="h-16 flex items-center px-4 border-b border-slate-800 gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white font-bold text-xl shadow-md shrink-0">
            M
          </div>
          {!sidebarCollapsed && (
            <div className="overflow-hidden">
              <h1 className="text-sm font-bold text-white tracking-wider truncate">MOUNTEC SYSTEM</h1>
              <p className="text-[10px] text-slate-400 uppercase tracking-widest truncate">Enterprise Edition</p>
            </div>
          )}
        </div>

        {/* User Role Card */}
        {!sidebarCollapsed && user && (
          <div className="p-3 mx-3 my-3 bg-slate-800/60 rounded-xl border border-slate-800/80 flex items-center justify-between">
            <div className="flex items-center gap-2.5 overflow-hidden">
              <Building2 className="w-4 h-4 text-blue-400 shrink-0" />
              <div className="truncate">
                <p className="text-xs font-semibold text-white truncate">{user.name}</p>
                <p className="text-[10px] text-slate-400 truncate">{user.department || 'Operations'}</p>
              </div>
            </div>
            <RoleBadge role={role} />
          </div>
        )}

        {/* Navigation Menu */}
        <nav className="p-3 space-y-1 overflow-y-auto max-h-[calc(100vh-180px)]">
          {/* Dashboard */}
          {canViewDashboard() && (
            <NavLink
              to="/dashboard"
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-medium transition-colors',
                  isActive
                    ? 'bg-blue-600 text-white shadow-sm font-semibold'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
                )
              }
            >
              <LayoutDashboard className="w-4 h-4 shrink-0" />
              {!sidebarCollapsed && <span>Dashboard</span>}
            </NavLink>
          )}

          {/* MOUNTEC Submenu */}
          {canViewInventory() && (
            <div>
              <button
                onClick={() => setMetcOpen(!metcOpen)}
                className={cn(
                  'w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-medium transition-colors',
                  isMetcActive
                    ? 'text-white bg-slate-800/80'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
                )}
              >
                <div className="flex items-center gap-3">
                  <Boxes className="w-4 h-4 shrink-0 text-blue-400" />
                  {!sidebarCollapsed && <span>MOUNTEC Assets</span>}
                </div>
                {!sidebarCollapsed && (
                  metcOpen ? <ChevronDown className="w-3.5 h-3.5 text-slate-400" /> : <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                )}
              </button>

              {(metcOpen || sidebarCollapsed) && (
                <div className={cn('space-y-1 mt-1', !sidebarCollapsed && 'pl-8')}>
                  <NavLink
                    to="/materials"
                    className={({ isActive }) =>
                      cn(
                        'flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-colors',
                        isActive ? 'text-blue-400 font-semibold bg-blue-950/40' : 'text-slate-400 hover:text-white'
                      )
                    }
                  >
                    <Package className="w-3.5 h-3.5 shrink-0" />
                    {!sidebarCollapsed && <span>Materials</span>}
                  </NavLink>

                  <NavLink
                    to="/equipment"
                    className={({ isActive }) =>
                      cn(
                        'flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-colors',
                        isActive ? 'text-blue-400 font-semibold bg-blue-950/40' : 'text-slate-400 hover:text-white'
                      )
                    }
                  >
                    <HardHat className="w-3.5 h-3.5 shrink-0" />
                    {!sidebarCollapsed && <span>Equipment</span>}
                  </NavLink>

                  <NavLink
                    to="/tools"
                    className={({ isActive }) =>
                      cn(
                        'flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-colors',
                        isActive ? 'text-blue-400 font-semibold bg-blue-950/40' : 'text-slate-400 hover:text-white'
                      )
                    }
                  >
                    <Wrench className="w-3.5 h-3.5 shrink-0" />
                    {!sidebarCollapsed && <span>Tools</span>}
                  </NavLink>

                  <NavLink
                    to="/consumables"
                    className={({ isActive }) =>
                      cn(
                        'flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-colors',
                        isActive ? 'text-blue-400 font-semibold bg-blue-950/40' : 'text-slate-400 hover:text-white'
                      )
                    }
                  >
                    <Fuel className="w-3.5 h-3.5 shrink-0" />
                    {!sidebarCollapsed && <span>Consumables</span>}
                  </NavLink>

                  <NavLink
                    to="/ppe"
                    className={({ isActive }) =>
                      cn(
                        'flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-colors',
                        isActive ? 'text-blue-400 font-semibold bg-blue-950/40' : 'text-slate-400 hover:text-white'
                      )
                    }
                  >
                    <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
                    {!sidebarCollapsed && <span>PPE</span>}
                  </NavLink>
                </div>
              )}
            </div>
          )}

          {/* Workers */}
          {canViewWorkers() && (
            <NavLink
              to="/workers"
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-medium transition-colors',
                  isActive ? 'bg-blue-600 text-white shadow-sm font-semibold' : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
                )
              }
            >
              <Users className="w-4 h-4 shrink-0 text-amber-400" />
              {!sidebarCollapsed && <span>Workers</span>}
            </NavLink>
          )}

          {/* Issue */}
          {canIssueItems() && (
            <NavLink
              to="/issue"
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-medium transition-colors',
                  isActive ? 'bg-blue-600 text-white shadow-sm font-semibold' : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
                )
              }
            >
              <ArrowUpRight className="w-4 h-4 shrink-0 text-emerald-400" />
              {!sidebarCollapsed && <span>Issue Items</span>}
            </NavLink>
          )}

          {/* Return */}
          {canReturnItems() && (
            <NavLink
              to="/return"
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-medium transition-colors',
                  isActive ? 'bg-blue-600 text-white shadow-sm font-semibold' : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
                )
              }
            >
              <ArrowDownLeft className="w-4 h-4 shrink-0 text-sky-400" />
              {!sidebarCollapsed && <span>Return Items</span>}
            </NavLink>
          )}

          {/* Transfer */}
          {canTransferItems() && (
            <NavLink
              to="/transfer"
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-medium transition-colors',
                  isActive ? 'bg-blue-600 text-white shadow-sm font-semibold' : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
                )
              }
            >
              <ArrowRightLeft className="w-4 h-4 shrink-0 text-purple-400" />
              {!sidebarCollapsed && <span>Transfer Items</span>}
            </NavLink>
          )}

          {/* Maintenance */}
          {canRepairItems() && (
            <NavLink
              to="/maintenance"
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-medium transition-colors',
                  isActive ? 'bg-blue-600 text-white shadow-sm font-semibold' : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
                )
              }
            >
              <Hammer className="w-4 h-4 shrink-0 text-orange-400" />
              {!sidebarCollapsed && <span>Maintenance</span>}
            </NavLink>
          )}

          {/* Lost Items */}
          {canReportLost() && (
            <NavLink
              to="/lost-items"
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-medium transition-colors',
                  isActive ? 'bg-blue-600 text-white shadow-sm font-semibold' : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
                )
              }
            >
              <ShieldAlert className="w-4 h-4 shrink-0 text-rose-400" />
              {!sidebarCollapsed && <span>Lost Items</span>}
            </NavLink>
          )}

          {/* Reports */}
          {canViewReports() && (
            <NavLink
              to="/reports"
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-medium transition-colors',
                  isActive ? 'bg-blue-600 text-white shadow-sm font-semibold' : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
                )
              }
            >
              <FileText className="w-4 h-4 shrink-0 text-indigo-400" />
              {!sidebarCollapsed && <span>Reports & Analytics</span>}
            </NavLink>
          )}

          {/* Notifications */}
          <NavLink
            to="/notifications"
            className={({ isActive }) =>
              cn(
                'flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-medium transition-colors',
                isActive ? 'bg-blue-600 text-white shadow-sm font-semibold' : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
              )
            }
          >
            <Bell className="w-4 h-4 shrink-0 text-yellow-400" />
            {!sidebarCollapsed && <span>Notifications</span>}
          </NavLink>

          {/* Profile link */}
          <NavLink
            to="/profile"
            className={({ isActive }) =>
              cn(
                'flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-medium transition-colors',
                isActive ? 'bg-blue-600 text-white shadow-sm font-semibold' : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
              )
            }
          >
            <UserCheck className="w-4 h-4 shrink-0 text-cyan-400" />
            {!sidebarCollapsed && <span>My Profile</span>}
          </NavLink>

          {/* Administration */}
          {canManageSettings() && (
            <NavLink
              to="/admin"
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-medium transition-colors',
                  isActive ? 'bg-blue-600 text-white shadow-sm font-semibold' : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
                )
              }
            >
              <ShieldCheck className="w-4 h-4 shrink-0 text-purple-400" />
              {!sidebarCollapsed && <span>Administration</span>}
            </NavLink>
          )}

          {/* Settings */}
          {canManageSettings() && (
            <NavLink
              to="/settings"
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-medium transition-colors',
                  isActive ? 'bg-blue-600 text-white shadow-sm font-semibold' : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
                )
              }
            >
              <Settings className="w-4 h-4 shrink-0 text-slate-400" />
              {!sidebarCollapsed && <span>Settings</span>}
            </NavLink>
          )}
        </nav>
      </div>

      {/* Footer System Version */}
      {!sidebarCollapsed && (
        <div className="p-4 border-t border-slate-800 text-[10px] text-slate-500">
          <p className="font-semibold text-slate-400">MOUNTEC PTE LTD</p>
          <p>MOUNTEC v2.5.0-EE Enterprise</p>
        </div>
      )}
    </aside>
  );
};

export default Sidebar;
