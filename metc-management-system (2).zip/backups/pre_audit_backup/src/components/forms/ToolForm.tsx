import React, { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Tool } from '../../types';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';

const toolSchema = z.object({
  code: z.string().min(2, 'Code required'),
  name: z.string().min(2, 'Tool name required'),
  brand: z.string().optional(),
  condition: z.enum(['New', 'Good', 'Fair', 'Requires Service']),
  quantity: z.preprocess((val) => Number(val), z.number().min(1)),
  location: z.string().min(2, 'Location required'),
  assignedBox: z.string().optional(),
  unitPrice: z.preprocess((val) => Number(val), z.number().optional()),
  description: z.string().optional(),
});

export type ToolFormData = {
  code: string;
  name: string;
  brand?: string;
  condition: 'New' | 'Good' | 'Fair' | 'Requires Service';
  quantity: number;
  location: string;
  assignedBox?: string;
  unitPrice?: number;
  description?: string;
};

export interface ToolFormProps {
  initialData?: Tool | null;
  onSubmit: (data: ToolFormData) => void;
  onCancel: () => void;
  isLoading?: boolean;
}

export const ToolForm: React.FC<ToolFormProps> = ({
  initialData,
  onSubmit,
  onCancel,
  isLoading = false,
}) => {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<ToolFormData>({
    resolver: zodResolver(toolSchema) as any,
    defaultValues: {
      code: `TOL-${Math.floor(100 + Math.random() * 900)}`,
      name: '',
      brand: 'Bosch Professional',
      condition: 'Good',
      quantity: 1,
      location: 'Tool Crib Room 2',
      assignedBox: '',
      unitPrice: 0,
      description: '',
    },
  });

  useEffect(() => {
    if (initialData) {
      reset({
        code: initialData.code,
        name: initialData.name,
        brand: initialData.brand || '',
        condition: initialData.condition,
        quantity: initialData.quantity,
        location: initialData.location,
        assignedBox: initialData.assignedBox || '',
        unitPrice: initialData.unitPrice || 0,
        description: initialData.description || '',
      });
    }
  }, [initialData, reset]);

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Input label="Tool Code" {...register('code')} error={errors.code?.message} />
        <Input label="Tool Name" {...register('name')} error={errors.name?.message} />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Input label="Brand / Manufacturer" {...register('brand')} />
        <Select
          label="Physical Condition"
          {...register('condition')}
          options={[
            { label: 'New', value: 'New' },
            { label: 'Good', value: 'Good' },
            { label: 'Fair', value: 'Fair' },
            { label: 'Requires Service', value: 'Requires Service' },
          ]}
        />
        <Input label="Quantity" type="number" {...register('quantity')} error={errors.quantity?.message} />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Input label="Crib / Rack Location" {...register('location')} error={errors.location?.message} />
        <Input label="Assigned Tool Box ID" {...register('assignedBox')} placeholder="e.g. CRIB-BOX-12" />
        <Input label="Replacement Cost ($)" type="number" step="0.01" {...register('unitPrice')} />
      </div>

      <div>
        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1">
          Notes / Serial Number
        </label>
        <textarea
          {...register('description')}
          rows={2}
          className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2 text-sm text-slate-900 dark:text-slate-100"
        />
      </div>

      <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
        <Button variant="outline" type="button" onClick={onCancel}>
          Cancel
        </Button>
        <Button variant="primary" type="submit" isLoading={isLoading}>
          {initialData ? 'Update Tool' : 'Save Tool'}
        </Button>
      </div>
    </form>
  );
};
