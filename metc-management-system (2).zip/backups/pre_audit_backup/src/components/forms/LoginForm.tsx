import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Link, useNavigate } from 'react-router-dom';
import { Mail, Lock, LogIn } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';

const loginSchema = z.object({
  email: z.string().email('Please enter a valid work email address'),
  password: z.string().min(1, 'Password is required'),
  rememberMe: z.boolean(),
});

type LoginFormData = z.infer<typeof loginSchema>;

export const LoginForm: React.FC = () => {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [errorMsg, setErrorMsg] = useState('');
  const [loading, setLoading] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: '',
      password: '',
      rememberMe: true,
    },
  });

  const onSubmit = async (data: LoginFormData) => {
    setErrorMsg('');
    setLoading(true);
    try {
      const result = await login(data.email, data.password, data.rememberMe);
      if (result.success) {
        navigate('/dashboard');
      } else {
        setErrorMsg(result.error || 'Invalid login credentials or unauthorized role access.');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Authentication service error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {errorMsg && (
        <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-xs text-rose-700 dark:text-rose-300">
          {errorMsg}
        </div>
      )}

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <Input
          label="Corporate Work Email"
          type="email"
          leftIcon={<Mail className="w-4 h-4" />}
          {...register('email')}
          error={errors.email?.message}
        />

        <Input
          label="Password"
          type="password"
          leftIcon={<Lock className="w-4 h-4" />}
          {...register('password')}
          error={errors.password?.message}
        />

        <div className="flex items-center justify-between text-xs">
          <label className="flex items-center gap-2 cursor-pointer text-slate-600 dark:text-slate-400">
            <input
              type="checkbox"
              {...register('rememberMe')}
              className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
            />
            <span>Remember session on this device</span>
          </label>

          <Link
            to="/forgot-password"
            className="font-semibold text-blue-600 dark:text-blue-400 hover:underline"
          >
            Forgot password?
          </Link>
        </div>

        <Button
          variant="primary"
          size="lg"
          type="submit"
          isLoading={loading}
          icon={<LogIn className="w-4 h-4" />}
          className="w-full mt-2 py-3"
        >
          Sign In To MOUNTEC System
        </Button>
      </form>
    </div>
  );
};
