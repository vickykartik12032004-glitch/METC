import React, { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Consumable } from '../../types';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';

const consumableSchema = z.object({
  code: z.string().min(2, 'Code required'),
  name: z.string().min(2, 'Name required'),
  unit: z.string().min(1, 'Unit required'),
  quantity: z.preprocess((val) => Number(val), z.number().min(0)),
  reorderLevel: z.preprocess((val) => Number(val), z.number().min(1, 'Reorder level required')),
  location: z.string().min(2, 'Location required'),
  unitPrice: z.preprocess((val) => Number(val), z.number().optional()),
  supplier: z.string().optional(),
  description: z.string().optional(),
});

export type ConsumableFormData = {
  code: string;
  name: string;
  unit: string;
  quantity: number;
  reorderLevel: number;
  location: string;
  unitPrice?: number;
  supplier?: string;
  description?: string;
};

export interface ConsumableFormProps {
  initialData?: Consumable | null;
  onSubmit: (data: ConsumableFormData) => void;
  onCancel: () => void;
  isLoading?: boolean;
}

export const ConsumableForm: React.FC<ConsumableFormProps> = ({
  initialData,
  onSubmit,
  onCancel,
  isLoading = false,
}) => {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<ConsumableFormData>({
    resolver: zodResolver(consumableSchema) as any,
    defaultValues: {
      code: `CON-${Math.floor(100 + Math.random() * 900)}`,
      name: '',
      unit: 'Boxes',
      quantity: 50,
      reorderLevel: 10,
      location: 'Consumable Rack 3',
      unitPrice: 0,
      supplier: '',
      description: '',
    },
  });

  useEffect(() => {
    if (initialData) {
      reset({
        code: initialData.code,
        name: initialData.name,
        unit: initialData.unit,
        quantity: initialData.quantity,
        reorderLevel: initialData.reorderLevel,
        location: initialData.location,
        unitPrice: initialData.unitPrice || 0,
        supplier: initialData.supplier || '',
        description: initialData.description || '',
      });
    }
  }, [initialData, reset]);

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Input label="Consumable Code" {...register('code')} error={errors.code?.message} />
        <Input label="Item Name" {...register('name')} error={errors.name?.message} />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Input label="Unit (e.g. Boxes, Packs, Units)" {...register('unit')} error={errors.unit?.message} />
        <Input label="Current Stock" type="number" {...register('quantity')} error={errors.quantity?.message} />
        <Input label="Reorder Level Alert Threshold" type="number" {...register('reorderLevel')} error={errors.reorderLevel?.message} />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Input label="Rack / Shelf Location" {...register('location')} error={errors.location?.message} />
        <Input label="Unit Cost ($)" type="number" step="0.01" {...register('unitPrice')} />
        <Input label="Supplier" {...register('supplier')} />
      </div>

      <div>
        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1">
          Description
        </label>
        <textarea
          {...register('description')}
          rows={2}
          className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2 text-sm text-slate-900 dark:text-slate-100"
        />
      </div>

      <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
        <Button variant="outline" type="button" onClick={onCancel}>
          Cancel
        </Button>
        <Button variant="primary" type="submit" isLoading={isLoading}>
          {initialData ? 'Update Consumable' : 'Save Consumable'}
        </Button>
      </div>
    </form>
  );
};
