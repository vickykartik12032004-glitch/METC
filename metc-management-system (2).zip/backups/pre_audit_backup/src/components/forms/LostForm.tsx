import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useAssetStore } from '../../store/useAssetStore';
import { useWorkerStore } from '../../store/useWorkerStore';
import { useAuthStore } from '../../store/useAuthStore';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';

const lostSchema = z.object({
  itemId: z.string().min(1, 'Item selection required'),
  workerId: z.string().optional(),
  quantityLost: z.preprocess((val) => Number(val), z.number().min(1)),
  reportedDate: z.string(),
  location: z.string().min(2, 'Location required'),
  estimatedValue: z.preprocess((val) => Number(val), z.number()),
  incidentDetails: z.string().min(3, 'Incident details required'),
  actionTaken: z.enum(['Worker Charged', 'Company Absorbed', 'Under Investigation', 'Insurance Claim']),
});

export type LostFormData = {
  itemId: string;
  workerId?: string;
  quantityLost: number;
  reportedDate: string;
  location: string;
  estimatedValue: number;
  incidentDetails: string;
  actionTaken: 'Worker Charged' | 'Company Absorbed' | 'Under Investigation' | 'Insurance Claim';
};

export interface LostFormProps {
  onSubmit: (data: LostFormData & { itemName: string; workerName?: string; reportedBy: string; status: 'Reported' }) => void;
  onCancel: () => void;
  isLoading?: boolean;
}

export const LostForm: React.FC<LostFormProps> = ({ onSubmit, onCancel, isLoading = false }) => {
  const { getAllAssets } = useAssetStore();
  const { workers } = useWorkerStore();
  const { user } = useAuthStore();
  const assets = getAllAssets();

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm<LostFormData>({
    resolver: zodResolver(lostSchema) as any,
    defaultValues: {
      itemId: assets[0]?.id || '',
      workerId: '',
      quantityLost: 1,
      reportedDate: new Date().toISOString().split('T')[0],
      location: 'Tower A Site',
      estimatedValue: 200,
      incidentDetails: '',
      actionTaken: 'Under Investigation',
    },
  });

  const selectedItemId = watch('itemId');

  const handleFormSubmit = (data: LostFormData) => {
    const item = assets.find((a) => a.id === data.itemId);
    const worker = workers.find((w) => w.id === data.workerId);
    if (!item) return;

    onSubmit({
      ...data,
      itemName: item.name,
      workerName: worker?.name,
      reportedBy: user?.name || 'Site Supervisor',
      status: 'Reported',
    });
  };

  return (
    <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-4">
      <Select
        label="Select Missing Asset"
        {...register('itemId')}
        error={errors.itemId?.message}
        options={assets.map((a) => ({
          label: `[${a.code}] ${a.name} (${a.category})`,
          value: a.id,
        }))}
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Select
          label="Assigned Worker (If applicable)"
          {...register('workerId')}
          options={[
            { label: '-- None / Unassigned --', value: '' },
            ...workers.map((w) => ({
              label: `[${w.workerCode}] ${w.name}`,
              value: w.id,
            })),
          ]}
        />
        <Input label="Quantity Lost" type="number" {...register('quantityLost')} error={errors.quantityLost?.message} />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Input label="Reported Date" type="date" {...register('reportedDate')} />
        <Input label="Site Incident Location" {...register('location')} error={errors.location?.message} />
        <Input label="Estimated Value Loss ($)" type="number" step="0.01" {...register('estimatedValue')} />
      </div>

      <Select
        label="Administrative Action Taken"
        {...register('actionTaken')}
        options={[
          { label: 'Under Investigation', value: 'Under Investigation' },
          { label: 'Worker Charged (Payroll Deduction)', value: 'Worker Charged' },
          { label: 'Company Absorbed (Write-off)', value: 'Company Absorbed' },
          { label: 'Insurance Claim Filed', value: 'Insurance Claim' },
        ]}
      />

      <div>
        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1">
          Incident Investigation Details
        </label>
        <textarea
          {...register('incidentDetails')}
          rows={3}
          className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2 text-sm text-slate-900 dark:text-slate-100"
          placeholder="Describe how, when, and where the item went missing..."
        />
      </div>

      <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
        <Button variant="outline" type="button" onClick={onCancel}>
          Cancel
        </Button>
        <Button variant="danger" type="submit" isLoading={isLoading}>
          File Lost Asset Report
        </Button>
      </div>
    </form>
  );
};
