import React, { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Equipment } from '../../types';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';

const equipmentSchema = z.object({
  code: z.string().min(2, 'Code required'),
  name: z.string().min(2, 'Equipment name required'),
  serialNumber: z.string().min(2, 'Serial number required'),
  modelNumber: z.string().optional(),
  manufacturer: z.string().optional(),
  quantity: z.preprocess((val) => Number(val), z.number().min(1)),
  location: z.string().min(2, 'Location required'),
  unitPrice: z.preprocess((val) => Number(val), z.number().optional()),
  powerSource: z.string().optional(),
  description: z.string().optional(),
});

export type EquipmentFormData = {
  code: string;
  name: string;
  serialNumber: string;
  modelNumber?: string;
  manufacturer?: string;
  quantity: number;
  location: string;
  unitPrice?: number;
  powerSource?: string;
  description?: string;
};

export interface EquipmentFormProps {
  initialData?: Equipment | null;
  onSubmit: (data: EquipmentFormData) => void;
  onCancel: () => void;
  isLoading?: boolean;
}

export const EquipmentForm: React.FC<EquipmentFormProps> = ({
  initialData,
  onSubmit,
  onCancel,
  isLoading = false,
}) => {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<EquipmentFormData>({
    resolver: zodResolver(equipmentSchema) as any,
    defaultValues: {
      code: `EQP-${Math.floor(100 + Math.random() * 900)}`,
      name: '',
      serialNumber: '',
      modelNumber: '',
      manufacturer: '',
      quantity: 1,
      location: 'Main Yard',
      unitPrice: 0,
      powerSource: 'Diesel',
      description: '',
    },
  });

  useEffect(() => {
    if (initialData) {
      reset({
        code: initialData.code,
        name: initialData.name,
        serialNumber: initialData.serialNumber,
        modelNumber: initialData.modelNumber || '',
        manufacturer: initialData.manufacturer || '',
        quantity: initialData.quantity,
        location: initialData.location,
        unitPrice: initialData.unitPrice || 0,
        powerSource: initialData.powerSource || 'Diesel',
        description: initialData.description || '',
      });
    }
  }, [initialData, reset]);

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Input label="Equipment Code" {...register('code')} error={errors.code?.message} />
        <Input label="Equipment Name" {...register('name')} error={errors.name?.message} />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Input label="Serial Number / Tag" {...register('serialNumber')} error={errors.serialNumber?.message} />
        <Input label="Model Number" {...register('modelNumber')} />
        <Input label="Manufacturer" {...register('manufacturer')} />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Input label="Quantity" type="number" {...register('quantity')} error={errors.quantity?.message} />
        <Input label="Location / Site" {...register('location')} error={errors.location?.message} />
        <Input label="Power Source (e.g. Diesel, Electric)" {...register('powerSource')} />
      </div>

      <Input label="Asset Value ($)" type="number" step="0.01" {...register('unitPrice')} />

      <div>
        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1">
          Technical Specifications / Maintenance Log
        </label>
        <textarea
          {...register('description')}
          rows={3}
          className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2 text-sm text-slate-900 dark:text-slate-100"
          placeholder="Operating specs, fuel capacity, maintenance history..."
        />
      </div>

      <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
        <Button variant="outline" type="button" onClick={onCancel}>
          Cancel
        </Button>
        <Button variant="primary" type="submit" isLoading={isLoading}>
          {initialData ? 'Update Equipment' : 'Save Equipment'}
        </Button>
      </div>
    </form>
  );
};
