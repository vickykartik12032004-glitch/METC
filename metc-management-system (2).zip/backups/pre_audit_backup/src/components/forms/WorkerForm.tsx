import React, { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Worker } from '../../types';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';

const workerSchema = z.object({
  workerCode: z.string().min(2, 'Worker code required'),
  name: z.string().min(2, 'Full name required'),
  trade: z.string().min(2, 'Trade specialization required'),
  phone: z.string().min(5, 'Phone number required'),
  email: z.string().email('Invalid email').optional().or(z.literal('')),
  projectSite: z.string().min(2, 'Site location required'),
  badgeNumber: z.string().min(2, 'Badge number required'),
  status: z.enum(['Active', 'Inactive', 'On Leave']),
});

type WorkerFormData = z.infer<typeof workerSchema>;

export interface WorkerFormProps {
  initialData?: Worker | null;
  onSubmit: (data: WorkerFormData) => void;
  onCancel: () => void;
  isLoading?: boolean;
}

export const WorkerForm: React.FC<WorkerFormProps> = ({
  initialData,
  onSubmit,
  onCancel,
  isLoading = false,
}) => {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<WorkerFormData>({
    resolver: zodResolver(workerSchema),
    defaultValues: {
      workerCode: `WRK-${Math.floor(100 + Math.random() * 900)}`,
      name: '',
      trade: 'Electrician',
      phone: '+1 (555) 000-0000',
      email: '',
      projectSite: 'Tower A Site',
      badgeNumber: `BDG-${Math.floor(1000 + Math.random() * 9000)}`,
      status: 'Active',
    },
  });

  useEffect(() => {
    if (initialData) {
      reset({
        workerCode: initialData.workerCode,
        name: initialData.name,
        trade: initialData.trade,
        phone: initialData.phone,
        email: initialData.email || '',
        projectSite: initialData.projectSite,
        badgeNumber: initialData.badgeNumber,
        status: initialData.status,
      });
    }
  }, [initialData, reset]);

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Input label="Worker Code" {...register('workerCode')} error={errors.workerCode?.message} />
        <Input label="Full Name" {...register('name')} error={errors.name?.message} placeholder="e.g. John Smith" />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Input label="Trade Specialization" {...register('trade')} error={errors.trade?.message} placeholder="e.g. Master Welder, Mason, Electrician" />
        <Input label="Security Badge ID" {...register('badgeNumber')} error={errors.badgeNumber?.message} />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Input label="Phone Contact" {...register('phone')} error={errors.phone?.message} />
        <Input label="Email Address (Optional)" {...register('email')} error={errors.email?.message} />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Input label="Assigned Project Site" {...register('projectSite')} error={errors.projectSite?.message} />
        <Select
          label="Employment Status"
          {...register('status')}
          options={[
            { label: 'Active', value: 'Active' },
            { label: 'Inactive', value: 'Inactive' },
            { label: 'On Leave', value: 'On Leave' },
          ]}
        />
      </div>

      <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
        <Button variant="outline" type="button" onClick={onCancel}>
          Cancel
        </Button>
        <Button variant="primary" type="submit" isLoading={isLoading}>
          {initialData ? 'Update Worker' : 'Save Worker Profile'}
        </Button>
      </div>
    </form>
  );
};
