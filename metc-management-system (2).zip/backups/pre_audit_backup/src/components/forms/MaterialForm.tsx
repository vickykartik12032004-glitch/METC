import React, { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Material } from '../../types';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';

const materialSchema = z.object({
  code: z.string().min(2, 'Code is required'),
  name: z.string().min(2, 'Material name is required'),
  unit: z.string().min(1, 'Unit is required'),
  quantity: z.preprocess((val) => Number(val), z.number().min(0)),
  minQuantityThreshold: z.preprocess((val) => Number(val), z.number().min(0)),
  location: z.string().min(2, 'Location is required'),
  unitPrice: z.preprocess((val) => Number(val), z.number().optional()),
  supplier: z.string().optional(),
  materialGrade: z.string().optional(),
  batchNumber: z.string().optional(),
  description: z.string().optional(),
});

export type MaterialFormData = {
  code: string;
  name: string;
  unit: string;
  quantity: number;
  minQuantityThreshold: number;
  location: string;
  unitPrice?: number;
  supplier?: string;
  materialGrade?: string;
  batchNumber?: string;
  description?: string;
};

export interface MaterialFormProps {
  initialData?: Material | null;
  onSubmit: (data: MaterialFormData) => void;
  onCancel: () => void;
  isLoading?: boolean;
}

export const MaterialForm: React.FC<MaterialFormProps> = ({
  initialData,
  onSubmit,
  onCancel,
  isLoading = false,
}) => {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<MaterialFormData>({
    resolver: zodResolver(materialSchema) as any,
    defaultValues: {
      code: `MAT-${Math.floor(100 + Math.random() * 900)}`,
      name: '',
      unit: 'Bags (50kg)',
      quantity: 100,
      minQuantityThreshold: 20,
      location: 'Warehouse Main Yard',
      unitPrice: 0,
      supplier: '',
      materialGrade: '',
      batchNumber: '',
      description: '',
    },
  });

  useEffect(() => {
    if (initialData) {
      reset({
        code: initialData.code,
        name: initialData.name,
        unit: initialData.unit,
        quantity: initialData.quantity,
        minQuantityThreshold: initialData.minQuantityThreshold || 10,
        location: initialData.location,
        unitPrice: initialData.unitPrice || 0,
        supplier: initialData.supplier || '',
        materialGrade: initialData.materialGrade || '',
        batchNumber: initialData.batchNumber || '',
        description: initialData.description || '',
      });
    }
  }, [initialData, reset]);

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Input
          label="Material Code"
          {...register('code')}
          error={errors.code?.message}
          placeholder="e.g. MAT-101"
        />
        <Input
          label="Material Name"
          {...register('name')}
          error={errors.name?.message}
          placeholder="e.g. Portland Cement Grade 53"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Input
          label="Unit (e.g. Bags, Tons, m³)"
          {...register('unit')}
          error={errors.unit?.message}
        />
        <Input
          label="Initial Quantity"
          type="number"
          {...register('quantity')}
          error={errors.quantity?.message}
        />
        <Input
          label="Min Low Stock Level"
          type="number"
          {...register('minQuantityThreshold')}
          error={errors.minQuantityThreshold?.message}
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Input
          label="Warehouse / Site Location"
          {...register('location')}
          error={errors.location?.message}
          placeholder="e.g. Warehouse Bay 3"
        />
        <Input
          label="Unit Price ($)"
          type="number"
          step="0.01"
          {...register('unitPrice')}
          error={errors.unitPrice?.message}
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Input label="Supplier / Vendor" {...register('supplier')} placeholder="e.g. LafargeHolcim" />
        <Input label="Material Grade" {...register('materialGrade')} placeholder="e.g. PPC 53" />
        <Input label="Batch Number" {...register('batchNumber')} placeholder="e.g. BATCH-2025-01" />
      </div>

      <div>
        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1">
          Description / Storage Instructions
        </label>
        <textarea
          {...register('description')}
          rows={3}
          className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:border-blue-500 focus:outline-none"
          placeholder="Detailed notes, storage specifications..."
        />
      </div>

      <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
        <Button variant="outline" type="button" onClick={onCancel}>
          Cancel
        </Button>
        <Button variant="primary" type="submit" isLoading={isLoading}>
          {initialData ? 'Update Material' : 'Save Material'}
        </Button>
      </div>
    </form>
  );
};
