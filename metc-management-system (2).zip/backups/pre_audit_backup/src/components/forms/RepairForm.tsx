import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useAssetStore } from '../../store/useAssetStore';
import { useAuthStore } from '../../store/useAuthStore';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';

const repairSchema = z.object({
  itemId: z.string().min(1, 'Item selection required'),
  serialOrTag: z.string().optional(),
  issueDescription: z.string().min(3, 'Fault description required'),
  repairVendor: z.string().optional(),
  sentDate: z.string(),
  estimatedReturnDate: z.string().optional(),
  repairCost: z.preprocess((val) => Number(val), z.number().optional()),
});

export type RepairFormData = {
  itemId: string;
  serialOrTag?: string;
  issueDescription: string;
  repairVendor?: string;
  sentDate: string;
  estimatedReturnDate?: string;
  repairCost?: number;
};

export interface RepairFormProps {
  onSubmit: (data: RepairFormData & { itemName: string; handledBy: string; status: 'In Repair' }) => void;
  onCancel: () => void;
  isLoading?: boolean;
}

export const RepairForm: React.FC<RepairFormProps> = ({ onSubmit, onCancel, isLoading = false }) => {
  const { getAllAssets } = useAssetStore();
  const { user } = useAuthStore();
  const assets = getAllAssets();

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<RepairFormData>({
    resolver: zodResolver(repairSchema) as any,
    defaultValues: {
      itemId: assets[0]?.id || '',
      serialOrTag: '',
      issueDescription: '',
      repairVendor: 'Authorized Service Center',
      sentDate: new Date().toISOString().split('T')[0],
      estimatedReturnDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      repairCost: 0,
    },
  });

  const handleFormSubmit = (data: RepairFormData) => {
    const item = assets.find((a) => a.id === data.itemId);
    if (!item) return;

    onSubmit({
      ...data,
      itemName: item.name,
      handledBy: user?.name || 'Store Keeper',
      status: 'In Repair',
    });
  };

  return (
    <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-4">
      <Select
        label="Select Asset For Repair / Maintenance"
        {...register('itemId')}
        error={errors.itemId?.message}
        options={assets.map((a) => ({
          label: `[${a.code}] ${a.name} (${a.category})`,
          value: a.id,
        }))}
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Input label="Serial / Tag No." {...register('serialOrTag')} placeholder="e.g. SN-99823" />
        <Input label="External Service Center / Vendor" {...register('repairVendor')} />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Input label="Dispatch Date" type="date" {...register('sentDate')} />
        <Input label="Est. Return Date" type="date" {...register('estimatedReturnDate')} />
        <Input label="Est. Cost ($)" type="number" step="0.01" {...register('repairCost')} />
      </div>

      <div>
        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1">
          Fault Description & Repair Work Scope
        </label>
        <textarea
          {...register('issueDescription')}
          rows={3}
          className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2 text-sm text-slate-900 dark:text-slate-100"
          placeholder="Detailed explanation of breakdown, defective parts, or error messages..."
        />
      </div>

      <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
        <Button variant="outline" type="button" onClick={onCancel}>
          Cancel
        </Button>
        <Button variant="primary" type="submit" isLoading={isLoading}>
          Log Repair Dispatch
        </Button>
      </div>
    </form>
  );
};
