import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useAssetStore } from '../../store/useAssetStore';
import { useWorkerStore } from '../../store/useWorkerStore';
import { useAuthStore } from '../../store/useAuthStore';
import { INITIAL_WORKERS } from '../../data/mockData';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';
import { User, Sparkles } from 'lucide-react';

const issueSchema = z.object({
  itemId: z.string().min(1, 'Item selection required'),
  workerId: z.string().min(1, 'Worker selection required'),
  quantity: z.preprocess((val) => Number(val), z.number().min(1, 'Quantity must be at least 1')),
  expectedReturnDate: z.string().optional(),
  projectSite: z.string().min(2, 'Project site required'),
  remarks: z.string().optional(),
});

export type IssueFormData = {
  itemId: string;
  workerId: string;
  quantity: number;
  expectedReturnDate?: string;
  projectSite: string;
  remarks?: string;
};

export interface IssueFormProps {
  onSubmit: (data: IssueFormData & { itemName: string; itemCategory: any; workerName: string; issuedBy: string }) => void;
  onCancel: () => void;
  isLoading?: boolean;
}

export const IssueForm: React.FC<IssueFormProps> = ({ onSubmit, onCancel, isLoading = false }) => {
  const { getAllAssets } = useAssetStore();
  const { workers } = useWorkerStore();
  const { user } = useAuthStore();

  const effectiveWorkers = workers && workers.length > 0 ? workers : INITIAL_WORKERS;
  const assets = getAllAssets().filter((a) => a.availableQuantity > 0);

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = useForm<IssueFormData>({
    resolver: zodResolver(issueSchema) as any,
    defaultValues: {
      itemId: assets[0]?.id || '',
      workerId: effectiveWorkers[0]?.id || '',
      quantity: 1,
      expectedReturnDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      projectSite: effectiveWorkers[0]?.projectSite || 'Tuas Mega Logistics Depot',
      remarks: '',
    },
  });

  const selectedItemId = watch('itemId');
  const selectedWorkerId = watch('workerId');
  const selectedAsset = assets.find((a) => a.id === selectedItemId);
  const selectedWorker = effectiveWorkers.find((w) => w.id === selectedWorkerId);

  const handleQuickSelectWorker = (wId: string) => {
    setValue('workerId', wId);
    const found = effectiveWorkers.find((w) => w.id === wId);
    if (found?.projectSite) {
      setValue('projectSite', found.projectSite);
    }
  };

  const handleFormSubmit = (data: IssueFormData) => {
    const item = assets.find((a) => a.id === data.itemId);
    const worker = effectiveWorkers.find((w) => w.id === data.workerId);

    if (!item || !worker) return;

    onSubmit({
      ...data,
      itemName: item.name,
      itemCategory: item.category,
      workerName: worker.name,
      issuedBy: user?.name || 'Store Keeper',
    });
  };

  return (
    <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-4">
      <div>
        <Select
          label="Select Asset to Issue"
          {...register('itemId')}
          error={errors.itemId?.message}
          options={assets.map((a) => ({
            label: `[${a.code}] ${a.name} (Available: ${a.availableQuantity} ${a.unit})`,
            value: a.id,
          }))}
        />
        {selectedAsset && (
          <p className="text-xs text-slate-500 mt-1">
            Category: <strong className="font-semibold text-slate-700 dark:text-slate-300">{selectedAsset.category}</strong> | Location: {selectedAsset.location}
          </p>
        )}
      </div>

      {/* Quick Worker Selection Chips (Click Name to Pop In) */}
      <div className="space-y-1.5 p-2.5 rounded-xl bg-blue-50/60 dark:bg-blue-950/30 border border-blue-200/70 dark:border-blue-900/40">
        <div className="flex items-center justify-between text-[11px]">
          <span className="font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-blue-600 animate-pulse" />
            <span>Quick-Select Worker (Click Name):</span>
          </span>
          <span className="text-[10px] text-slate-500 font-mono">
            {effectiveWorkers.length} registered
          </span>
        </div>
        <div className="flex flex-wrap gap-1.5 max-h-20 overflow-y-auto">
          {effectiveWorkers.map((w) => {
            const isSelected = selectedWorkerId === w.id;
            return (
              <button
                key={w.id}
                type="button"
                onClick={() => handleQuickSelectWorker(w.id)}
                className={`px-2.5 py-1 text-[11px] font-bold rounded-lg border transition-all flex items-center gap-1 cursor-pointer ${
                  isSelected
                    ? 'bg-blue-600 text-white border-blue-600 shadow-2xs'
                    : 'bg-white hover:bg-blue-50 text-blue-700 dark:bg-slate-800 dark:text-blue-300 dark:hover:bg-blue-900/40 border-blue-200 dark:border-blue-900'
                }`}
              >
                <User className="w-3 h-3 opacity-70" />
                <span>{w.name}</span>
                <span className="text-[9px] opacity-75 font-mono">({w.workerCode})</span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <Select
            label="Issue To Worker"
            {...register('workerId')}
            error={errors.workerId?.message}
            options={effectiveWorkers.map((w) => ({
              label: `[${w.workerCode}] ${w.name} - ${w.trade} (${w.projectSite})`,
              value: w.id,
            }))}
          />
          {selectedWorker && (
            <p className="text-[11px] text-slate-500 mt-1">
              Assigned: <strong className="font-semibold text-blue-600 dark:text-blue-400">{selectedWorker.name}</strong> • {selectedWorker.trade}
            </p>
          )}
        </div>
        <Input
          label="Quantity To Issue"
          type="number"
          {...register('quantity')}
          error={errors.quantity?.message}
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Input
          label="Expected Return Date"
          type="date"
          {...register('expectedReturnDate')}
        />
        <Input
          label="Target Project Site"
          {...register('projectSite')}
          error={errors.projectSite?.message}
        />
      </div>

      <div>
        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1">
          Issue Remarks / Purpose
        </label>
        <textarea
          {...register('remarks')}
          rows={2}
          className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2 text-sm text-slate-900 dark:text-slate-100"
          placeholder="e.g. Work order reference, specific floor placement..."
        />
      </div>

      <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
        <Button variant="outline" type="button" onClick={onCancel}>
          Cancel
        </Button>
        <Button variant="primary" type="submit" isLoading={isLoading}>
          Issue Asset Now
        </Button>
      </div>
    </form>
  );
};
