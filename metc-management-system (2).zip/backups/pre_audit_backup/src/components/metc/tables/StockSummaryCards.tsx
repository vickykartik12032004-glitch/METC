import React from 'react';
import { METCItem, AssetCategory } from '../../../types';
import { formatCurrency } from '../../../lib/utils';
import { 
  Boxes, 
  CheckCircle2, 
  ArrowUpRight, 
  Wrench, 
  AlertTriangle, 
  ShieldAlert, 
  DollarSign 
} from 'lucide-react';

interface StockSummaryCardsProps {
  items: METCItem[];
  activeCategory: AssetCategory | 'All';
}

export const StockSummaryCards: React.FC<StockSummaryCardsProps> = ({ items, activeCategory }) => {
  const totalCount = items.length;

  const totalValue = items.reduce((acc, item) => {
    const qty = item.quantity || 0;
    const price = item.unitPrice || item.purchaseCost || 0;
    return acc + qty * price;
  }, 0);

  const availableCount = items.reduce((acc, item) => acc + (item.availableQuantity ?? item.quantity ?? 0), 0);
  
  const lowStockCount = items.filter((item) => {
    const minVal = item.minQuantityThreshold ?? item.minimumStock ?? 10;
    const qty = item.availableQuantity ?? item.quantity ?? 0;
    return qty <= minVal || item.status === 'Low Stock' || item.status === 'Out of Stock';
  }).length;

  const issuedCount = items.filter((item) => item.status === 'Issued').length;
  const repairCount = items.filter((item) => item.status === 'Under Repair' || item.status === 'Repair').length;
  const lostCount = items.filter((item) => item.status === 'Lost').length;

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
      {/* Total Items & Value */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 shadow-xs hover:border-slate-300 dark:hover:border-slate-700 transition-all">
        <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-1.5">
          <span className="text-[11px] font-medium uppercase tracking-wider">Total Assets</span>
          <div className="p-1.5 rounded-lg bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400">
            <Boxes className="w-4 h-4" />
          </div>
        </div>
        <div className="text-xl font-bold text-slate-900 dark:text-white">{totalCount}</div>
        <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-1 truncate">
          Valued at <strong className="font-semibold text-slate-700 dark:text-slate-300">{formatCurrency(totalValue)}</strong>
        </p>
      </div>

      {/* Available Stock */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 shadow-xs hover:border-slate-300 dark:hover:border-slate-700 transition-all">
        <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-1.5">
          <span className="text-[11px] font-medium uppercase tracking-wider">Available Stock</span>
          <div className="p-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400">
            <CheckCircle2 className="w-4 h-4" />
          </div>
        </div>
        <div className="text-xl font-bold text-emerald-600 dark:text-emerald-400">{availableCount.toLocaleString()}</div>
        <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-1">Ready for site issue</p>
      </div>

      {/* Low / Out of Stock */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 shadow-xs hover:border-slate-300 dark:hover:border-slate-700 transition-all">
        <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-1.5">
          <span className="text-[11px] font-medium uppercase tracking-wider">Low / Out Stock</span>
          <div className="p-1.5 rounded-lg bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400">
            <AlertTriangle className="w-4 h-4" />
          </div>
        </div>
        <div className="text-xl font-bold text-amber-600 dark:text-amber-400">{lowStockCount}</div>
        <p className="text-[10px] text-amber-600/80 dark:text-amber-400/80 mt-1">Below min threshold</p>
      </div>

      {/* Issued Stock */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 shadow-xs hover:border-slate-300 dark:hover:border-slate-700 transition-all">
        <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-1.5">
          <span className="text-[11px] font-medium uppercase tracking-wider">Issued Stock</span>
          <div className="p-1.5 rounded-lg bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400">
            <ArrowUpRight className="w-4 h-4" />
          </div>
        </div>
        <div className="text-xl font-bold text-slate-900 dark:text-white">{issuedCount}</div>
        <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-1">Assigned to workers</p>
      </div>

      {/* Under Repair */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 shadow-xs hover:border-slate-300 dark:hover:border-slate-700 transition-all">
        <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-1.5">
          <span className="text-[11px] font-medium uppercase tracking-wider">In Repair</span>
          <div className="p-1.5 rounded-lg bg-orange-50 dark:bg-orange-950/60 text-orange-600 dark:text-orange-400">
            <Wrench className="w-4 h-4" />
          </div>
        </div>
        <div className="text-xl font-bold text-slate-900 dark:text-white">{repairCount}</div>
        <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-1">Vendor maintenance</p>
      </div>

      {/* Lost / Missing */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 shadow-xs hover:border-slate-300 dark:hover:border-slate-700 transition-all">
        <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-1.5">
          <span className="text-[11px] font-medium uppercase tracking-wider">Lost / Missing</span>
          <div className="p-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400">
            <ShieldAlert className="w-4 h-4" />
          </div>
        </div>
        <div className="text-xl font-bold text-rose-600 dark:text-rose-400">{lostCount}</div>
        <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-1">Investigation open</p>
      </div>
    </div>
  );
};
