import React, { useState } from 'react';
import { METCItem } from '../../../types';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '../../ui/Table';
import { StatusBadge } from '../../common/StatusBadge';
import { Button } from '../../ui/Button';
import { formatCurrency } from '../../../lib/utils';
import { 
  Eye, 
  Edit2, 
  ArrowUpRight, 
  ArrowRightLeft, 
  QrCode, 
  Copy, 
  Trash2, 
  Package, 
  ArrowUpDown, 
  CheckSquare, 
  Square, 
  SlidersHorizontal, 
  Check, 
  ChevronLeft, 
  ChevronRight, 
  SearchX, 
  X,
  LayoutGrid,
  List,
  MapPin
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { usePermissions } from '../../../hooks/usePermissions';

interface ItemTableProps {
  items: METCItem[];
  selectedIds: string[];
  onToggleSelectAll: () => void;
  onToggleSelectRow: (id: string) => void;
  onView: (item: METCItem) => void;
  onEdit: (item: METCItem) => void;
  onPrintQr: (item: METCItem) => void;
  onDuplicate: (item: METCItem) => void;
  onDelete: (id: string) => void;
  sortBy: string;
  sortOrder: 'asc' | 'desc';
  onSort: (field: string) => void;
  currentPage: number;
  totalPages: number;
  itemsPerPage: number;
  totalItems: number;
  onPageChange: (page: number) => void;
  onItemsPerPageChange: (limit: number) => void;
  searchQuery?: string;
  onClearSearch?: () => void;
  onAddNew?: () => void;
  canEdit?: boolean;
}

export const ItemTable: React.FC<ItemTableProps> = ({
  items,
  selectedIds,
  onToggleSelectAll,
  onToggleSelectRow,
  onView,
  onEdit,
  onPrintQr,
  onDuplicate,
  onDelete,
  sortBy,
  sortOrder,
  onSort,
  currentPage,
  totalPages,
  itemsPerPage,
  totalItems,
  onPageChange,
  onItemsPerPageChange,
  searchQuery = '',
  onClearSearch,
  onAddNew,
  canEdit: propCanEdit,
}) => {
  const navigate = useNavigate();
  const { canEdit: permCanEdit } = usePermissions();
  const canEdit = propCanEdit ?? permCanEdit;
  const [viewMode, setViewMode] = useState<'cards' | 'table' | 'auto'>('auto');

  // Column visibility state
  const [visibleColumns, setVisibleColumns] = useState<Record<string, boolean>>({
    photo: true,
    code: true,
    name: true,
    category: true,
    brandModel: true,
    stock: true,
    available: true,
    location: true,
    status: true,
    valuation: true,
    actions: true,
  });

  const [isColumnToggleOpen, setIsColumnToggleOpen] = useState(false);

  const isAllSelected = items.length > 0 && selectedIds.length === items.length;

  const toggleColumn = (key: string) => {
    setVisibleColumns((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="space-y-4">
      {/* Table Toolbar Header (Top Rows per page, Pagination, View Mode & Column Toggle) */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-2xs">
        {/* Left: Rows per page & Count */}
        <div className="flex flex-wrap items-center gap-2.5 text-xs text-slate-500 dark:text-slate-400">
          <span className="font-medium text-slate-700 dark:text-slate-300">Rows per page:</span>
          <select
            value={itemsPerPage}
            onChange={(e) => onItemsPerPageChange(Number(e.target.value))}
            className="px-2.5 py-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-semibold text-slate-800 dark:text-slate-200 shadow-2xs focus:outline-hidden focus:ring-2 focus:ring-blue-500/20"
          >
            <option value={10}>10</option>
            <option value={20}>20</option>
            <option value={50}>50</option>
            <option value={100}>100</option>
          </select>
          <span className="hidden sm:inline text-slate-300 dark:text-slate-700">|</span>
          <span className="hidden sm:inline">
            Showing <strong className="font-semibold text-slate-900 dark:text-white">{items.length}</strong> of{' '}
            <strong className="font-semibold text-slate-900 dark:text-white">{totalItems}</strong> assets
          </span>
        </div>

        {/* Right: Page Navigation, View Switcher & Column Options */}
        <div className="flex flex-wrap items-center justify-between sm:justify-end gap-3">
          {/* Top Page Numbers & Arrows */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500 dark:text-slate-400">
              Page <strong className="font-semibold text-slate-900 dark:text-white">{currentPage}</strong> of{' '}
              <strong className="font-semibold text-slate-900 dark:text-white">{totalPages}</strong>
            </span>

            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => onPageChange(currentPage - 1)}
                disabled={currentPage <= 1}
                className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors shadow-2xs"
                title="Previous Page"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => onPageChange(currentPage + 1)}
                disabled={currentPage >= totalPages}
                className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors shadow-2xs"
                title="Next Page"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="hidden sm:block h-4 w-px bg-slate-200 dark:bg-slate-800" />

          {/* Select All Checkbox for Mobile */}
          <button
            onClick={onToggleSelectAll}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-900 md:hidden shadow-2xs"
          >
            {isAllSelected ? (
              <CheckSquare className="w-4 h-4 text-blue-600" />
            ) : (
              <Square className="w-4 h-4 text-slate-400" />
            )}
            <span>Select All</span>
          </button>

          {/* View Mode Switcher (Cards / Table) */}
          <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-0.5 rounded-lg border border-slate-200 dark:border-slate-700">
            <button
              type="button"
              onClick={() => setViewMode('cards')}
              title="Card View"
              className={`p-1.5 rounded-md text-xs font-medium transition-all ${
                viewMode === 'cards' || viewMode === 'auto'
                  ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-2xs'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setViewMode('table')}
              title="Table Spreadsheet View"
              className={`p-1.5 rounded-md text-xs font-medium transition-all ${
                viewMode === 'table'
                  ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-2xs'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              <List className="w-4 h-4" />
            </button>
          </div>

          {/* Column Toggle (Desktop) */}
          <div className="relative hidden md:block">
            <Button
              variant="outline"
              size="sm"
              icon={<SlidersHorizontal className="w-3.5 h-3.5" />}
              onClick={() => setIsColumnToggleOpen(!isColumnToggleOpen)}
            >
              Columns
            </Button>

            {isColumnToggleOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xl z-30 p-2 text-xs space-y-1">
                <p className="font-semibold text-slate-400 text-[10px] uppercase px-2 py-1 border-b border-slate-100 dark:border-slate-800">
                  Toggle Table Columns
                </p>
                {[
                  { key: 'photo', label: 'Asset Photo' },
                  { key: 'code', label: 'Asset Code' },
                  { key: 'name', label: 'Item Name' },
                  { key: 'category', label: 'Category' },
                  { key: 'brandModel', label: 'Brand & Model' },
                  { key: 'stock', label: 'Total Stock' },
                  { key: 'available', label: 'Available Stock' },
                  { key: 'location', label: 'Storage Location' },
                  { key: 'status', label: 'Status Badge' },
                  { key: 'valuation', label: 'Valuation ($)' },
                ].map((col) => (
                  <button
                    key={col.key}
                    onClick={() => toggleColumn(col.key)}
                    className="w-full flex items-center justify-between px-2 py-1.5 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                  >
                    <span>{col.label}</span>
                    {visibleColumns[col.key] && <Check className="w-3.5 h-3.5 text-blue-600" />}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Empty State */}
      {items.length === 0 ? (
        <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
          <div className="flex flex-col items-center justify-center max-w-md mx-auto space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-400 dark:text-slate-500 shadow-inner">
              {searchQuery ? <SearchX className="w-6 h-6 text-amber-500" /> : <Package className="w-6 h-6 text-slate-400" />}
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                {searchQuery ? 'No items found' : 'No items in inventory'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {searchQuery ? (
                  <>
                    No assets match &ldquo;<span className="font-semibold text-slate-800 dark:text-slate-200">{searchQuery}</span>&rdquo;. Check for spelling errors or try broader keywords.
                  </>
                ) : (
                  'All previous items have been cleared. You can now add your own assets from scratch.'
                )}
              </p>
            </div>
            {searchQuery && onClearSearch && (
              <Button
                variant="outline"
                size="sm"
                icon={<X className="w-3.5 h-3.5" />}
                onClick={onClearSearch}
                className="mt-2 text-xs hover:bg-blue-50 dark:hover:bg-blue-950/40 hover:text-blue-600 border-dashed"
              >
                Clear search query
              </Button>
            )}
            {!searchQuery && onAddNew && canEdit && (
              <Button
                variant="primary"
                size="sm"
                icon={<Package className="w-3.5 h-3.5" />}
                onClick={onAddNew}
                className="mt-2 text-xs"
              >
                Add First Asset
              </Button>
            )}
          </div>
        </div>
      ) : (
        <>
          {/* MOBILE RESPONSIVE CARDS VIEW */}
          <div className={`${viewMode === 'table' ? 'hidden' : viewMode === 'cards' ? 'grid' : 'grid md:hidden'} grid-cols-1 sm:grid-cols-2 gap-3`}>
            {items.map((item) => {
              const isSelected = selectedIds.includes(item.id);
              const available = item.availableQuantity ?? item.quantity ?? 0;
              const total = item.quantity || 1;
              const stockPercent = Math.min(100, Math.round((available / total) * 100));

              return (
                <div
                  key={item.id}
                  className={`bg-white dark:bg-slate-900 border rounded-2xl p-4 shadow-xs space-y-3 transition-all ${
                    isSelected
                      ? 'border-blue-500 ring-2 ring-blue-500/20 bg-blue-50/20 dark:bg-blue-950/20'
                      : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                  }`}
                >
                  {/* Card Header */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3 min-w-0">
                      {/* Checkbox */}
                      <button
                        type="button"
                        onClick={() => onToggleSelectRow(item.id)}
                        className="mt-1 text-slate-400 hover:text-blue-600 transition-colors shrink-0"
                      >
                        {isSelected ? (
                          <CheckSquare className="w-5 h-5 text-blue-600" />
                        ) : (
                          <Square className="w-5 h-5" />
                        )}
                      </button>

                      {/* Photo */}
                      <div
                        onClick={() => onView(item)}
                        className="w-12 h-12 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 overflow-hidden cursor-pointer shrink-0 flex items-center justify-center shadow-2xs"
                      >
                        {item.photoUrl ? (
                          <img src={item.photoUrl} alt={item.name} className="w-full h-full object-cover" />
                        ) : (
                          <Package className="w-6 h-6 text-slate-400" />
                        )}
                      </div>

                      {/* Title & Code */}
                      <div className="min-w-0">
                        <button
                          type="button"
                          onClick={() => onView(item)}
                          className="font-bold text-sm text-slate-900 dark:text-slate-100 hover:text-blue-600 dark:hover:text-blue-400 text-left line-clamp-1 transition-colors"
                        >
                          {item.name}
                        </button>
                        <div className="flex items-center gap-1.5 text-xs text-slate-400 mt-0.5 flex-wrap">
                          {item.code ? (
                            <span className="font-mono font-bold text-blue-600 dark:text-blue-400">{item.code}</span>
                          ) : (
                            <span className="text-[10px] font-mono text-slate-400 bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded border border-slate-200 dark:border-slate-700 italic">
                              No MET Tag
                            </span>
                          )}
                          <span>•</span>
                          <span className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-[10px] font-semibold text-slate-700 dark:text-slate-300">
                            {item.category}
                          </span>
                        </div>
                      </div>
                    </div>

                    <StatusBadge status={item.status} />
                  </div>

                  {/* Stock & Location Specs */}
                  <div className="grid grid-cols-2 gap-2 bg-slate-50 dark:bg-slate-800/50 p-2.5 rounded-xl text-xs">
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-semibold block">Available Stock</span>
                      <div className="font-bold text-emerald-600 dark:text-emerald-400 text-sm">
                        {available} <span className="text-xs text-slate-500 font-normal">{item.unit || 'units'}</span>
                      </div>
                      <div className="text-[10px] text-slate-400">Total: {total} {item.unit}</div>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-semibold block">Location</span>
                      <div className="font-bold text-slate-800 dark:text-slate-200 truncate flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                        <span className="truncate">{item.location || 'Central Warehouse'}</span>
                      </div>
                      <div className="text-[10px] text-slate-400 truncate">
                        {item.rackNumber ? `Rack: ${item.rackNumber}` : 'Val: ' + formatCurrency(item.unitPrice || item.purchaseCost)}
                      </div>
                    </div>
                  </div>

                  {/* Mini Stock Progress Bar */}
                  <div className="w-full bg-slate-100 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full ${
                        stockPercent <= 20 ? 'bg-rose-500' : stockPercent <= 50 ? 'bg-amber-500' : 'bg-emerald-500'
                      }`}
                      style={{ width: `${stockPercent}%` }}
                    />
                  </div>

                  {/* Touch Action Bar */}
                  <div className="pt-1 flex items-center justify-between border-t border-slate-100 dark:border-slate-800 gap-1">
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => onView(item)}
                        className="px-2.5 py-1.5 rounded-lg bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 dark:hover:bg-blue-900/60 text-blue-700 dark:text-blue-300 font-bold text-xs flex items-center gap-1 transition-colors"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>View</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => navigate(`/issue?item=${item.id}`)}
                        className="px-2.5 py-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 font-bold text-xs flex items-center gap-1 transition-colors"
                      >
                        <ArrowUpRight className="w-3.5 h-3.5" />
                        <span>Issue</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => navigate(`/transfer?item=${item.id}`)}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-purple-600 hover:bg-purple-50 dark:hover:bg-slate-800 transition-colors"
                        title="Transfer"
                      >
                        <ArrowRightLeft className="w-4 h-4" />
                      </button>

                      <button
                        type="button"
                        onClick={() => onPrintQr(item)}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-sky-600 hover:bg-sky-50 dark:hover:bg-slate-800 transition-colors"
                        title="Print QR"
                      >
                        <QrCode className="w-4 h-4" />
                      </button>
                    </div>

                    {canEdit && (
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => onEdit(item)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-amber-600 hover:bg-amber-50 dark:hover:bg-slate-800 transition-colors"
                          title="Edit"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>

                        <button
                          type="button"
                          onClick={() => onDuplicate(item)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-slate-800 transition-colors"
                          title="Duplicate"
                        >
                          <Copy className="w-4 h-4" />
                        </button>

                        <button
                          type="button"
                          onClick={() => onDelete(item.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-slate-800 transition-colors"
                          title="Delete"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* DESKTOP SPREADSHEET TABLE VIEW */}
          <div className={`${viewMode === 'cards' ? 'hidden' : viewMode === 'table' ? 'block' : 'hidden md:block'} overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs bg-white dark:bg-slate-900`}>
            <Table>
              <TableHeader>
                <TableRow>
                  {/* Checkbox select all */}
                  <TableHead className="w-10 text-center">
                    <button
                      onClick={onToggleSelectAll}
                      className="text-slate-400 hover:text-blue-600 transition-colors"
                    >
                      {isAllSelected ? (
                        <CheckSquare className="w-4 h-4 text-blue-600" />
                      ) : (
                        <Square className="w-4 h-4" />
                      )}
                    </button>
                  </TableHead>

                  {visibleColumns.photo && <TableHead className="w-14">Photo</TableHead>}

                  {visibleColumns.code && (
                    <TableHead>
                      <button
                        onClick={() => onSort('code')}
                        className="flex items-center gap-1 font-bold text-slate-700 dark:text-slate-300 hover:text-blue-600"
                      >
                        <span>Asset Code</span>
                        <ArrowUpDown className="w-3 h-3 text-slate-400" />
                      </button>
                    </TableHead>
                  )}

                  {visibleColumns.name && (
                    <TableHead>
                      <button
                        onClick={() => onSort('name')}
                        className="flex items-center gap-1 font-bold text-slate-700 dark:text-slate-300 hover:text-blue-600"
                      >
                        <span>Item Name</span>
                        <ArrowUpDown className="w-3 h-3 text-slate-400" />
                      </button>
                    </TableHead>
                  )}

                  {visibleColumns.category && <TableHead>Category</TableHead>}
                  {visibleColumns.brandModel && <TableHead>Brand & Model / Tag</TableHead>}

                  {visibleColumns.stock && (
                    <TableHead className="text-right">
                      <button
                        onClick={() => onSort('quantity')}
                        className="flex items-center justify-end gap-1 font-bold text-slate-700 dark:text-slate-300 hover:text-blue-600 ml-auto"
                      >
                        <span>Total Qty</span>
                        <ArrowUpDown className="w-3 h-3 text-slate-400" />
                      </button>
                    </TableHead>
                  )}

                  {visibleColumns.available && (
                    <TableHead className="text-right">
                      <button
                        onClick={() => onSort('availableQuantity')}
                        className="flex items-center justify-end gap-1 font-bold text-slate-700 dark:text-slate-300 hover:text-blue-600 ml-auto"
                      >
                        <span>Available</span>
                        <ArrowUpDown className="w-3 h-3 text-slate-400" />
                      </button>
                    </TableHead>
                  )}

                  {visibleColumns.location && <TableHead>Location</TableHead>}
                  {visibleColumns.status && <TableHead>Status</TableHead>}

                  {visibleColumns.valuation && (
                    <TableHead className="text-right">
                      <button
                        onClick={() => onSort('unitPrice')}
                        className="flex items-center justify-end gap-1 font-bold text-slate-700 dark:text-slate-300 hover:text-blue-600 ml-auto"
                      >
                        <span>Unit Cost</span>
                        <ArrowUpDown className="w-3 h-3 text-slate-400" />
                      </button>
                    </TableHead>
                  )}

                  {visibleColumns.actions && <TableHead className="text-right pr-4">Actions</TableHead>}
                </TableRow>
              </TableHeader>

              <TableBody>
                {items.map((item) => {
                  const isSelected = selectedIds.includes(item.id);
                  return (
                    <TableRow
                      key={item.id}
                      className={`hover:bg-slate-50/80 dark:hover:bg-slate-800/50 transition-colors ${
                        isSelected ? 'bg-blue-50/50 dark:bg-blue-950/30' : ''
                      }`}
                    >
                      {/* Checkbox */}
                      <TableCell className="text-center">
                        <button
                          onClick={() => onToggleSelectRow(item.id)}
                          className="text-slate-400 hover:text-blue-600 transition-colors"
                        >
                          {isSelected ? (
                            <CheckSquare className="w-4 h-4 text-blue-600" />
                          ) : (
                            <Square className="w-4 h-4" />
                          )}
                        </button>
                      </TableCell>

                      {/* Photo thumbnail */}
                      {visibleColumns.photo && (
                        <TableCell>
                          <div
                            onClick={() => onView(item)}
                            className="w-10 h-10 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 overflow-hidden cursor-pointer shrink-0 flex items-center justify-center hover:opacity-80 transition-opacity"
                          >
                            {item.photoUrl ? (
                              <img src={item.photoUrl} alt={item.name} className="w-full h-full object-cover" />
                            ) : (
                              <Package className="w-5 h-5 text-slate-400" />
                            )}
                          </div>
                        </TableCell>
                      )}

                      {/* Asset Code */}
                      {visibleColumns.code && (
                        <TableCell>
                          {item.code ? (
                            <button
                              onClick={() => onView(item)}
                              className="font-mono text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline"
                            >
                              {item.code}
                            </button>
                          ) : (
                            <span className="text-[10px] font-mono text-slate-400 bg-slate-100 dark:bg-slate-800/80 px-1.5 py-0.5 rounded border border-slate-200 dark:border-slate-700/60 italic" title="No MET Tag (Optional for consumables/bulk)">
                              No MET Tag
                            </span>
                          )}
                          {item.serialNumber && (
                            <div className="text-[10px] text-slate-400 font-mono">SN: {item.serialNumber}</div>
                          )}
                        </TableCell>
                      )}

                      {/* Item Name */}
                      {visibleColumns.name && (
                        <TableCell>
                          <div
                            onClick={() => onView(item)}
                            className="font-bold text-slate-900 dark:text-slate-100 text-xs cursor-pointer hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                          >
                            {item.name}
                          </div>
                          {item.description && (
                            <div className="text-[11px] text-slate-500 line-clamp-1 max-w-[200px]">
                              {item.description}
                            </div>
                          )}
                        </TableCell>
                      )}

                      {/* Category */}
                      {visibleColumns.category && (
                        <TableCell>
                          <span className="inline-flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                            {item.category}
                          </span>
                        </TableCell>
                      )}

                      {/* Brand & Model */}
                      {visibleColumns.brandModel && (
                        <TableCell>
                          <div className="text-xs font-medium text-slate-800 dark:text-slate-200">
                            {item.brand || (item as any).manufacturer || 'Standard'}
                          </div>
                          <div className="text-[10px] text-slate-500">
                            {item.model || (item as any).materialGrade || 'N/A'}
                          </div>
                        </TableCell>
                      )}

                      {/* Total Stock */}
                      {visibleColumns.stock && (
                        <TableCell className="text-right">
                          <strong className="font-semibold text-slate-900 dark:text-slate-100">
                            {item.quantity}
                          </strong>{' '}
                          <span className="text-[11px] text-slate-500">{item.unit}</span>
                        </TableCell>
                      )}

                      {/* Available Stock */}
                      {visibleColumns.available && (
                        <TableCell className="text-right">
                          <strong className="font-semibold text-emerald-600 dark:text-emerald-400">
                            {item.availableQuantity}
                          </strong>{' '}
                          <span className="text-[11px] text-slate-500">{item.unit}</span>
                        </TableCell>
                      )}

                      {/* Location */}
                      {visibleColumns.location && (
                        <TableCell>
                          <div className="text-xs font-medium text-slate-700 dark:text-slate-300">
                            {item.location}
                          </div>
                          {item.rackNumber && (
                            <div className="text-[10px] text-slate-400">Rack: {item.rackNumber}</div>
                          )}
                        </TableCell>
                      )}

                      {/* Status Badge */}
                      {visibleColumns.status && (
                        <TableCell>
                          <StatusBadge status={item.status} />
                        </TableCell>
                      )}

                      {/* Valuation */}
                      {visibleColumns.valuation && (
                        <TableCell className="text-right font-mono text-xs">
                          {formatCurrency(item.unitPrice || item.purchaseCost)}
                        </TableCell>
                      )}

                      {/* Action Buttons */}
                      {visibleColumns.actions && (
                        <TableCell className="text-right pr-4">
                          <div className="flex items-center justify-end gap-1">
                            {/* View Item */}
                            <button
                              onClick={() => onView(item)}
                              className="p-1.5 rounded-lg text-slate-500 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950/50 transition-colors"
                              title="View Item Details"
                            >
                              <Eye className="w-4 h-4" />
                            </button>

                            {/* Quick Issue */}
                            <button
                              onClick={() => navigate(`/issue?item=${item.id}`)}
                              className="p-1.5 rounded-lg text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/50 transition-colors"
                              title="Issue Item to Worker"
                            >
                              <ArrowUpRight className="w-4 h-4" />
                            </button>

                            {/* Quick Transfer */}
                            <button
                              onClick={() => navigate(`/transfer?item=${item.id}`)}
                              className="p-1.5 rounded-lg text-slate-500 hover:text-purple-600 hover:bg-purple-50 dark:hover:bg-purple-950/50 transition-colors"
                              title="Transfer Item Location"
                            >
                              <ArrowRightLeft className="w-4 h-4" />
                            </button>

                            {/* Print Tag / QR */}
                            <button
                              onClick={() => onPrintQr(item)}
                              className="p-1.5 rounded-lg text-slate-500 hover:text-sky-600 hover:bg-sky-50 dark:hover:bg-sky-950/50 transition-colors"
                              title="Print Barcode / QR Label"
                            >
                              <QrCode className="w-4 h-4" />
                            </button>

                            {/* Edit, Duplicate, and Delete Actions - Admin & Super Admin Only */}
                            {canEdit && (
                              <>
                                <button
                                  onClick={() => onEdit(item)}
                                  className="p-1.5 rounded-lg text-slate-500 hover:text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-950/50 transition-colors"
                                  title="Edit Asset Record"
                                >
                                  <Edit2 className="w-4 h-4" />
                                </button>

                                <button
                                  onClick={() => onDuplicate(item)}
                                  className="p-1.5 rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/50 transition-colors"
                                  title="Duplicate Asset"
                                >
                                  <Copy className="w-4 h-4" />
                                </button>

                                <button
                                  onClick={() => onDelete(item.id)}
                                  className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/50 transition-colors"
                                  title="Archive / Delete Asset"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </>
                            )}
                          </div>
                        </TableCell>
                      )}
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </>
      )}

      {/* Pagination Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
        <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
          <span>Rows per page:</span>
          <select
            value={itemsPerPage}
            onChange={(e) => onItemsPerPageChange(Number(e.target.value))}
            className="px-2 py-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-md text-xs font-medium"
          >
            <option value={10}>10</option>
            <option value={20}>20</option>
            <option value={50}>50</option>
            <option value={100}>100</option>
          </select>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500 dark:text-slate-400">
            Page <strong className="font-semibold text-slate-900 dark:text-white">{currentPage}</strong> of{' '}
            <strong className="font-semibold text-slate-900 dark:text-white">{totalPages}</strong>
          </span>

          <div className="flex items-center gap-1">
            <button
              onClick={() => onPageChange(currentPage - 1)}
              disabled={currentPage <= 1}
              className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => onPageChange(currentPage + 1)}
              disabled={currentPage >= totalPages}
              className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
