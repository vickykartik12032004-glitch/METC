import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { METCItem, AssetCategory, AssetStatus } from '../../../types';
import { Button } from '../../ui/Button';
import { 
  Package, 
  HardHat, 
  Wrench, 
  Fuel, 
  ShieldCheck, 
  Upload, 
  Image as ImageIcon, 
  X, 
  Calendar, 
  Building2, 
  Barcode, 
  QrCode, 
  DollarSign, 
  AlertCircle,
  Cloud,
  CheckCircle
} from 'lucide-react';

import { useAssetStore } from '../../../store/useAssetStore';
import { getNextMetNumber, isMetNumberRecommended } from '../../../utils/metAssetNumber';

const itemSchema = z.object({
  name: z.string().min(2, 'Item name must be at least 2 characters'),
  category: z.enum(['Material', 'Equipment', 'Tool', 'Consumable', 'PPE']),
  code: z.string().optional(),
  description: z.string().optional(),
  brand: z.string().optional(),
  model: z.string().optional(),
  serialNumber: z.string().optional(),
  assetNumber: z.string().optional(),
  barcode: z.string().optional(),
  qrCode: z.string().optional(),
  unit: z.string().min(1, 'Unit of measurement is required'),
  quantity: z.number().min(0, 'Quantity cannot be negative'),
  minQuantityThreshold: z.number().min(0, 'Min threshold cannot be negative'),
  maximumStock: z.number().min(1, 'Max stock must be at least 1'),
  unitPrice: z.number().min(0, 'Unit price cannot be negative'),
  supplier: z.string().optional(),
  purchaseDate: z.string().optional(),
  warrantyExpiry: z.string().optional(),
  calibrationDue: z.string().optional(),
  location: z.string().min(2, 'Storage location is required'),
  rackNumber: z.string().optional(),
  status: z.enum([
    'Available', 
    'Issued', 
    'In Transit', 
    'Under Repair', 
    'Lost', 
    'Low Stock', 
    'Out of Stock', 
    'Decommissioned', 
    'Repair', 
    'Disposed', 
    'Inactive'
  ]),
  photoUrl: z.string().optional(),
  remarks: z.string().optional(),
});

type ItemFormValues = z.infer<typeof itemSchema>;

interface ItemFormProps {
  initialData?: METCItem | null;
  defaultCategory?: AssetCategory;
  onSubmit: (data: ItemFormValues) => void | Promise<void>;
  onCancel: () => void;
}

export const ItemForm: React.FC<ItemFormProps> = ({
  initialData,
  defaultCategory = 'Material',
  onSubmit,
  onCancel,
}) => {
  const allAssets = useAssetStore((s) => s.getAllAssets());
  const isEditing = !!initialData?.id;

  // Determine initial state of MET number option:
  // If item already has a code or assetNumber, enable it.
  // If brand new item, Equipment & Tools recommend MET tag by default, while Consumables & Materials default to optional/none.
  const [hasMetNumber, setHasMetNumber] = useState<boolean>(() => {
    if (initialData?.code || initialData?.assetNumber) return true;
    if (isEditing) return false;
    return isMetNumberRecommended(defaultCategory);
  });

  const [photoPreview, setPhotoPreview] = useState<string>(
    initialData?.photoUrl || initialData?.id ? `https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=400&q=80` : ''
  );

  // For new items, start with "MET - 1" as requested by user ("uska asset number MET - 1 Se suru hona chahiye")
  const defaultStartingMet = 'MET - 1';
  const calculatedNextMet = getNextMetNumber(allAssets, false, true);
  const initialCode = initialData?.code 
    ? initialData.code 
    : (hasMetNumber ? (isEditing ? calculatedNextMet : defaultStartingMet) : '');

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors, isSubmitting },
  } = useForm<ItemFormValues>({
    resolver: zodResolver(itemSchema) as any,
    defaultValues: {
      name: initialData?.name || '',
      category: initialData?.category || defaultCategory,
      code: initialCode,
      description: initialData?.description || '',
      brand: initialData?.brand || (initialData as any)?.manufacturer || '',
      model: initialData?.model || (initialData as any)?.materialGrade || '',
      serialNumber: initialData?.serialNumber || (initialData as any)?.batchNumber || '',
      assetNumber: initialData?.assetNumber || (hasMetNumber ? initialCode : ''),
      barcode: initialData?.barcode || (initialCode ? `BC-${initialCode.replace(/\s+/g, '')}` : ''),
      qrCode: initialData?.qrCode || (initialCode ? `QR-${initialCode.replace(/\s+/g, '')}` : ''),
      unit: initialData?.unit || 'Units',
      quantity: initialData?.quantity ?? 100,
      minQuantityThreshold: initialData?.minQuantityThreshold ?? initialData?.minimumStock ?? 10,
      maximumStock: initialData?.maximumStock ?? 1000,
      unitPrice: initialData?.unitPrice ?? initialData?.purchaseCost ?? 0,
      supplier: initialData?.supplier || '',
      purchaseDate: initialData?.purchaseDate || new Date().toISOString().split('T')[0],
      warrantyExpiry: initialData?.warrantyExpiry || '',
      calibrationDue: initialData?.calibrationDue || '',
      location: initialData?.location || 'Warehouse A - Bay 1',
      rackNumber: initialData?.rackNumber || '',
      status: initialData?.status || 'Available',
      photoUrl: initialData?.photoUrl || '',
      remarks: initialData?.remarks || '',
    },
  });

  const handleFormSubmit = async (values: ItemFormValues) => {
    try {
      const codeVal = hasMetNumber ? (values.code?.trim() || '') : '';
      const assetNumVal = hasMetNumber ? (values.assetNumber?.trim() || codeVal || '') : '';
      const cleanValues = {
        ...values,
        code: codeVal,
        assetNumber: assetNumVal,
      };
      await onSubmit(cleanValues as any);
    } catch (err) {
      console.error('[ItemForm] Submit failed:', err);
    }
  };

  const selectedCategory = watch('category');

  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setPhotoPreview(result);
        setValue('photoUrl', result);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-6 text-slate-900 dark:text-slate-100">
      {/* Category Selection Pills */}
      <div>
        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
          Asset Category <span className="text-rose-500">*</span>
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
          {[
            { id: 'Material', label: 'Material', icon: Package, color: 'text-blue-500' },
            { id: 'Equipment', label: 'Equipment', icon: HardHat, color: 'text-amber-500' },
            { id: 'Tool', label: 'Tool', icon: Wrench, color: 'text-emerald-500' },
            { id: 'Consumable', label: 'Consumable', icon: Fuel, color: 'text-purple-500' },
            { id: 'PPE', label: 'PPE Safety', icon: ShieldCheck, color: 'text-rose-500' },
          ].map((cat) => {
            const Icon = cat.icon;
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => {
                  setValue('category', cat.id as AssetCategory);
                  if (!isEditing && !initialData?.code) {
                    if (cat.id === 'Equipment' || cat.id === 'Tool') {
                      if (!hasMetNumber) {
                        setHasMetNumber(true);
                        setValue('code', 'MET - 1');
                        setValue('assetNumber', 'MET - 1');
                      }
                    }
                  }
                }}
                className={`flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl text-xs font-medium border transition-all ${
                  isSelected
                    ? 'bg-blue-600 text-white border-blue-600 shadow-sm font-semibold'
                    : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700/60 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <Icon className={`w-4 h-4 ${isSelected ? 'text-white' : cat.color}`} />
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* MET Asset Number (Option) - Starts from MET - 1 and is optional for items like consumables */}
      <div className={`p-4 rounded-xl border transition-all ${
        hasMetNumber 
          ? 'bg-blue-50/70 dark:bg-blue-950/30 border-blue-200 dark:border-blue-900/60 shadow-xs' 
          : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800'
      }`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <label className="flex items-start sm:items-center gap-2.5 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={hasMetNumber}
              onChange={(e) => {
                const checked = e.target.checked;
                setHasMetNumber(checked);
                if (checked) {
                  const startCode = 'MET - 1';
                  setValue('code', startCode);
                  setValue('assetNumber', startCode);
                } else {
                  setValue('code', '');
                  setValue('assetNumber', '');
                }
              }}
              className="w-4 h-4 mt-0.5 sm:mt-0 text-blue-600 rounded border-slate-300 dark:border-slate-700 focus:ring-blue-500 shrink-0"
            />
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-bold text-slate-800 dark:text-slate-100">
                  Assign MET Asset Number
                </span>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-900/70 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
                  Option (Optional)
                </span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                Asset Number starts from <strong className="font-mono text-blue-600 dark:text-blue-400">MET - 1</strong>. MET Number option me hai — uncheck this for items where MET number is not required (e.g. bulk consumables, materials, cement, screws, fuel).
              </p>
            </div>
          </label>

          {hasMetNumber && (
            <div className="flex items-center gap-1.5 shrink-0 self-start sm:self-center">
              <button
                type="button"
                onClick={() => {
                  setValue('code', 'MET - 1');
                  setValue('assetNumber', 'MET - 1');
                }}
                className="text-[11px] font-mono font-bold px-2.5 py-1 rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition-colors shadow-2xs cursor-pointer"
                title="Start from MET - 1"
              >
                Set MET - 1
              </button>
              <button
                type="button"
                onClick={() => {
                  setValue('code', 'MET-1');
                  setValue('assetNumber', 'MET-1');
                }}
                className="text-[11px] font-mono font-medium px-2 py-1 rounded-lg bg-blue-100 text-blue-800 dark:bg-blue-900/60 dark:text-blue-200 hover:bg-blue-200 transition-colors cursor-pointer"
                title="Set compact MET-1"
              >
                MET-1
              </button>
              <button
                type="button"
                onClick={() => {
                  const nextNum = getNextMetNumber(allAssets, false, true);
                  setValue('code', nextNum);
                  setValue('assetNumber', nextNum);
                }}
                className="text-[11px] font-mono font-medium px-2.5 py-1 rounded-lg bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-200 transition-colors cursor-pointer"
                title="Calculate next sequential MET number based on highest existing asset"
              >
                Auto Next MET#
              </button>
            </div>
          )}
        </div>

        {hasMetNumber ? (
          <div className="mt-3 pt-3 border-t border-blue-100 dark:border-blue-900/40 grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-blue-900 dark:text-blue-200 mb-1">
                MET Asset Number / Code
              </label>
              <input
                type="text"
                placeholder="e.g. MET-1"
                {...register('code')}
                className="w-full px-3 py-2 text-xs font-mono font-bold bg-white dark:bg-slate-900 border border-blue-300 dark:border-blue-700 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-blue-700 dark:text-blue-300 tracking-wide"
              />
              <p className="text-[10px] text-slate-500 mt-0.5">Primary identifier in MOUNTEC inventory.</p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-blue-900 dark:text-blue-200 mb-1">
                Physical Asset Tag / Sticker Reference
              </label>
              <input
                type="text"
                placeholder="e.g. MET-1"
                {...register('assetNumber')}
                className="w-full px-3 py-2 text-xs font-mono bg-white dark:bg-slate-900 border border-blue-300 dark:border-blue-700 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-slate-900 dark:text-slate-100"
              />
              <p className="text-[10px] text-slate-500 mt-0.5">Physical label affixed to equipment or tool.</p>
            </div>
          </div>
        ) : (
          <div className="mt-2.5 p-2.5 rounded-lg bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/60 flex items-center justify-between text-xs text-slate-600 dark:text-slate-300">
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-slate-400"></span>
              No MET Number required for this item. Item will be cataloged by name and category without a MET tag.
            </span>
            <button
              type="button"
              onClick={() => {
                setHasMetNumber(true);
                const nextCode = getNextMetNumber(allAssets);
                setValue('code', nextCode);
                setValue('assetNumber', nextCode);
              }}
              className="text-xs font-bold text-blue-600 hover:text-blue-700 dark:text-blue-400 hover:underline shrink-0 ml-2"
            >
              + Enable MET Number
            </button>
          </div>
        )}
      </div>

      {/* Primary Details Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Item Name */}
        <div className="sm:col-span-3">
          <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
            Item Name <span className="text-rose-500">*</span>
          </label>
          <input
            type="text"
            placeholder="e.g. Caterpillar 320 Hydraulic Excavator / Portland Cement Grade 53"
            {...register('name')}
            className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-slate-900 dark:text-slate-100"
          />
          {errors.name && <p className="text-[11px] text-rose-500 mt-1">{errors.name.message}</p>}
        </div>

        {/* Brand / Manufacturer */}
        <div>
          <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Brand / Manufacturer</label>
          <input
            type="text"
            placeholder="Bosch / Caterpillar / Lafarge"
            {...register('brand')}
            className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-slate-900 dark:text-slate-100"
          />
        </div>

        {/* Model / Grade */}
        <div>
          <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Model / Specification Grade</label>
          <input
            type="text"
            placeholder="320 Hydraulic / Fe500D / PPC 53"
            {...register('model')}
            className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-slate-900 dark:text-slate-100"
          />
        </div>

        {/* Serial Number */}
        <div>
          <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Serial / Batch Number</label>
          <input
            type="text"
            placeholder="SN-9988231 / BATCH-2025"
            {...register('serialNumber')}
            className="w-full px-3 py-2 text-xs font-mono bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-slate-900 dark:text-slate-100"
          />
        </div>

        {/* Barcode */}
        <div>
          <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Barcode Value</label>
          <div className="relative">
            <Barcode className="w-4 h-4 text-slate-400 absolute left-2.5 top-2.5" />
            <input
              type="text"
              placeholder="BC-1002938"
              {...register('barcode')}
              className="w-full pl-8 pr-3 py-2 text-xs font-mono bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-slate-900 dark:text-slate-100"
            />
          </div>
        </div>

        {/* QR Code */}
        <div>
          <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">QR Code Data</label>
          <div className="relative">
            <QrCode className="w-4 h-4 text-slate-400 absolute left-2.5 top-2.5" />
            <input
              type="text"
              placeholder="QR-1002938"
              {...register('qrCode')}
              className="w-full pl-8 pr-3 py-2 text-xs font-mono bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-slate-900 dark:text-slate-100"
            />
          </div>
        </div>
      </div>

      {/* Stock & Measurement Section */}
      <div className="bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 rounded-xl p-4 space-y-4">
        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
          Stock Levels & Valuation
        </h4>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {/* Quantity */}
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Total Quantity <span className="text-rose-500">*</span>
            </label>
            <input
              type="number"
              min="0"
              {...register('quantity', { valueAsNumber: true })}
              className="w-full px-3 py-2 text-xs font-semibold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-slate-900 dark:text-slate-100"
            />
            {errors.quantity && <p className="text-[11px] text-rose-500 mt-1">{errors.quantity.message}</p>}
          </div>

          {/* Unit of measure */}
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Unit <span className="text-rose-500">*</span>
            </label>
            <select
              {...register('unit')}
              className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-slate-900 dark:text-slate-100"
            >
              <option value="Units">Units</option>
              <option value="Bags (50kg)">Bags (50kg)</option>
              <option value="Tons">Tons</option>
              <option value="Sets">Sets</option>
              <option value="Pairs">Pairs</option>
              <option value="Boxes">Boxes</option>
              <option value="Meters">Meters</option>
              <option value="Pcs">Pcs</option>
              <option value="Cubic Meters">Cubic Meters</option>
              <option value="Liters">Liters</option>
            </select>
          </div>

          {/* Min Stock Threshold */}
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Min Stock Alert
            </label>
            <input
              type="number"
              min="0"
              {...register('minQuantityThreshold', { valueAsNumber: true })}
              className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-slate-900 dark:text-slate-100"
            />
          </div>

          {/* Unit Cost */}
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Unit Cost ($)
            </label>
            <input
              type="number"
              step="0.01"
              min="0"
              {...register('unitPrice', { valueAsNumber: true })}
              className="w-full px-3 py-2 text-xs font-semibold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-slate-900 dark:text-slate-100"
            />
          </div>
        </div>
      </div>

      {/* Location, Supplier & Maintenance Dates */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Storage Location */}
        <div>
          <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
            Storage Location / Site <span className="text-rose-500">*</span>
          </label>
          <input
            type="text"
            placeholder="Warehouse A - Bay 1"
            {...register('location')}
            className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-slate-900 dark:text-slate-100"
          />
          {errors.location && <p className="text-[11px] text-rose-500 mt-1">{errors.location.message}</p>}
        </div>

        {/* Rack Number */}
        <div>
          <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Rack / Locker Number</label>
          <input
            type="text"
            placeholder="Rack 4 - Shelf B"
            {...register('rackNumber')}
            className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-slate-900 dark:text-slate-100"
          />
        </div>

        {/* Status */}
        <div>
          <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
            Current Status
          </label>
          <select
            {...register('status')}
            className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-slate-900 dark:text-slate-100"
          >
            <option value="Available">Available</option>
            <option value="Issued">Issued</option>
            <option value="Under Repair">Under Repair</option>
            <option value="Lost">Lost</option>
            <option value="Low Stock">Low Stock</option>
            <option value="Out of Stock">Out of Stock</option>
            <option value="Inactive">Inactive</option>
            <option value="Disposed">Disposed</option>
          </select>
        </div>

        {/* Supplier */}
        <div>
          <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Supplier Name</label>
          <input
            type="text"
            placeholder="LafargeHolcim / Caterpillar / 3M"
            {...register('supplier')}
            className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-slate-900 dark:text-slate-100"
          />
        </div>

        {/* Warranty Expiry */}
        <div>
          <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Warranty Expiry Date</label>
          <input
            type="date"
            {...register('warrantyExpiry')}
            className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-slate-900 dark:text-slate-100"
          />
        </div>

        {/* Calibration Due */}
        <div>
          <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Calibration / Safety Inspection Due</label>
          <input
            type="date"
            {...register('calibrationDue')}
            className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-slate-900 dark:text-slate-100"
          />
        </div>
      </div>

      {/* Photo Attachment Section */}
      <div>
        <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">Asset Photo</label>
        <div className="flex items-center gap-4">
          <div className="w-20 h-20 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center overflow-hidden shrink-0 relative">
            {photoPreview ? (
              <img src={photoPreview} alt="Asset Preview" className="w-full h-full object-cover" />
            ) : (
              <ImageIcon className="w-8 h-8 text-slate-400" />
            )}
          </div>
          <div className="space-y-1">
            <label className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 text-xs font-medium cursor-pointer hover:bg-blue-100 dark:hover:bg-blue-900/60 transition-colors">
              <Upload className="w-3.5 h-3.5" />
              <span>Upload Image File</span>
              <input type="file" accept="image/*" onChange={handleImageFileChange} className="hidden" />
            </label>
            <p className="text-[10px] text-slate-500 dark:text-slate-400">Supported formats: JPG, PNG, WEBP (Max 5MB)</p>
          </div>
        </div>
      </div>

      {/* Description & Remarks */}
      <div>
        <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Item Description & Remarks</label>
        <textarea
          rows={3}
          placeholder="Detailed specs, safety precautions, storage guidelines..."
          {...register('description')}
          className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-slate-900 dark:text-slate-100"
        />
      </div>

      {/* Form Buttons */}
      <div className="flex items-center justify-between pt-4 border-t border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400">
          <Cloud className="w-3.5 h-3.5 text-blue-500" />
          <span>Real-time Cloud & Firestore persistence enabled</span>
        </div>
        <div className="flex items-center gap-3">
          <Button type="button" variant="outline" size="sm" onClick={onCancel} disabled={isSubmitting}>
            Cancel
          </Button>
          <Button 
            id="save-asset-submit-btn"
            type="submit" 
            variant="primary" 
            size="sm" 
            isLoading={isSubmitting}
            disabled={isSubmitting}
            icon={<Cloud className="w-4 h-4" />}
          >
            {isSubmitting ? 'Saving to Database...' : initialData ? 'Save Changes' : 'Save & Sync to All Devices'}
          </Button>
        </div>
      </div>
    </form>
  );
};
