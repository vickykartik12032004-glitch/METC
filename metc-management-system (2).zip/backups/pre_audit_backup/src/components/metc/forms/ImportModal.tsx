import React, { useState } from 'react';
import * as XLSX from 'xlsx';
import { Button } from '../../ui/Button';
import { Modal } from '../../ui/Modal';
import { AssetCategory } from '../../../types';
import { Upload, FileSpreadsheet, CheckCircle, AlertTriangle, X, Download } from 'lucide-react';
import { toast } from 'sonner';

interface ImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImportData: (importedItems: any[]) => void;
}

export const ImportModal: React.FC<ImportModalProps> = ({ isOpen, onClose, onImportData }) => {
  const [fileName, setFileName] = useState<string>('');
  const [parsedData, setParsedData] = useState<any[]>([]);
  const [isValidating, setIsValidating] = useState<boolean>(false);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    setIsValidating(true);

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        const data = XLSX.utils.sheet_to_json(ws);

        if (!data || data.length === 0) {
          toast.error('The uploaded file contains no data rows');
          setParsedData([]);
          return;
        }

        // Map columns gracefully
        const mapped = data.map((row: any, index: number) => {
          const name = row['Item Name'] || row['Name'] || row['item_name'] || `Imported Item ${index + 1}`;
          const categoryRaw = row['Category'] || row['category'] || 'Material';
          let category: AssetCategory = 'Material';
          if (['Equipment', 'Tool', 'Consumable', 'PPE'].includes(categoryRaw)) {
            category = categoryRaw as AssetCategory;
          }

          const quantity = Number(row['Quantity'] || row['quantity'] || row['Stock'] || 10);
          const unit = row['Unit'] || row['unit'] || 'Units';
          const code = row['Code'] || row['Asset ID'] || row['asset_id'] || `${category.slice(0, 3).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`;
          const unitPrice = Number(row['Unit Price'] || row['Price'] || row['purchase_cost'] || 0);
          const location = row['Location'] || row['Storage'] || row['storage_location'] || 'Main Store';
          const brand = row['Brand'] || row['Manufacturer'] || '';
          const supplier = row['Supplier'] || '';

          return {
            name,
            category,
            code,
            quantity,
            availableQuantity: quantity,
            unit,
            unitPrice,
            minQuantityThreshold: Number(row['Min Threshold'] || 10),
            location,
            brand,
            supplier,
            status: quantity > 0 ? 'Available' : 'Out of Stock',
          };
        });

        setParsedData(mapped);
        toast.success(`Successfully parsed ${mapped.length} items from ${file.name}`);
      } catch (err: any) {
        toast.error('Failed to parse file: ' + err.message);
      } finally {
        setIsValidating(false);
      }
    };

    reader.readAsBinaryString(file);
  };

  const handleDownloadSample = () => {
    const sampleData = [
      {
        'Asset ID': 'MAT-901',
        'Item Name': 'High Tensile Structural Bolts M20',
        'Category': 'Material',
        'Quantity': 500,
        'Unit': 'Pcs',
        'Unit Price': 4.50,
        'Min Threshold': 50,
        'Location': 'Warehouse B - Bin 12',
        'Brand': 'Fastenal',
        'Supplier': 'MOUNTEC Fasteners Corp',
      },
      {
        'Asset ID': 'EQP-902',
        'Item Name': 'Generac 50kW Diesel Standby Generator',
        'Category': 'Equipment',
        'Quantity': 2,
        'Unit': 'Units',
        'Unit Price': 12500,
        'Min Threshold': 1,
        'Location': 'Power Yard Site 1',
        'Brand': 'Generac',
        'Supplier': 'Generac Power Systems',
      },
      {
        'Asset ID': 'PPE-903',
        'Item Name': 'ANSI Z87.1 Clear Safety Spectacles',
        'Category': 'PPE',
        'Quantity': 150,
        'Unit': 'Pairs',
        'Unit Price': 8.00,
        'Min Threshold': 30,
        'Location': 'Safety Locker 1',
        'Brand': '3M',
        'Supplier': '3M Industrial Safety',
      }
    ];

    const ws = XLSX.utils.json_to_sheet(sampleData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sample_METC_Import');
    XLSX.writeFile(wb, 'METC_Inventory_Import_Template.xlsx');
  };

  const handleConfirmImport = () => {
    if (parsedData.length === 0) return;
    onImportData(parsedData);
    toast.success(`Successfully imported ${parsedData.length} inventory items!`);
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Bulk Excel / CSV Inventory Import" size="lg">
      <div className="space-y-5 text-slate-900 dark:text-slate-100">
        {/* Helper Banner */}
        <div className="p-3.5 bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800/80 rounded-xl flex items-start gap-3">
          <FileSpreadsheet className="w-5 h-5 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
          <div className="text-xs text-blue-900 dark:text-blue-200 space-y-1">
            <p className="font-semibold">Import Guidelines</p>
            <p className="text-blue-700 dark:text-blue-300">
              Upload an Excel (.xlsx, .xls) or CSV file containing your inventory items. Use the sample template for exact column mapping.
            </p>
            <button
              onClick={handleDownloadSample}
              className="inline-flex items-center gap-1.5 text-[11px] font-bold text-blue-600 dark:text-blue-400 hover:underline mt-1"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Excel Import Template</span>
            </button>
          </div>
        </div>

        {/* File Dropzone */}
        <div className="border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-xl p-6 text-center hover:border-blue-500 transition-colors">
          <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
          <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">
            Click or drag Excel/CSV file here
          </p>
          <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-1">
            Supports .xlsx, .xls, .csv files up to 10MB
          </p>
          <label className="mt-3 inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-600 text-white text-xs font-semibold cursor-pointer hover:bg-blue-700 transition-colors">
            <span>Browse Files</span>
            <input type="file" accept=".xlsx,.xls,.csv" onChange={handleFileUpload} className="hidden" />
          </label>
          {fileName && (
            <p className="text-xs font-mono font-medium text-emerald-600 dark:text-emerald-400 mt-3">
              Selected File: {fileName}
            </p>
          )}
        </div>

        {/* Data Preview Table */}
        {parsedData.length > 0 && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
              <span>Preview Parsed Items ({parsedData.length})</span>
              <span className="text-[11px] font-normal text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                <CheckCircle className="w-3.5 h-3.5" /> Ready for Import
              </span>
            </div>
            <div className="max-h-56 overflow-y-auto border border-slate-200 dark:border-slate-800 rounded-lg text-xs">
              <table className="w-full text-left border-collapse">
                <thead className="bg-slate-100 dark:bg-slate-800 sticky top-0 font-semibold text-slate-700 dark:text-slate-300">
                  <tr>
                    <th className="p-2 border-b border-slate-200 dark:border-slate-700">Code</th>
                    <th className="p-2 border-b border-slate-200 dark:border-slate-700">Name</th>
                    <th className="p-2 border-b border-slate-200 dark:border-slate-700">Category</th>
                    <th className="p-2 border-b border-slate-200 dark:border-slate-700">Qty</th>
                    <th className="p-2 border-b border-slate-200 dark:border-slate-700">Unit Price</th>
                    <th className="p-2 border-b border-slate-200 dark:border-slate-700">Location</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800 font-medium">
                  {parsedData.slice(0, 10).map((row, idx) => (
                    <tr key={idx} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                      <td className="p-2 font-mono text-[11px] text-blue-600 dark:text-blue-400">{row.code}</td>
                      <td className="p-2 font-semibold">{row.name}</td>
                      <td className="p-2">{row.category}</td>
                      <td className="p-2">{row.quantity} {row.unit}</td>
                      <td className="p-2">${row.unitPrice}</td>
                      <td className="p-2">{row.location}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {parsedData.length > 10 && (
                <div className="p-2 text-center text-[10px] text-slate-500 bg-slate-50 dark:bg-slate-800/80 border-t border-slate-200 dark:border-slate-800">
                  ...and {parsedData.length - 10} more rows
                </div>
              )}
            </div>
          </div>
        )}

        {/* Modal Actions */}
        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
          <Button variant="outline" size="sm" onClick={onClose}>
            Cancel
          </Button>
          <Button
            variant="primary"
            size="sm"
            disabled={parsedData.length === 0}
            onClick={handleConfirmImport}
          >
            Confirm Import ({parsedData.length} Items)
          </Button>
        </div>
      </div>
    </Modal>
  );
};
