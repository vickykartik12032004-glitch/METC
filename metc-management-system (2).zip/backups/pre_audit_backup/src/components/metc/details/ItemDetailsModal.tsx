import React, { useState } from 'react';
import { METCItem, ItemDocument } from '../../../types';
import { Modal } from '../../ui/Modal';
import { Button } from '../../ui/Button';
import { StatusBadge } from '../../common/StatusBadge';
import { ItemHistoryTab } from './ItemHistoryTab';
import { formatCurrency, formatDate } from '../../../lib/utils';
import { 
  Package, 
  HardHat, 
  Wrench, 
  Fuel, 
  ShieldCheck, 
  Printer, 
  Edit2, 
  QrCode, 
  Barcode, 
  Building2, 
  Calendar, 
  MapPin, 
  FileText, 
  Upload, 
  Trash2, 
  Download, 
  Clock, 
  User, 
  ShieldAlert, 
  CheckCircle2, 
  X 
} from 'lucide-react';
import { toast } from 'sonner';
import { usePermissions } from '../../../hooks/usePermissions';

interface ItemDetailsModalProps {
  item: METCItem | null;
  isOpen: boolean;
  onClose: () => void;
  onEdit: (item: METCItem) => void;
  onPrintQr: (item: METCItem) => void;
  canEdit?: boolean;
}

export const ItemDetailsModal: React.FC<ItemDetailsModalProps> = ({
  item,
  isOpen,
  onClose,
  onEdit,
  onPrintQr,
  canEdit: propCanEdit,
}) => {
  const { canEdit: permCanEdit } = usePermissions();
  const canEdit = propCanEdit ?? permCanEdit;
  const [activeTab, setActiveTab] = useState<'overview' | 'documents' | 'history'>('overview');
  const [documents, setDocuments] = useState<ItemDocument[]>([
    {
      id: 'doc-1',
      item_id: item?.id || '',
      title: 'Manufacturer User Manual & Specs.pdf',
      file_url: '#',
      file_type: 'application/pdf',
      uploaded_by: 'Store Keeper',
      created_at: '2025-01-15T10:00:00Z',
    },
    {
      id: 'doc-[2]',
      item_id: item?.id || '',
      title: 'Calibration & Safety Certificate 2025.pdf',
      file_url: '#',
      file_type: 'application/pdf',
      uploaded_by: 'Safety Officer',
      created_at: '2025-02-01T14:30:00Z',
    },
  ]);

  if (!item) return null;

  const handleDocumentUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const newDoc: ItemDocument = {
        id: `doc-${Date.now()}`,
        item_id: item.id,
        title: file.name,
        file_url: '#',
        file_type: file.type || 'application/pdf',
        uploaded_by: 'Current User',
        created_at: new Date().toISOString(),
      };
      setDocuments((prev) => [newDoc, ...prev]);
      toast.success(`Attached document ${file.name}`);
    }
  };

  const handleDeleteDocument = (docId: string) => {
    setDocuments((prev) => prev.filter((d) => d.id !== docId));
    toast.success('Document deleted');
  };

  // Warranty Days Remaining
  const getWarrantyInfo = () => {
    if (!item.warrantyExpiry) return null;
    const exp = new Date(item.warrantyExpiry).getTime();
    const now = new Date().getTime();
    const diffDays = Math.ceil((exp - now) / (1000 * 3600 * 24));

    if (diffDays < 0) {
      return <span className="text-xs font-semibold px-2 py-0.5 rounded bg-rose-100 text-rose-800 dark:bg-rose-950/80 dark:text-rose-300">Warranty Expired</span>;
    }
    if (diffDays <= 30) {
      return <span className="text-xs font-semibold px-2 py-0.5 rounded bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300">Expiring in {diffDays} days</span>;
    }
    return <span className="text-xs font-semibold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300">{diffDays} Days Active Warranty</span>;
  };

  // Calibration Days Remaining
  const getCalibrationInfo = () => {
    if (!item.calibrationDue) return null;
    const due = new Date(item.calibrationDue).getTime();
    const now = new Date().getTime();
    const diffDays = Math.ceil((due - now) / (1000 * 3600 * 24));

    if (diffDays < 0) {
      return <span className="text-xs font-semibold px-2 py-0.5 rounded bg-rose-100 text-rose-800 dark:bg-rose-950/80 dark:text-rose-300">Inspection Overdue</span>;
    }
    return <span className="text-xs font-semibold px-2 py-0.5 rounded bg-sky-100 text-sky-800 dark:bg-sky-950/80 dark:text-sky-300">Due in {diffDays} Days ({formatDate(item.calibrationDue)})</span>;
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`Asset Details - ${item.code}`} size="xl">
      <div className="space-y-6 text-slate-900 dark:text-slate-100">
        {/* Top Overview Banner */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl">
          <div className="flex items-center gap-4">
            <div className="w-20 h-20 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 overflow-hidden shrink-0 flex items-center justify-center">
              {item.photoUrl ? (
                <img src={item.photoUrl} alt={item.name} className="w-full h-full object-cover" />
              ) : (
                <Package className="w-8 h-8 text-slate-400" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider">{item.code}</span>
                <StatusBadge status={item.status} />
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white mt-0.5">{item.name}</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                {item.brand || 'Brand Unspecified'} • {item.model || 'Standard Grade'} • Category: <strong className="font-semibold text-slate-700 dark:text-slate-300">{item.category}</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
            <Button
              variant="outline"
              size="sm"
              icon={<QrCode className="w-4 h-4 text-slate-600 dark:text-slate-300" />}
              onClick={() => onPrintQr(item)}
            >
              Print Tag
            </Button>
            {canEdit ? (
              <Button
                variant="primary"
                size="sm"
                icon={<Edit2 className="w-4 h-4" />}
                onClick={() => {
                  onClose();
                  onEdit(item);
                }}
              >
                Edit Item
              </Button>
            ) : (
              <span className="px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-slate-800 text-slate-500 border border-slate-200 dark:border-slate-700">
                Viewer Mode
              </span>
            )}
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeTab === 'overview'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            General & Stock Specs
          </button>
          <button
            onClick={() => setActiveTab('documents')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
              activeTab === 'documents'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Documents ({documents.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
              activeTab === 'history'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>Audit History & Movements</span>
          </button>
        </div>

        {/* Tab Content */}
        {activeTab === 'overview' && (
          <div className="space-y-5">
            {/* Stock Level Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl">
                <span className="text-[10px] font-medium uppercase tracking-wider text-slate-500">Current Stock</span>
                <p className="text-lg font-bold text-slate-900 dark:text-white mt-1">
                  {item.quantity} <span className="text-xs font-normal text-slate-500">{item.unit}</span>
                </p>
              </div>
              <div className="p-3 bg-emerald-50/60 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/80 rounded-xl">
                <span className="text-[10px] font-medium uppercase tracking-wider text-emerald-700 dark:text-emerald-400">Available Stock</span>
                <p className="text-lg font-bold text-emerald-700 dark:text-emerald-400 mt-1">
                  {item.availableQuantity} <span className="text-xs font-normal text-emerald-600/80">{item.unit}</span>
                </p>
              </div>
              <div className="p-3 bg-amber-50/60 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/80 rounded-xl">
                <span className="text-[10px] font-medium uppercase tracking-wider text-amber-700 dark:text-amber-400">Min Alert Threshold</span>
                <p className="text-lg font-bold text-amber-700 dark:text-amber-400 mt-1">
                  {item.minQuantityThreshold ?? item.minimumStock ?? 10} <span className="text-xs font-normal text-amber-600/80">{item.unit}</span>
                </p>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl">
                <span className="text-[10px] font-medium uppercase tracking-wider text-slate-500">Unit Valuation</span>
                <p className="text-lg font-bold text-slate-900 dark:text-white mt-1">
                  {formatCurrency(item.unitPrice || item.purchaseCost)}
                </p>
              </div>
            </div>

            {/* Specifications Matrix */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              {/* Asset Technical Specifications */}
              <div className="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-2.5">
                <h4 className="font-bold uppercase tracking-wider text-[11px] text-slate-500 border-b border-slate-200 dark:border-slate-800 pb-1.5">
                  Technical Specifications
                </h4>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Brand / Manufacturer:</span>
                    <strong className="font-semibold">{item.brand || 'N/A'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Model / Grade:</span>
                    <strong className="font-semibold">{item.model || 'N/A'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Serial / Batch No:</span>
                    <strong className="font-mono font-semibold">{item.serialNumber || 'N/A'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Asset Tag Tag:</span>
                    <strong className="font-mono font-semibold">{item.assetNumber || 'N/A'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Barcode Identifier:</span>
                    <strong className="font-mono text-blue-600 dark:text-blue-400">{item.barcode || 'N/A'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">QR Code Tag:</span>
                    <strong className="font-mono text-blue-600 dark:text-blue-400">{item.qrCode || 'N/A'}</strong>
                  </div>
                </div>
              </div>

              {/* Storage & Procurement Details */}
              <div className="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-2.5">
                <h4 className="font-bold uppercase tracking-wider text-[11px] text-slate-500 border-b border-slate-200 dark:border-slate-800 pb-1.5">
                  Location & Supplier Records
                </h4>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Storage Location:</span>
                    <strong className="font-semibold">{item.location}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Rack / Locker:</span>
                    <strong className="font-semibold">{item.rackNumber || 'Standard Pallet'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Supplier Name:</span>
                    <strong className="font-semibold">{item.supplier || 'Main Contracting Depot'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Purchase Date:</span>
                    <strong className="font-semibold">{item.purchaseDate ? formatDate(item.purchaseDate) : 'N/A'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Warranty Status:</span>
                    <div>{getWarrantyInfo() || <span className="text-slate-400">N/A</span>}</div>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Calibration Due:</span>
                    <div>{getCalibrationInfo() || <span className="text-slate-400">N/A</span>}</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Description & Notes */}
            {item.description && (
              <div className="p-3.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs space-y-1">
                <span className="font-bold text-slate-500 uppercase tracking-wider text-[10px]">Description & Remarks</span>
                <p className="text-slate-700 dark:text-slate-300 leading-relaxed">{item.description}</p>
              </div>
            )}
          </div>
        )}

        {/* Documents Tab */}
        {activeTab === 'documents' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-800">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                Asset Attached Documents & Certificates
              </span>
              {canEdit && (
                <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 text-white text-xs font-semibold cursor-pointer hover:bg-blue-700 transition-colors">
                  <Upload className="w-3.5 h-3.5" />
                  <span>Attach New Document</span>
                  <input type="file" onChange={handleDocumentUpload} className="hidden" />
                </label>
              )}
            </div>

            {documents.length === 0 ? (
              <p className="text-xs text-slate-500 py-6 text-center">No documents uploaded for this asset yet.</p>
            ) : (
              <div className="space-y-2">
                {documents.map((doc) => (
                  <div
                    key={doc.id}
                    className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs"
                  >
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400">
                        <FileText className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="font-bold text-slate-900 dark:text-white">{doc.title}</p>
                        <p className="text-[10px] text-slate-500">
                          Uploaded by {doc.uploaded_by} on {formatDate(doc.created_at)}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <a
                        href={doc.file_url}
                        target="_blank"
                        rel="noreferrer"
                        className="p-1.5 rounded-lg text-slate-500 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950/50"
                        title="Download Document"
                      >
                        <Download className="w-4 h-4" />
                      </a>
                      {canEdit && (
                        <button
                          onClick={() => handleDeleteDocument(doc.id)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/50"
                          title="Delete Document"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* History Tab */}
        {activeTab === 'history' && <ItemHistoryTab item={item} />}

        {/* Close Action */}
        <div className="flex items-center justify-end pt-3 border-t border-slate-200 dark:border-slate-800">
          <Button variant="outline" size="sm" onClick={onClose}>
            Close Window
          </Button>
        </div>
      </div>
    </Modal>
  );
};
