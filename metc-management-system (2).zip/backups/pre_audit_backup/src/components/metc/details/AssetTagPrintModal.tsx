import React, { useRef } from 'react';
import { BaseAsset } from '../../../types';
import { Modal } from '../../ui/Modal';
import { Button } from '../../ui/Button';
import { Printer, Download, QrCode as QrIcon, Barcode as BarcodeIcon, ShieldCheck } from 'lucide-react';

interface AssetTagPrintModalProps {
  item: BaseAsset | null;
  isOpen: boolean;
  onClose: () => void;
}

export const AssetTagPrintModal: React.FC<AssetTagPrintModalProps> = ({ item, isOpen, onClose }) => {
  const printRef = useRef<HTMLDivElement>(null);

  if (!item) return null;

  const handlePrint = () => {
    const printContent = printRef.current;
    if (!printContent) return;

    const windowUrl = 'about:blank';
    const uniqueName = 'Asset_Tag_Print';
    const printWindow = window.open(windowUrl, uniqueName, 'left=100,top=100,width=800,height=600');
    if (!printWindow) return;

    printWindow.document.write(`
      <html>
        <head>
          <title>Asset Tag - ${item.code}</title>
          <style>
            body { font-family: sans-serif; padding: 20px; text-align: center; background: #fff; }
            .tag-card { border: 2px solid #000; padding: 16px; border-radius: 8px; width: 340px; margin: 0 auto; box-shadow: none; }
            .header { font-size: 12px; font-weight: bold; text-transform: uppercase; border-b: 1px solid #000; padding-bottom: 6px; margin-bottom: 8px; }
            .title { font-size: 14px; font-weight: bold; margin-bottom: 4px; }
            .code { font-family: monospace; font-size: 16px; font-weight: bold; margin-bottom: 12px; }
            .qr-placeholder { background: #f0f0f0; padding: 10px; display: inline-block; border: 1px solid #ccc; margin-bottom: 8px; }
            .barcode-lines { font-family: monospace; letter-spacing: 4px; font-size: 18px; font-weight: bold; margin-top: 6px; }
            .footer { font-size: 9px; color: #555; border-t: 1px solid #ddd; padding-top: 6px; margin-top: 8px; }
          </style>
        </head>
        <body>
          ${printContent.innerHTML}
          <script>
            window.onload = function() { window.print(); window.close(); }
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  // Generate SVG QR Code pattern deterministically
  const renderSvgQr = (code: string) => {
    return (
      <svg className="w-28 h-28 mx-auto" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="100" height="100" fill="white" />
        {/* Finder pattern 1 (top-left) */}
        <rect x="5" y="5" width="25" height="25" fill="black" />
        <rect x="9" y="9" width="17" height="17" fill="white" />
        <rect x="13" y="13" width="9" height="9" fill="black" />

        {/* Finder pattern 2 (top-right) */}
        <rect x="70" y="5" width="25" height="25" fill="black" />
        <rect x="74" y="9" width="17" height="17" fill="white" />
        <rect x="78" y="13" width="9" height="9" fill="black" />

        {/* Finder pattern 3 (bottom-left) */}
        <rect x="5" y="70" width="25" height="25" fill="black" />
        <rect x="9" y="74" width="17" height="17" fill="white" />
        <rect x="13" y="78" width="9" height="9" fill="black" />

        {/* Data dots */}
        <rect x="35" y="10" width="5" height="5" fill="black" />
        <rect x="45" y="10" width="10" height="5" fill="black" />
        <rect x="60" y="10" width="5" height="5" fill="black" />

        <rect x="35" y="20" width="5" height="10" fill="black" />
        <rect x="50" y="20" width="5" height="5" fill="black" />
        <rect x="60" y="25" width="5" height="5" fill="black" />

        <rect x="10" y="35" width="10" height="5" fill="black" />
        <rect x="25" y="35" width="5" height="10" fill="black" />
        <rect x="35" y="35" width="15" height="5" fill="black" />
        <rect x="55" y="35" width="10" height="10" fill="black" />
        <rect x="70" y="35" width="20" height="5" fill="black" />

        <rect x="5" y="50" width="15" height="5" fill="black" />
        <rect x="25" y="50" width="10" height="5" fill="black" />
        <rect x="40" y="50" width="10" height="10" fill="black" />
        <rect x="55" y="50" width="5" height="5" fill="black" />
        <rect x="65" y="50" width="15" height="5" fill="black" />
        <rect x="85" y="50" width="10" height="5" fill="black" />

        <rect x="35" y="65" width="10" height="10" fill="black" />
        <rect x="50" y="65" width="15" height="5" fill="black" />
        <rect x="70" y="65" width="25" height="5" fill="black" />

        <rect x="35" y="80" width="5" height="15" fill="black" />
        <rect x="45" y="80" width="10" height="5" fill="black" />
        <rect x="60" y="80" width="10" height="15" fill="black" />
        <rect x="75" y="80" width="20" height="10" fill="black" />
      </svg>
    );
  };

  // Render Barcode SVG lines
  const renderSvgBarcode = (val: string) => {
    return (
      <div className="text-center font-mono py-1">
        <div className="flex justify-center items-center gap-[2px] h-10 bg-white p-1">
          {Array.from({ length: 32 }).map((_, i) => (
            <div
              key={i}
              className={`h-full ${i % 3 === 0 ? 'w-1 bg-black' : i % 2 === 0 ? 'w-0.5 bg-black' : 'w-0.5 bg-transparent'}`}
            />
          ))}
        </div>
        <div className="text-xs font-bold font-mono tracking-widest text-slate-900 mt-0.5">
          *{item.barcode || item.code}*
        </div>
      </div>
    );
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Print Asset QR & Barcode Tag" size="md">
      <div className="space-y-6 text-slate-900 dark:text-slate-100">
        {/* Tag Preview Card */}
        <div className="p-4 bg-slate-100 dark:bg-slate-950 rounded-2xl flex justify-center">
          <div
            ref={printRef}
            className="tag-card bg-white text-slate-900 border-2 border-slate-900 rounded-xl p-5 w-[320px] shadow-lg space-y-3"
          >
            {/* Header */}
            <div className="header flex items-center justify-between border-b-2 border-slate-900 pb-2">
              <div className="flex items-center gap-1.5 font-bold text-xs uppercase tracking-wider">
                <ShieldCheck className="w-4 h-4 text-blue-600" />
                <span>MOUNTEC ASSET TAG</span>
              </div>
              <span className="text-[10px] font-mono font-semibold bg-slate-100 px-1.5 py-0.5 rounded border border-slate-300">
                {item.category}
              </span>
            </div>

            {/* Asset Title & ID */}
            <div className="text-center">
              <p className="title text-sm font-extrabold text-slate-900 leading-tight">{item.name}</p>
              <p className="code text-base font-mono font-bold text-blue-700 tracking-wider mt-1">{item.code}</p>
            </div>

            {/* QR Code Container */}
            <div className="qr-placeholder text-center bg-white p-2 border border-slate-200 rounded-lg">
              {renderSvgQr(item.code)}
              <p className="text-[9px] font-mono text-slate-500 mt-1">SCAN FOR SITE VERIFICATION</p>
            </div>

            {/* Barcode Section */}
            {renderSvgBarcode(item.code)}

            {/* Footer Metadata */}
            <div className="footer border-t border-slate-300 pt-2 flex items-center justify-between text-[10px] text-slate-600">
              <span>Location: <strong>{item.location}</strong></span>
              <span>Site ID: <strong>MOUNTEC-TOWER-A</strong></span>
            </div>
          </div>
        </div>

        {/* Modal Actions */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-200 dark:border-slate-800">
          <p className="text-xs text-slate-500">Tag size: 3.5" x 2" Standard Thermal Label</p>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={onClose}>
              Close
            </Button>
            <Button
              variant="primary"
              size="sm"
              icon={<Printer className="w-4 h-4" />}
              onClick={handlePrint}
            >
              Print Barcode Sticker
            </Button>
          </div>
        </div>
      </div>
    </Modal>
  );
};
