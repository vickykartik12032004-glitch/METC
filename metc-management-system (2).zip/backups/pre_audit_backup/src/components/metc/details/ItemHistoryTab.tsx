import React from 'react';
import { METCItem } from '../../../types';
import { formatDate } from '../../../lib/utils';
import { useTransactionStore } from '../../../store/useTransactionStore';
import { 
  ArrowUpRight, 
  ArrowDownLeft, 
  ArrowRightLeft, 
  Hammer, 
  ShieldAlert, 
  Clock, 
  User, 
  MapPin 
} from 'lucide-react';

interface ItemHistoryTabProps {
  item: METCItem;
}

export const ItemHistoryTab: React.FC<ItemHistoryTabProps> = ({ item }) => {
  const { issues, returns, transfers, repairs, lostItems } = useTransactionStore();

  // Find real transactions for this item
  const itemIssues = issues.filter(i => i.itemId === item.id || i.itemName === item.name);
  const itemReturns = returns.filter(r => r.itemId === item.id || r.itemName === item.name);
  const itemTransfers = transfers.filter(t => t.itemId === item.id || t.itemName === item.name);
  const itemRepairs = repairs.filter(r => r.itemId === item.id || r.itemName === item.name);
  const itemLost = lostItems.filter(l => l.itemId === item.id || l.itemName === item.name);

  const realLogs = [
    ...itemIssues.map(i => ({
      id: i.id,
      action: 'Issued to Worker',
      type: 'issue',
      user: i.issuedBy || 'Store Keeper',
      targetWorker: i.workerName,
      date: i.issueDate ? formatDate(i.issueDate) : 'N/A',
      quantity: i.quantity,
      location: i.projectSite || item.location,
      notes: i.remarks || 'Issued item',
    })),
    ...itemReturns.map(r => ({
      id: r.id,
      action: 'Returned to Store',
      type: 'return',
      user: r.receivedBy || 'Store Keeper',
      targetWorker: r.workerName,
      date: r.returnDate ? formatDate(r.returnDate) : 'N/A',
      quantity: r.quantityReturned,
      location: item.location,
      notes: r.notes || `Returned in ${r.conditionOnReturn} condition`,
    })),
    ...itemTransfers.map(t => ({
      id: t.id,
      action: 'Transferred Site Location',
      type: 'transfer',
      user: t.initiatedBy || 'Site Admin',
      targetWorker: 'N/A',
      date: t.transferDate ? formatDate(t.transferDate) : 'N/A',
      quantity: t.quantity,
      location: `From ${t.fromLocation} to ${t.toLocation}`,
      notes: t.notes || 'Inter-site transfer',
    })),
    ...itemRepairs.map(r => ({
      id: r.id,
      action: 'Sent for Repair',
      type: 'repair',
      user: r.handledBy || 'Maintenance Lead',
      targetWorker: r.repairVendor || 'Vendor',
      date: r.sentDate ? formatDate(r.sentDate) : 'N/A',
      quantity: 1,
      location: r.repairVendor || 'Repair Workshop',
      notes: r.issueDescription || 'Maintenance repair',
    })),
    ...itemLost.map(l => ({
      id: l.id,
      action: 'Reported Lost/Damaged',
      type: 'lost',
      user: l.reportedBy || 'Site Inspector',
      targetWorker: l.workerName || 'N/A',
      date: l.reportedDate ? formatDate(l.reportedDate) : 'N/A',
      quantity: l.quantityLost,
      location: l.location || item.location,
      notes: l.incidentDetails || 'Lost item incident',
    })),
  ];

  // Base creation log
  const creationLog = {
    id: 'created-' + item.id,
    action: 'Initial Asset Registration',
    type: 'created',
    user: 'System Admin',
    targetWorker: 'N/A',
    date: item.createdAt ? formatDate(item.createdAt) : formatDate(new Date().toISOString()),
    quantity: item.quantity,
    location: item.location || 'Store Warehouse',
    notes: `Registered asset code ${item.code}`,
  };

  const historyLogs = [creationLog, ...realLogs];

  const getLogIcon = (type: string) => {
    switch (type) {
      case 'issue':
        return <ArrowUpRight className="w-4 h-4 text-emerald-500" />;
      case 'return':
        return <ArrowDownLeft className="w-4 h-4 text-sky-500" />;
      case 'transfer':
        return <ArrowRightLeft className="w-4 h-4 text-purple-500" />;
      case 'repair':
        return <Hammer className="w-4 h-4 text-amber-500" />;
      case 'lost':
        return <ShieldAlert className="w-4 h-4 text-rose-500" />;
      default:
        return <Clock className="w-4 h-4 text-blue-500" />;
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-800">
        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
          Movement & Audit History Log ({historyLogs.length})
        </h4>
        <span className="text-[11px] font-mono text-slate-500">Asset Code: {item.code}</span>
      </div>

      <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200 dark:before:bg-slate-800">
        {historyLogs.map((log) => (
          <div key={log.id} className="relative group">
            {/* Timeline Dot */}
            <div className="absolute -left-6 top-1 w-5 h-5 rounded-full bg-white dark:bg-slate-900 border-2 border-slate-300 dark:border-slate-700 flex items-center justify-center shadow-xs">
              {getLogIcon(log.type)}
            </div>

            <div className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 rounded-xl p-3.5 space-y-1.5 transition-all hover:border-blue-400">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900 dark:text-slate-100">{log.action}</span>
                <span className="text-[11px] text-slate-500 font-mono">{log.date}</span>
              </div>

              <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-600 dark:text-slate-400">
                <span className="flex items-center gap-1">
                  <User className="w-3 h-3 text-slate-400" />
                  {log.user}
                </span>
                {log.targetWorker && log.targetWorker !== 'N/A' && (
                  <span className="font-semibold text-blue-600 dark:text-blue-400">
                    Recipient: {log.targetWorker}
                  </span>
                )}
                <span className="flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-slate-400" />
                  {log.location}
                </span>
              </div>

              {log.notes && (
                <p className="text-xs text-slate-600 dark:text-slate-300 bg-white dark:bg-slate-900/60 p-2 rounded-lg border border-slate-200/60 dark:border-slate-800/80 mt-1">
                  "{log.notes}"
                </p>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

