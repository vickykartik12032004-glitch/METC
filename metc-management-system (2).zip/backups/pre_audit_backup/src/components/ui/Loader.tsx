import React from 'react';
import { cn } from '../../lib/utils';

export interface LoaderProps {
  size?: 'sm' | 'md' | 'lg';
  label?: string;
  className?: string;
  fullScreen?: boolean;
}

export const Loader: React.FC<LoaderProps> = ({
  size = 'md',
  label,
  className,
  fullScreen = false,
}) => {
  const sizes = {
    sm: 'w-5 h-5 border-2',
    md: 'w-8 h-8 border-3',
    lg: 'w-12 h-12 border-4',
  };

  const content = (
    <div className={cn('flex flex-col items-center justify-center p-4 gap-3', className)}>
      <div
        className={cn(
          'rounded-full border-blue-600 border-t-transparent animate-spin',
          sizes[size]
        )}
      />
      {label && <p className="text-xs font-medium text-slate-500 dark:text-slate-400 animate-pulse">{label}</p>}
    </div>
  );

  if (fullScreen) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-xs">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-2xl shadow-xl flex flex-col items-center">
          {content}
        </div>
      </div>
    );
  }

  return content;
};
