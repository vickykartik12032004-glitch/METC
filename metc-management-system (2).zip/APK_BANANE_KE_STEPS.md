# Is Web App ko APK me Convert Karne Ke Steps (VS Code se)

## Zaroori Cheezein (pehle install karein)
1. **Node.js** (v18 ya usse upar) — https://nodejs.org
2. **Android Studio** — https://developer.android.com/studio
3. **VS Code** — https://code.visualstudio.com

---

## Step 1: Project VS Code me kholein
- Yeh zip file extract karein
- VS Code kholein → File > Open Folder → extract ki hui folder select karein
- VS Code me Terminal kholein: `Terminal > New Terminal`

## Step 2: Dependencies install karein
```bash
npm install
```

## Step 3: .env file banayein
`.env.example` ko copy karke `.env` naam se save karein, aur apni Supabase details bharein:
```
VITE_SUPABASE_URL=your-supabase-url
VITE_SUPABASE_ANON_KEY=your-supabase-anon-key
```
(Ye aapko apne Supabase project dashboard se milega: Settings > API)

## Step 4: Web app build karein
```bash
npm run build
```
Isse `dist` folder banega — yehi APK ke andar jaayega.

## Step 5: Capacitor install karein
```bash
npm install @capacitor/core @capacitor/android
npm install -D @capacitor/cli
```
(`capacitor.config.ts` file already project me daal di gayi hai — appId aur appName aap chahein to change kar sakte hain)

## Step 6: Android platform add karein
```bash
npx cap add android
```
Isse `android` folder banega — ye poora Android Studio project hai.

## Step 7: Build ko sync karein
Jab bhi aap website me koi change karke `npm run build` chalayein, uske baad ye command chalayein:
```bash
npx cap sync
```

## Step 8: Android Studio me kholein
```bash
npx cap open android
```
Ye seedha Android Studio khol dega with aapka project.

## Step 9: APK banayein
Android Studio ke upar menu me:
`Build` > `Build Bundle(s) / APK(s)` > `Build APK(s)`

Kuch minute wait karein. APK yahan milega:
```
android/app/build/outputs/apk/debug/app-debug.apk
```

Is file ko phone me transfer karke install kar lein (phone me "unknown sources se install" allow karna padega).

---

## Important Notes
- Ye **debug APK** hai — testing/personal use ke liye theek hai
- Play Store pe daalne ke liye "signed release APK" banana padta hai (Android Studio me hi option milta hai: Build > Generate Signed Bundle/APK)
- Agar app me Supabase login/data features hain, .env sahi se fill karna zaroori hai warna wo features kaam nahi karenge
- Agar `GEMINI_API_KEY` wali AI features use ho rahi hain app me, unhe bhi properly configure karna hoga (ye Google AI Studio ka env variable hai, isliye production build me isko apne backend/proxy se handle karna better rahega — client-side me API key expose mat karein)
